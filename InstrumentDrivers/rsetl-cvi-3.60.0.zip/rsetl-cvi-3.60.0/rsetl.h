/****************************************************************************
 *
 *  Rohde & Schwarz ETL instrument driver include file
 *
 ****************************************************************************/

#ifndef RSETL_HEADER
#define RSETL_HEADER

#include "rscore.h"
#include "rsetl_attributes.h"
#include "rsetl_utility.h"

#include <float.h>
#include <math.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#if defined(__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif

/*****************************************************************************
 *- Useful Macros & Constants -----------------------------------------------*
 *****************************************************************************/

#define RSETL_SIMULATION_ID_QUERY      "Rohde&Schwarz,ETL,123456/789,1.23"  /* Default definition of ID Query Response for simulation */
#define RSETL_VALID_ID_RESPONSE_STRING "Rohde&Schwarz"      /* Valid response for identification query */
#define RSETL_SIMULATION_OPT_QUERY     "K0"      /* Simulated response for *OPT? command */

#define RSETL_OPC_TIMEOUT              10000L   /* Maximum time to wait for OPC in milliseconds */

/****************************************************************************
 *----------------- Instrument Driver Revision Information -----------------*
 ****************************************************************************/

/* Class Driver Identification */

#define RSETL_CLASS_DRIVER_DESCRIPTION           ""
#define RSETL_CLASS_DRIVER_PREFIX                ""
#define RSETL_CLASS_DRIVER_VENDOR                ""
#define RSETL_CLASS_DRIVER_REVISION              ""
#define RSETL_CLASS_SPEC_MAJOR_VERSION           1L    /* Class specification major version */
#define RSETL_CLASS_SPEC_MINOR_VERSION           0L    /* Class specification minor version */

/* Driver Identification */

#define RSETL_SPECIFIC_DRIVER_DESCRIPTION        ""
#define RSETL_SPECIFIC_DRIVER_PREFIX             "RSETL"
#define RSETL_SPECIFIC_DRIVER_LOCATOR            ""
#define RSETL_SPECIFIC_DRIVER_VENDOR             ""
#define RSETL_MAJOR_VERSION                      3L    /* Instrument driver major version          */
#define RSETL_MINOR_VERSION                      60   /* Instrument driver minor version          */
#define RSETL_MINOR_MINOR_VERSION                0L    /* Instrument driver minor minor version    */

/* Driver Capabilities */

#define RSETL_SUPPORTED_INSTRUMENT_MODELS        ""    /* Instrument driver supported model(s)     */
#define RSETL_GROUP_CAPABILITIES                 ""
#define RSETL_FUNCTION_CAPABILITIES              ""

/****************************************************************************
 *---------------------------- Attribute Defines ---------------------------*
 ****************************************************************************/

    /*- Inherent Instrument Specific Attributes ----------------------------*/

        /* User Options */

#define RSETL_ATTR_RANGE_CHECK                                           RS_ATTR_RANGE_CHECK                                     /* ViBoolean */
#define RSETL_ATTR_QUERY_INSTRUMENT_STATUS                               RS_ATTR_QUERY_INSTRUMENT_STATUS                         /* ViBoolean */
#define RSETL_ATTR_CACHE                                                 RS_ATTR_CACHE                                           /* ViBoolean */
#define RSETL_ATTR_SIMULATE                                              RS_ATTR_SIMULATE                                        /* ViBoolean */
#define RSETL_ATTR_RECORD_COERCIONS                                      RS_ATTR_RECORD_COERCIONS                                /* ViBoolean */
#define RSETL_ATTR_INTERCHANGE_CHECK                                     RS_ATTR_INTERCHANGE_CHECK                               /* ViBoolean */
#define RSETL_ATTR_SPY                                                   RS_ATTR_SPY                                             /* ViBoolean */
#define RSETL_ATTR_USE_SPECIFIC_SIMULATION                               RS_ATTR_USE_SPECIFIC_SIMULATION                         /* ViBoolean */

        /* Class Driver Identification */

#define RSETL_ATTR_CLASS_DRIVER_DESCRIPTION                              RS_ATTR_CLASS_DRIVER_DESCRIPTION                        /* ViString, read-only */
#define RSETL_ATTR_CLASS_DRIVER_PREFIX                                   RS_ATTR_CLASS_DRIVER_PREFIX                             /* ViString, read-only */
#define RSETL_ATTR_CLASS_DRIVER_VENDOR                                   RS_ATTR_CLASS_DRIVER_VENDOR                             /* ViString, read-only */
#define RSETL_ATTR_CLASS_DRIVER_REVISION                                 RS_ATTR_CLASS_DRIVER_REVISION                           /* ViString, read-only */
#define RSETL_ATTR_CLASS_DRIVER_CLASS_SPEC_MAJOR_VERSION                 RS_ATTR_CLASS_DRIVER_CLASS_SPEC_MAJOR_VERSION           /* ViInt32,  read-only */
#define RSETL_ATTR_CLASS_DRIVER_CLASS_SPEC_MINOR_VERSION                 RS_ATTR_CLASS_DRIVER_CLASS_SPEC_MINOR_VERSION           /* ViInt32,  read-only */

        /* Driver Identification */

#define RSETL_ATTR_SPECIFIC_DRIVER_DESCRIPTION                           RS_ATTR_SPECIFIC_DRIVER_DESCRIPTION                     /* ViString, read-only */
#define RSETL_ATTR_SPECIFIC_DRIVER_PREFIX                                RS_ATTR_SPECIFIC_DRIVER_PREFIX                          /* ViString, read-only */
#define RSETL_ATTR_SPECIFIC_DRIVER_LOCATOR                               RS_ATTR_SPECIFIC_DRIVER_LOCATOR                         /* ViString, read-only */
#define RSETL_ATTR_SPECIFIC_DRIVER_VENDOR                                RS_ATTR_SPECIFIC_DRIVER_VENDOR                          /* ViString, read-only */
#define RSETL_ATTR_SPECIFIC_DRIVER_REVISION                              RS_ATTR_SPECIFIC_DRIVER_REVISION                        /* ViString, read-only */
#define RSETL_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MAJOR_VERSION              RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MAJOR_VERSION        /* ViInt32,  read-only */
#define RSETL_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MINOR_VERSION              RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MINOR_VERSION        /* ViInt32,  read-only */

        /* Driver Capabilities */

#define RSETL_ATTR_SUPPORTED_INSTRUMENT_MODELS                           RS_ATTR_SUPPORTED_INSTRUMENT_MODELS                     /* ViString, read-only */
#define RSETL_ATTR_GROUP_CAPABILITIES                                    RS_ATTR_GROUP_CAPABILITIES                              /* ViString, read-only */
#define RSETL_ATTR_FUNCTION_CAPABILITIES                                 RS_ATTR_FUNCTION_CAPABILITIES                           /* ViString, read-only */
#define RSETL_ATTR_CHANNEL_COUNT                                         RS_ATTR_CHANNEL_COUNT                                   /* ViInt32,  read-only */

        /* Driver Setup */

#define RSETL_ATTR_DRIVER_SETUP                                          RS_ATTR_DRIVER_SETUP                                    /* ViString            */

        /* Instrument Identification */

#define RSETL_ATTR_INSTRUMENT_MANUFACTURER                               RS_ATTR_INSTRUMENT_MANUFACTURER                         /* ViString, read-only */
#define RSETL_ATTR_INSTRUMENT_MODEL                                      RS_ATTR_INSTRUMENT_MODEL                                /* ViString, read-only */
#define RSETL_ATTR_INSTRUMENT_FIRMWARE_REVISION                          RS_ATTR_INSTRUMENT_FIRMWARE_REVISION                    /* ViString, read-only */

        /* Advanced Session Information */

#define RSETL_ATTR_IO_RESOURCE_DESCRIPTOR                                RS_ATTR_IO_RESOURCE_DESCRIPTOR                          /* ViString, read-only */
#define RSETL_ATTR_LOGICAL_NAME                                          RS_ATTR_LOGICAL_NAME                                    /* ViString, read-only */

    /*- Instrument-Specific Attributes -------------------------------------*/

//#define RSETL_ATTR_ID_QUERY_RESPONSE                                     (RS_SPECIFIC_PUBLIC_ATTR_BASE + 1L)                     /* ViString (Read Only)              */

/* BEGIN GENERATE */
#define RSETL_ATTR_AMPLITUDE_UNITS                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86016
#define RSETL_ATTR_INSTR_MODE                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86017
#define RSETL_ATTR_ATTENUATION                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86018
#define RSETL_ATTR_ATTENUATION_AUTO                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86019
#define RSETL_ATTR_FREQUENCY_START                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86020
#define RSETL_ATTR_FREQUENCY_STOP                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86021
#define RSETL_ATTR_FREQUENCY_OFFSET                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86022
#define RSETL_ATTR_FREQUENCY_CENTER                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86023
#define RSETL_ATTR_FREQUENCY_CENTER_STEP                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86024
#define RSETL_ATTR_FREQUENCY_STEP_AUTO                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86025
#define RSETL_ATTR_FREQUENCY_CENTER_LINK                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86026
#define RSETL_ATTR_FREQUENCY_CENTER_LINK_FACTOR                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86027
#define RSETL_ATTR_FREQUENCY_SPAN                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86028
#define RSETL_ATTR_FREQUENCY_SPAN_FULL                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86029
#define RSETL_ATTR_FREQUENCY_MODE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86030
#define RSETL_ATTR_INPUT_IMPEDANCE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86031
#define RSETL_ATTR_INPUT_IQ_STATE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86032
#define RSETL_ATTR_NUMBER_OF_SWEEPS                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86033
#define RSETL_ATTR_REFERENCE_LEVEL                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86034
#define RSETL_ATTR_REFERENCE_LEVEL_OFFSET                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86035
#define RSETL_ATTR_RESOLUTION_BANDWIDTH                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86036
#define RSETL_ATTR_RESOLUTION_BANDWIDTH_AUTO                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86037
#define RSETL_ATTR_RESOLUTION_BANDWIDTH_RATIO                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86038
#define RSETL_ATTR_SWEEP_MODE_CONTINUOUS                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86039
#define RSETL_ATTR_SWEEP_TIME                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86040
#define RSETL_ATTR_SWEEP_TIME_AUTO                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86041
#define RSETL_ATTR_SWEEP_POINTS                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86042
#define RSETL_ATTR_SWEEP_COUNT_CURRENT                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86043
#define RSETL_ATTR_VERTICAL_SCALE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86044
#define RSETL_ATTR_VIDEO_BANDWIDTH                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86045
#define RSETL_ATTR_VIDEO_BANDWIDTH_AUTO                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86046
#define RSETL_ATTR_VIDEO_BANDWIDTH_RATIO                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86047
#define RSETL_ATTR_MEAS_ABORT                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86048
#define RSETL_ATTR_INIT                                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86049
#define RSETL_ATTR_INIT_CONT                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86050
#define RSETL_ATTR_INIT_SW_TRIGGER                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86051
#define RSETL_ATTR_INIT_CONMEAS                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86052
#define RSETL_ATTR_AVG_STATE                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86053
#define RSETL_ATTR_AVG_TYPE                                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86054
#define RSETL_ATTR_AVG_COUNT                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86055
#define RSETL_ATTR_AVG_COUNT_AUTO                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86056
#define RSETL_ATTR_RESOLUTION_BANDWIDTH_FILTER_TYPE                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86057
#define RSETL_ATTR_VIDEO_BANDWIDTH_TYPE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86058
#define RSETL_ATTR_TRACE_STATE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86059
#define RSETL_ATTR_TRACE_RESET_BEHAVIOR                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86060
#define RSETL_ATTR_TRACE_TYPE                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86061
#define RSETL_ATTR_TRACE_MATH_STATE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86062
#define RSETL_ATTR_TRACE_MATH_POSITION                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86063
#define RSETL_ATTR_DETECTOR_TYPE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86064
#define RSETL_ATTR_DETECTOR_TYPE_AUTO                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86065
#define RSETL_ATTR_CALIBRATION_CHECK                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86066
#define RSETL_ATTR_CALIBRATION                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86067
#define RSETL_ATTR_CALIBRATION_ABORT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86068
#define RSETL_ATTR_CALIBRATION_RESULT_QUERY                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86069
#define RSETL_ATTR_CALIBRATION_STATE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86070
#define RSETL_ATTR_INP_UPORT_STATE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86071
#define RSETL_ATTR_INP_UPORT_VALUE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86072
#define RSETL_ATTR_OUT_UPORT_VALUE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86073
#define RSETL_ATTR_DISP_REF_VALUE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86074
#define RSETL_ATTR_DISP_COUP_REF_LEV                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86075
#define RSETL_ATTR_DISP_REF_POSITION                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86076
#define RSETL_ATTR_DISP_FREQ_STATE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86077
#define RSETL_ATTR_DISP_TIME_STATE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86078
#define RSETL_ATTR_DISP_LOGO                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86079
#define RSETL_ATTR_DISP_COMMENT_STATE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86080
#define RSETL_ATTR_DISP_COMMENT                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86081
#define RSETL_ATTR_DISP_PWR_SAVE_STATE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86082
#define RSETL_ATTR_DISP_PWR_SAVE_HOLDOFF                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86083
#define RSETL_ATTR_DISP_WINDOW_SIZE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86084
#define RSETL_ATTR_DISP_COL_PRESET                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86085
#define RSETL_ATTR_DISP_COL_PREDEFINED                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86086
#define RSETL_ATTR_DISP_LOG_RANGE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86087
#define RSETL_ATTR_DISP_AMPLITUDE_GRID_MODE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86088
#define RSETL_ATTR_DISP_SINGLE_SWEEP                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86089
#define RSETL_ATTR_DISP_UPDATE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86090
#define RSETL_ATTR_DISP_FP_KEYS                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86091
#define RSETL_ATTR_UNIT_POWER                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86092
#define RSETL_ATTR_DISP_CHANNEL_IMPULSE_RESPONSE                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86093
#define RSETL_ATTR_DISP_MER_VS_FREQ                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86094
#define RSETL_ATTR_DISPL_SET_TO_FOREGROUND                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86095
#define RSETL_ATTR_DISP_MER_PHASE_REFERENCE_POSITION                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328068
#define RSETL_ATTR_DISP_MER_PHASE_REFERENCE_DEVIATION                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328069
#define RSETL_ATTR_DISP_MER_PHASE_DEVIATION_SCALING                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328070
#define RSETL_ATTR_DISP_MER_PHASE_DEVIATION_RANGE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328071
#define RSETL_ATTR_DISP_GPS_POSITION                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328072
#define RSETL_ATTR_DISP_PEAK_LIST                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328073
#define RSETL_ATTR_DISP_DIAGRAM_FULL_SIZE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328074
#define RSETL_ATTR_DISP_MISO                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328191
#define RSETL_ATTR_TFAC_SEL_NAME                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86096
#define RSETL_ATTR_TFAC_UNIT                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86097
#define RSETL_ATTR_TFAC_SCALING                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86098
#define RSETL_ATTR_TFAC_COMMENT                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86099
#define RSETL_ATTR_TFAC_STATE                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86100
#define RSETL_ATTR_TFAC_DELETE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86101
#define RSETL_ATTR_TFAC_DISPLAY                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86102
#define RSETL_ATTR_TFAC_ADJ_STATE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86103
#define RSETL_ATTR_MARKER_AMPLITUDE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86104
#define RSETL_ATTR_MARKER_ENABLED                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86105
#define RSETL_ATTR_MARKER_POSITION                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86106
#define RSETL_ATTR_MARKER_TRACE                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86107
#define RSETL_ATTR_MARKER_AOFF                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86108
#define RSETL_ATTR_MARKER_LOEX                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86109
#define RSETL_ATTR_SIGNAL_TRACK_ENABLED                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86110
#define RSETL_ATTR_SIGNAL_TRACK_BWID                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86111
#define RSETL_ATTR_SIGNAL_TRACK_THRESHOLD                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86112
#define RSETL_ATTR_SIGNAL_TRACK_TRACE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86113
#define RSETL_ATTR_MARKER_STEP_SIZE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86114
#define RSETL_ATTR_MARKER_PROBABILITY                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86115
#define RSETL_ATTR_MARKER_RADIO_PROBABILITY                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328198
#define RSETL_ATTR_MARKER_RADIO_PROBABILITY_VALUE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328199
#define RSETL_ATTR_MARKER_RADIO_DEVIATION                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328200
#define RSETL_ATTR_MARKER_SEARCH_MIN_RIGHT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86116
#define RSETL_ATTR_MARKER_SEARCH_MIN_LEFT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86117
#define RSETL_ATTR_MARKER_SEARCH_PEAK                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86118
#define RSETL_ATTR_MARKER_SEARCH_PEAK_NEXT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86119
#define RSETL_ATTR_MARKER_SEARCH_PEAK_RIGHT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86120
#define RSETL_ATTR_MARKER_SEARCH_PEAK_LEFT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86121
#define RSETL_ATTR_MARKER_SEARCH_MIN                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86122
#define RSETL_ATTR_MARKER_SEARCH_MIN_NEXT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86123
#define RSETL_ATTR_MARKER_SEARCH_PEAK_AUTO                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86124
#define RSETL_ATTR_MARKER_SEARCH_MIN_AUTO                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86125
#define RSETL_ATTR_MARKER_THRESHOLD_STATE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86126
#define RSETL_ATTR_MARKER_THRESHOLD                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86127
#define RSETL_ATTR_PEAK_EXCURSION                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86128
#define RSETL_ATTR_MARKER_SEARCH_LIMITS_STATE                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86129
#define RSETL_ATTR_MARKER_SEARCH_LIMITS_LEFT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86130
#define RSETL_ATTR_MARKER_SEARCH_LIMITS_RIGHT                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86131
#define RSETL_ATTR_MARKER_PEAK_LIST_COUNT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86132
#define RSETL_ATTR_MARKER_PEAK_LIST_FOUND                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86133
#define RSETL_ATTR_MARKER_PEAK_LIST_SORT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86134
#define RSETL_ATTR_MARKER_ZOOM                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86135
#define RSETL_ATTR_MARKER_DEMOD_STATE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86136
#define RSETL_ATTR_MARKER_DEMOD_TYPE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86137
#define RSETL_ATTR_MARKER_DEMOD_HOLDOFF                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86138
#define RSETL_ATTR_MARKER_DEMOD_CONT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86139
#define RSETL_ATTR_MARKER_TO_CENTER                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86140
#define RSETL_ATTR_MARKER_TO_STEP                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86141
#define RSETL_ATTR_MARKER_TO_REFERENCE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86142
#define RSETL_ATTR_MARKER_REF_STATE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86143
#define RSETL_ATTR_MARKER_REF_LEVEL                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86144
#define RSETL_ATTR_MARKER_REF_LEVEL_OFFSET                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86145
#define RSETL_ATTR_MARKER_REF_FREQ                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86146
#define RSETL_ATTR_MARKER_REF_PEAK                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86147
#define RSETL_ATTR_REFERENCE_MARKER_STATE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86148
#define RSETL_ATTR_REFERENCE_MARKER_MODE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86149
#define RSETL_ATTR_REFERENCE_MARKER_POSITION                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86150
#define RSETL_ATTR_REFERENCE_MARKER_REL_POSITION                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86151
#define RSETL_ATTR_REFERENCE_MARKER_AMPLITUDE                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86152
#define RSETL_ATTR_REFERENCE_MARKER_TRACE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86153
#define RSETL_ATTR_REFERENCE_MARKER_AOFF                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86154
#define RSETL_ATTR_REFERENCE_MARKER_PEAK                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86155
#define RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86156
#define RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_RIGHT                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86157
#define RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_LEFT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86158
#define RSETL_ATTR_REFERENCE_MARKER_MIN                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86159
#define RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86160
#define RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_RIGHT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86161
#define RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_LEFT                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86162
#define RSETL_LIMIT_STATE                                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86163
#define RSETL_LIMIT_CLEAR                                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86164
#define RSETL_LIMIT_ASSIGN_TRACE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86165
#define RSETL_LIMIT_UNITS                                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86166
#define RSETL_LIMIT_COMMENT                                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86167
#define RSETL_LIMIT_COPY                                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86168
#define RSETL_LIMIT_NAME                                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86169
#define RSETL_LIMIT_DELETE                                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86170
#define RSETL_LIMIT_CONTROL_DOMAIN                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86171
#define RSETL_LIMIT_CONTROL_SPACING                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86172
#define RSETL_LIMIT_CONTROL_SCALING                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86173
#define RSETL_LIMIT_CONTROL_OFFSET                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86174
#define RSETL_LIMIT_CONTROL_SHIFT                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86175
#define RSETL_LIMIT_LOWER_STATE                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86176
#define RSETL_LIMIT_LOWER_SCALING                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86177
#define RSETL_LIMIT_LOWER_SPACING                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86178
#define RSETL_LIMIT_LOWER_MARGIN                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86179
#define RSETL_LIMIT_LOWER_THRESHOLD                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86180
#define RSETL_LIMIT_LOWER_OFFSET                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86181
#define RSETL_LIMIT_LOWER_SHIFT                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86182
#define RSETL_LIMIT_UPPER_STATE                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86183
#define RSETL_LIMIT_UPPER_SCALING                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86184
#define RSETL_LIMIT_UPPER_SPACING                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86185
#define RSETL_LIMIT_UPPER_MARGIN                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86186
#define RSETL_LIMIT_UPPER_THRESHOLD                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86187
#define RSETL_LIMIT_UPPER_OFFSET                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86188
#define RSETL_LIMIT_UPPER_SHIFT                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86189
#define RSETL_ATTR_THRLINE_STATE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86190
#define RSETL_ATTR_THRLINE_POSITION                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86191
#define RSETL_ATTR_DLINE_STATE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86192
#define RSETL_ATTR_DLINE_POSITION                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86193
#define RSETL_ATTR_FLINE_STATE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86194
#define RSETL_ATTR_FLINE_POSITION                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86195
#define RSETL_ATTR_TLINE_STATE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86196
#define RSETL_ATTR_TLINE_POSITION                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86197
#define RSETL_ATTR_TRIGGER_SOURCE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86198
#define RSETL_ATTR_TRIGGER_DELAY                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86199
#define RSETL_ATTR_TRIGGER_SLOPE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86200
#define RSETL_ATTR_EXTERNAL_GATE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86201
#define RSETL_ATTR_EXTERNAL_GATE_HOLD                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86202
#define RSETL_ATTR_EXTERNAL_GATE_TRIGGER_TYPE                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86203
#define RSETL_ATTR_EXTERNAL_GATE_POLARITY                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86204
#define RSETL_ATTR_EXTERNAL_GATE_LENGTH                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86205
#define RSETL_ATTR_EXTERNAL_GATE_SIGNAL_SOURCE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86206
#define RSETL_ATTR_VIDEO_TRIGGER_LEVEL                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86207
#define RSETL_ATTR_TRIGGER_IFP_LEVEL                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86208
#define RSETL_ATTR_TRIGGER_IFP_OFFSET                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86209
#define RSETL_ATTR_TRIGGER_IFP_HYSTERESIS                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86210
#define RSETL_ATTR_TRIGGER_TV_FREE_RUN_TRIG_MODE                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86211
#define RSETL_ATTR_TRIGGER_TV_VERTICAL_SYNC                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86212
#define RSETL_ATTR_TRIGGER_TV_LINE_SYSTEM                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86213
#define RSETL_ATTR_TRIGGER_TV_HORIZONTAL_SYNC_LINE_NUMBER                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86214
#define RSETL_ATTR_TRIGGER_TV_VIDEO_SYNC_SIGNAL_POLARITY                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86215
#define RSETL_ATTR_AMPL_PREAMPLIFIER                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86216
#define RSETL_ATTR_EXTERN_PREAMP_GAIN                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86217
#define RSETL_LIMIT_CHECK_RESULT                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86218
#define RSETL_ATTR_TRACK_GEN_STATE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86219
#define RSETL_ATTR_TRACK_GEN_CORR_STATE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86220
#define RSETL_ATTR_TRACK_GEN_RECALL_SETTINGS                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86221
#define RSETL_ATTR_TRACK_GEN_MEAS_TYPE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86222
#define RSETL_ATTR_TRACK_GEN_CAL_RESULT_TYPE                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86223
#define RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86224
#define RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL_OFFSET                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86225
#define RSETL_ATTR_MARKER_NOISE_STATE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86226
#define RSETL_ATTR_MARKER_NOISE_RESULT                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86227
#define RSETL_ATTR_REFERENCE_MARKER_PNO_STATE                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86228
#define RSETL_ATTR_REFERENCE_MARKER_PNO_RESULT                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86229
#define RSETL_ATTR_MARKER_FREQUENCY_COUNTER_ENABLED                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86230
#define RSETL_ATTR_MARKER_FREQUENCY_COUNTER_RESOLUTION                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86231
#define RSETL_ATTR_MARKER_COUNT                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86232
#define RSETL_ATTR_MARKER_NDB_STATE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86233
#define RSETL_ATTR_MARKER_NDB_VAL                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86234
#define RSETL_ATTR_MARKER_NDB_RESULT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86235
#define RSETL_ATTR_LIST_POW_STATE_OFF                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86236
#define RSETL_ATTR_MEAS_TDOM_STATE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86237
#define RSETL_ATTR_MEAS_TDOM_PEAK                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86238
#define RSETL_ATTR_MEAS_TDOM_RMS                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86239
#define RSETL_ATTR_MEAS_TDOM_MEAN                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86240
#define RSETL_ATTR_MEAS_TDOM_SDEV                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86241
#define RSETL_ATTR_MEAS_TDOM_AVG                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86242
#define RSETL_ATTR_MEAS_TDOM_MAX_HOLD                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86243
#define RSETL_ATTR_MEAS_TDOM_MODE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86244
#define RSETL_ATTR_MEAS_TDOM_AOFF                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86245
#define RSETL_ATTR_MEAS_TDOM_SET_REFERENCE                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86246
#define RSETL_ATTR_MEAS_TDOM_PEAK_RESULT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86247
#define RSETL_ATTR_MEAS_TDOM_RMS_RESULT                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86248
#define RSETL_ATTR_MEAS_TDOM_MEAN_RESULT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86249
#define RSETL_ATTR_MEAS_TDOM_SDEV_RESULT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86250
#define RSETL_ATTR_MEAS_TDOM_AVG_PEAK_RESULT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86251
#define RSETL_ATTR_MEAS_TDOM_AVG_RMS_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86252
#define RSETL_ATTR_MEAS_TDOM_AVG_MEAN_RESULT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86253
#define RSETL_ATTR_MEAS_TDOM_AVG_SDEV_RESULT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86254
#define RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RESULT                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86255
#define RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RMS_RESULT                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86256
#define RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_MEAN_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86257
#define RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_SDEV_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86258
#define RSETL_ATTR_MEAS_POW_SELECT                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86259
#define RSETL_ATTR_MEAS_POW_OFF                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86260
#define RSETL_ATTR_MEAS_POW_ADJ_NUM                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86261
#define RSETL_ATTR_MEAS_POW_ADJ_MODE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86262
#define RSETL_ATTR_MEAS_POW_MODE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86263
#define RSETL_ATTR_MEAS_POW_RESULT_MODE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86264
#define RSETL_ATTR_MEAS_POW_CHANNEL_SPACING                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86265
#define RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_SPACING                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86266
#define RSETL_ATTR_MEAS_POW_ALT_CHANNEL_SPACING                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86267
#define RSETL_ATTR_MEAS_POW_CHANNEL_BANDWIDTH                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86268
#define RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_BANDWIDTH                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86269
#define RSETL_ATTR_MEAS_POW_ALT_CHANNEL_BANDWIDTH                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86270
#define RSETL_ATTR_MEAS_POW_TRACE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86271
#define RSETL_ATTR_MEAS_POW_STANDARD                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86272
#define RSETL_ATTR_MEAS_POW_REF_VALUE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86273
#define RSETL_ATTR_MEAS_POW_ADJ_PRESET                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86274
#define RSETL_ATTR_MEAS_ACP_HSP                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86275
#define RSETL_ATTR_MEAS_ACP_PRESET_REF_LEVEL                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86276
#define RSETL_ATTR_MEAS_ACP_LIMIT_STATE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86277
#define RSETL_ATTR_MEAS_ACP_LIMIT_REL_STATE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86278
#define RSETL_ATTR_MEAS_ACP_LIMIT_ABS_STATE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86279
#define RSETL_ATTR_MEAS_ACP_ALT_LIMIT_REL_STATE                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86280
#define RSETL_ATTR_MEAS_ACP_ALT_LIMIT_ABS_STATE                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86281
#define RSETL_ATTR_MEAS_POW_CARR_SIG_NUM                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86282
#define RSETL_ATTR_MEAS_POW_REF_CHAN_SEL_AUTO                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86283
#define RSETL_ATTR_MEAS_POW_ADJ_REF_TXCHANNEL                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86284
#define RSETL_ATTR_MEAS_POW_BANDWIDTH                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86285
#define RSETL_ATTR_MEAS_STAT_APD_STATE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86286
#define RSETL_ATTR_MEAS_STAT_CCDF_STATE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86287
#define RSETL_ATTR_MEAS_STAT_SAMPLES                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86288
#define RSETL_ATTR_MEAS_STAT_X_REF                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86289
#define RSETL_ATTR_MEAS_STAT_X_RANGE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86290
#define RSETL_ATTR_MEAS_STAT_Y_MIN                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86291
#define RSETL_ATTR_MEAS_STAT_Y_MAX                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86292
#define RSETL_ATTR_MEAS_STAT_ADJ                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86293
#define RSETL_ATTR_MEAS_STAT_PRESET                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86294
#define RSETL_ATTR_STAT_RESULT                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86295
#define RSETL_ATTR_MEAS_MDEPTH_STATE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86296
#define RSETL_ATTR_MEAS_MDEPTH_RESULT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86297
#define RSETL_ATTR_MEAS_MDEPTH_SEARCH                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86298
#define RSETL_ATTR_MEAS_TOI_STATE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86299
#define RSETL_ATTR_MEAS_TOI_RESULT                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86300
#define RSETL_ATTR_MEAS_TOI_SEARCH                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86301
#define RSETL_ATTR_MEAS_HDIST_STATE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86302
#define RSETL_ATTR_MEAS_HDIST_NOOFHARM                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86303
#define RSETL_ATTR_MEAS_HDIST_RBWAUTO                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86304
#define RSETL_ATTR_MEAS_HDIST_PRESET                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86305
#define RSETL_ATTR_MPOW_MIN                                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86306
#define RSETL_ATTR_MPOW_FTYPE                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86307
#define RSETL_ATTR_IQ_SAMPLE_RATE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86308
#define RSETL_ATTR_IQ_DATA_STATE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86309
#define RSETL_ATTR_IQ_DATA_AVER_STATE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86310
#define RSETL_ATTR_IQ_DATA_AVER_COUNT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86311
#define RSETL_ATTR_IQ_DATA_SYNC                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86312
#define RSETL_ATTR_SERVICE_INPUT_SOURCE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86313
#define RSETL_ATTR_SERVICE_INPUT_COMB_FREQUENCY                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86314
#define RSETL_ATTR_SERVICE_NOISE_SOURCE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86315
#define RSETL_ATTR_SERVICE_STEST_RESULTS                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86316
#define RSETL_ATTR_SERVICE_STEST                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86317
#define RSETL_ATTR_FILE_RECALL                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86318
#define RSETL_ATTR_FILE_STARTUP_RECALL                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86319
#define RSETL_ATTR_FILE_SAVE                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86320
#define RSETL_ATTR_FILE_DATA_CLEAR                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86321
#define RSETL_ATTR_FILE_DATA_CLEAR_ALL                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86322
#define RSETL_ATTR_FILE_DEC_SEPARATOR                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86323
#define RSETL_ATTR_FILE_MANAGER_EDIT_PATH                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86324
#define RSETL_ATTR_FILE_MANAGER_DELETE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86325
#define RSETL_ATTR_FILE_MANAGER_MAKE_DIR                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86326
#define RSETL_ATTR_FILE_MANAGER_EDIT_PATH_DEVICE                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86327
#define RSETL_ATTR_FILE_MANAGER_DELETE_DIR                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86328
#define RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_SOURCE_CAL_DATA                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86329
#define RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAN                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86330
#define RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_HWSETTINGS                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86331
#define RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAC                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86332
#define RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_LINE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86333
#define RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_ALL                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86334
#define RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_NONE                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86335
#define RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_DEFAULT                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86336
#define RSETL_ATTR_HCOPY_ABORT                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86337
#define RSETL_ATTR_HCOPY_COLOR_DEF                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86338
#define RSETL_ATTR_HCOPY_COLOR                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86339
#define RSETL_ATTR_HCOPY_PRINT                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86340
#define RSETL_ATTR_HCOPY_PRINT_NEXT                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86341
#define RSETL_ATTR_HCOPY_DEVICE_DESTINATION                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86342
#define RSETL_ATTR_HCOPY_COLOR_PREDEFINED                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86343
#define RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86344
#define RSETL_ATTR_HCOPY_PRINT_SCREEN                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86345
#define RSETL_ATTR_HCOPY_COMM_SCR                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86346
#define RSETL_ATTR_HCOPY_PRINT_TRACE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86347
#define RSETL_ATTR_HCOPY_DEVICE_ORIENTATION                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86348
#define RSETL_ATTR_HCOPY_FILE_NAME                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86349
#define RSETL_ATTR_HCOPY_PRINTER                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86350
#define RSETL_ATTR_HCOPY_PRINTER_NEXT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86351
#define RSETL_ATTR_HCOPY_PRINTER_FIRST                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86352
#define RSETL_ATTR_ROSC_SOURCE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86353
#define RSETL_ATTR_SYST_ERR                                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86354
#define RSETL_ATTR_SYST_ERR_LIST                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86355
#define RSETL_ATTR_SYST_ERR_CLEAR                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86356
#define RSETL_ATTR_SYST_PRESET                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86357
#define RSETL_ATTR_SYST_VERSION                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86358
#define RSETL_ATTR_SYST_SPEAKER                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86359
#define RSETL_ATTR_OUTPUT_MEAS_MODE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86360
#define RSETL_ATTR_SYSTEM_POWER_SUPPLY                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86361
#define RSETL_ATTR_FMDEM_TRIGGER_SOURCE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86362
#define RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_ABS                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86363
#define RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_REL                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86364
#define RSETL_ATTR_ADEM_TRIGGER_FM_LEVEL                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86365
#define RSETL_ATTR_ADEM_TRIGGER_PM_LEVEL                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86366
#define RSETL_ATTR_FMDEM_DISPLAY_PDIV                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86367
#define RSETL_ATTR_FMDEM_STATE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86368
#define RSETL_ATTR_FMDEM_AF_COUP                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86369
#define RSETL_ATTR_FMDEM_MTIM                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86370
#define RSETL_ATTR_FMDEM_BAND_DEM                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86371
#define RSETL_ATTR_FMDEM_RLEN                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86372
#define RSETL_ATTR_FMDEM_SRATE                                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86373
#define RSETL_ATTR_FMDEM_ZOOM                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86374
#define RSETL_ATTR_FMDEM_ZOOM_START                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86375
#define RSETL_ATTR_ADEM_PHASE_WRAP                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86376
#define RSETL_ATTR_ADEM_UNIT_ANGLE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86377
#define RSETL_ATTR_ADEM_PM_RPO_X                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86378
#define RSETL_ATTR_FMDEM_AF_CENTER                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86379
#define RSETL_ATTR_FMDEM_AF_SPAN                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86380
#define RSETL_ATTR_FMDEM_AF_START                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86381
#define RSETL_ATTR_FMDEM_AF_STOP                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86382
#define RSETL_ATTR_FMDEM_AF_FULL_SPAN                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86383
#define RSETL_ATTR_FMDEM_BAND_RES                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86384
#define RSETL_ATTR_FMDEM_SPEC_SPAN                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86385
#define RSETL_ATTR_FMDEM_SPEC_ZOOM                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86386
#define RSETL_ATTR_FMDEM_FILT_HPAS_STAT                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86387
#define RSETL_ATTR_FMDEM_FILT_HPAS_FREQ                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86388
#define RSETL_ATTR_FMDEM_FILT_LPAS_STAT                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86389
#define RSETL_ATTR_FMDEM_FILT_DEMP_STAT                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86390
#define RSETL_ATTR_FMDEM_FILT_LPAS_FREQ                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86391
#define RSETL_ATTR_FMDEM_FILT_DEMP_TCON                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86392
#define RSETL_ATTR_ADEM_FILT_LPAS_FREQ_REL                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86393
#define RSETL_ATTR_FMDEM_AFR_RES                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86394
#define RSETL_ATTR_FMDEM_FERR_RES                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86395
#define RSETL_ATTR_FMDEM_SIN_RES                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86396
#define RSETL_ATTR_FMDEM_THD_RES                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86397
#define RSETL_ATTR_FMDEM_CARR_RES                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86398
#define RSETL_ATTR_ADEM_SUMM_RES                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86399
#define RSETL_ATTR_ADEM_FM_OFFSET                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86400
#define RSETL_ATTR_PMET_REL                                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86401
#define RSETL_ATTR_PMET_REL_AUTO                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86402
#define RSETL_ATTR_PMET_FREQ                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86403
#define RSETL_ATTR_PMET_MEAS_TIME                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86404
#define RSETL_ATTR_PMET_COUPLING                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86405
#define RSETL_ATTR_PMET_ZERO                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86406
#define RSETL_ATTR_PMET_UNIT_ABS                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86407
#define RSETL_ATTR_PMET_UNIT_REL                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86408
#define RSETL_ATTR_PMET_STATE                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86409
#define RSETL_ATTR_PMET_AVERAGE_AUTO                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86410
#define RSETL_ATTR_PMET_AVERAGE_COUNT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86411
#define RSETL_ATTR_PMET_REF_LEVEL_OFFSET_STATE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86412
#define RSETL_ATTR_PMET_BARGRAPH_STATE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86413
#define RSETL_ATTR_PMET_RELATIVE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86414
#define RSETL_ATTR_PMET_READ                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86415
#define RSETL_ATTR_PMET_FETCH                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86416
#define RSETL_ATTR_CATV_MODE                                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86417
#define RSETL_ATTR_CATV_MEAS_MODE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86418
#define RSETL_ATTR_CATV_Y_SCALE_AUTO                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86419
#define RSETL_ATTR_CATV_EPAT_ZOOM_STATE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86420
#define RSETL_ATTR_CATV_EPAT_ZOOM_FACTOR                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86421
#define RSETL_ATTR_CATV_EPAT_MEAS_SORT                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86422
#define RSETL_ATTR_CATV_MERR_ZOOM                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86423
#define RSETL_ATTR_CATV_OVER_ZOOM                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86424
#define RSETL_ATTR_CATV_QUAD_ZOOM                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86425
#define RSETL_ATTR_CATV_TRACE_MODE_FREEZE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86426
#define RSETL_ATTR_CATV_X_AXIS_AUTO_SCALING                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86427
#define RSETL_ATTR_CATV_DISPLAY_CENTER_POSITION                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86428
#define RSETL_ATTR_CATV_DISPAY_DIVISION                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86429
#define RSETL_ATTR_CATV_CHANNEL                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86430
#define RSETL_ATTR_CATV_RF_FREQUENCY                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86431
#define RSETL_ATTR_CATV_RF_FREQUENCY_STEP_SIZE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86432
#define RSETL_ATTR_CATV_SWEEP_SPACING                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86433
#define RSETL_ATTR_CATV_SIDE_BAND                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86434
#define RSETL_ATTR_CATV_MODUL_STANDARD                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86435
#define RSETL_ATTR_CATV_MODUL_STANDARD_GDELAY                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86436
#define RSETL_ATTR_CATV_MODUL_STANDARD_SIG_TYPE                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86437
#define RSETL_ATTR_CATV_PRES_STATE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86438
#define RSETL_ATTR_CATV_ATT_MODE                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86439
#define RSETL_ATTR_CATV_SOUND_CHAN                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86440
#define RSETL_ATTR_CATV_GET_TRIGGER_SOURCE                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86441
#define RSETL_ATTR_CATV_AUDIO_STATE                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86442
#define RSETL_ATTR_CATV_AUDIO_VOLUME                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86443
#define RSETL_ATTR_CATV_REFERENCE_LEVEL_AUTO                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86444
#define RSETL_ATTR_CATV_LEVEL_DISPLAY                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86445
#define RSETL_ATTR_CATV_INPUT_SELECT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86446
#define RSETL_ATTR_CATV_INPUT_SELECT_MPX                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328075
#define RSETL_ATTR_CATV_VISION_MODULATION                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86447
#define RSETL_ATTR_CATV_ATTENUATOR_STATE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328192
#define RSETL_ATTR_CATV_ATTENUATION_DRIVE_MODE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328193
#define RSETL_ATTR_CATV_ATTENUATION_DRIVE_RESERVE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328194
#define RSETL_ATTR_CATV_ATTENUATION_DRIVE_HYSTERESIS                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328195
#define RSETL_ATTR_QUERY_CATV_AMPL_PREAMPLIFIER_STATE                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328196
#define RSETL_ATTR_CATV_ATV_MEAS                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86448
#define RSETL_ATTR_CATV_ATV_CARR_MEAS                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86449
#define RSETL_ATTR_CATV_ATV_MEAS_MODE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86450
#define RSETL_ATTR_CATV_ATV_BWID                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86451
#define RSETL_ATTR_CATV_ATV_FREQ_NEXT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86452
#define RSETL_ATTR_CATV_ATV_NOISE_FLOOR_CORRECTION                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86453
#define RSETL_ATTR_CATV_ATV_REF_CHANNEL_MANUAL                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86454
#define RSETL_ATTR_CATV_ATV_REF_POWER_MANUAL                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86455
#define RSETL_ATTR_CATV_ATV_REF_POWER_MODE                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86456
#define RSETL_ATTR_CATV_ATV_HUM_UNIT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86457
#define RSETL_ATTR_CATV_ATV_VCP_UNIT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86458
#define RSETL_ATTR_CATV_ATV_VMOD_UNIT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86459
#define RSETL_ATTR_CATV_ATV_STANDARD                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86460
#define RSETL_ATTR_CATV_ATV_SOUND_SYSTEM                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86461
#define RSETL_ATTR_CATV_ATV_COLOR                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86462
#define RSETL_ATTR_CATV_ATV_TRIGGER_BAR_FIELD                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86463
#define RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86464
#define RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE_TYPE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86465
#define RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_FIELD                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86466
#define RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_LINE                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86467
#define RSETL_ATTR_CATV_ATV_TRIGGER_QLINE_FIELD                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86468
#define RSETL_ATTR_CATV_ATV_TRIGGER_QUIET_LINE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86469
#define RSETL_ATTR_CATV_ATV_MEAS_TEST_SIGNAL                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86470
#define RSETL_ATTR_CATV_GET_ATV_MEAS_TEST_SIGNAL                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86471
#define RSETL_ATTR_CATV_ATV_AVER_DEPTH                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86472
#define RSETL_ATTR_CATV_ATV_AVER_RESET                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86473
#define RSETL_ATTR_CATV_GET_ATV_ACHIEVED_AVER_DEPTH                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86474
#define RSETL_ATTR_CATV_RESIDUAL_CARRIER_STATE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86475
#define RSETL_ATTR_CATV_RESIDUAL_CARRIER_VALUE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86476
#define RSETL_ATTR_CATV_SOUND_DEMOD_MODE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86477
#define RSETL_ATTR_CATV_VIDEO_CLAMPING_MODE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86478
#define RSETL_ATTR_CATV_VIDEO_GEN_STATE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86479
#define RSETL_ATTR_CATV_VIDEO_GEN_IF_OUT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86480
#define RSETL_ATTR_CATV_VIDEO_GEN_TEST_PATTERN                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86481
#define RSETL_ATTR_CATV_VIDEO_GEN_USER_DEFINED_IMAGE                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86482
#define RSETL_ATTR_CATV_ATV_WAV_PARAM                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86483
#define RSETL_ATTR_CATV_ATV_WAV_LOC                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86484
#define RSETL_ATTR_CATV_GET_ATV_WAV_POINTS                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86485
#define RSETL_ATTR_CATV_GET_ATV_WAV_CENTER                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86486
#define RSETL_ATTR_CATV_GET_ATV_WAV_WIDTH                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86487
#define RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86488
#define RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86489
#define RSETL_ATTR_CATV_ATV_CARR_LIM_VCF                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86490
#define RSETL_ATTR_CATV_ATV_CARR_LIM_VCP                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86491
#define RSETL_ATTR_CATV_ATV_LIM_CN                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86492
#define RSETL_ATTR_CATV_ATV_LIM_CSO                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86493
#define RSETL_ATTR_CATV_ATV_LIM_CTB                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86494
#define RSETL_ATTR_CATV_ATV_LIM_HUM_LOW                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86495
#define RSETL_ATTR_CATV_ATV_LIM_HUM_UPP                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86496
#define RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86497
#define RSETL_ATTR_CATV_ATV_LIM_VMOD_RPC                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86498
#define RSETL_ATTR_CATV_ATV_LIM_VMOD_VCP                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86499
#define RSETL_ATTR_CATV_ATV_LIM_VMOD_LFOF                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86500
#define RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86501
#define RSETL_ATTR_CATV_GET_ATV_LIM_ANALYSIS_MEAS                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86502
#define RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_MIN_MAX                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86503
#define RSETL_ATTR_CATV_GET_ATV_LIM_ANALYSIS_MEAS_MIN_MAX                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86504
#define RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET_RESULT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86505
#define RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER_RESULT                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86506
#define RSETL_ATTR_CATV_ATV_CARR_LIM_VCF_RESULT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86507
#define RSETL_ATTR_CATV_ATV_CARR_LIM_VCP_RESULT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86508
#define RSETL_ATTR_CATV_ATV_LIM_CN_RESULT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86509
#define RSETL_ATTR_CATV_ATV_LIM_CSO_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86510
#define RSETL_ATTR_CATV_ATV_LIM_CTB_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86511
#define RSETL_ATTR_CATV_ATV_LIM_HUM_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86512
#define RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP_RESULT                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86513
#define RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_RESULT                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86514
#define RSETL_ATTR_CATV_ATV_SIGNAL_LOCKED                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86515
#define RSETL_ATTR_CATV_ATV_CARR_VCPA                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86516
#define RSETL_ATTR_CATV_ATV_CARR_VCF_VALUE                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86517
#define RSETL_ATTR_CATV_ATV_CARR_REL_POWER_VALUE                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86518
#define RSETL_ATTR_CATV_ATV_CARR_FREQ_OFFSET_VALUE                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86519
#define RSETL_ATTR_CATV_ATV_VALUE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86520
#define RSETL_ATTR_CATV_ATV_CN_CN_VALUE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86521
#define RSETL_ATTR_CATV_ATV_CSO_CSO_VALUE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86522
#define RSETL_ATTR_CATV_ATV_CTB_CTB_VALUE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86523
#define RSETL_ATTR_CATV_ATV_HUM_VALUE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86524
#define RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86525
#define RSETL_ATTR_CATV_GET_ATV_ANALYSIS_MEAS_VALUE                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86526
#define RSETL_ATTR_CATV_DTV_MEAS                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86527
#define RSETL_ATTR_CATV_DTV_SATT                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86528
#define RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_STATE                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86529
#define RSETL_ATTR_CATV_DTV_SATT_GUIDELINE                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328201
#define RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER_RANGE   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86530
#define RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86531
#define RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_MASK_TYPE                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86532
#define RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_SHOW_PEAKS                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86533
#define RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_NOISE_FLOOR_CORRECTION    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86534
#define RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_EXTERNAL_NOTCH_FILTER     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86535
#define RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_COUNTRY                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86536
#define RSETL_ATTR_CATV_DTV_FREQ_OFFSET                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86537
#define RSETL_ATTR_CATV_DTV_SPECTRUM_MARGIN_LIST                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86538
#define RSETL_ATTR_CATV_DTV_REFERENCE_FREQUENCY                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86539
#define RSETL_ATTR_CATV_DTV_CHAN_BAND                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86540
#define RSETL_ATTR_CATV_DTV_CHAN_BAND_DVBT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86541
#define RSETL_ATTR_CATV_DTV_OVERVIEW_SCREEN_SELECT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86542
#define RSETL_ATTR_CATV_DTV_MER_FREQUENCY_START                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328076
#define RSETL_ATTR_CATV_DTV_MER_FREQUENCY_STOP                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328077
#define RSETL_ATTR_CATV_DTV_MER_FREQUENCY_CENTER                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328078
#define RSETL_ATTR_CATV_DTV_MER_FREQUENCY_SPAN                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328079
#define RSETL_ATTR_CATV_DTV_MER_OPTIMIZATION                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328197
#define RSETL_ATTR_CATV_DTV_EPAT_UNIT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86543
#define RSETL_ATTR_CATV_DTV_EPAT_RVEL                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86544
#define RSETL_ATTR_CATV_DTV_TIME_RANGE_MODE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86545
#define RSETL_ATTR_CATV_DTV_ECHO_THRESHOLD_LINE                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86546
#define RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_STATE                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328080
#define RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_MODE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328081
#define RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_TRESHOLD                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328082
#define RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQUALIZER_STATE                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328083
#define RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_TAPS                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328084
#define RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_SECONDS                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328085
#define RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_TAPS                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328086
#define RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_SECONDS                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328087
#define RSETL_ATTR_CATV_DTV_ECHO_FREQ_VELOCITY_FACTOR                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328088
#define RSETL_ATTR_CATV_DTV_EYE_DIAGRAM_TIME_SPAN                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86547
#define RSETL_ATTR_CATV_DTV_ISDBT_CONST_SELECT                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86548
#define RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_CONTINUAL_SCATTERED_PILOTS RS_SPECIFIC_PUBLIC_ATTR_BASE + 86549
#define RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_TMCC       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86550
#define RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC1        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86551
#define RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC2        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86552
#define RSETL_ATTR_CATV_DTV_ISDBT_XAXIS_UNIT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86553
#define RSETL_ATTR_CATV_DTV_ERROR_UNIT                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86554
#define RSETL_ATTR_CATV_DTV_POW_LEV_UNIT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86555
#define RSETL_ATTR_CATV_DTV_EQUALIZER_STATE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86556
#define RSETL_ATTR_CATV_DTV_EQUALIZER_COUNT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86557
#define RSETL_ATTR_CATV_DTV_EQUALIZER_FREEZE                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86558
#define RSETL_ATTR_CATV_DTV_EQUALIZER_MODE                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86559
#define RSETL_ATTR_CATV_DTV_EQUALIZER_RESET                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86560
#define RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86561
#define RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE_SHRINK                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86562
#define RSETL_ATTR_CATV_DTV_FILTER_ALPHA                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86563
#define RSETL_ATTR_CATV_DTV_SRATE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86564
#define RSETL_ATTR_CATV_DTV_STANDARD                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86565
#define RSETL_ATTR_CATV_DTV_T2_PROFILE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328202
#define RSETL_ATTR_CATV_DTV_FORMAT                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86566
#define RSETL_ATTR_CATV_DTV_MIN_BER_SAMPLES                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86567
#define RSETL_ATTR_CATV_DTV_DISP_IQ_SAMPLES                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86568
#define RSETL_ATTR_CATV_DTV_IQ_SOURCE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86569
#define RSETL_ATTR_CATV_DTV_IQ_CARRIER_TYPE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328203
#define RSETL_ATTR_CATV_DTV_DISPLAY_START_SYMBOL                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328089
#define RSETL_ATTR_CATV_DTV_DISPLAY_FRAME_COUNT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328090
#define RSETL_ATTR_CATV_DTV_DISPLAY_CELL_COUNT                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328091
#define RSETL_ATTR_CATV_DTV_BER_RESET                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86570
#define RSETL_ATTR_CATV_DTV_MLOG_RESET                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86571
#define RSETL_ATTR_CATV_DTV_AUTO_DETECTION                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86572
#define RSETL_ATTR_CATV_DTV_CARRIER_START                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86573
#define RSETL_ATTR_CATV_DTV_CARRIER_STOP                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86574
#define RSETL_ATTR_CATV_DTV_CARRIER_SPAN                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86575
#define RSETL_ATTR_CATV_DTV_CARRIER_CENTER                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86576
#define RSETL_ATTR_CATV_DTV_CARRIER_DATA_STATE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328092
#define RSETL_ATTR_CATV_DTV_CARRIER_TR_STATE                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328093
#define RSETL_ATTR_CATV_DTV_CARRIER_LOOPS                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86577
#define RSETL_ATTR_CATV_DTV_CARRIER_MODULATION                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86578
#define RSETL_ATTR_CATV_DTV_CODE_RATE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86579
#define RSETL_ATTR_CATV_DTV_CODE_RATE_HIGH_PRIOR                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86580
#define RSETL_ATTR_CATV_DTV_CODE_RATE_LOW_PRIOR                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86581
#define RSETL_ATTR_CATV_DTV_FEC_SYNC_REQUIRED                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86582
#define RSETL_ATTR_CATV_DTV_FIC_SYNC_REQUIRED                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86583
#define RSETL_ATTR_CATV_DTV_MPEG_SYNC_REQUIRED                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86584
#define RSETL_ATTR_CATV_DTV_FFT_MODE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86585
#define RSETL_ATTR_CATV_DTV_GUARD_INTERVAL                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86586
#define RSETL_ATTR_CATV_DTV_GUARD_INTERVAL_PN                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86587
#define RSETL_ATTR_CATV_DTV_INTERLEAVER                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86588
#define RSETL_ATTR_CATV_DTV_LDPC_MODE                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86589
#define RSETL_ATTR_CATV_DTV_SYMBOL_LOOPS                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86590
#define RSETL_ATTR_CATV_DTV_AGC_LOOPS                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86591
#define RSETL_ATTR_CATV_DTV_SYSTEM_OPTIMATION                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86592
#define RSETL_ATTR_CATV_DTV_TIME_DEINTERLEAVER                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86593
#define RSETL_ATTR_CATV_DTV_MPEG_TS_OUTPUT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86594
#define RSETL_ATTR_CATV_DTV_DISPLAY_TMCC_NEXT_VALUES                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86595
#define RSETL_ATTR_CATV_DTV_DATA_ID_MODE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328094
#define RSETL_ATTR_CATV_DTV_DATA_ID_MAN                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328095
#define RSETL_ATTR_QUERY_CATV_DTV_DATA_ID                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328097
#define RSETL_ATTR_CATV_DTV_ISDBT_CODE_RATE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86596
#define RSETL_ATTR_CATV_DTV_ISDBT_TIME_DEINTERLEAVER                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86597
#define RSETL_ATTR_CATV_DTV_ISDBT_SEGMENTS                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86598
#define RSETL_ATTR_CATV_GET_DTV_ISDBT_SEGMENT_C                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86599
#define RSETL_ATTR_CATV_DTV_ISDBT_MODULATION                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86600
#define RSETL_ATTR_CATV_DTV_ISDBT_PARTIAL_RECEPTION                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86601
#define RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_POSITION                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86602
#define RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_OFFSET                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86603
#define RSETL_ATTR_CATV_DTV_DTMB_SI_POWER_NORMALIZATION                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328204
#define RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_BOOST                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328205
#define RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_REFERENCE                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328206
#define RSETL_ATTR_CATV_DTV_DTMB_ESR_TIMEBASE                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328207
#define RSETL_ATTR_CATV_DTV_DTMB_BER_INDICATION                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328208
#define RSETL_ATTR_CATV_DTV_DVB_ISSY_PROCESSING                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328209
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_TRANSMISSION_SYSTEM                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328098
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PILOT_PATTERN                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328099
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PAPR                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328100
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_DATA_SYMBOLS                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328101
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_PAYLOAD_TYPE                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328102
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_CODE_RATE                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328103
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MODULATION                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328104
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_ROTATION                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328105
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_FEC_TYPE                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328106
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MAX_BLOCKS                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328107
#define RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_TI_BLOCKS                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328108
#define RSETL_ATTR_CATV_DIGITAL_TV_ATSC_SCAN_SLT                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328109
#define RSETL_ATTR_CATV_DTV_ATSC_SORT_LIST                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328210
#define RSETL_ATTR_CATV_DTV_ATSC_SELECT_PARADE_BY_SERVICE                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328211
#define RSETL_ATTR_CATV_DTV_NOISE_GEN_CN_STATE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86604
#define RSETL_ATTR_CATV_DTV_NOISE_GEN_CN                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86605
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_STATE                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86606
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_DISP_PARAM                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86607
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_MAN                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86608
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_AUTO                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86609
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_PORT                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328110
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_STATE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328111
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_CONNECTION_STATE                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328112
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_HDOP                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328113
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_SATELLITES                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328114
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_VALID_INFO                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328115
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LONGITUDE                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328116
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LATITUDE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328117
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_ALTITUDE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328118
#define RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_STATUS                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328212
#define RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_DEVICE                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328213
#define RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_ENABLED                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328214
#define RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_DEAD_RECKONING         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328215
#define RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_PIN_DIRECTION          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328216
#define RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_STATUS       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328217
#define RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_STATUS     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328218
#define RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_CALIBRATION_STATUS RS_SPECIFIC_PUBLIC_ATTR_BASE + 328219
#define RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_CALIBRATION_STATUS RS_SPECIFIC_PUBLIC_ATTR_BASE + 328220
#define RSETL_ATTR_CATV_DTV_FREQ_RANGE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86610
#define RSETL_ATTR_CATV_DTV_NOTCH_FILTER                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86611
#define RSETL_ATTR_CATV_DTV_NOTCH_FILTER_BWIDTH                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86612
#define RSETL_ATTR_CATV_DTV_NOTCH_FILTER_FREQ                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86613
#define RSETL_ATTR_CATV_DTV_FIC_RETRIEVE_DATA_SET                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86614
#define RSETL_ATTR_CATV_DTV_CN_MEAS_STATE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328119
#define RSETL_ATTR_CATV_DTV_CN_MEAS_FREQUENCY                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328120
#define RSETL_ATTR_CATV_DTV_CN_MEAS_NOISE_BANDWIDTH                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328121
#define RSETL_ATTR_CATV_DTV_FIC_SUBCH_SELECT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86615
#define RSETL_ATTR_CATV_GET_DTV_FIC_SUBCH_NUMBER                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86616
#define RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_NUMBER                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86617
#define RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_COMP_NUMBER                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86618
#define RSETL_ATTR_CATV_DTV_TRANS_MODE                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86619
#define RSETL_ATTR_CATV_DTV_AUTO_SUBCH_ORG                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86620
#define RSETL_ATTR_CATV_DTV_SUBCH_FIRST_CUNIT                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86621
#define RSETL_ATTR_CATV_DTV_SUBCH_DATA_RATE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86622
#define RSETL_ATTR_CATV_DTV_SUBCH_USE_MPEG                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86623
#define RSETL_ATTR_CATV_DTV_SUBCH_PROTECTION_LEVEL                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86624
#define RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86625
#define RSETL_ATTR_CATV_DTV_LIM_SUPP                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86626
#define RSETL_ATTR_CATV_DTV_LIM_ERR_LOW                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86627
#define RSETL_ATTR_CATV_DTV_LIM_ERR_UPP                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86628
#define RSETL_ATTR_CATV_DTV_LIM_IMB                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86629
#define RSETL_ATTR_CATV_DTV_LIM_PJIT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86630
#define RSETL_ATTR_CATV_DTV_LIM_QERR                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86631
#define RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86632
#define RSETL_ATTR_CATV_DTV_LIM_SNR                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86633
#define RSETL_ATTR_CATV_DTV_LIM_BBV                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86634
#define RSETL_ATTR_CATV_DTV_LIM_BVF                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86635
#define RSETL_ATTR_CATV_DTV_LIM_BVM                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86636
#define RSETL_ATTR_CATV_DTV_LIM_BBRS                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86637
#define RSETL_ATTR_CATV_DTV_LIM_BIT_RATE_OFFSET                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86638
#define RSETL_ATTR_CATV_DTV_LIM_LEVEL                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86639
#define RSETL_ATTR_CATV_DTV_LIM_PER                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86640
#define RSETL_ATTR_CATV_DTV_LIM_PERR                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86641
#define RSETL_ATTR_CATV_DTV_LIM_BER_LDPC                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86642
#define RSETL_ATTR_CATV_DTV_LIM_BER_BBCH                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328122
#define RSETL_ATTR_CATV_DTV_LIM_MRLO_LOW                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328123
#define RSETL_ATTR_CATV_DTV_LIM_MRLO_UPP                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328124
#define RSETL_ATTR_CATV_DTV_LIM_MPLO_LOW                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328125
#define RSETL_ATTR_CATV_DTV_LIM_MPLO_UPP                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328126
#define RSETL_ATTR_CATV_DTV_LIM_MRPL                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328127
#define RSETL_ATTR_CATV_DTV_LIM_MPPL                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328128
#define RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328221
#define RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328222
#define RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328223
#define RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328224
#define RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328225
#define RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328226
#define RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328227
#define RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328228
#define RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328229
#define RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328230
#define RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328231
#define RSETL_ATTR_CATV_DTV_LIM_ERPL                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328129
#define RSETL_ATTR_CATV_DTV_LIM_EPPL                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328130
#define RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328131
#define RSETL_ATTR_CATV_DTV_LIM_CNR                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86643
#define RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86644
#define RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86645
#define RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86646
#define RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATE                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86647
#define RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86648
#define RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET_RESULT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86649
#define RSETL_ATTR_CATV_DTV_CARR_LIM_CARR_SUPP_RESULT                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86650
#define RSETL_ATTR_CATV_DTV_LIM_ERROR_RESULT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86651
#define RSETL_ATTR_CATV_DTV_LIM_IMB_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86652
#define RSETL_ATTR_CATV_DTV_LIM_PJIT_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86653
#define RSETL_ATTR_CATV_DTV_LIM_QERR_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86654
#define RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET_RESULT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86655
#define RSETL_ATTR_CATV_DTV_LIM_SNR_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86656
#define RSETL_ATTR_CATV_DTV_LIM_BBV_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86657
#define RSETL_ATTR_CATV_DTV_LIM_BVF_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86658
#define RSETL_ATTR_CATV_DTV_LIM_BVM_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86659
#define RSETL_ATTR_CATV_DTV_LIM_BBRS_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86660
#define RSETL_ATTR_CATV_DTV_LIM_BROF_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86661
#define RSETL_ATTR_CATV_DTV_LIM_LEVEL_RESULT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86662
#define RSETL_ATTR_CATV_DTV_LIM_PER_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86663
#define RSETL_ATTR_CATV_DTV_LIM_PERR_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86664
#define RSETL_ATTR_CATV_DTV_LIM_BER_LDPC_RESULT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86665
#define RSETL_ATTR_CATV_DTV_LIM_BER_BBCH_RESULT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328132
#define RSETL_ATTR_CATV_DTV_LIM_MRLO_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328133
#define RSETL_ATTR_CATV_DTV_LIM_MPLO_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328134
#define RSETL_ATTR_CATV_DTV_LIM_MRPL_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328135
#define RSETL_ATTR_CATV_DTV_LIM_MPPL_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328136
#define RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT_RESULT           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328232
#define RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT_RESULT           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328233
#define RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT RS_SPECIFIC_PUBLIC_ATTR_BASE + 328234
#define RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT RS_SPECIFIC_PUBLIC_ATTR_BASE + 328235
#define RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT_RESULT         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328236
#define RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT_RESULT         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328237
#define RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328238
#define RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328239
#define RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT_RESULT          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328240
#define RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT_RESULT          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328241
#define RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT_RESULT              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328242
#define RSETL_ATTR_CATV_DTV_LIM_ERPL_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328137
#define RSETL_ATTR_CATV_DTV_LIM_EPPL_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328138
#define RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW_RESULT                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328139
#define RSETL_ATTR_CATV_DTV_LIM_CNR_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86666
#define RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86667
#define RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA_RESULT                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86668
#define RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR_RESULT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86669
#define RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_RESULT         RS_SPECIFIC_PUBLIC_ATTR_BASE + 86670
#define RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_CARRIERS_RESULT RS_SPECIFIC_PUBLIC_ATTR_BASE + 86671
#define RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS_RESULT                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86672
#define RSETL_ATTR_CATV_DTV_SIGNAL_LOCKED                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86673
#define RSETL_ATTR_CATV_DTV_MPEG_SIGNAL_LOCKED                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 86674
#define RSETL_ATTR_CATV_DTV_FIC_SYNC_STATUS                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86675
#define RSETL_ATTR_CATV_DTV_TPS_MEAS_CONST_SETTING                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86676
#define RSETL_ATTR_CATV_DTV_TPS_MEAS_FFT_MODE_SETTING                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86677
#define RSETL_ATTR_CATV_DTV_TPS_MEAS_GUARD_INTERVAL_SETTING                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 86678
#define RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_SETTING                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86679
#define RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_HIGH_PRIOR_SETTING           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86680
#define RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_LOW_PRIOR_SETTING            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86681
#define RSETL_ATTR_CATV_DTV_TPS_MEAS_INTERLEAVER_SETTING                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86682
#define RSETL_ATTR_CATV_DTV_TPS_MEAS_DEINTERLEAVER_SETTING                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86683
#define RSETL_ATTR_CATV_DTV_APGD_MEAS_RESULT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 86684
#define RSETL_ATTR_CATV_DTV_SPEC                                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86685
#define RSETL_ATTR_CATV_DTV_ERROR                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86686
#define RSETL_ATTR_CATV_DTV_OVER_CARR_FREQ_OFFSET                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86687
#define RSETL_ATTR_CATV_DTV_OVER_SRATE_OFFSET                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86688
#define RSETL_ATTR_CATV_DTV_OVERVIEW                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86689
#define RSETL_ATTR_CATV_GET_DTV_FFT_MODE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328176
#define RSETL_ATTR_CATV_GET_DTV_GUARD_INTERVAL                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328177
#define RSETL_ATTR_CATV_GET_DTV_CODE_RATE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328178
#define RSETL_ATTR_CATV_GET_DTV_CODE_RATE_HIGH_PRIORITY                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328179
#define RSETL_ATTR_CATV_GET_DTV_CODE_RATE_LOW_PRIORITY                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328180
#define RSETL_ATTR_CATV_GET_DTV_INTERLEAVER                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328181
#define RSETL_ATTR_CATV_GET_DTV_TRANSMISSION_MODE                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328182
#define RSETL_ATTR_CATV_GET_DTV_SIDEBAND_POSITION                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328183
#define RSETL_ATTR_CATV_GET_DTV_TIME_DEINTERLEAVER                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328184
#define RSETL_ATTR_CATV_GET_DTV_CONTROL_FRAME                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328185
#define RSETL_ATTR_CATV_GET_DTV_CELL_ID                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328186
#define RSETL_ATTR_CATV_GET_DTV_TPS_RESERVED                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328187
#define RSETL_ATTR_CATV_GET_DTV_LENGTH_INDICATOR                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328188
#define RSETL_ATTR_CATV_DTV_CONST_VAL                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86690
#define RSETL_ATTR_CATV_DTV_MERR_IMB                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86691
#define RSETL_ATTR_CATV_DTV_MERR_QERR                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86692
#define RSETL_ATTR_CATV_DTV_MERR_CSUP                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86693
#define RSETL_ATTR_CATV_DTV_MERR_PJIT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86694
#define RSETL_ATTR_CATV_DTV_MOD_ERRORS                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86695
#define RSETL_ATTR_CATV_DTV_CONST                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 86696
#define RSETL_ATTR_CATV_DTV_MER_VS_CAR                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86697
#define RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328140
#define RSETL_ATTR_CATV_DTV_IQ_IMBALANCE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 86698
#define RSETL_ATTR_CATV_GET_DIGITAL_TV_ECHO_PATTERN_RESULT                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328141
#define RSETL_ATTR_CATV_DTV_INGRESS_DIAGRAM_EQUIVALENT_NOISE_BANDWIDTH      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86699
#define RSETL_ATTR_CATV_DTV_ISDBT_LAYER_SPECIFIC                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 86700
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_SYSTEM_IDENTIFICATION       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86701
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PARAMETER_SWITCHING_INDICATOR RS_SPECIFIC_PUBLIC_ATTR_BASE + 86702
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_EMERGENCY_ALARM_BROADCASTING RS_SPECIFIC_PUBLIC_ATTR_BASE + 86703
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CURRENT_PARTIAL_RECEPTION   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86704
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NEXT_PARTIAL_RECEPTION      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86705
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PHASE_SHIFT_CORRECTION      RS_SPECIFIC_PUBLIC_ATTR_BASE + 86706
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_RESERVED_BITS               RS_SPECIFIC_PUBLIC_ATTR_BASE + 86707
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_MODULATION                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 86708
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CODE_RATE                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 86709
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_TIME_DEINTERLEAVER          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86710
#define RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NUMBER_OF_SEGMENTS          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86711
#define RSETL_ATTR_CATV_DTV_DVB_PLP_SYNC_STATE_RESULT                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328142
#define RSETL_ATTR_CATV_DTV_DVB_T2_RESULT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328189
#define RSETL_ATTR_CATV_DTV_L1_BANDWIDTH_EXTENSION_RESULT                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328143
#define RSETL_ATTR_CATV_DTV_L1_GUARD_INTERVAL_RESULT                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328144
#define RSETL_ATTR_CATV_DTV_L1_PILOT_PATTERN_RESULT                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328145
#define RSETL_ATTR_CATV_DTV_L1_TRANSMISSION_SYSTEM_RESULT                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328146
#define RSETL_ATTR_CATV_DTV_L1_T2_VERSION_RESULT                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328147
#define RSETL_ATTR_CATV_DTV_L1_T2_FRAME_RESULT                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328148
#define RSETL_ATTR_CATV_DTV_L1_POST_CONSTELATION_RESULT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328149
#define RSETL_ATTR_CATV_DTV_L1_POST_SIZE_RESULT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328150
#define RSETL_ATTR_CATV_DTV_L1_POST_EXTENSION_RESULT                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328151
#define RSETL_ATTR_CATV_DTV_L1_POST_REPETITION_RESULT                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328152
#define RSETL_ATTR_CATV_DTV_L1_POST_CODE_RATE_RESULT                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328153
#define RSETL_ATTR_CATV_DTV_L1_POST_FEC_TYPE_RESULT                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328154
#define RSETL_ATTR_CATV_DTV_L1_PAPR_RESULT                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328155
#define RSETL_ATTR_CATV_DTV_L1_STREAM_TYPE_RESULT                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328190
#define RSETL_ATTR_CATV_DTV_L1_S_BIT_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328156
#define RSETL_ATTR_CATV_DTV_L1_ID_RESULT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328157
#define RSETL_ATTR_CATV_DTV_L1_REGENERATION_FLAG_RESULT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328158
#define RSETL_ATTR_CATV_DTV_L1_FREQUENCIES_COUNT_RESULT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328159
#define RSETL_ATTR_CATV_DTV_L1_RF_INDEX_RESULT                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328160
#define RSETL_ATTR_CATV_DTV_L1_CRC_RESULT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328161
#define RSETL_ATTR_CATV_DTV_L1_RESERVED_BITS_RESULT                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328162
#define RSETL_ATTR_CATV_DTV_L1_POST_SIGNALING_RESULT                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328163
#define RSETL_ATTR_CATV_DTV_ATSC_SYNC_STATE_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328164
#define RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_RESULT                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328165
#define RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_PROGRESS                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328166
#define RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_TARGET                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328167
#define RSETL_ATTR_CATV_DTV_ATSC_ENS_SIG_BIT_RATE_RESULT                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328168
#define RSETL_ATTR_CATV_DTV_ATSC_PAY_PAR_BIT_RATE_RESULT                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328169
#define RSETL_ATTR_CATV_DTV_ATSC_FIC_DECODED_PARADE_RESULT                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328170
#define RSETL_ATTR_CATV_DTV_ATSC_FIC_ALL_PARADE_RESULT                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328171
#define RSETL_ATTR_CATV_TV_MEAS                                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 86712
#define RSETL_ATTR_CATV_TV_CHANNEL                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 86713
#define RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_ACTIVATE                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 86714
#define RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_DEACTIVATE                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 86715
#define RSETL_ATTR_RADIO_MEASUREMENT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 327954
#define RSETL_ATTR_RADIO_SPECTRUM_SELECT_MASK                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328243
#define RSETL_ATTR_RADIO_STANDARD                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 327955
#define RSETL_ATTR_RADIO_CHANNEL_BANDWIDTH                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 327956
#define RSETL_ATTR_RADIO_DATA_SYSTEM                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 327957
#define RSETL_ATTR_RADIO_SCA_MODE                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 327958
#define RSETL_ATTR_RADIO_SCA_FREQUENCY                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 327959
#define RSETL_ATTR_RADIO_PILOT_DEVIATION_TRESHOLD                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 327960
#define RSETL_ATTR_RADIO_PILOT_NOISE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328244
#define RSETL_ATTR_RADIO_OUTPUT_SIGNAL                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 327961
#define RSETL_ATTR_RADIO_OUTPUT_DEEMPHASIS                                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 327962
#define RSETL_ATTR_RADIO_OUTPUT_DEVIATION                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 327963
#define RSETL_ATTR_RADIO_OUTPUT_CCVS                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 327964
#define RSETL_ATTR_RADIO_DUT_INPUT_LEVEL                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 327965
#define RSETL_ATTR_RADIO_DUT_AES_EBU                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 327966
#define RSETL_ATTR_RADIO_DUT_DEVIATION                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 327967
#define RSETL_ATTR_RADIO_VERTICAL_SCALING                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 327968
#define RSETL_ATTR_RADIO_SWEEP_POINTS                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 327969
#define RSETL_ATTR_RADIO_START_FREQUENCY                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 327970
#define RSETL_ATTR_RADIO_STOP_FREQUENCY                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 327971
#define RSETL_ATTR_RADIO_CENTER_FREQUENCY                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 327972
#define RSETL_ATTR_RADIO_FREQUENCY_SPAN                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 327973
#define RSETL_ATTR_RADIO_ZOOM                                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 327974
#define RSETL_ATTR_RADIO_FREQ_RESPONSE_TYPE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 327975
#define RSETL_ATTR_RADIO_FREQ_RESPONSE_REFERENCE                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 327976
#define RSETL_ATTR_RADIO_FREQ_RESPONSE_PHASE_RANGE                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 327977
#define RSETL_ATTR_RADIO_FREQUENCY_RANGE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 327978
#define RSETL_ATTR_RADIO_REFERENCE_POSITION                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 327979
#define RSETL_ATTR_RADIO_CROSSTALK_TYPE                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 327980
#define RSETL_ATTR_RADIO_CROSSTALK_REFERENCE                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 327981
#define RSETL_ATTR_RADIO_SN_REFERENCE_DEVIATION                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 327982
#define RSETL_ATTR_RADIO_SN_WEIGHTING_FILTER                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 327983
#define RSETL_ATTR_RADIO_REFERENCE_DEVIATION                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 327984
#define RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 327985
#define RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328245
#define RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN_AUTO                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328246
#define RSETL_ATTR_RADIO_MPX_POWER_REF_POSITION                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 327986
#define RSETL_ATTR_RADIO_MPX_POWER_RANGE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 327987
#define RSETL_ATTR_RADIO_MPX_PEAK_DEV_REFERENCE                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 327988
#define RSETL_ATTR_RADIO_MPX_PEAK_DEV_RANGE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 327989
#define RSETL_ATTR_RADIO_MPX_SAMPLES                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328247
#define RSETL_ATTR_RADIO_SAMPLE_COUNT                                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 327990
#define RSETL_ATTR_RADIO_THD_TOP_LIMIT                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 327991
#define RSETL_ATTR_RADIO_THD_BOTTOM_LIMIT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 327992
#define RSETL_ATTR_RADIO_DFD_TOP_LIMIT                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 327993
#define RSETL_ATTR_RADIO_DFD_BOTTOM_LIMIT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 327994
#define RSETL_ATTR_RADIO_SIGNAL_PATH                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 327995
#define RSETL_ATTR_RADIO_DEEMPHASIS                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 327996
#define RSETL_ATTR_RADIO_OBW_ADJUST_SETTINGS                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328248
#define RSETL_ATTR_RADIO_AGEN_TYPE                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 327997
#define RSETL_ATTR_RADIO_AGEN_SIGNAL                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 327998
#define RSETL_ATTR_RADIO_AGEN_CONNECTOR_CONFIG                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 327999
#define RSETL_ATTR_RADIO_AGEN_AMPLITUDE_DEFINITION                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328000
#define RSETL_ATTR_RADIO_AGEN_WAVEFORM                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328001
#define RSETL_ATTR_RADIO_AGEN_LEVEL                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328002
#define RSETL_ATTR_RADIO_AGEN_FREQUENCY                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328003
#define RSETL_ATTR_RADIO_AGEN_FREQUENCY_SPACING                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328174
#define RSETL_ATTR_RADIO_AGEN_FREQUENCY_UPPER                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328175
#define RSETL_ATTR_RADIO_AGEN_SUBCARRIER_STATE                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328004
#define RSETL_ATTR_RADIO_AGEN_SUBCARRIER_DEVIATION                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328005
#define RSETL_ATTR_RADIO_AGEN_ALTERNATE_CHANNEL                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328006
#define RSETL_ATTR_RADIO_AGEN_DUT_PREEMPHASIS                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328007
#define RSETL_ATTR_RADIO_AGEN_DUT_DEVIATION                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328008
#define RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328009
#define RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328010
#define RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328011
#define RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328012
#define RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328013
#define RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328014
#define RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328015
#define RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328016
#define RSETL_ATTR_RADIO_AUDIO_SN_LIMIT                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328017
#define RSETL_ATTR_RADIO_AUDIO_THD_LIMIT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328018
#define RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328019
#define RSETL_ATTR_RADIO_MPX_POW_LIMIT                                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328020
#define RSETL_ATTR_RADIO_MPX_PEAK_LIMIT                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328172
#define RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328249
#define RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT_RATIO                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328250
#define RSETL_ATTR_RADIO_OBW_UPPER_LIMIT                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328251
#define RSETL_ATTR_RADIO_MP_DETECTION_LIMIT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328021
#define RSETL_ATTR_RADIO_DFD_UNIT                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328022
#define RSETL_ATTR_RADIO_THD_UNIT                                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328023
#define RSETL_ATTR_RADIO_OVERVIEW_LEVEL_RESULT                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328024
#define RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328025
#define RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_RESULT                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328026
#define RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_RESULT                      RS_SPECIFIC_PUBLIC_ATTR_BASE + 328027
#define RSETL_ATTR_RADIO_OVERVIEW_PILOT_RESULT                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328028
#define RSETL_ATTR_RADIO_OVERVIEW_RDS_RESULT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328029
#define RSETL_ATTR_RADIO_OVERVIEW_DARC_RESULT                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328030
#define RSETL_ATTR_RADIO_OVERVIEW_SCA_RESULT                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328031
#define RSETL_ATTR_RADIO_AUDIO_SCOPE_RESULT                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328032
#define RSETL_ATTR_RADIO_SPECTRUM_RESULT_SINAD                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328033
#define RSETL_ATTR_RADIO_SPECTRUM_RESULT_THD                                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328034
#define RSETL_ATTR_RADIO_SPECTRUM_RESULT_MOD_FREQ                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328035
#define RSETL_ATTR_RADIO_SPECTRUM_RESULT_SC_FREQ_OFFSET                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328036
#define RSETL_ATTR_RADIO_POWER_PEAK_CURRENT_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328037
#define RSETL_ATTR_RADIO_POWER_PEAK_LIMIT_RESULT                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328038
#define RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_RATIO_RESULT               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328252
#define RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_VIOLATING_RESULT   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328253
#define RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_TOTAL_RESULT       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328254
#define RSETL_ATTR_RADIO_MPX_DEVIATION_RAW_VIOLATION_SAMPLES_RESULT         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328255
#define RSETL_ATTR_RADIO_MULTIPATH_DETECTION_RESULT                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328039
#define RSETL_ATTR_RADIO_RDS_RESULT_SYNC                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328040
#define RSETL_ATTR_RADIO_RDS_RESULT_PID                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328041
#define RSETL_ATTR_RADIO_RDS_RESULT_NAME                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328042
#define RSETL_ATTR_RADIO_RDS_RESULT_ECC                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328043
#define RSETL_ATTR_RADIO_RDS_RESULT_COUNTRY                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328044
#define RSETL_ATTR_RADIO_RDS_RESULT_FLAG                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328045
#define RSETL_ATTR_RADIO_RDS_RESULT_PTYPE                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328046
#define RSETL_ATTR_RADIO_RDS_RESULT_DID                                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328173
#define RSETL_ATTR_RADIO_RDS_RESULT_DATE_TIME                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328047
#define RSETL_ATTR_RADIO_OBW_RESULT                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328256
#define RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_AMPLIITUDE                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328048
#define RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_PHASE                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328049
#define RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_FREQUENCY                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328050
#define RSETL_ATTR_RADIO_CROSSTALK_RESULT                                   RS_SPECIFIC_PUBLIC_ATTR_BASE + 328051
#define RSETL_ATTR_RADIO_SN_RESULT                                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328052
#define RSETL_ATTR_RADIO_THD_RESULT                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328053
#define RSETL_ATTR_RADIO_DFD_RESULT                                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328054
#define RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT_RESULT                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328055
#define RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT_RESULT                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328056
#define RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT_RESULT                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328057
#define RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT_RESULT                RS_SPECIFIC_PUBLIC_ATTR_BASE + 328058
#define RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT_RESULT                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328059
#define RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328060
#define RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT_RESULT                         RS_SPECIFIC_PUBLIC_ATTR_BASE + 328061
#define RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328062
#define RSETL_ATTR_RADIO_MPX_POW_PEAK_LIMIT_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328063
#define RSETL_ATTR_RADIO_OBW_UPPER_LIMIT_RESULT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328257
#define RSETL_ATTR_RADIO_MP_DETECTION_LIMIT_RESULT                          RS_SPECIFIC_PUBLIC_ATTR_BASE + 328064
#define RSETL_ATTR_RADIO_AUDIO_SN_LIMIT_RESULT                              RS_SPECIFIC_PUBLIC_ATTR_BASE + 328065
#define RSETL_ATTR_RADIO_AUDIO_THD_LIMIT_RESULT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328066
#define RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT_RESULT                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328067
#define RSETL_ATTR_TS_GENERATOR_RECORDER_MODE                               RS_SPECIFIC_PUBLIC_ATTR_BASE + 328258
#define RSETL_ATTR_TS_GENERATOR_RECORDER_STATUS                             RS_SPECIFIC_PUBLIC_ATTR_BASE + 328259
#define RSETL_ATTR_TS_GENERATOR_SELECT_FILE                                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328260
#define RSETL_ATTR_TS_GENERATOR_TIMING_DATA_RATE                            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328261
#define RSETL_ATTR_TS_GENERATOR_TIMING_NULLPACKET_STUFFING                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328262
#define RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_START                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328263
#define RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_STOP                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328264
#define RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_POSITION                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328265
#define RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328266
#define RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_WAVEFORM                  RS_SPECIFIC_PUBLIC_ATTR_BASE + 328267
#define RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_AMPLITUDE                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328268
#define RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_FREQUENCY                 RS_SPECIFIC_PUBLIC_ATTR_BASE + 328269
#define RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_CONTINUITY_COUNTER            RS_SPECIFIC_PUBLIC_ATTR_BASE + 328270
#define RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_PCR                           RS_SPECIFIC_PUBLIC_ATTR_BASE + 328271
#define RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_TDT_TOT                       RS_SPECIFIC_PUBLIC_ATTR_BASE + 328272
#define RSETL_ATTR_TS_GENERATOR_INTERFACE_PACKET_LENGTH                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328273
#define RSETL_ATTR_TS_GENERATOR_INTERFACE_SERIAL_OUTPUT                     RS_SPECIFIC_PUBLIC_ATTR_BASE + 328274
#define RSETL_ATTR_TS_RECORDER_INPUT                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 328275
#define RSETL_ATTR_TS_RECORDER_FILE_SIZE                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328276
#define RSETL_ATTR_TS_RECORDER_FILE_NAME                                    RS_SPECIFIC_PUBLIC_ATTR_BASE + 328277
#define RSETL_ATTR_ID_QUERY_RESPONSE                                        RS_SPECIFIC_PUBLIC_ATTR_BASE + 86716

// rsetl_rngUnits
#define RSETL_VAL_UNIT_DBM                                                  0
#define RSETL_VAL_UNIT_DBPW                                                 1
#define RSETL_VAL_UNIT_WATT                                                 2
#define RSETL_VAL_UNIT_DBUV                                                 3
#define RSETL_VAL_UNIT_DBMV                                                 4
#define RSETL_VAL_UNIT_VOLT                                                 5
#define RSETL_VAL_UNIT_DBUA                                                 6
#define RSETL_VAL_UNIT_AMP                                                  7
#define RSETL_VAL_UNIT_DB                                                   8
#define RSETL_VAL_UNIT_DEG                                                  9
#define RSETL_VAL_UNIT_RAD                                                  10
#define RSETL_VAL_UNIT_S                                                    11
#define RSETL_VAL_UNIT_HZ                                                   12
#define RSETL_VAL_UNIT_PCT                                                  13
#define RSETL_VAL_UNIT_UNITLESS                                             14
#define RSETL_VAL_UNIT_DBPT                                                 15

// rsetl_rngTraceMode
#define RSETL_TRAC_MOD_WRITE                                                0
#define RSETL_TRAC_MOD_VIEW                                                 1
#define RSETL_TRAC_MOD_AVER                                                 2
#define RSETL_TRAC_MOD_MAXH                                                 3
#define RSETL_TRAC_MOD_MINH                                                 4
#define RSETL_TRAC_MOD_RMS                                                  5
#define RSETL_TRAC_MOD_BLANK                                                6

// rsetl_rngAmplitudeUnitsRangeTable
#define RSETL_VAL_AMPLITUDE_UNITS_DBM                                       0
#define RSETL_VAL_AMPLITUDE_UNITS_DBMV                                      1
#define RSETL_VAL_AMPLITUDE_UNITS_DBUV                                      2
#define RSETL_VAL_AMPLITUDE_UNITS_VOLT                                      3
#define RSETL_VAL_AMPLITUDE_UNITS_WATT                                      4
#define RSETL_VAL_AMPLITUDE_UNITS_DBPW                                      5
#define RSETL_VAL_AMPLITUDE_UNITS_DBUA                                      6
#define RSETL_VAL_AMPLITUDE_UNITS_AMP                                       7

// rsetl_rngAbsRel
#define RSETL_VAL_ABS                                                       0
#define RSETL_VAL_REL                                                       1

// rsetl_rngESPMode
#define RSETL_VAL_ESP_MODE_AUTO                                             0
#define RSETL_VAL_ESP_MODE_MAN                                              1
#define RSETL_VAL_ESP_MODE_USER                                             2

// rsetl_rngDetectorTypeRangeTable
#define RSETL_VAL_DETECTOR_TYPE_AUTO_PEAK                                   0
#define RSETL_VAL_DETECTOR_TYPE_AVERAGE                                     1
#define RSETL_VAL_DETECTOR_TYPE_MAX_PEAK                                    2
#define RSETL_VAL_DETECTOR_TYPE_MIN_PEAK                                    3
#define RSETL_VAL_DETECTOR_TYPE_SAMPLE                                      4
#define RSETL_VAL_DETECTOR_TYPE_RMS                                         5
#define RSETL_VAL_DETECTOR_TYPE_QPK                                         6

// rsetl_rngDISPConfPreDefColour
#define RSETL_VAL_DISP_COL_BLAC                                             0
#define RSETL_VAL_DISP_COL_BLUE                                             1
#define RSETL_VAL_DISP_COL_BROW                                             2
#define RSETL_VAL_DISP_COL_GRE                                              3
#define RSETL_VAL_DISP_COL_CYAN                                             4
#define RSETL_VAL_DISP_COL_RED                                              5
#define RSETL_VAL_DISP_COL_MAG                                              6
#define RSETL_VAL_DISP_COL_YELL                                             7
#define RSETL_VAL_DISP_COL_WHIT                                             8
#define RSETL_VAL_DISP_COL_DGRA                                             9
#define RSETL_VAL_DISP_COL_LGRA                                             10
#define RSETL_VAL_DISP_COL_LBLU                                             11
#define RSETL_VAL_DISP_COL_LGRE                                             12
#define RSETL_VAL_DISP_COL_LCY                                              13
#define RSETL_VAL_DISP_COL_LRED                                             14
#define RSETL_VAL_DISP_COL_LMAG                                             15

// rsetl_rngHcopyDeviceLang
#define RSETL_VAL_HCOPY_DEVICE_LANG_GDI                                     0
#define RSETL_VAL_HCOPY_DEVICE_LANG_WMF                                     1
#define RSETL_VAL_HCOPY_DEVICE_LANG_EWMF                                    2
#define RSETL_VAL_HCOPY_DEVICE_LANG_BMP                                     3
#define RSETL_VAL_HCOPY_DEVICE_LANG_JPG                                     4
#define RSETL_VAL_HCOPY_DEVICE_LANG_PNG                                     5

// rsetl_rngHcopyDeviceOrient
#define RSETL_VAL_HCOPY_DEVICE_ORIENT_LAND                                  0
#define RSETL_VAL_HCOPY_DEVICE_ORIENT_PORT                                  1

// rsetl_rngDomain
#define RSETL_VAL_FREQ                                                      0
#define RSETL_VAL_TIME                                                      1

// rsetl_rngLinLog
#define RSETL_VAL_VBW_FILT_LIN                                              0
#define RSETL_VAL_VBW_FILT_LOG                                              1

// rsetl_rngServiceInput
#define RSETL_VAL_INPUT_RF                                                  0
#define RSETL_VAL_INPUT_CAL                                                 1
#define RSETL_VAL_INPUT_TG                                                  2

// rsetl_rngAvgType
#define RSETL_VAL_AVG_LIN                                                   0
#define RSETL_VAL_AVG_VID                                                   1

// rsetl_rngDISPSizeWindow
#define RSETL_VAL_DISP_SIZE_LARGE                                           0
#define RSETL_VAL_DISP_SIZE_SMALL                                           1

// rsetl_rngMarkerPeakListSort
#define RSETL_VAL_MARKER_SORT_X                                             0
#define RSETL_VAL_MARKER_SORT_Y                                             1

// rsetl_rngMarkerDemodType
#define RSETL_VAL_MARKER_DEMOD_AM                                           0
#define RSETL_VAL_MARKER_DEMOD_FM                                           1

// rsetl_rngMeasPowerSelect
#define RSETL_VAL_MEAS_POW_ACP                                              0
#define RSETL_VAL_MEAS_POW_CPOW                                             1
#define RSETL_VAL_MEAS_POW_MCAC                                             2
#define RSETL_VAL_MEAS_POW_OBAN                                             3
#define RSETL_VAL_MEAS_POW_CN                                               4
#define RSETL_VAL_MEAS_POW_CN0                                              5

// rsetl_rngMeasPowerStandard
#define RSETL_VAL_MEAS_POW_STD_NONE                                         0
#define RSETL_VAL_MEAS_POW_STD_NADC                                         1
#define RSETL_VAL_MEAS_POW_STD_TETRA                                        2
#define RSETL_VAL_MEAS_POW_STD_PDC                                          3
#define RSETL_VAL_MEAS_POW_STD_PHS                                          4
#define RSETL_VAL_MEAS_POW_STD_CDPD                                         5
#define RSETL_VAL_MEAS_POW_STD_FWCD                                         6
#define RSETL_VAL_MEAS_POW_STD_RWCD                                         7
#define RSETL_VAL_MEAS_POW_STD_F19C                                         8
#define RSETL_VAL_MEAS_POW_STD_R19C                                         9
#define RSETL_VAL_MEAS_POW_STD_FW3G                                         10
#define RSETL_VAL_MEAS_POW_STD_RW3G                                         11
#define RSETL_VAL_MEAS_POW_STD_D2CD                                         12
#define RSETL_VAL_MEAS_POW_STD_S2CD                                         13
#define RSETL_VAL_MEAS_POW_STD_M2CD                                         14
#define RSETL_VAL_MEAS_POW_STD_FIS95A                                       15
#define RSETL_VAL_MEAS_POW_STD_RIS95A                                       16
#define RSETL_VAL_MEAS_POW_STD_FIS95C0                                      17
#define RSETL_VAL_MEAS_POW_STD_RIS95C0                                      18
#define RSETL_VAL_MEAS_POW_STD_FIS95C1                                      19
#define RSETL_VAL_MEAS_POW_STD_RIS95C1                                      20
#define RSETL_VAL_MEAS_POW_STD_FJ008                                        21
#define RSETL_VAL_MEAS_POW_STD_RJ008                                        22
#define RSETL_VAL_MEAS_POW_STD_TCDM                                         23
#define RSETL_VAL_MEAS_POW_STD_FTCDM                                        24
#define RSETL_VAL_MEAS_POW_STD_RTCDM                                        25
#define RSETL_VAL_MEAS_POW_STD_AWL                                          26
#define RSETL_VAL_MEAS_POW_STD_BWL                                          27
#define RSETL_VAL_MEAS_POW_STD_WIM                                          28
#define RSETL_VAL_MEAS_POW_STD_WIBRO                                        29

// rsetl_rngMeasPowerMode
#define RSETL_VAL_MEAS_POW_MODE_WRITE                                       0
#define RSETL_VAL_MEAS_POW_MODE_MAXH                                        1

// rsetl_rngBandFiltType
#define RSETL_VAL_FILT_TYPE_NORM                                            0
#define RSETL_VAL_FILT_TYPE_FFT                                             1
#define RSETL_VAL_FILT_TYPE_CFIL                                            2
#define RSETL_VAL_FILT_TYPE_RRC                                             3
#define RSETL_VAL_FILT_TYPE_PULSE                                           4

// rsetl_rngTFacUnit
#define RSETL_VAL_TFAC_UNIT_DB                                              0
#define RSETL_VAL_TFAC_UNIT_DBM                                             1
#define RSETL_VAL_TFAC_UNIT_DBMV                                            2
#define RSETL_VAL_TFAC_UNIT_DBUV                                            3
#define RSETL_VAL_TFAC_UNIT_DBUVM                                           4
#define RSETL_VAL_TFAC_UNIT_DBUA                                            5
#define RSETL_VAL_TFAC_UNIT_DBUAM                                           6
#define RSETL_VAL_TFAC_UNIT_DBPW                                            7
#define RSETL_VAL_TFAC_UNIT_DBPT                                            8

// rsetl_rngFreqCentLink
#define RSETL_VAL_CENT_FREQ_LINK_OFF                                        0
#define RSETL_VAL_CENT_FREQ_LINK_SPAN                                       1
#define RSETL_VAL_CENT_FREQ_LINK_RBW                                        2

// rsetl_rngFreqMode
#define RSETL_VAL_FREQ_MODE_CW                                              0
#define RSETL_VAL_FREQ_MODE_FIX                                             1
#define RSETL_VAL_FREQ_MODE_SWE                                             2

// rsetl_rngOffOnAuto
#define RSETL_VAL_STATE_OFF                                                 0
#define RSETL_VAL_STATE_ON                                                  1
#define RSETL_VAL_STATE_AUTO                                                2

// rsetl_rngExtMixerHarmonicType
#define RSETL_VAL_EXT_MIX_HARM_ODD                                          0
#define RSETL_VAL_EXT_MIX_HARM_EVEN                                         1
#define RSETL_VAL_EXT_MIX_HARM_EODD                                         2

// rsetl_rngExtMixerHarmBand
#define RSETL_VAL_EXT_MIX_BAND_A                                            0
#define RSETL_VAL_EXT_MIX_BAND_Q                                            1
#define RSETL_VAL_EXT_MIX_BAND_U                                            2
#define RSETL_VAL_EXT_MIX_BAND_V                                            3
#define RSETL_VAL_EXT_MIX_BAND_E                                            4
#define RSETL_VAL_EXT_MIX_BAND_W                                            5
#define RSETL_VAL_EXT_MIX_BAND_F                                            6
#define RSETL_VAL_EXT_MIX_BAND_D                                            7
#define RSETL_VAL_EXT_MIX_BAND_G                                            8
#define RSETL_VAL_EXT_MIX_BAND_Y                                            9
#define RSETL_VAL_EXT_MIX_BAND_J                                            10
#define RSETL_VAL_EXT_MIX_BAND_USER                                         11

// rsetl_rngAdjChAutoSel
#define RSETL_VAL_ADJ_RCHAN_AUTO_MIN                                        0
#define RSETL_VAL_ADJ_RCHAN_AUTO_MAX                                        1
#define RSETL_VAL_ADJ_RCHAN_AUTO_LHIG                                       2

// rsetl_rngAdjPreset
#define RSETL_VAL_ADJ_PRE_ACP                                               0
#define RSETL_VAL_ADJ_PRE_CPOW                                              1
#define RSETL_VAL_ADJ_PRE_MCAC                                              2
#define RSETL_VAL_ADJ_PRE_OBAN                                              3
#define RSETL_VAL_ADJ_PRE_CN                                                4
#define RSETL_VAL_ADJ_PRE_CN0                                               5

// rsetl_rngSourceIntExt
#define RSETL_VAL_SOUR_INT                                                  0
#define RSETL_VAL_SOUR_EXT                                                  1

// rsetl_rngExtGateTrigType
#define RSETL_VAL_EGAT_TRIG_LEV                                             0
#define RSETL_VAL_EGAT_TRIG_EDGE                                            1

// rsetl_rngHcopyDevice
#define RSETL_VAL_HCOPY_DEVICE_MEM                                          0
#define RSETL_VAL_HCOPY_DEVICE_PRN                                          1
#define RSETL_VAL_HCOPY_DEVICE_CLP                                          2

// rsetl_rngPolarity
#define RSETL_VAL_NEG                                                       0
#define RSETL_VAL_POS                                                       1

// rsetl_rngExtGateSource
#define RSETL_VAL_EGAT_SOUR_EXT                                             0
#define RSETL_VAL_EGAT_SOUR_IFP                                             1

// rsetl_rngSweepContMode
#define RSETL_VAL_SWE_MODE_AUTO                                             0
#define RSETL_VAL_SWE_MODE_LIST                                             1
#define RSETL_VAL_SWE_MODE_ESYNC                                            2

// rsetl_rngTriggerSource
#define RSETL_VAL_TRG_IMM                                                   0
#define RSETL_VAL_TRG_EXT                                                   1
#define RSETL_VAL_TRG_IFP                                                   2
#define RSETL_VAL_TRG_VID                                                   3
#define RSETL_VAL_TRG_TV                                                    4

// rsetl_rngFileDecSeparator
#define RSETL_VAL_DEC_SEP_POIN                                              0
#define RSETL_VAL_DEC_SEP_COMMA                                             1

// rsetl_rngMarkerStepSize
#define RSETL_VAL_MARK_STEP_SIZE_STAN                                       0
#define RSETL_VAL_MARK_STEP_SIZE_POIN                                       1

// rsetl_rngMpowFiltType
#define RSETL_VAL_MPOW_FTYPE_NORM                                           0
#define RSETL_VAL_MPOW_FTYPE_CFIL                                           1
#define RSETL_VAL_MPOW_FTYPE_RRC                                            2

// rsetl_rngServiceCombFrequency
#define RSETL_VAL_SERV_COMB_FREQ_COMB1                                      0
#define RSETL_VAL_SERV_COMB_FREQ_COMB64                                     1
#define RSETL_VAL_SERV_COMB_FREQ_COMB65                                     2

// rsetl_rngTraceSpacing
#define RSETL_VAL_TRACE_SPACE_LIN                                           0
#define RSETL_VAL_TRACE_SPACE_LOG                                           1
#define RSETL_VAL_TRACE_SPACE_PCT                                           2
#define RSETL_VAL_TRACE_SPACE_LDB                                           3

// rsetl_rngHcopyPageSettings
#define RSETL_VAL_HCOPY_ACT                                                 0
#define RSETL_VAL_HCOPY_ALL                                                 1
#define RSETL_VAL_HCOPY_SING                                                2

// rsetl_rngInstrMode
#define RSETL_VAL_SAN                                                       0
#define RSETL_VAL_CATV                                                      1
#define RSETL_VAL_TSAN                                                      2
#define RSETL_VAL_TSG                                                       3
#define RSETL_VAL_RAD                                                       4

// rsetl_rngTGenMeasType
#define RSETL_VAL_TRACK_GEN_MEAS_TYPE_TRAN                                  0
#define RSETL_VAL_TRACK_GEN_MEAS_TYPE_REFL                                  1

// rsetl_rngTGenResultType
#define RSETL_VAL_TRACK_GEN_CAL_RES_TYPE_THR                                0
#define RSETL_VAL_TRACK_GEN_CAL_RES_TYPE_OPEN                               1

// rsetl_rngFmTriggerSource
#define RSETL_VAL_TRG_FM                                                    3
#define RSETL_VAL_TRG_AM                                                    4
#define RSETL_VAL_TRG_PM                                                    5
#define RSETL_VAL_TRG_AMR                                                   6

// rsetl_rngCoupling
#define RSETL_VAL_DC                                                        0
#define RSETL_VAL_AC                                                        1

// rsetl_rngAdemPhaseWrap
#define RSETL_VAL_ADEM_UPHAS                                                0
#define RSETL_VAL_ADEM_PHAS                                                 1

// rsetl_rngUnitAngle
#define RSETL_VAL_UNIT_ANGLE_DEG                                            0
#define RSETL_VAL_UNIT_ANGLE_RAD                                            1

// rsetl_rngPmetMeasTime
#define RSETL_VAL_PMET_MEASTIME_NORM                                        0
#define RSETL_VAL_PMET_MEASTIME_SHORT                                       1
#define RSETL_VAL_PMET_MEASTIME_LONG                                        2

// rsetl_rngPmetCoupling
#define RSETL_VAL_PMET_COUP_OFF                                             0
#define RSETL_VAL_PMET_COUP_CENT                                            1
#define RSETL_VAL_PMET_COUP_MARK                                            2

// rsetl_rngCatvMerrZoom
#define RSETL_VAL_CATV_MERR_ZOOM_NONE                                       0
#define RSETL_VAL_CATV_MERR_ZOOM_MERR                                       1
#define RSETL_VAL_CATV_MERR_ZOOM_MERP                                       2
#define RSETL_VAL_CATV_MERR_ZOOM_EVMR                                       3
#define RSETL_VAL_CATV_MERR_ZOOM_EVMP                                       4
#define RSETL_VAL_CATV_MERR_ZOOM_IMB                                        5
#define RSETL_VAL_CATV_MERR_ZOOM_QERR                                       6
#define RSETL_VAL_CATV_MERR_ZOOM_SUP                                        7
#define RSETL_VAL_CATV_MERR_ZOOM_PJIT                                       8
#define RSETL_VAL_CATV_MERR_ZOOM_LEV                                        9
#define RSETL_VAL_CATV_MERR_ZOOM_SNR                                        10
#define RSETL_VAL_CATV_MERR_ZOOM_CPH                                        11
#define RSETL_VAL_CATV_MERR_ZOOM_CNR                                        12
#define RSETL_VAL_CATV_MERR_ZOOM_BVF                                        13
#define RSETL_VAL_CATV_MERR_ZOOM_BVM                                        14
#define RSETL_VAL_CATV_MERR_ZOOM_PILV                                       15
#define RSETL_VAL_CATV_MERR_ZOOM_SPV                                        16
#define RSETL_VAL_CATV_MERR_ZOOM_PAER                                       17
#define RSETL_VAL_CATV_MERR_ZOOM_EPPL                                       18
#define RSETL_VAL_CATV_MERR_ZOOM_ERPL                                       19
#define RSETL_VAL_CATV_MERR_ZOOM_MPLO                                       20
#define RSETL_VAL_CATV_MERR_ZOOM_MRLO                                       21
#define RSETL_VAL_CATV_MERR_ZOOM_MPPL                                       22
#define RSETL_VAL_CATV_MERR_ZOOM_MRPL                                       23

// rsetl_rngCatvOverZoom
#define RSETL_VAL_CATV_OVER_ZOOM_NONE                                       0
#define RSETL_VAL_CATV_OVER_ZOOM_LEV                                        1
#define RSETL_VAL_CATV_OVER_ZOOM_MERR                                       2
#define RSETL_VAL_CATV_OVER_ZOOM_MERP                                       3
#define RSETL_VAL_CATV_OVER_ZOOM_EVMR                                       4
#define RSETL_VAL_CATV_OVER_ZOOM_EVMP                                       5
#define RSETL_VAL_CATV_OVER_ZOOM_BBV                                        6
#define RSETL_VAL_CATV_OVER_ZOOM_BBRS                                       7
#define RSETL_VAL_CATV_OVER_ZOOM_PER                                        8
#define RSETL_VAL_CATV_OVER_ZOOM_PERR                                       9
#define RSETL_VAL_CATV_OVER_ZOOM_CFOF                                       10
#define RSETL_VAL_CATV_OVER_ZOOM_BROF                                       11
#define RSETL_VAL_CATV_OVER_ZOOM_SROF                                       12
#define RSETL_VAL_CATV_OVER_ZOOM_MTBR                                       13
#define RSETL_VAL_CATV_OVER_ZOOM_GINT                                       14
#define RSETL_VAL_CATV_OVER_ZOOM_CRAT                                       15
#define RSETL_VAL_CATV_OVER_ZOOM_TDE                                        16
#define RSETL_VAL_CATV_OVER_ZOOM_CFR                                        17
#define RSETL_VAL_CATV_OVER_ZOOM_BERL                                       18
#define RSETL_VAL_CATV_OVER_ZOOM_BARS                                       19
#define RSETL_VAL_CATV_OVER_ZOOM_EMER                                       20
#define RSETL_VAL_CATV_OVER_ZOOM_BBCH                                       21
#define RSETL_VAL_CATV_OVER_ZOOM_FER                                        22
#define RSETL_VAL_CATV_OVER_ZOOM_FERR                                       23
#define RSETL_VAL_CATV_OVER_ZOOM_ITLD                                       24
#define RSETL_VAL_CATV_OVER_ZOOM_MRLO                                       25
#define RSETL_VAL_CATV_OVER_ZOOM_MRPL                                       26
#define RSETL_VAL_CATV_OVER_ZOOM_LTB                                        27
#define RSETL_VAL_CATV_OVER_ZOOM_MMTB                                       28
#define RSETL_VAL_CATV_OVER_ZOOM_MTB                                        29

// rsetl_rngCatvConstDiagZoom
#define RSETL_VAL_CATV_QUAD_ZOOM_NONE                                       0
#define RSETL_VAL_CATV_QUAD_ZOOM_1                                          1
#define RSETL_VAL_CATV_QUAD_ZOOM_2                                          2
#define RSETL_VAL_CATV_QUAD_ZOOM_3                                          3
#define RSETL_VAL_CATV_QUAD_ZOOM_4                                          4

// rsetl_rngCatvSBand
#define RSETL_VAL_CATV_SBAND_NORM                                           0
#define RSETL_VAL_CATV_SBAND_INV                                            1
#define RSETL_VAL_CATV_SBAND_AUTO                                           2

// rsetl_rngCatvModStandGroupDelay
#define RSETL_VAL_CATV_GDELAY_GENERAL                                       0
#define RSETL_VAL_CATV_GDELAY_GHALF                                         1
#define RSETL_VAL_CATV_GDELAY_AUSTRALIA                                     2
#define RSETL_VAL_CATV_GDELAY_DENMARK                                       3
#define RSETL_VAL_CATV_GDELAY_NEWZELAND                                     4
#define RSETL_VAL_CATV_GDELAY_NORWAY                                        5
#define RSETL_VAL_CATV_GDELAY_SWEDENFULL                                    6
#define RSETL_VAL_CATV_GDELAY_FLAT                                          7
#define RSETL_VAL_CATV_GDELAY_OIRT                                          8
#define RSETL_VAL_CATV_GDELAY_CHINA                                         9
#define RSETL_VAL_CATV_GDELAY_CCIR                                          10
#define RSETL_VAL_CATV_GDELAY_TDF                                           11
#define RSETL_VAL_CATV_GDELAY_FCC                                           12
#define RSETL_VAL_CATV_GDELAY_K1                                            13
#define RSETL_VAL_CATV_GDELAY_OIRT75                                        14
#define RSETL_VAL_CATV_GDELAY_OIRT83                                        15

// rsetl_rngCatvModStandSignalType
#define RSETL_VAL_CATV_SIG_TYPE_ATV                                         0
#define RSETL_VAL_CATV_SIG_TYPE_DTV                                         1

// rsetl_rngCatvAtvMeas
#define RSETL_VAL_ATV_MEAS_ASP                                              0
#define RSETL_VAL_ATV_MEAS_CARR                                             1
#define RSETL_VAL_ATV_MEAS_CN                                               2
#define RSETL_VAL_ATV_MEAS_CSO                                              3
#define RSETL_VAL_ATV_MEAS_CTB                                              4
#define RSETL_VAL_ATV_MEAS_HUM                                              5
#define RSETL_VAL_ATV_MEAS_VMOD                                             6
#define RSETL_VAL_ATV_MEAS_VSC                                              7
#define RSETL_VAL_ATV_MEAS_AVCP                                             8
#define RSETL_VAL_ATV_MEAS_ATVY                                             9
#define RSETL_VAL_ATV_MEAS_ICPM                                             10
#define RSETL_VAL_ATV_MEAS_TTP                                              11
#define RSETL_VAL_ATV_MEAS_STD                                              12
#define RSETL_VAL_ATV_MEAS_SINX                                             13
#define RSETL_VAL_ATV_MEAS_AWF                                              14

// rsetl_rngCatvAtvCarrMeas
#define RSETL_VAL_ATV_MEAS_CARR_CARR                                        0
#define RSETL_VAL_ATV_MEAS_CARR_NOIS                                        1

// rsetl_rngCatvAtvCarrMeasMode
#define RSETL_VAL_ATV_MEAS_MODE_INSERVICE                                   0
#define RSETL_VAL_ATV_MEAS_MODE_OFFSERVICE                                  1
#define RSETL_VAL_ATV_MEAS_MODE_QUIETLINE                                   2

// rsetl_rngCatvAtvRefPowerMode
#define RSETL_VAL_ATV_RPOW_MODE_RCH                                         0
#define RSETL_VAL_ATV_RPOW_MODE_MCH                                         1
#define RSETL_VAL_ATV_RPOW_MODE_MAN                                         2

// rsetl_rngCatvAtvStandard
#define RSETL_VAL_ATV_STAN_BG                                               0
#define RSETL_VAL_ATV_STAN_DK                                               1
#define RSETL_VAL_ATV_STAN_I                                                2
#define RSETL_VAL_ATV_STAN_K1                                               3
#define RSETL_VAL_ATV_STAN_L                                                4
#define RSETL_VAL_ATV_STAN_M                                                5
#define RSETL_VAL_ATV_STAN_N                                                6

// rsetl_rngCatvAtvSoundSystem
#define RSETL_VAL_ATV_AUDIO_FM55NICAM585                                    0
#define RSETL_VAL_ATV_AUDIO_FM55FM5742                                      1
#define RSETL_VAL_ATV_AUDIO_FM55MONO                                        2
#define RSETL_VAL_ATV_AUDIO_FM65NICAM585                                    3
#define RSETL_VAL_ATV_AUDIO_FM65FM6258                                      4
#define RSETL_VAL_ATV_AUDIO_FM65FM6742                                      5
#define RSETL_VAL_ATV_AUDIO_FM65MONO                                        6
#define RSETL_VAL_ATV_AUDIO_FM60NICAM6552                                   7
#define RSETL_VAL_ATV_AUDIO_FM60MONO                                        8
#define RSETL_VAL_ATV_AUDIO_AM65NICAM585                                    9
#define RSETL_VAL_ATV_AUDIO_AM65MONO                                        10
#define RSETL_VAL_ATV_AUDIO_FM45BTSC                                        11
#define RSETL_VAL_ATV_AUDIO_FM45EIA_J                                       12
#define RSETL_VAL_ATV_AUDIO_FM45FM4742                                      13
#define RSETL_VAL_ATV_AUDIO_FM45MONO                                        14

// rsetl_rngCatvAtvColorSystem
#define RSETL_VAL_ATV_COLOR_SYSTEM_PAL                                      0
#define RSETL_VAL_ATV_COLOR_SYSTEM_NTSC                                     1
#define RSETL_VAL_ATV_COLOR_SYSTEM_SECAM                                    2

// rsetl_rngCatvAtvTriggBarLineType
#define RSETL_VAL_ATV_BLIN_TYPE_CCIR17                                      0
#define RSETL_VAL_ATV_BLIN_TYPE_FCC                                         1
#define RSETL_VAL_ATV_BLIN_TYPE_NTC7                                        2

// rsetl_rngCatvResults
#define RSETL_VAL_RES_FAIL                                                  0
#define RSETL_VAL_RES_PASS                                                  1

// rsetl_rngCatvDtvMeas
#define RSETL_VAL_DTV_MEAS_DSP                                              0
#define RSETL_VAL_DTV_MEAS_CONS                                             1
#define RSETL_VAL_DTV_MEAS_MERR                                             2
#define RSETL_VAL_DTV_MEAS_MERF                                             3
#define RSETL_VAL_DTV_MEAS_EPATT                                            4
#define RSETL_VAL_DTV_MEAS_APH                                              5
#define RSETL_VAL_DTV_MEAS_AGR                                              6
#define RSETL_VAL_DTV_MEAS_APD                                              7
#define RSETL_VAL_DTV_MEAS_CCDF                                             8
#define RSETL_VAL_DTV_MEAS_OVER                                             9
#define RSETL_VAL_DTV_MEAS_IQIM                                             10
#define RSETL_VAL_DTV_MEAS_DREC                                             11
#define RSETL_VAL_DTV_MEAS_DVCP                                             12
#define RSETL_VAL_DTV_MEAS_SCOR                                             13
#define RSETL_VAL_DTV_MEAS_EINF                                             14
#define RSETL_VAL_DTV_MEAS_TMID                                             15
#define RSETL_VAL_DTV_MEAS_INGR                                             16
#define RSETL_VAL_DTV_MEAS_EYED                                             17
#define RSETL_VAL_DTV_MEAS_L1_PRE                                           18
#define RSETL_VAL_DTV_MEAS_L1_P1                                            19
#define RSETL_VAL_DTV_MEAS_L1_P2                                            20
#define RSETL_VAL_DTV_MEAS_L1_P3                                            21
#define RSETL_VAL_DTV_MEAS_MER                                              22
#define RSETL_VAL_DTV_MEAS_CFD                                              23
#define RSETL_VAL_DTV_MEAS_CPD                                              24
#define RSETL_VAL_DTV_MEAS_AFIC                                             25
#define RSETL_VAL_DTV_MEAS_FIC1                                             26
#define RSETL_VAL_DTV_MEAS_FIC2                                             27
#define RSETL_VAL_DTV_MEAS_ATPC                                             28
#define RSETL_VAL_DTV_MEAS_TPC1                                             29
#define RSETL_VAL_DTV_MEAS_TPC2                                             30
#define RSETL_VAL_DTV_MEAS_ASER                                             31
#define RSETL_VAL_DTV_MEAS_SERV                                             32
#define RSETL_VAL_DTV_MEAS_MHOV                                             33

// rsetl_rngUnitSecMin
#define RSETL_VAL_UNIT_SEC                                                  0
#define RSETL_VAL_UNIT_MIN                                                  1
#define RSETL_VAL_UNIT_MILE                                                 2

// rsetl_rngCatvDtvFilterAlpha
#define RSETL_VAL_CATV_DTV_ALPHA_R012                                       0
#define RSETL_VAL_CATV_DTV_ALPHA_R013                                       1
#define RSETL_VAL_CATV_DTV_ALPHA_R015                                       2
#define RSETL_VAL_CATV_DTV_ALPHA_R018                                       3
#define RSETL_VAL_CATV_DTV_ALPHA_R0115                                      4

// rsetl_rngCatvDtvStandard
#define RSETL_VAL_DTV_STAN_J83A                                             0
#define RSETL_VAL_DTV_STAN_J83B                                             1
#define RSETL_VAL_DTV_STAN_J83C                                             2
#define RSETL_VAL_DTV_STAN_DMBT                                             3
#define RSETL_VAL_DTV_STAN_DVBT                                             4
#define RSETL_VAL_DTV_STAN_ATSC                                             5
#define RSETL_VAL_DTV_STAN_TDMB                                             6
#define RSETL_VAL_DTV_STAN_ISDBT                                            7
#define RSETL_VAL_DTV_STAN_DVBT2                                            8

// rsetl_rngCatvDtvFormat
#define RSETL_VAL_DTV_FORMAT_QAM4                                           0
#define RSETL_VAL_DTV_FORMAT_QAM4NR                                         1
#define RSETL_VAL_DTV_FORMAT_QAM16                                          2
#define RSETL_VAL_DTV_FORMAT_QAM32                                          3
#define RSETL_VAL_DTV_FORMAT_QAM64                                          4
#define RSETL_VAL_DTV_FORMAT_QAM128                                         5
#define RSETL_VAL_DTV_FORMAT_QAM256                                         6
#define RSETL_VAL_DTV_FORMAT_QPSK                                           7
#define RSETL_VAL_DTV_FORMAT_QAM16NH                                        8
#define RSETL_VAL_DTV_FORMAT_QAM16H1                                        9
#define RSETL_VAL_DTV_FORMAT_QAM16H2                                        10
#define RSETL_VAL_DTV_FORMAT_QAM16H4                                        11
#define RSETL_VAL_DTV_FORMAT_QAM64NH                                        12
#define RSETL_VAL_DTV_FORMAT_QAM64H1                                        13
#define RSETL_VAL_DTV_FORMAT_QAM64H2                                        14
#define RSETL_VAL_DTV_FORMAT_QAM64H4                                        15
#define RSETL_VAL_DTV_FORMAT_QAM512                                         16
#define RSETL_VAL_DTV_FORMAT_QAM1024                                        17
#define RSETL_VAL_DTV_FORMAT_VSB                                            18
#define RSETL_VAL_DTV_FORMAT_BPSK                                           19

// rsetl_rngCatvTvMeas
#define RSETL_VAL_TV_MEAS_TILT                                              0

// rsetl_rngCatvDtvBERSamples
#define RSETL_VAL_DTV_BER_SAMP_1                                            0
#define RSETL_VAL_DTV_BER_SAMP_10                                           1
#define RSETL_VAL_DTV_BER_SAMP_100                                          2
#define RSETL_VAL_DTV_BER_SAMP_1K                                           3
#define RSETL_VAL_DTV_BER_SAMP_10K                                          4
#define RSETL_VAL_DTV_BER_SAMP_100K                                         5
#define RSETL_VAL_DTV_BER_SAMP_1M                                           6

// rsetl_rngDispChanImpulseResponse
#define RSETL_VAL_DISP_CHAN_IMP_RES_MLEV                                    0
#define RSETL_VAL_DISP_CHAN_IMP_RES_PECH                                    1

// rsetl_rngCatvVisionMod
#define RSETL_VAL_CATV_VIS_DET_MPOR                                         0
#define RSETL_VAL_CATV_VIS_DET_SPOR                                         1
#define RSETL_VAL_CATV_VIS_DET_FCON                                         2
#define RSETL_VAL_CATV_VIS_DET_MCON                                         3
#define RSETL_VAL_CATV_VIS_DET_SCON                                         4
#define RSETL_VAL_CATV_VIS_DET_ENV                                          5

// rsetl_rngCatvDtvCodeRate
#define RSETL_VAL_DTV_CODE_RATE_R04                                         0
#define RSETL_VAL_DTV_CODE_RATE_R06                                         1
#define RSETL_VAL_DTV_CODE_RATE_R08                                         2

// rsetl_rngCatvDtvCodeRatePriority
#define RSETL_VAL_DTV_CODE_RATE_PRIOR_R1_2                                  0
#define RSETL_VAL_DTV_CODE_RATE_PRIOR_R2_3                                  1
#define RSETL_VAL_DTV_CODE_RATE_PRIOR_R3_4                                  2
#define RSETL_VAL_DTV_CODE_RATE_PRIOR_R5_6                                  3
#define RSETL_VAL_DTV_CODE_RATE_PRIOR_R7_8                                  4

// rsetl_rngCatvDtvEqualStepSize
#define RSETL_VAL_DTV_EQUAL_SSIZE_COAR                                      0
#define RSETL_VAL_DTV_EQUAL_SSIZE_MED                                       1
#define RSETL_VAL_DTV_EQUAL_SSIZE_FINE                                      2

// rsetl_rngCatvDtvEqualStepSizeShrink
#define RSETL_VAL_DTV_EQUAL_SSIZE_SHRINK_NONE                               0
#define RSETL_VAL_DTV_EQUAL_SSIZE_SHRINK_FAST                               1
#define RSETL_VAL_DTV_EQUAL_SSIZE_SHRINK_SLOW                               2

// rsetl_rngCatvDtvFECSync
#define RSETL_VAL_DTV_FEC_SYNC_FEC                                          0
#define RSETL_VAL_DTV_FEC_SYNC_NFEC                                         1

// rsetl_rngCatvDtvFFTMode
#define RSETL_VAL_DTV_FFT_MODE_F2K                                          0
#define RSETL_VAL_DTV_FFT_MODE_F4K                                          1
#define RSETL_VAL_DTV_FFT_MODE_F8K                                          2
#define RSETL_VAL_DTV_FFT_MODE_F1K                                          3
#define RSETL_VAL_DTV_FFT_MODE_F8KE                                         4
#define RSETL_VAL_DTV_FFT_MODE_F16K                                         5
#define RSETL_VAL_DTV_FFT_MODE_F16E                                         6
#define RSETL_VAL_DTV_FFT_MODE_F32K                                         7
#define RSETL_VAL_DTV_FFT_MODE_F32E                                         8

// rsetl_rngCatvDtvGInterval
#define RSETL_VAL_DTV_GINT_G420                                             0
#define RSETL_VAL_DTV_GINT_G595                                             1
#define RSETL_VAL_DTV_GINT_G945                                             2
#define RSETL_VAL_DTV_GINT_G1_4                                             3
#define RSETL_VAL_DTV_GINT_G1_8                                             4
#define RSETL_VAL_DTV_GINT_G1_16                                            5
#define RSETL_VAL_DTV_GINT_G1_32                                            6
#define RSETL_VAL_DTV_GINT_G1_128                                           7
#define RSETL_VAL_DTV_GINT_G19_128                                          8
#define RSETL_VAL_DTV_GINT_G19_256                                          9
#define RSETL_VAL_DTV_GINT_NONE                                             10

// rsetl_rngCatvDtvInterleaver
#define RSETL_VAL_DTV_INTERLEAVER_NAT                                       0
#define RSETL_VAL_DTV_INTERLEAVER_IND                                       1

// rsetl_rngCatvDtvLDPCMode
#define RSETL_VAL_DTV_LDPC_MODE_NORM                                        0
#define RSETL_VAL_DTV_LDPC_MODE_BYP                                         1

// rsetl_rngCatvDtvLoops
#define RSETL_VAL_DTV_LOOPS_HIGH                                            0
#define RSETL_VAL_DTV_LOOPS_MED                                             1
#define RSETL_VAL_DTV_LOOPS_LOW                                             2

// rsetl_rngCatvDtvCarrierModulation
#define RSETL_VAL_DTV_CARR_MOD_MULT                                         0
#define RSETL_VAL_DTV_CARR_MOD_SING                                         1

// rsetl_rngCatvDtvSystOpt
#define RSETL_VAL_DTV_SOPT_MOB                                              0
#define RSETL_VAL_DTV_SOPT_FAST                                             1
#define RSETL_VAL_DTV_SOPT_SLOW                                             2
#define RSETL_VAL_DTV_SOPT_MED                                              3

// rsetl_rngCatvDtvTSOutput
#define RSETL_VAL_DTV_TSO_HIGH                                              0
#define RSETL_VAL_DTV_TSO_LOW                                               1
#define RSETL_VAL_DTV_TSO_A                                                 2
#define RSETL_VAL_DTV_TSO_B                                                 3
#define RSETL_VAL_DTV_TSO_C                                                 4

// rsetl_rngCatvSound
#define RSETL_VAL_SOUND_A1                                                  0
#define RSETL_VAL_SOUND_A2                                                  1
#define RSETL_VAL_SOUND_ASS                                                 2
#define RSETL_VAL_SOUND_ASST                                                3
#define RSETL_VAL_SOUND_SAP                                                 4
#define RSETL_VAL_SOUND_STER                                                5
#define RSETL_VAL_SOUND_S1                                                  6
#define RSETL_VAL_SOUND_S2                                                  7
#define RSETL_VAL_SOUND_S12                                                 8
#define RSETL_VAL_SOUND_MONO                                                9
#define RSETL_VAL_SOUND_NS1                                                 10
#define RSETL_VAL_SOUND_NS2                                                 11
#define RSETL_VAL_SOUND_NS12                                                12
#define RSETL_VAL_SOUND_NMON                                                13
#define RSETL_VAL_SOUND_FMM                                                 14
#define RSETL_VAL_SOUND_AMM                                                 15

// rsetl_rngCatvDtvIQSource
#define RSETL_VAL_DTV_IQ_SRC_PLO                                            0
#define RSETL_VAL_DTV_IQ_SRC_TPS                                            1
#define RSETL_VAL_DTV_IQ_SRC_P1_SYM                                         2
#define RSETL_VAL_DTV_IQ_SRC_BFD                                            3
#define RSETL_VAL_DTV_IQ_SRC_L1PRE                                          4
#define RSETL_VAL_DTV_IQ_SRC_L1POST                                         5
#define RSETL_VAL_DTV_IQ_SRC_BTD                                            6
#define RSETL_VAL_DTV_IQ_SRC_BDE                                            7
#define RSETL_VAL_DTV_IQ_SRC_ADER                                           8

// rsetl_rngCatvTriggerSource
#define RSETL_VAL_CATV_TRG_IMM                                              0
#define RSETL_VAL_CATV_TRG_EXT                                              1
#define RSETL_VAL_CATV_TRG_IFP                                              2
#define RSETL_VAL_CATV_TRG_VID                                              3
#define RSETL_VAL_CATV_TRG_TV                                               4
#define RSETL_VAL_CATV_TRG_AF                                               5
#define RSETL_VAL_CATV_TRG_FM                                               6
#define RSETL_VAL_CATV_TRG_PM                                               7
#define RSETL_VAL_CATV_TRG_AM                                               8
#define RSETL_VAL_CATV_TRG_AMR                                              9

// rsetl_rngOutputMeasMode
#define RSETL_VAL_OUTP_MEAS_MODE_IF                                         0
#define RSETL_VAL_OUTP_MEAS_MODE_VID                                        1

// rsetl_rngTLinLog
#define RSETL_VAL_LIN                                                       0
#define RSETL_VAL_LOG                                                       1

// rsetl_rngTrgTVerticalSync
#define RSETL_VAL_TRG_TV_VSYNC_ALL                                          0
#define RSETL_VAL_TRG_TV_VSYNC_ODD                                          1
#define RSETL_VAL_TRG_TV_VSYNC_EVEN                                         2

// rsetl_rngTrgTVPolarity
#define RSETL_VAL_TRG_TV_POLARITY_NEG                                       0
#define RSETL_VAL_TRG_TV_POLARITY_POS                                       1

// rsetl_rngCatvDtvMLogMode
#define RSETL_VAL_DTV_MLOG_MODE_LEV                                         0
#define RSETL_VAL_DTV_MLOG_MODE_CFOF                                        1
#define RSETL_VAL_DTV_MLOG_MODE_BROF                                        2
#define RSETL_VAL_DTV_MLOG_MODE_MTB                                         3
#define RSETL_VAL_DTV_MLOG_MODE_BBV                                         4
#define RSETL_VAL_DTV_MLOG_MODE_BBRS                                        5
#define RSETL_VAL_DTV_MLOG_MODE_MERR                                        6
#define RSETL_VAL_DTV_MLOG_MODE_EVMR                                        7
#define RSETL_VAL_DTV_MLOG_MODE_MERP                                        8
#define RSETL_VAL_DTV_MLOG_MODE_EVMP                                        9
#define RSETL_VAL_DTV_MLOG_MODE_PER                                         10
#define RSETL_VAL_DTV_MLOG_MODE_PERR                                        11
#define RSETL_VAL_DTV_MLOG_MODE_BERL                                        12
#define RSETL_VAL_DTV_MLOG_MODE_BARS                                        13

// rsetl_rngCatvDtvMLogSpan
#define RSETL_VAL_DTV_MLOG_SPAN_T1MIN                                       0
#define RSETL_VAL_DTV_MLOG_SPAN_T2MIN                                       1
#define RSETL_VAL_DTV_MLOG_SPAN_T5MIN                                       2
#define RSETL_VAL_DTV_MLOG_SPAN_T10MIN                                      3
#define RSETL_VAL_DTV_MLOG_SPAN_T20MIN                                      4
#define RSETL_VAL_DTV_MLOG_SPAN_T30MIN                                      5
#define RSETL_VAL_DTV_MLOG_SPAN_T1H                                         6
#define RSETL_VAL_DTV_MLOG_SPAN_T2H                                         7
#define RSETL_VAL_DTV_MLOG_SPAN_T5H                                         8
#define RSETL_VAL_DTV_MLOG_SPAN_T10H                                        9
#define RSETL_VAL_DTV_MLOG_SPAN_T1D                                         10
#define RSETL_VAL_DTV_MLOG_SPAN_T2D                                         11
#define RSETL_VAL_DTV_MLOG_SPAN_T5D                                         12
#define RSETL_VAL_DTV_MLOG_SPAN_T10D                                        13
#define RSETL_VAL_DTV_MLOG_SPAN_T20D                                        14
#define RSETL_VAL_DTV_MLOG_SPAN_T50D                                        15
#define RSETL_VAL_DTV_MLOG_SPAN_T100D                                       16
#define RSETL_VAL_DTV_MLOG_SPAN_T200D                                       17
#define RSETL_VAL_DTV_MLOG_SPAN_T500D                                       18
#define RSETL_VAL_DTV_MLOG_SPAN_T1000D                                      19

// rsetl_rngCatvDtvTimeRangeMode
#define RSETL_VAL_DTV_RANGE_TIME_MODE_NORM                                  0
#define RSETL_VAL_DTV_RANGE_TIME_MODE_EXT                                   1

// rsetl_rngCatvDtvChanBwid
#define RSETL_VAL_DTV_CHAN_BWID_5MHZ                                        0
#define RSETL_VAL_DTV_CHAN_BWID_6MHZ                                        1
#define RSETL_VAL_DTV_CHAN_BWID_7MHZ                                        2
#define RSETL_VAL_DTV_CHAN_BWID_8MHZ                                        3

// rsetl_rngCatvAttMode
#define RSETL_VAL_ATT_MODE_LNO                                              0
#define RSETL_VAL_ATT_MODE_NORM                                             1
#define RSETL_VAL_ATT_MODE_LDIS                                             2

// rsetl_rngCatvPNSequence
#define RSETL_VAL_DTV_PN_SEQ_VAR                                            0
#define RSETL_VAL_DTV_PN_SEQ_CONS                                           1

// rsetl_rngCatvDtvFICSync
#define RSETL_VAL_DTV_FIC_SYNC_FIC                                          0
#define RSETL_VAL_DTV_FIC_SYNC_NFIC                                         1

// rsetl_rngCatvDtvMPGSync
#define RSETL_VAL_DTV_MPEG_SYNC_MPG                                         0
#define RSETL_VAL_DTV_MPEG_SYNC_NMPG                                        1

// rsetl_rngCatvDtvEquMode
#define RSETL_VAL_DTV_EQU_MODE_OFF                                          0
#define RSETL_VAL_DTV_EQU_MODE_ON                                           1
#define RSETL_VAL_DTV_EQU_MODE_FRE                                          2

// rsetl_rngCatvDtvNotchBW
#define RSETL_VAL_DTV_NOTCH_BW_100                                          0
#define RSETL_VAL_DTV_NOTCH_BW_1K                                           1
#define RSETL_VAL_DTV_NOTCH_BW_10K                                          2
#define RSETL_VAL_DTV_NOTCH_BW_100K                                         3

// rsetl_rngCatvDtvProtLevel
#define RSETL_VAL_DTV_PROT_LEV_PL1A                                         0
#define RSETL_VAL_DTV_PROT_LEV_PL2A                                         1
#define RSETL_VAL_DTV_PROT_LEV_PL3A                                         2
#define RSETL_VAL_DTV_PROT_LEV_PL4A                                         3
#define RSETL_VAL_DTV_PROT_LEV_PL1B                                         4
#define RSETL_VAL_DTV_PROT_LEV_PL2B                                         5
#define RSETL_VAL_DTV_PROT_LEV_PL3B                                         6
#define RSETL_VAL_DTV_PROT_LEV_PL4B                                         7
#define RSETL_VAL_DTV_PROT_LEV_PL1                                          8
#define RSETL_VAL_DTV_PROT_LEV_PL2                                          9
#define RSETL_VAL_DTV_PROT_LEV_PL3                                          10
#define RSETL_VAL_DTV_PROT_LEV_PL4                                          11
#define RSETL_VAL_DTV_PROT_LEV_PL5                                          12

// rsetl_rngCatvSoundMode
#define RSETL_VAL_CATV_SOUND_ICAR                                           0
#define RSETL_VAL_CATV_SOUND_SCAR                                           1

// rsetl_rngCatvVideoClamp
#define RSETL_VAL_CATV_VIDEO_HARD                                           0
#define RSETL_VAL_CATV_VIDEO_SOFT                                           1

// rsetl_rngCatvVideoGenIFOut
#define RSETL_VAL_CATV_VIDEO_IF_OUT_IFS                                     0
#define RSETL_VAL_CATV_VIDEO_IF_OUT_CCVS                                    1

// rsetl_rngCatvVideoTestPattern
#define RSETL_VAL_CATV_VIDEO_PATT_CBAR75                                    0
#define RSETL_VAL_CATV_VIDEO_PATT_CBAR100                                   1
#define RSETL_VAL_CATV_VIDEO_PATT_WHITE                                     2
#define RSETL_VAL_CATV_VIDEO_PATT_BLACK                                     3
#define RSETL_VAL_CATV_VIDEO_PATT_FUBK                                      4
#define RSETL_VAL_CATV_VIDEO_PATT_V15KHZ                                    5
#define RSETL_VAL_CATV_VIDEO_PATT_V250KHZ                                   6
#define RSETL_VAL_CATV_VIDEO_PATT_RFIELD                                    7
#define RSETL_VAL_CATV_VIDEO_PATT_USER1                                     8
#define RSETL_VAL_CATV_VIDEO_PATT_USER2                                     9
#define RSETL_VAL_CATV_VIDEO_PATT_USER3                                     10
#define RSETL_VAL_CATV_VIDEO_PATT_USER4                                     11
#define RSETL_VAL_CATV_VIDEO_PATT_USER5                                     12

// rsetl_rngCatvTestSignal
#define RSETL_VAL_CATV_TEST_SIGNAL_T17C                                     0
#define RSETL_VAL_CATV_TEST_SIGNAL_T15K                                     1
#define RSETL_VAL_CATV_TEST_SIGNAL_T250                                     2
#define RSETL_VAL_CATV_TEST_SIGNAL_T184                                     3
#define RSETL_VAL_CATV_TEST_SIGNAL_T186                                     4
#define RSETL_VAL_CATV_TEST_SIGNAL_T330                                     5
#define RSETL_VAL_CATV_TEST_SIGNAL_T331                                     6
#define RSETL_VAL_CATV_TEST_SIGNAL_TBUR                                     7
#define RSETL_VAL_CATV_TEST_SIGNAL_TCBN                                     8
#define RSETL_VAL_CATV_TEST_SIGNAL_TCPF                                     9
#define RSETL_VAL_CATV_TEST_SIGNAL_TCPN                                     10
#define RSETL_VAL_CATV_TEST_SIGNAL_TMOD                                     11
#define RSETL_VAL_CATV_TEST_SIGNAL_TMUL                                     12
#define RSETL_VAL_CATV_TEST_SIGNAL_TQU                                      13
#define RSETL_VAL_CATV_TEST_SIGNAL_TSIN                                     14
#define RSETL_VAL_CATV_TEST_SIGNAL_TSYN                                     15
#define RSETL_VAL_CATV_TEST_SIGNAL_TTTP                                     16
#define RSETL_VAL_CATV_TEST_SIGNAL_TUK1                                     17
#define RSETL_VAL_CATV_TEST_SIGNAL_TUK2                                     18
#define RSETL_VAL_CATV_TEST_SIGNAL_TUK                                      19

// rsetl_rngSystemPower
#define RSETL_VAL_SYST_POWER_AC                                             0
#define RSETL_VAL_SYST_POWER_DC                                             1
#define RSETL_VAL_SYST_POWER_BATT                                           2

// rsetl_rngDispWindowMode
#define RSETL_VAL_DISP_MODE_ETF                                             0

// rsetl_rngCATVMeasMode
#define RSETL_VAL_CATV_MEAS_MODE_ATV                                        0
#define RSETL_VAL_CATV_MEAS_MODE_DTV                                        1
#define RSETL_VAL_CATV_MEAS_MODE_RAD                                        2

// rsetl_rngCATVWavParam
#define RSETL_VAL_ATV_VME_LBAR                                              0
#define RSETL_VAL_ATV_VME_SARB                                              1
#define RSETL_VAL_ATV_VME_BARB                                              2
#define RSETL_VAL_ATV_VME_CLDP                                              3
#define RSETL_VAL_ATV_VME_CLGB                                              4
#define RSETL_VAL_ATV_VME_CLGP                                              5
#define RSETL_VAL_ATV_VME_BD                                                6
#define RSETL_VAL_ATV_VME_TTPA                                              7
#define RSETL_VAL_ATV_VME_TTPK                                              8
#define RSETL_VAL_ATV_VME_TILT                                              9
#define RSETL_VAL_ATV_VME_STRE                                              10
#define RSETL_VAL_ATV_VME_STFE                                              11
#define RSETL_VAL_ATV_VME_LTD                                               12
#define RSETL_VAL_ATV_VME_CLIP                                              13
#define RSETL_VAL_ATV_VME_CLI3                                              14
#define RSETL_VAL_ATV_VME_GPPC                                              15
#define RSETL_VAL_ATV_VME_PPPC                                              16
#define RSETL_VAL_ATV_VME_LNL                                               17
#define RSETL_VAL_ATV_VME_DGP                                               23
#define RSETL_VAL_ATV_VME_DGN                                               24
#define RSETL_VAL_ATV_VME_DPP                                               30
#define RSETL_VAL_ATV_VME_DPN                                               31
#define RSETL_VAL_ATV_VME_ICPH                                              37
#define RSETL_VAL_ATV_VME_ICPL                                              38
#define RSETL_VAL_ATV_VME_MRB                                               46
#define RSETL_VAL_ATV_VME_M05P                                              47
#define RSETL_VAL_ATV_VME_M10P                                              48
#define RSETL_VAL_ATV_VME_M20P                                              49
#define RSETL_VAL_ATV_VME_M40P                                              50
#define RSETL_VAL_ATV_VME_M48P                                              51
#define RSETL_VAL_ATV_VME_M58P                                              52
#define RSETL_VAL_ATV_VME_NRB                                               53
#define RSETL_VAL_ATV_VME_N05P                                              54
#define RSETL_VAL_ATV_VME_N15P                                              55
#define RSETL_VAL_ATV_VME_N30P                                              56
#define RSETL_VAL_ATV_VME_N44P                                              57
#define RSETL_VAL_ATV_VME_SXAP                                              58
#define RSETL_VAL_ATV_VME_SXAN                                              59
#define RSETL_VAL_ATV_VME_SXGP                                              60
#define RSETL_VAL_ATV_VME_SXGN                                              61
#define RSETL_VAL_ATV_VME_FRB                                               62
#define RSETL_VAL_ATV_VME_F05P                                              63
#define RSETL_VAL_ATV_VME_F12P                                              64
#define RSETL_VAL_ATV_VME_F20P                                              65
#define RSETL_VAL_ATV_VME_F30P                                              66
#define RSETL_VAL_ATV_VME_F35P                                              67
#define RSETL_VAL_ATV_VME_F41P                                              68
#define RSETL_VAL_ATV_VME_TRB                                               69
#define RSETL_VAL_ATV_VME_T05P                                              70
#define RSETL_VAL_ATV_VME_T10P                                              71
#define RSETL_VAL_ATV_VME_T20P                                              72
#define RSETL_VAL_ATV_VME_T30P                                              73
#define RSETL_VAL_ATV_VME_T35P                                              74
#define RSETL_VAL_ATV_VME_T42P                                              75

// rsetl_rngCATVOOBEMaskType
#define RSETL_VAL_DTV_MASK_TYPE_CRIT                                        0
#define RSETL_VAL_DTV_MASK_TYPE_SUB                                         1
#define RSETL_VAL_DTV_MASK_TYPE_NONE                                        2
#define RSETL_VAL_DTV_MASK_TYPE_C1                                          3
#define RSETL_VAL_DTV_MASK_TYPE_C2                                          4
#define RSETL_VAL_DTV_MASK_TYPE_C3                                          5
#define RSETL_VAL_DTV_MASK_TYPE_C4                                          6

// rsetl_rngCATVOOBECountry
#define RSETL_VAL_DTV_COUNTRY_JAPAN                                         0
#define RSETL_VAL_DTV_COUNTRY_BRAZIL                                        1

// rsetl_rngCATVEyeDiagramTimeSpan
#define RSETL_VAL_DTV_TIME_SPAN_S1_4                                        0
#define RSETL_VAL_DTV_TIME_SPAN_S1_2                                        1
#define RSETL_VAL_DTV_TIME_SPAN_S1                                          2
#define RSETL_VAL_DTV_TIME_SPAN_S2                                          3
#define RSETL_VAL_DTV_TIME_SPAN_S3                                          4
#define RSETL_VAL_DTV_TIME_SPAN_S4                                          5
#define RSETL_VAL_DTV_TIME_SPAN_S5                                          6
#define RSETL_VAL_DTV_TIME_SPAN_S6                                          7
#define RSETL_VAL_DTV_TIME_SPAN_S7                                          8
#define RSETL_VAL_DTV_TIME_SPAN_S8                                          9

// rsetl_rngCATVISDBTConstSelect
#define RSETL_VAL_DTV_CONS_SEL_SUM                                          0
#define RSETL_VAL_DTV_CONS_SEL_A                                            1
#define RSETL_VAL_DTV_CONS_SEL_B                                            2
#define RSETL_VAL_DTV_CONS_SEL_C                                            3
#define RSETL_VAL_DTV_CONS_SEL_ABC                                          4

// rsetl_rngCATVISDBTXAxisUnit
#define RSETL_VAL_DTV_X_AXIS_UNIT_BOTH                                      0
#define RSETL_VAL_DTV_X_AXIS_UNIT_CARR                                      1
#define RSETL_VAL_DTV_X_AXIS_UNIT_SEG                                       2

// rsetl_rngCATVISDBTCodeRate
#define RSETL_VAL_DTV_FUNC_CODE_RATE_R1_2                                   1
#define RSETL_VAL_DTV_FUNC_CODE_RATE_R2_3                                   2
#define RSETL_VAL_DTV_FUNC_CODE_RATE_R3_4                                   3
#define RSETL_VAL_DTV_FUNC_CODE_RATE_R5_6                                   4
#define RSETL_VAL_DTV_FUNC_CODE_RATE_R7_8                                   5
#define RSETL_VAL_NA                                                        0
#define RSETL_VAL_NAN                                                       -1

// rsetl_rngCATVISDBTModulation
#define RSETL_VAL_DTV_MODUL_QPSK                                            1
#define RSETL_VAL_DTV_MODUL_DQPSK                                           2
#define RSETL_VAL_DTV_MODUL_QAM16                                           3
#define RSETL_VAL_DTV_MODUL_QAM64                                           4

// rsetl_rngCATVISDBTFFTWindowPosition
#define RSETL_VAL_DTV_WPOS_AUTO                                             0
#define RSETL_VAL_DTV_WPOS_MAN                                              1

// rsetl_rngRadioMeas
#define RSETL_VAL_RADIO_MEAS_SPECTRUM                                       0
#define RSETL_VAL_RADIO_MEAS_OVERVIEW                                       1
#define RSETL_VAL_RADIO_MEAS_AUDIO_SPECTRUM                                 2
#define RSETL_VAL_RADIO_MEAS_AUDIO_SCOPE                                    3
#define RSETL_VAL_RADIO_MEAS_AUDIO_LEVEL                                    4
#define RSETL_VAL_RADIO_MEAS_MPX_POWER                                      5
#define RSETL_VAL_RADIO_MEAS_MPX_DEV_DISTR                                  6
#define RSETL_VAL_RADIO_MEAS_MULTIPATH                                      7
#define RSETL_VAL_RADIO_MEAS_THD                                            8
#define RSETL_VAL_RADIO_MEAS_DFD                                            9
#define RSETL_VAL_RADIO_MEAS_SN                                             10
#define RSETL_VAL_RADIO_MEAS_CROSSTALK                                      11
#define RSETL_VAL_RADIO_MEAS_FREQ_RESPONSE                                  12
#define RSETL_VAL_RADIO_MEAS_RDS                                            13
#define RSETL_VAL_RADIO_MEAS_LOG                                            14
#define RSETL_VAL_RADIO_MEAS_OBW                                            15
#define RSETL_VAL_RADIO_MEAS_DVI                                            16

// rsetl_rngRadioStandard
#define RSETL_VAL_RADIO_FM_STEREO                                           0
#define RSETL_VAL_RADIO_FM_MONO                                             1

// rsetl_rngRadioBandwidth
#define RSETL_VAL_RADIO_BW_150K                                             0
#define RSETL_VAL_RADIO_BW_200K                                             1
#define RSETL_VAL_RADIO_BW_250K                                             2
#define RSETL_VAL_RADIO_BW_300K                                             3
#define RSETL_VAL_RADIO_BW_350K                                             4
#define RSETL_VAL_RADIO_BW_400K                                             5

// rsetl_rngRadioData
#define RSETL_VAL_RADIO_DATA_NONE                                           0
#define RSETL_VAL_RADIO_DATA_RDS                                            1
#define RSETL_VAL_RADIO_DATA_DARC                                           2

// rsetl_rngRadioSCA
#define RSETL_VAL_RADIO_SCA_OFF                                             0
#define RSETL_VAL_RADIO_SCA_NARROW                                          1
#define RSETL_VAL_RADIO_SCA_WIDE                                            2

// rsetl_rngRadioZoom
#define RSETL_VAL_RADIO_ZOOM_NONE                                           0
#define RSETL_VAL_RADIO_ZOOM_LEVEL                                          1
#define RSETL_VAL_RADIO_ZOOM_CF_OFFSET                                      2
#define RSETL_VAL_RADIO_ZOOM_MPX_DEV                                        3
#define RSETL_VAL_RADIO_ZOOM_L_DEV                                          4
#define RSETL_VAL_RADIO_ZOOM_R_DEV                                          5
#define RSETL_VAL_RADIO_ZOOM_M_DEV                                          6
#define RSETL_VAL_RADIO_ZOOM_S_DEV                                          7
#define RSETL_VAL_RADIO_ZOOM_PILOT_DEV                                      8
#define RSETL_VAL_RADIO_ZOOM_AM_MOD_DEPTH                                   9
#define RSETL_VAL_RADIO_ZOOM_PILOT_FREQ_OFFSET                              10
#define RSETL_VAL_RADIO_ZOOM_PILOT_PHA_OFFSET                               11
#define RSETL_VAL_RADIO_ZOOM_RDS_DEV                                        12
#define RSETL_VAL_RADIO_ZOOM_RDS_FREQ_OFFSET                                13
#define RSETL_VAL_RADIO_ZOOM_RDS_PHA_OFFSET                                 14
#define RSETL_VAL_RADIO_ZOOM_RDS_BER                                        15
#define RSETL_VAL_RADIO_ZOOM_DARC_DEV                                       16
#define RSETL_VAL_RADIO_ZOOM_SCA_CARR_DEV                                   17
#define RSETL_VAL_RADIO_ZOOM_SCA_OFFSET                                     18
#define RSETL_VAL_RADIO_ZOOM_SCA_DEV                                        19

// rsetl_rngRadioType
#define RSETL_VAL_FREQ_RESPONSE_ARMS                                        0
#define RSETL_VAL_FREQ_RESPONSE_ASEL                                        1
#define RSETL_VAL_FREQ_RESPONSE_LRBA                                        2
#define RSETL_VAL_FREQ_RESPONSE_PHASE                                       3
#define RSETL_VAL_FREQ_RESPONSE_APH                                         4

// rsetl_rngCrosstalkType
#define RSETL_VAL_CROSSTALK_LINEAR                                          0
#define RSETL_VAL_CROSSTALK_NO_LINEAR                                       1
#define RSETL_VAL_CROSSTALK_COMBINED                                        2

// rsetl_rngCrosstalkReference
#define RSETL_VAL_CROSSTALK_REF_LR                                          0
#define RSETL_VAL_CROSSTALK_REF_L                                           1
#define RSETL_VAL_CROSSTALK_REF_R                                           2
#define RSETL_VAL_CROSSTALK_REF_MS                                          3
#define RSETL_VAL_CROSSTALK_REF_M                                           4
#define RSETL_VAL_CROSSTALK_REF_S                                           5
#define RSETL_VAL_CROSSTALK_REF_RDEV                                        6

// rsetl_rngRadioSignalPath
#define RSETL_VAL_RADIO_PATH_MPX                                            0
#define RSETL_VAL_RADIO_PATH_AM                                             1
#define RSETL_VAL_RADIO_PATH_LR                                             2
#define RSETL_VAL_RADIO_PATH_L                                              3
#define RSETL_VAL_RADIO_PATH_R                                              4
#define RSETL_VAL_RADIO_PATH_MS                                             5
#define RSETL_VAL_RADIO_PATH_M                                              6
#define RSETL_VAL_RADIO_PATH_S                                              7
#define RSETL_VAL_RADIO_PATH_PILOT                                          8
#define RSETL_VAL_RADIO_PATH_RDS_SC                                         9
#define RSETL_VAL_RADIO_PATH_DARC_SC                                        10
#define RSETL_VAL_RADIO_PATH_SCA_SC                                         11
#define RSETL_VAL_RADIO_PATH_SCA                                            12

// rsetl_rngRadioDeemphasis
#define RSETL_VAL_RADIO_DEEMPHASIS_OFF                                      0
#define RSETL_VAL_RADIO_DEEMPHASIS_D50                                      1
#define RSETL_VAL_RADIO_DEEMPHASIS_D75                                      2

// rsetl_rngRadioAGenType
#define RSETL_VAL_AUDIO_GEN_ANALOG                                          0
#define RSETL_VAL_AUDIO_GEN_MPX                                             1
#define RSETL_VAL_AUDIO_GEN_ALR                                             2

// rsetl_rngRadioAGenSignal
#define RSETL_VAL_AUDIO_SIG_OFF                                             0
#define RSETL_VAL_AUDIO_SIG_AF                                              1
#define RSETL_VAL_AUDIO_SIG_L                                               2
#define RSETL_VAL_AUDIO_SIG_R                                               3
#define RSETL_VAL_AUDIO_SIG_LGR                                             4
#define RSETL_VAL_AUDIO_SIG_LMR                                             5
#define RSETL_VAL_AUDIO_SIG_LUR                                             6
#define RSETL_VAL_AUDIO_SIG_SCA                                             7

// rsetl_rngRadioAGenConfig
#define RSETL_VAL_AUDIO_CON_LRM                                             0
#define RSETL_VAL_AUDIO_CON_MRN                                             1

// rsetl_rngRadioAGenAmplitude
#define RSETL_VAL_AUDIO_AMP_LEVEL                                           0
#define RSETL_VAL_AUDIO_AMP_VOLTAGE                                         1
#define RSETL_VAL_AUDIO_AMP_DUT                                             2

// rsetl_rngRadioAGenWaveform
#define RSETL_VAL_AUDIO_SINGLE                                              0
#define RSETL_VAL_AUDIO_DUAL_CONST                                          1
#define RSETL_VAL_AUDIO_DUAL_IND                                            2

// rsetl_rngRadioPhasis
#define RSETL_VAL_AUDIO_PHASIS_OFF                                          0
#define RSETL_VAL_AUDIO_PHASIS_D50                                          1
#define RSETL_VAL_AUDIO_PHASIS_D75                                          2
#define RSETL_VAL_AUDIO_PHASIS_D100                                         3
#define RSETL_VAL_AUDIO_PHASIS_D150                                         4

// rsetl_rngRadioPowPeakMeas
#define RSETL_VAL_RADIO_MPX_POWER                                           0
#define RSETL_VAL_RADIO_PEAK_DEVIATION                                      1
#define RSETL_VAL_RADIO_MPX_POWER_PEAK                                      2

// rsetl_rngRadioOutSignal
#define RSETL_VAL_RADIO_OUTPUT_AUTO                                         0
#define RSETL_VAL_RADIO_OUTPUT_MONO                                         1
#define RSETL_VAL_RADIO_OUTPUT_STEREO                                       2
#define RSETL_VAL_RADIO_OUTPUT_MS                                           3
#define RSETL_VAL_RADIO_OUTPUT_GENERATOR                                    4

// rsetl_rngRadioOutCCVS
#define RSETL_VAL_RADIO_OUTPUT_CCVS_OFF                                     0
#define RSETL_VAL_RADIO_OUTPUT_CCVS_MPX                                     1
#define RSETL_VAL_RADIO_OUTPUT_CCVS_AES_EBU                                 2
#define RSETL_VAL_RADIO_OUTPUT_CCVS_PILOT                                   3
#define RSETL_VAL_RADIO_OUTPUT_CCVS_RDS                                     4
#define RSETL_VAL_RADIO_OUTPUT_CCVS_DARC                                    5
#define RSETL_VAL_RADIO_OUTPUT_CCVS_SCA                                     6

// rsetl_rngDTVEchoOffMode
#define RSETL_VAL_STATE_MAN                                                 3

// rsetl_rngDTVDataMode
#define RSETL_VAL_DTV_AUTO                                                  0
#define RSETL_VAL_DTV_MANUAL                                                1

// rsetl_rngDTVDVBSystem
#define RSETL_VAL_DTV_TS_SISO                                               0
#define RSETL_VAL_DTV_TS_MISO                                               1

// rsetl_rngDTVDVBPilPat
#define RSETL_VAL_DTV_PILOT_PP1                                             1
#define RSETL_VAL_DTV_PILOT_PP2                                             2
#define RSETL_VAL_DTV_PILOT_PP3                                             3
#define RSETL_VAL_DTV_PILOT_PP4                                             4
#define RSETL_VAL_DTV_PILOT_PP5                                             5
#define RSETL_VAL_DTV_PILOT_PP6                                             6
#define RSETL_VAL_DTV_PILOT_PP7                                             7

// rsetl_rngDTVPLPPayload
#define RSETL_VAL_DTV_PLP_TS                                                0
#define RSETL_VAL_DTV_PLP_GFPS                                              1
#define RSETL_VAL_DTV_PLP_GCS                                               2
#define RSETL_VAL_DTV_PLP_GSE                                               3

// rsetl_rngDTVPLPCodeRate
#define RSETL_VAL_DTV_CODE_RATE_12                                          0
#define RSETL_VAL_DTV_CODE_RATE_35                                          1
#define RSETL_VAL_DTV_CODE_RATE_23                                          2
#define RSETL_VAL_DTV_CODE_RATE_34                                          3
#define RSETL_VAL_DTV_CODE_RATE_45                                          4
#define RSETL_VAL_DTV_CODE_RATE_56                                          5

// rsetl_rngDTVPLPModulation
#define RSETL_VAL_DTV_PLP_MOD_QPSK                                          0
#define RSETL_VAL_DTV_PLP_MOD_QAM16                                         1
#define RSETL_VAL_DTV_PLP_MOD_QAM64                                         2
#define RSETL_VAL_DTV_PLP_MOD_QAM256                                        3

// rsetl_rngDTVPLPFECType
#define RSETL_VAL_DTV_PLP_FEC_SHORT                                         0
#define RSETL_VAL_DTV_PLP_FEC_NORMAL                                        1

// rsetl_rngDTVTransSyst
#define RSETL_VAL_DVBT2_SISO                                                0
#define RSETL_VAL_DVBT2_MISO                                                1
#define RSETL_VAL_DVBT2_NTO2                                                2

// rsetl_rngDTVConstelation
#define RSETL_VAL_DVBT2_BPSK                                                0
#define RSETL_VAL_DVBT2_QPSK                                                1
#define RSETL_VAL_DVBT2_QAM16                                               2
#define RSETL_VAL_DVBT2_QAM64                                               3

// rsetl_rngDTVCodeRate
#define RSETL_VAL_DVBT2_RESERVED                                            -1
#define RSETL_VAL_DVBT2_POST_CODE_RATE_1_2                                  0

// rsetl_rngDTVFECType
#define RSETL_VAL_DVBT2_FEC_SHORT                                           0

// rsetl_rngDTVPAPR
#define RSETL_VAL_DVBT2_PAPR_NONE                                           0
#define RSETL_VAL_DVBT2_PAPR_ACE                                            1
#define RSETL_VAL_DVBT2_PAPR_TR                                             2
#define RSETL_VAL_DVBT2_PAPR_ACTR                                           3
#define RSETL_VAL_DVBT2_PAPR_LAPT                                           4
#define RSETL_VAL_DVBT2_PAPR_LATR                                           5
#define RSETL_VAL_DVBT2_PAPR_LAAC                                           6
#define RSETL_VAL_DVBT2_PAPR_LAAT                                           7

// rsetl_rngCATVGetDigitalTVCodeRate
#define RSETL_VAL_DTV_CODE_RATE_PRIOR_R3_5                                  4
#define RSETL_VAL_DTV_CODE_RATE_PRIOR_R4_5                                  5
#define RSETL_VAL_DTV_CODE_RATE_PRIOR_RES                                   6

// rsetl_rngCATVGetDigitalTVCFrame
#define RSETL_VAL_CATV_CONTROL_FRAME_UNDEFINED                              -1
#define RSETL_VAL_CATV_CONTROL_FRAME_NOT_PRESENT                            0
#define RSETL_VAL_CATV_CONTROL_FRAME_PRESENT                                1

// rsetl_rngCATVDTVL1StreamTypeResult
#define RSETL_VAL_DVBT2_STYPE_TS_ONLY                                       0
#define RSETL_VAL_DVBT2_STYPE_GENERIC                                       1
#define RSETL_VAL_DVBT2_STYPE_TS_GEN                                        2

// rsetl_rngDisplayMISO
#define RSETL_VAL_DTV_MISO_DISPLAY_SUM                                      0
#define RSETL_VAL_DTV_MISO_DISPLAY_GRP1                                     1
#define RSETL_VAL_DTV_MISO_DISPLAY_GRP2                                     2
#define RSETL_VAL_DTV_MISO_DISPLAY_GRPS                                     3

// rsetl_rngDTVISSYProcessing
#define RSETL_VAL_DTV_ISSY_COMPLIANT                                        0
#define RSETL_VAL_DTV_ISSY_TOLERANT                                         1

// rsetl_rngDTVT2Profile
#define RSETL_VAL_DTV_T2_PROFILE_T2BASE                                     0
#define RSETL_VAL_DTV_T2_PROFILE_T2LITE                                     1

// rsetl_rngRadioSpectrumMask
#define RSETL_VAL_RADIO_SPECTRUM_MASK_PSHQ                                  0
#define RSETL_VAL_RADIO_SPECTRUM_MASK_K200                                  1
#define RSETL_VAL_RADIO_SPECTRUM_MASK_K250                                  2
#define RSETL_VAL_RADIO_SPECTRUM_MASK_K300                                  3

// rsetl_rngDTVShoulderGuideline
#define RSETL_VAL_DTV_SHOULDER_GUIDELINE_ETSI                               0
#define RSETL_VAL_DTV_SHOULDER_GUIDELINE_TRAN                               1
#define RSETL_VAL_DTV_SHOULDER_GUIDELINE_EXC                                2

// rsetl_rngDTMBPowerBoost
#define RSETL_VAL_DTMB_POWER_BOOST_OFF                                      0
#define RSETL_VAL_DTMB_POWER_BOOST_ON                                       1
#define RSETL_VAL_DTMB_POWER_BOOST_AUTO                                     2

// rsetl_rngDTMBPowerNormalization
#define RSETL_VAL_DTMB_POWER_NORMALIZATION_AUTO                             0
#define RSETL_VAL_DTMB_POWER_NORMALIZATION_MAX                              1
#define RSETL_VAL_DTMB_POWER_NORMALIZATION_RMS                              2

// rsetl_rngDTMBPowerReference
#define RSETL_VAL_DTMB_POWER_REFERENCE_STDC                                 0
#define RSETL_VAL_DTMB_POWER_REFERENCE_QAM4                                 1

// rsetl_rngRadioMPXSamples
#define RSETL_VAL_RADIO_MPX_SAMPLES_PKHOLD                                  0
#define RSETL_VAL_RADIO_MPX_SAMPLES_RAW                                     1

// rsetl_rngRadioMPXTimeSpan
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T1MIN                                 0
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T2MIN                                 1
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T5MIN                                 2
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T10MIN                                3
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T20MIN                                4
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T30MIN                                5
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T1H                                   6
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T2H                                   7
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T5H                                   8
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T10H                                  9
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T1D                                   10
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T2D                                   11
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T5D                                   12
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T10D                                  13
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T20D                                  14
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T50D                                  15
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T100D                                 16
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T200D                                 17
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T500D                                 18
#define RSETL_VAL_RADIO_MPX_TIME_SPAN_T1000D                                19

// rsetl_rngDTMBBERIndication
#define RSETL_VAL_DTMB_BER_INDICATION_BERL                                  0
#define RSETL_VAL_DTMB_BER_INDICATION_BBCH                                  1

// rsetl_rngIQCarrierType
#define RSETL_VAL_IQ_CARRIER_TYPE_FHON                                      0
#define RSETL_VAL_IQ_CARRIER_TYPE_FHOFF                                     1
#define RSETL_VAL_IQ_CARRIER_TYPE_SION                                      2
#define RSETL_VAL_IQ_CARRIER_TYPE_SIOFF                                     3
#define RSETL_VAL_IQ_CARRIER_TYPE_DAON                                      4
#define RSETL_VAL_IQ_CARRIER_TYPE_DAOFF                                     5

// rsetl_rngGPSDevice
#define RSETL_VAL_GPS_DEVICE_NONE                                           0
#define RSETL_VAL_GPS_DEVICE_NMEA                                           1
#define RSETL_VAL_GPS_DEVICE_PPS                                            2
#define RSETL_VAL_GPS_DEVICE_PPS2                                           3

// rsetl_rngGPSPinDirection
#define RSETL_VAL_GPS_PIN_DIRECTION_FORW                                    0
#define RSETL_VAL_GPS_PIN_DIRECTION_BACK                                    1

// rsetl_rngGPSTSMXCalibrationStatus
#define RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_INV                           0
#define RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_NONE                          1
#define RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_ONG                           2
#define RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_COAR                          3
#define RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_FINE                          4

// rsetl_rngGPSTSMXStatus
#define RSETL_VAL_GPS_TSMX_STATUS_INV                                       0
#define RSETL_VAL_GPS_TSMX_STATUS_INC                                       1
#define RSETL_VAL_GPS_TSMX_STATUS_FAIL                                      2
#define RSETL_VAL_GPS_TSMX_STATUS_OK                                        3

// rsetl_rngGPSStatus
#define RSETL_VAL_GPS_STATUS_OFF                                            0
#define RSETL_VAL_GPS_STATUS_NCON                                           1
#define RSETL_VAL_GPS_STATUS_NSAT                                           2
#define RSETL_VAL_GPS_STATUS_DREC                                           3
#define RSETL_VAL_GPS_STATUS_OK                                             4

// rsetl_rngTSGeneratorWaveform
#define RSETL_VAL_TSGEN_WAVEFORM_SINE                                       0
#define RSETL_VAL_TSGEN_WAVEFORM_SQU                                        1
#define RSETL_VAL_TSGEN_WAVEFORM_TRI                                        2

// rsetl_rngTSGeneratorPacketLength
#define RSETL_VAL_TSGEN_PACKET_LENGTH_P188                                  0
#define RSETL_VAL_TSGEN_PACKET_LENGTH_P204                                  1
#define RSETL_VAL_TSGEN_PACKET_LENGTH_P208                                  2

// rsetl_rngTSGeneratorSerialOutput
#define RSETL_VAL_TSGEN_SERIAL_OUTPUT_ASIB                                  0
#define RSETL_VAL_TSGEN_SERIAL_OUTPUT_ASIC                                  1
#define RSETL_VAL_TSGEN_SERIAL_OUTPUT_SMPT                                  2

// rsetl_rngTSRecorderInput
#define RSETL_VAL_TSREC_INPUT_ASII                                          0
#define RSETL_VAL_TSREC_INPUT_ASIE                                          1
#define RSETL_VAL_TSREC_INPUT_SMPT                                          2
#define RSETL_VAL_TSREC_INPUT_OFF                                           3

// rsetl_rngTSGeneratorRecorderStatus
#define RSETL_VAL_TSGEN_REC_STATUS_STOP                                     0
#define RSETL_VAL_TSGEN_REC_STATUS_PLAY                                     1
#define RSETL_VAL_TSGEN_REC_STATUS_PAUSE                                    2
#define RSETL_VAL_TSGEN_REC_STATUS_RECORD                                   3

// rsetl_rngTSGeneratorRecorderMode
#define RSETL_VAL_TSGEN_REC_MODE_GENERATOR                                  0
#define RSETL_VAL_TSGEN_REC_MODE_RECORDER                                   1

//repcap Marker
#define RSETL_REPCAP_MARKER_M1                                              1
#define RSETL_REPCAP_MARKER_M2                                              2
#define RSETL_REPCAP_MARKER_M3                                              3
#define RSETL_REPCAP_MARKER_M4                                              4

//repcap Default
#define RSETL_REPCAP_DEFAULT_DEF1                                           1
#define RSETL_REPCAP_DEFAULT_DEF2                                           2
#define RSETL_REPCAP_DEFAULT_DEF3                                           3

//repcap Destination
#define RSETL_REPCAP_DESTINATION_DE1                                        1
#define RSETL_REPCAP_DESTINATION_DE2                                        2

//repcap CMAP
#define RSETL_REPCAP_CMAP_CM1                                               1
#define RSETL_REPCAP_CMAP_CM2                                               2
#define RSETL_REPCAP_CMAP_CM3                                               3
#define RSETL_REPCAP_CMAP_CM4                                               4
#define RSETL_REPCAP_CMAP_CM5                                               5
#define RSETL_REPCAP_CMAP_CM6                                               6
#define RSETL_REPCAP_CMAP_CM7                                               7
#define RSETL_REPCAP_CMAP_CM8                                               8
#define RSETL_REPCAP_CMAP_CM9                                               9
#define RSETL_REPCAP_CMAP_CM10                                              10
#define RSETL_REPCAP_CMAP_CM11                                              11
#define RSETL_REPCAP_CMAP_CM12                                              12
#define RSETL_REPCAP_CMAP_CM13                                              13
#define RSETL_REPCAP_CMAP_CM14                                              14
#define RSETL_REPCAP_CMAP_CM15                                              15
#define RSETL_REPCAP_CMAP_CM16                                              16
#define RSETL_REPCAP_CMAP_CM17                                              17
#define RSETL_REPCAP_CMAP_CM18                                              18
#define RSETL_REPCAP_CMAP_CM19                                              19
#define RSETL_REPCAP_CMAP_CM20                                              20
#define RSETL_REPCAP_CMAP_CM21                                              21
#define RSETL_REPCAP_CMAP_CM22                                              22
#define RSETL_REPCAP_CMAP_CM23                                              23
#define RSETL_REPCAP_CMAP_CM24                                              24
#define RSETL_REPCAP_CMAP_CM25                                              25
#define RSETL_REPCAP_CMAP_CM26                                              26

//repcap Limit
#define RSETL_REPCAP_LIMIT_L1                                               1
#define RSETL_REPCAP_LIMIT_L2                                               2
#define RSETL_REPCAP_LIMIT_L3                                               3
#define RSETL_REPCAP_LIMIT_L4                                               4
#define RSETL_REPCAP_LIMIT_L5                                               5
#define RSETL_REPCAP_LIMIT_L6                                               6
#define RSETL_REPCAP_LIMIT_L7                                               7
#define RSETL_REPCAP_LIMIT_L8                                               8

//repcap DeltaMarker
#define RSETL_REPCAP_DELTAMARKER_DM1                                        1
#define RSETL_REPCAP_DELTAMARKER_DM2                                        2
#define RSETL_REPCAP_DELTAMARKER_DM3                                        3
#define RSETL_REPCAP_DELTAMARKER_DM4                                        4

//repcap Trace
#define RSETL_REPCAP_TRACE_TR1                                              1
#define RSETL_REPCAP_TRACE_TR2                                              2
#define RSETL_REPCAP_TRACE_TR3                                              3
#define RSETL_REPCAP_TRACE_TR4                                              4

//repcap Line
#define RSETL_REPCAP_LINE_L1                                                1
#define RSETL_REPCAP_LINE_L2                                                2

//repcap Channel
#define RSETL_REPCAP_CHANNEL_CH1                                            1
#define RSETL_REPCAP_CHANNEL_CH2                                            2
#define RSETL_REPCAP_CHANNEL_CH3                                            3
#define RSETL_REPCAP_CHANNEL_CH4                                            4
#define RSETL_REPCAP_CHANNEL_CH5                                            5
#define RSETL_REPCAP_CHANNEL_CH6                                            6
#define RSETL_REPCAP_CHANNEL_CH7                                            7
#define RSETL_REPCAP_CHANNEL_CH8                                            8
#define RSETL_REPCAP_CHANNEL_CH9                                            9
#define RSETL_REPCAP_CHANNEL_CH10                                           10
#define RSETL_REPCAP_CHANNEL_CH11                                           11

//repcap StatisticMeasType
#define RSETL_REPCAP_STATISTICMEASTYPE_STATMEAN                             0
#define RSETL_REPCAP_STATISTICMEASTYPE_STATPEAK                             1
#define RSETL_REPCAP_STATISTICMEASTYPE_STATCRESTFACTOR                      2

//repcap DiagramArea
#define RSETL_REPCAP_DIAGRAMAREA_DA1                                        1
#define RSETL_REPCAP_DIAGRAMAREA_DA2                                        2
#define RSETL_REPCAP_DIAGRAMAREA_DA3                                        3
#define RSETL_REPCAP_DIAGRAMAREA_DA4                                        4
#define RSETL_REPCAP_DIAGRAMAREA_DA5                                        5
#define RSETL_REPCAP_DIAGRAMAREA_DA6                                        6
#define RSETL_REPCAP_DIAGRAMAREA_DA7                                        7
#define RSETL_REPCAP_DIAGRAMAREA_DA8                                        8
#define RSETL_REPCAP_DIAGRAMAREA_DA9                                        9
#define RSETL_REPCAP_DIAGRAMAREA_DA10                                       10

//repcap AnalogModulation
#define RSETL_REPCAP_ANALOGMODULATION_ANALOGAM                              0
#define RSETL_REPCAP_ANALOGMODULATION_ANALOGFM                              1
#define RSETL_REPCAP_ANALOGMODULATION_ANALOGPM                              2

//repcap ResultDetector
#define RSETL_REPCAP_RESULTDETECTOR_RESDETPOSPEAK                           0
#define RSETL_REPCAP_RESULTDETECTOR_RESDETNEGPEAK                           1
#define RSETL_REPCAP_RESULTDETECTOR_RESDETAVERPEAK                          2
#define RSETL_REPCAP_RESULTDETECTOR_RESDETRMS                               3

//repcap FMOffsetResult
#define RSETL_REPCAP_FMOFFSETRESULT_FMOFFIMM                                0
#define RSETL_REPCAP_FMOFFSETRESULT_FMOFFAVER                               1

//repcap AtvVisionModulResult
#define RSETL_REPCAP_ATVVISIONMODULRESULT_VISCARRPOW                        0
#define RSETL_REPCAP_ATVVISIONMODULRESULT_RESPICTURE                        1
#define RSETL_REPCAP_ATVVISIONMODULRESULT_DEPTH                             2
#define RSETL_REPCAP_ATVVISIONMODULRESULT_SIGNOISERATIO                     3
#define RSETL_REPCAP_ATVVISIONMODULRESULT_FREQOFFSET                        4
#define RSETL_REPCAP_ATVVISIONMODULRESULT_SNRNOMINAL                        5

//repcap DtvShoulderAtt
#define RSETL_REPCAP_DTVSHOULDERATT_SATTLOW                                 0
#define RSETL_REPCAP_DTVSHOULDERATT_SATTUPP                                 1

//repcap DtvOverview
#define RSETL_REPCAP_DTVOVERVIEW_OVLEV                                      0
#define RSETL_REPCAP_DTVOVERVIEW_OVBBV                                      1
#define RSETL_REPCAP_DTVOVERVIEW_OVPBBV                                     2
#define RSETL_REPCAP_DTVOVERVIEW_OVTBBV                                     3
#define RSETL_REPCAP_DTVOVERVIEW_OVBBRS                                     4
#define RSETL_REPCAP_DTVOVERVIEW_OVPBBR                                     5
#define RSETL_REPCAP_DTVOVERVIEW_OVTBBR                                     6
#define RSETL_REPCAP_DTVOVERVIEW_OVPER                                      7
#define RSETL_REPCAP_DTVOVERVIEW_OVPPER                                     8
#define RSETL_REPCAP_DTVOVERVIEW_OVTPER                                     9
#define RSETL_REPCAP_DTVOVERVIEW_OVPERR                                     10
#define RSETL_REPCAP_DTVOVERVIEW_OVBROF                                     11
#define RSETL_REPCAP_DTVOVERVIEW_OVISR                                      12
#define RSETL_REPCAP_DTVOVERVIEW_OVMTB                                      13
#define RSETL_REPCAP_DTVOVERVIEW_OVFFTM                                     14
#define RSETL_REPCAP_DTVOVERVIEW_OVGINT                                     15
#define RSETL_REPCAP_DTVOVERVIEW_OVCRHP                                     16
#define RSETL_REPCAP_DTVOVERVIEW_OVCRLP                                     17
#define RSETL_REPCAP_DTVOVERVIEW_OVCID                                      18
#define RSETL_REPCAP_DTVOVERVIEW_OVTPSR                                     19
#define RSETL_REPCAP_DTVOVERVIEW_OVINT                                      20
#define RSETL_REPCAP_DTVOVERVIEW_OVLIND                                     21
#define RSETL_REPCAP_DTVOVERVIEW_OVBERL                                     22
#define RSETL_REPCAP_DTVOVERVIEW_OVPBER                                     23
#define RSETL_REPCAP_DTVOVERVIEW_OVTBER                                     24
#define RSETL_REPCAP_DTVOVERVIEW_OVTMOD                                     25
#define RSETL_REPCAP_DTVOVERVIEW_OVFERR                                     26
#define RSETL_REPCAP_DTVOVERVIEW_OVSBP                                      27
#define RSETL_REPCAP_DTVOVERVIEW_OVMTBR                                     28
#define RSETL_REPCAP_DTVOVERVIEW_OVCRAT                                     29
#define RSETL_REPCAP_DTVOVERVIEW_OVDEIN                                     30
#define RSETL_REPCAP_DTVOVERVIEW_OVBARS                                     31
#define RSETL_REPCAP_DTVOVERVIEW_OVPBAR                                     32
#define RSETL_REPCAP_DTVOVERVIEW_OVTBAR                                     33
#define RSETL_REPCAP_DTVOVERVIEW_OVLTB                                      34
#define RSETL_REPCAP_DTVOVERVIEW_OVMMTB                                     35
#define RSETL_REPCAP_DTVOVERVIEW_OVDCN                                      36
#define RSETL_REPCAP_DTVOVERVIEW_OVCN                                       37
#define RSETL_REPCAP_DTVOVERVIEW_OVSNRL                                     38
#define RSETL_REPCAP_DTVOVERVIEW_OVPNO                                      39
#define RSETL_REPCAP_DTVOVERVIEW_OVCIFC                                     40

//repcap DtvModErrors
#define RSETL_REPCAP_DTVMODERRORS_MESNR                                     0
#define RSETL_REPCAP_DTVMODERRORS_MELEV                                     1
#define RSETL_REPCAP_DTVMODERRORS_MECPH                                     2
#define RSETL_REPCAP_DTVMODERRORS_MEPILV                                    3
#define RSETL_REPCAP_DTVMODERRORS_MESPV                                     4
#define RSETL_REPCAP_DTVMODERRORS_MEPAER                                    5
#define RSETL_REPCAP_DTVMODERRORS_MECNR                                     6
#define RSETL_REPCAP_DTVMODERRORS_MEBVF                                     7
#define RSETL_REPCAP_DTVMODERRORS_MEPBVF                                    8
#define RSETL_REPCAP_DTVMODERRORS_METBVF                                    9
#define RSETL_REPCAP_DTVMODERRORS_MEBVM                                     10
#define RSETL_REPCAP_DTVMODERRORS_MEPBVM                                    11
#define RSETL_REPCAP_DTVMODERRORS_METBVM                                    12
#define RSETL_REPCAP_DTVMODERRORS_MEMTRM                                    13
#define RSETL_REPCAP_DTVMODERRORS_MEMARM                                    14

//repcap DtvConstellation
#define RSETL_REPCAP_DTVCONSTELLATION_COMERR                                0
#define RSETL_REPCAP_DTVCONSTELLATION_COMERP                                1
#define RSETL_REPCAP_DTVCONSTELLATION_COBBRS                                2
#define RSETL_REPCAP_DTVCONSTELLATION_COSPROC                               3
#define RSETL_REPCAP_DTVCONSTELLATION_COLEV                                 4

//repcap DtvAPGDResult
#define RSETL_REPCAP_DTVAPGDRESULT_APGDRESAMPL                              0
#define RSETL_REPCAP_DTVAPGDRESULT_APGDRESPHAS                              1
#define RSETL_REPCAP_DTVAPGDRESULT_APGDRESGDEL                              2

//repcap AtvCarrier
#define RSETL_REPCAP_ATVCARRIER_CN                                          0
#define RSETL_REPCAP_ATVCARRIER_CSO                                         1
#define RSETL_REPCAP_ATVCARRIER_CTB                                         2

//repcap AtvSoundCarrier
#define RSETL_REPCAP_ATVSOUNDCARRIER_SC1                                    0
#define RSETL_REPCAP_ATVSOUNDCARRIER_SC2                                    1

//repcap ModifLowUpp
#define RSETL_REPCAP_MODIFLOWUPP_LOW                                        0
#define RSETL_REPCAP_MODIFLOWUPP_UPP                                        1

//repcap AtvCarrierResult
#define RSETL_REPCAP_ATVCARRIERRESULT_REFPOW                                0
#define RSETL_REPCAP_ATVCARRIERRESULT_NOISEFLOORCORR                        1
#define RSETL_REPCAP_ATVCARRIERRESULT_FREQREL                               2
#define RSETL_REPCAP_ATVCARRIERRESULT_CR                                    3
#define RSETL_REPCAP_ATVCARRIERRESULT_NOISEREFBW                            4

//repcap DtvErrorMeas
#define RSETL_REPCAP_DTVERRORMEAS_EVMPEAK                                   0
#define RSETL_REPCAP_DTVERRORMEAS_EVMRMS                                    1
#define RSETL_REPCAP_DTVERRORMEAS_MERPEAK                                   2
#define RSETL_REPCAP_DTVERRORMEAS_MERRMS                                    3

//repcap MLogTrace
#define RSETL_REPCAP_MLOGTRACE_MTR1                                         1
#define RSETL_REPCAP_MLOGTRACE_MTR2                                         2
#define RSETL_REPCAP_MLOGTRACE_MTR3                                         3
#define RSETL_REPCAP_MLOGTRACE_MTR4                                         4

//repcap AtvAnalysisMeasValue
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMELBAR                           0
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMESARB                           1
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEBARB                           2
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMECLDP                           3
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMECLGB                           4
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMECLGP                           5
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEBD                             6
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMETTPA                           7
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMETTPK                           8
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMETILT                           9
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMESTRE                           10
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMESTFE                           11
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMELTD                            12
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMECLIP                           13
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMECLI3                           14
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEGPPC                           15
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEPPPC                           16
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMELNL                            17
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMELNL1                           18
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMELNL2                           19
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMELNL3                           20
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMELNL4                           21
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMELNL5                           22
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDGP                            23
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDGN                            24
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDG1S                           25
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDG2S                           26
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDG3S                           27
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDG4S                           28
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDG5S                           29
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDPP                            30
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDPN                            31
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDP1S                           32
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDP2S                           33
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDP3S                           34
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDP4S                           35
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEDP5S                           36
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICPH                           37
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICPL                           38
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICPS                           39
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICPB                           40
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICP1                           41
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICP2                           42
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICP3                           43
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICP4                           44
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEICP5                           45
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEMRB                            46
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEM05P                           47
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEM10P                           48
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEM20P                           49
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEM40P                           50
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEM48P                           51
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEM58P                           52
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMENRB                            53
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEN05P                           54
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEN15P                           55
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEN30P                           56
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEN44P                           57
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMESXAP                           58
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMESXAN                           59
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMESXGP                           60
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMESXGN                           61
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEFRB                            62
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEF05P                           63
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEF12P                           64
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEF20P                           65
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEF30P                           66
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEF35P                           67
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMEF41P                           68
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMETRB                            69
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMET05P                           70
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMET10P                           71
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMET20P                           72
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMET30P                           73
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMET35P                           74
#define RSETL_REPCAP_ATVANALYSISMEASVALUE_VMET42P                           75

//repcap ModifMinMax
#define RSETL_REPCAP_MODIFMINMAX_MIN                                        0
#define RSETL_REPCAP_MODIFMINMAX_MAX                                        1

//repcap Subchannel
#define RSETL_REPCAP_SUBCHANNEL_SCH1                                        1
#define RSETL_REPCAP_SUBCHANNEL_SCH2                                        2
#define RSETL_REPCAP_SUBCHANNEL_SCH3                                        3
#define RSETL_REPCAP_SUBCHANNEL_SCH4                                        4
#define RSETL_REPCAP_SUBCHANNEL_SCH5                                        5
#define RSETL_REPCAP_SUBCHANNEL_SCH6                                        6
#define RSETL_REPCAP_SUBCHANNEL_SCH7                                        7
#define RSETL_REPCAP_SUBCHANNEL_SCH8                                        8
#define RSETL_REPCAP_SUBCHANNEL_SCH9                                        9
#define RSETL_REPCAP_SUBCHANNEL_SCH10                                       10
#define RSETL_REPCAP_SUBCHANNEL_SCH11                                       11
#define RSETL_REPCAP_SUBCHANNEL_SCH12                                       12
#define RSETL_REPCAP_SUBCHANNEL_SCH13                                       13
#define RSETL_REPCAP_SUBCHANNEL_SCH14                                       14
#define RSETL_REPCAP_SUBCHANNEL_SCH15                                       15
#define RSETL_REPCAP_SUBCHANNEL_SCH16                                       16
#define RSETL_REPCAP_SUBCHANNEL_SCH17                                       17
#define RSETL_REPCAP_SUBCHANNEL_SCH18                                       18
#define RSETL_REPCAP_SUBCHANNEL_SCH19                                       19
#define RSETL_REPCAP_SUBCHANNEL_SCH20                                       20
#define RSETL_REPCAP_SUBCHANNEL_SCH21                                       21
#define RSETL_REPCAP_SUBCHANNEL_SCH22                                       22
#define RSETL_REPCAP_SUBCHANNEL_SCH23                                       23
#define RSETL_REPCAP_SUBCHANNEL_SCH24                                       24
#define RSETL_REPCAP_SUBCHANNEL_SCH25                                       25
#define RSETL_REPCAP_SUBCHANNEL_SCH26                                       26
#define RSETL_REPCAP_SUBCHANNEL_SCH27                                       27
#define RSETL_REPCAP_SUBCHANNEL_SCH28                                       28
#define RSETL_REPCAP_SUBCHANNEL_SCH29                                       29
#define RSETL_REPCAP_SUBCHANNEL_SCH30                                       30
#define RSETL_REPCAP_SUBCHANNEL_SCH31                                       31
#define RSETL_REPCAP_SUBCHANNEL_SCH32                                       32
#define RSETL_REPCAP_SUBCHANNEL_SCH33                                       33
#define RSETL_REPCAP_SUBCHANNEL_SCH34                                       34
#define RSETL_REPCAP_SUBCHANNEL_SCH35                                       35
#define RSETL_REPCAP_SUBCHANNEL_SCH36                                       36
#define RSETL_REPCAP_SUBCHANNEL_SCH37                                       37
#define RSETL_REPCAP_SUBCHANNEL_SCH38                                       38
#define RSETL_REPCAP_SUBCHANNEL_SCH39                                       39
#define RSETL_REPCAP_SUBCHANNEL_SCH40                                       40
#define RSETL_REPCAP_SUBCHANNEL_SCH41                                       41
#define RSETL_REPCAP_SUBCHANNEL_SCH42                                       42
#define RSETL_REPCAP_SUBCHANNEL_SCH43                                       43
#define RSETL_REPCAP_SUBCHANNEL_SCH44                                       44
#define RSETL_REPCAP_SUBCHANNEL_SCH45                                       45
#define RSETL_REPCAP_SUBCHANNEL_SCH46                                       46
#define RSETL_REPCAP_SUBCHANNEL_SCH47                                       47
#define RSETL_REPCAP_SUBCHANNEL_SCH48                                       48
#define RSETL_REPCAP_SUBCHANNEL_SCH49                                       49
#define RSETL_REPCAP_SUBCHANNEL_SCH50                                       50
#define RSETL_REPCAP_SUBCHANNEL_SCH51                                       51
#define RSETL_REPCAP_SUBCHANNEL_SCH52                                       52
#define RSETL_REPCAP_SUBCHANNEL_SCH53                                       53
#define RSETL_REPCAP_SUBCHANNEL_SCH54                                       54
#define RSETL_REPCAP_SUBCHANNEL_SCH55                                       55
#define RSETL_REPCAP_SUBCHANNEL_SCH56                                       56
#define RSETL_REPCAP_SUBCHANNEL_SCH57                                       57
#define RSETL_REPCAP_SUBCHANNEL_SCH58                                       58
#define RSETL_REPCAP_SUBCHANNEL_SCH59                                       59
#define RSETL_REPCAP_SUBCHANNEL_SCH60                                       60
#define RSETL_REPCAP_SUBCHANNEL_SCH61                                       61
#define RSETL_REPCAP_SUBCHANNEL_SCH62                                       62
#define RSETL_REPCAP_SUBCHANNEL_SCH63                                       63
#define RSETL_REPCAP_SUBCHANNEL_SCH64                                       64

//repcap TestSignal
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGLBA                                  0
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGSNR                                  1
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGSA                                   2
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGBA                                   3
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGCLP                                  4
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGCLB                                  5
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGBD                                   6
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGLTD                                  7
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGTTP                                  8
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGSTD                                  9
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGTILT                                 10
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGCLIP                                 11
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGCLIB                                 12
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGGCNL                                 13
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGPCNL                                 14
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGLNL                                  15
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGDG                                   16
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGDP                                   17
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGMB                                   18
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGSX                                   19
#define RSETL_REPCAP_TESTSIGNAL_TESTSIGICPM                                 20

//repcap User
#define RSETL_REPCAP_USER_U1                                                1
#define RSETL_REPCAP_USER_U2                                                2
#define RSETL_REPCAP_USER_U3                                                3
#define RSETL_REPCAP_USER_U4                                                4
#define RSETL_REPCAP_USER_U5                                                5

//repcap CATVlocation
#define RSETL_REPCAP_CATVLOCATION_LOC1                                      1
#define RSETL_REPCAP_CATVLOCATION_LOC2                                      2
#define RSETL_REPCAP_CATVLOCATION_LOC3                                      3
#define RSETL_REPCAP_CATVLOCATION_LOC4                                      4
#define RSETL_REPCAP_CATVLOCATION_LOC5                                      5
#define RSETL_REPCAP_CATVLOCATION_LOC6                                      6
#define RSETL_REPCAP_CATVLOCATION_LOC7                                      7
#define RSETL_REPCAP_CATVLOCATION_LOC8                                      8
#define RSETL_REPCAP_CATVLOCATION_LOC9                                      9
#define RSETL_REPCAP_CATVLOCATION_LOC10                                     10
#define RSETL_REPCAP_CATVLOCATION_LOC11                                     11
#define RSETL_REPCAP_CATVLOCATION_LOC12                                     12
#define RSETL_REPCAP_CATVLOCATION_LOC13                                     13
#define RSETL_REPCAP_CATVLOCATION_LOC14                                     14
#define RSETL_REPCAP_CATVLOCATION_LOC15                                     15

//repcap HierarchicalLayer
#define RSETL_REPCAP_HIERARCHICALLAYER_LAYERA                               0
#define RSETL_REPCAP_HIERARCHICALLAYER_LAYERB                               1
#define RSETL_REPCAP_HIERARCHICALLAYER_LAYERC                               2

//repcap ISDBTmerr
#define RSETL_REPCAP_ISDBTMERR_MERRRMS                                      0
#define RSETL_REPCAP_ISDBTMERR_MERRPEAK                                     1
#define RSETL_REPCAP_ISDBTMERR_MERRARM                                      2
#define RSETL_REPCAP_ISDBTMERR_MERRTRM                                      3
#define RSETL_REPCAP_ISDBTMERR_MERRMTBR                                     4
#define RSETL_REPCAP_ISDBTMERR_MERRBBV                                      5
#define RSETL_REPCAP_ISDBTMERR_MERRPBBV                                     6
#define RSETL_REPCAP_ISDBTMERR_MERRTBBV                                     7
#define RSETL_REPCAP_ISDBTMERR_MERRBBRS                                     8
#define RSETL_REPCAP_ISDBTMERR_MERRPBBR                                     9
#define RSETL_REPCAP_ISDBTMERR_MERRTBBR                                     10
#define RSETL_REPCAP_ISDBTMERR_MERRBARS                                     11
#define RSETL_REPCAP_ISDBTMERR_MERRPBAR                                     12
#define RSETL_REPCAP_ISDBTMERR_MERRTBAR                                     13
#define RSETL_REPCAP_ISDBTMERR_MERRPER                                      14
#define RSETL_REPCAP_ISDBTMERR_MERRPPER                                     15
#define RSETL_REPCAP_ISDBTMERR_MERRTPER                                     16
#define RSETL_REPCAP_ISDBTMERR_MERRPERR                                     17

//repcap TMCCNextCurr
#define RSETL_REPCAP_TMCCNEXTCURR_TMCCCURR                                  0
#define RSETL_REPCAP_TMCCNEXTCURR_TMCCNEXT                                  1

//repcap AudioLevel
#define RSETL_REPCAP_AUDIOLEVEL_LEFT                                        1
#define RSETL_REPCAP_AUDIOLEVEL_RIGHT                                       2
#define RSETL_REPCAP_AUDIOLEVEL_PILOT                                       3
#define RSETL_REPCAP_AUDIOLEVEL_SCA                                         4

//repcap AudioFrequency
#define RSETL_REPCAP_AUDIOFREQUENCY_LEFT                                    1
#define RSETL_REPCAP_AUDIOFREQUENCY_RIGHT                                   2
#define RSETL_REPCAP_AUDIOFREQUENCY_SCA                                     3
#define RSETL_REPCAP_AUDIOFREQUENCY_SPACING                                 4
#define RSETL_REPCAP_AUDIOFREQUENCY_UPPER                                   5

//repcap DUTDeviation
#define RSETL_REPCAP_DUTDEVIATION_LEFT                                      1
#define RSETL_REPCAP_DUTDEVIATION_RIGHT                                     2
#define RSETL_REPCAP_DUTDEVIATION_SCA                                       3

//repcap LimitType
#define RSETL_REPCAP_LIMITTYPE_LOWER                                        0
#define RSETL_REPCAP_LIMITTYPE_UPPER                                        1

//repcap MPXDev
#define RSETL_REPCAP_MPXDEV_MPX                                             0
#define RSETL_REPCAP_MPXDEV_LEFT                                            1
#define RSETL_REPCAP_MPXDEV_RIGHT                                           2
#define RSETL_REPCAP_MPXDEV_MONO                                            3
#define RSETL_REPCAP_MPXDEV_STEREO                                          4

//repcap Pilot
#define RSETL_REPCAP_PILOT_DEVIATION                                        0
#define RSETL_REPCAP_PILOT_OFFSET                                           1
#define RSETL_REPCAP_PILOT_PHASE                                            2

//repcap RDS
#define RSETL_REPCAP_RDS_DEVIATION                                          0
#define RSETL_REPCAP_RDS_OFFSET                                             1
#define RSETL_REPCAP_RDS_PHASE                                              2
#define RSETL_REPCAP_RDS_BER                                                3

//repcap SCA
#define RSETL_REPCAP_SCA_MAINDEVIATION                                      0
#define RSETL_REPCAP_SCA_OFFSET                                             1
#define RSETL_REPCAP_SCA_SUBCDEVIATION                                      2

//repcap LimitChannel
#define RSETL_REPCAP_LIMITCHANNEL_LEFT                                      1
#define RSETL_REPCAP_LIMITCHANNEL_RIGHT                                     2

//repcap SN
#define RSETL_REPCAP_SN_R15                                                 0
#define RSETL_REPCAP_SN_Q15                                                 1
#define RSETL_REPCAP_SN_QI15                                                2
#define RSETL_REPCAP_SN_MR1H                                                3
#define RSETL_REPCAP_SN_AP1H                                                4
#define RSETL_REPCAP_SN_AP20                                                5
#define RSETL_REPCAP_SN_AQ20                                                6
#define RSETL_REPCAP_SN_AQI2                                                7

//repcap DFD
#define RSETL_REPCAP_DFD_D2D                                                0
#define RSETL_REPCAP_DFD_D2DS                                               1
#define RSETL_REPCAP_DFD_D3                                                 2
#define RSETL_REPCAP_DFD_DEV                                                3
#define RSETL_REPCAP_DFD_F1                                                 4
#define RSETL_REPCAP_DFD_F2                                                 5

//repcap MPD
#define RSETL_REPCAP_MPD_RESP                                               0
#define RSETL_REPCAP_MPD_GRAD                                               1

//repcap AudioChannel
#define RSETL_REPCAP_AUDIOCHANNEL_SINGLE                                    1
#define RSETL_REPCAP_AUDIOCHANNEL_LEFTMONO                                  2
#define RSETL_REPCAP_AUDIOCHANNEL_RIGHTSTEREO                               3

//repcap PowerPeak
#define RSETL_REPCAP_POWERPEAK_MPOWER                                       0
#define RSETL_REPCAP_POWERPEAK_PDEVIATION                                   1

//repcap RDSFlag
#define RSETL_REPCAP_RDSFLAG_TP                                             0
#define RSETL_REPCAP_RDSFLAG_TA                                             1
#define RSETL_REPCAP_RDSFLAG_MS                                             2

//repcap RDSDateTime
#define RSETL_REPCAP_RDSDATETIME_DATE                                       0
#define RSETL_REPCAP_RDSDATETIME_LTIME                                      1
#define RSETL_REPCAP_RDSDATETIME_UTIME                                      2

//repcap AudioPosNeg
#define RSETL_REPCAP_AUDIOPOSNEG_POSITIVE                                   0
#define RSETL_REPCAP_AUDIOPOSNEG_NEGATIVE                                   1

//repcap AudioScope
#define RSETL_REPCAP_AUDIOSCOPE_PPEAK                                       0
#define RSETL_REPCAP_AUDIOSCOPE_NPEAK                                       1
#define RSETL_REPCAP_AUDIOSCOPE_HPEAK                                       2
#define RSETL_REPCAP_AUDIOSCOPE_RMS                                         3

//repcap AudioCrosstalk
#define RSETL_REPCAP_AUDIOCROSSTALK_CROSSTALK                               0
#define RSETL_REPCAP_AUDIOCROSSTALK_FREQUENCY                               1

//repcap THD
#define RSETL_REPCAP_THD_THD                                                0
#define RSETL_REPCAP_THD_DEVIATION                                          1
#define RSETL_REPCAP_THD_AUDIOFREQ                                          2

//repcap DataID
#define RSETL_REPCAP_DATAID_PLP                                             0
#define RSETL_REPCAP_DATAID_PARADE                                          1

//repcap PeakRMS
#define RSETL_REPCAP_PEAKRMS_PEAK                                           0
#define RSETL_REPCAP_PEAKRMS_RMS                                            1

//repcap ATSCChannel
#define RSETL_REPCAP_ATSCCHANNEL_PRIMARY                                    0
#define RSETL_REPCAP_ATSCCHANNEL_SECONDARY                                  1
#define RSETL_REPCAP_ATSCCHANNEL_TPC                                        2
#define RSETL_REPCAP_ATSCCHANNEL_FIC                                        3
#define RSETL_REPCAP_ATSCCHANNEL_PARADE                                     4

//repcap ATSCMeasurement
#define RSETL_REPCAP_ATSCMEASUREMENT_BBRS                                   0
#define RSETL_REPCAP_ATSCMEASUREMENT_BARS                                   1
#define RSETL_REPCAP_ATSCMEASUREMENT_PER                                    2
#define RSETL_REPCAP_ATSCMEASUREMENT_MPER                                   3

//repcap DTVMPnoise
#define RSETL_REPCAP_DTVMPNOISE_MPNOISE                                     0
#define RSETL_REPCAP_DTVMPNOISE_RESPM                                       1
#define RSETL_REPCAP_DTVMPNOISE_RESFM                                       2
#define RSETL_REPCAP_DTVMPNOISE_INTEGRATION                                 3
#define RSETL_REPCAP_DTVMPNOISE_RBW                                         4
#define RSETL_REPCAP_DTVMPNOISE_ACQTIME                                     5

//repcap DTVEchoPatt
#define RSETL_REPCAP_DTVECHOPATT_MERSHORTEQ                                 0
#define RSETL_REPCAP_DTVECHOPATT_ECHODET                                    1

//repcap T2Frame
#define RSETL_REPCAP_T2FRAME_FRAMECOUNT                                     0
#define RSETL_REPCAP_T2FRAME_SYMPERFRAME                                    1

//repcap PostSize
#define RSETL_REPCAP_POSTSIZE_SIZE                                          0
#define RSETL_REPCAP_POSTSIZE_INFOSIZE                                      1

//repcap SBit
#define RSETL_REPCAP_SBIT_S1                                                0
#define RSETL_REPCAP_SBIT_S2                                                1

//repcap L1ID
#define RSETL_REPCAP_L1ID_SYSTEM                                            0
#define RSETL_REPCAP_L1ID_CELL                                              1
#define RSETL_REPCAP_L1ID_NETWORK                                           2
#define RSETL_REPCAP_L1ID_TX                                                3

//repcap PostSignaling
#define RSETL_REPCAP_POSTSIGNALING_DECODEDPLP                               0
#define RSETL_REPCAP_POSTSIGNALING_ALLPLP                                   1
#define RSETL_REPCAP_POSTSIGNALING_COMMON                                   2

//repcap BitRate
#define RSETL_REPCAP_BITRATE_ENSEMBLE                                       0
#define RSETL_REPCAP_BITRATE_SIGNALING                                      1
#define RSETL_REPCAP_BITRATE_PAYLOAD                                        2
#define RSETL_REPCAP_BITRATE_PARADE                                         3

//repcap DtvDVBT2Result
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESMRLO                            0
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESMPLO                            1
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESMRPL                            2
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESMPPL                            3
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESERPL                            4
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESEPPL                            5
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESITLD                            6
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESACQ                             7
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESBBCH                            8
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESPBBC                            9
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESTBBC                            10
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESESR                             11
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESPESR                            12
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESTESR                            13
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESFER                             14
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESPFER                            15
#define RSETL_REPCAP_DTVDVBT2RESULT_DVBT2RESTFER                            16
/* END GENERATE */

/*****************************************************************************
 *- Hidden Attribute Declarations -------------------------------------------*
 *****************************************************************************/

#define RSETL_ATTR_OPC_TIMEOUT               (RS_ATTR_OPC_TIMEOUT)           /* ViInt32 */
#define RSETL_ATTR_IO_SESSION                (RS_ATTR_IO_SESSION)            /* ViSession */
#define RSETL_ATTR_OPC_CALLBACK              (RS_ATTR_OPC_CALLBACK)          /* ViAddr */
#define RSETL_ATTR_CHECK_STATUS_CALLBACK     (RS_ATTR_CHECK_STATUS_CALLBACK) /* ViAddr */

/****************************************************************************
 *---------------- Constant definition  ------------------------------------*
 ****************************************************************************/

#define RSETL_VAL_MAX_TIME_IMMEDIATE                             (0x0L)
#define RSETL_VAL_MAX_TIME_INFINITE                              (0xFFFFFFFFUL)

#define RSETL_VAL_MARKER_SEARCH_HIGHEST                          (1L)
#define RSETL_VAL_MARKER_SEARCH_NEXT_PEAK                        (2L)
#define RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_LEFT                   (3L)
#define RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_RIGHT                  (4L)
#define RSETL_VAL_MARKER_SEARCH_MINIMUM                          (5L)
#define RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM                     (6L) 
#define RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_LEFT                (7L) 
#define RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_RIGHT               (8L) 

#define RSETL_VAL_MARKER_SEARCH_CLASS_EXT_BASE                   (500L)
#define RSETL_VAL_MARKER_SEARCH_SPECIFIC_EXT_BASE                (1000L)

#define RSETL_VAL_INSTRUMENT_SETTING_FREQUENCY_CENTER            (1L)
#define RSETL_VAL_INSTRUMENT_SETTING_FREQUENCY_STEP              (2L)
#define RSETL_VAL_INSTRUMENT_SETTING_REFERENCE_LEVEL             (3L)

#define RSETL_VAL_INSTRUMENT_SETTING_CLASS_EXT_BASE              (500L)
#define RSETL_VAL_INSTRUMENT_SETTING_SPECIFIC_EXT_BASE           (1000L)

#define RSETL_VAL_COUPLING_RBW                                   0
#define RSETL_VAL_COUPLING_VBW                                   1
#define RSETL_VAL_COUPLING_SWEEP_TIME                            2
    
#define RSETL_VAL_COUPLING_RATIO_RBW                             0
#define RSETL_VAL_COUPLING_RATIO_VBW                             1
    
#define RSETL_VAL_DATE                                           0
    
#define RSETL_VAL_LIMIT_ALL                                      3
#define RSETL_VAL_LIMIT_CONTROL                                  3
#define RSETL_VAL_LIMIT_MOVE_OFFSET                              0
#define RSETL_VAL_LIMIT_MOVE_SHIFT                               1

#define RSETL_VAL_LIMIT_OFF                                      0
#define RSETL_VAL_LIMIT_UPPER                                    1
#define RSETL_VAL_LIMIT_LOWER                                    2

#define RSETL_VAL_LINE_THR                                       0
#define RSETL_VAL_LINE_DISPLAY                                   1
#define RSETL_VAL_LINE_FREQ                                      2
#define RSETL_VAL_LINE_TIME                                      3

#define RSETL_VAL_HCOPY_DEST_BMP                                 0
#define RSETL_VAL_HCOPY_DEST_WMF                                 1
#define RSETL_VAL_HCOPY_DEST_EMF                                 2
#define RSETL_VAL_HCOPY_DEST_CLP                                 3
#define RSETL_VAL_HCOPY_DEST_PRN                                 4
#define RSETL_VAL_HCOPY_DEST_JPG                                 5
#define RSETL_VAL_HCOPY_DEST_PNG                                 6

#define RSETL_VAL_HCOP_ALL                                       0
#define RSETL_VAL_HCOP_TRACE                                     1

#define RSETL_VAL_FILE_NEW                                       0
#define RSETL_VAL_FILE_COPY                                      1
#define RSETL_VAL_FILE_RENAME                                    2
#define RSETL_VAL_FILE_DELETE                                    3
#define RSETL_VAL_FILE_RDIR                                      4
#define RSETL_VAL_FILE_CDIR                                      5
#define RSETL_VAL_FILE_CDISC                                     6

#define RSETL_VAL_MEM_SAVE                                       0
#define RSETL_VAL_MEM_RECALL                                     1
#define RSETL_VAL_MEM_DELETE                                     2
#define RSETL_VAL_MEM_STARTUP                                    3

#define RSETL_VAL_FILE_ITEMS_NONE                                0
#define RSETL_VAL_FILE_ITEMS_DEFAULT                             1
#define RSETL_VAL_FILE_ITEMS_ALL                                 2
#define RSETL_VAL_FILE_ITEMS_HWSETTINGS                          3
#define RSETL_VAL_FILE_ITEMS_ALLTRACES                           4
#define RSETL_VAL_FILE_ITEMS_ALLLINES                            5
#define RSETL_VAL_FILE_ITEMS_SOUR_CAL_DATA                       6
#define RSETL_VAL_FILE_ITEMS_ALLTRAN                             7

#define RSETL_VAL_FORMAT_ASC                                     0
#define RSETL_VAL_FORMAT_REAL                                    1

#define RSETL_VAL_TDOM_PEAK                                      0
#define RSETL_VAL_TDOM_RMS                                       1
#define RSETL_VAL_TDOM_MEAN                                      2
#define RSETL_VAL_TDOM_SDEV                                      3

#define RSETL_VAL_TDOM_RESULT                                    0
#define RSETL_VAL_TDOM_AVG_RESULT                                1
#define RSETL_VAL_TDOM_MAX_HOLD_RESULT                           2

#define RSETL_VAL_ACP_TX                                         0
#define RSETL_VAL_ACP_ADJ                                        1
#define RSETL_VAL_ACP_ALT                                        2

#define RSETL_VAL_ACP_LIMIT_CHECK_OFF                            0
#define RSETL_VAL_ACP_LIMIT_CHECK_ABS                            1
#define RSETL_VAL_ACP_LIMIT_CHECK_REL                            2

#define RSETL_VAL_SSTAT_OFF                                      0
#define RSETL_VAL_SSTAT_APD                                      1
#define RSETL_VAL_SSTAT_CCDF                                     2

#define RSETL_VAL_TRACK_GEN_CAL_TRANS                            0
#define RSETL_VAL_TRACK_GEN_CAL_OPEN                             1
#define RSETL_VAL_TRACK_GEN_CAL_SHORT                            2
#define RSETL_VAL_TRACK_GEN_RECALL                               3

#define RSETL_VAL_FMDEM_AM                                       0
#define RSETL_VAL_FMDEM_FM                                       1
#define RSETL_VAL_FMDEM_PM                                       2
#define RSETL_VAL_FMDEM_AFSFM                                    3
#define RSETL_VAL_FMDEM_AFSPM                                    4
#define RSETL_VAL_FMDEM_RF                                       5
#define RSETL_VAL_FMDEM_AMREL                                    6
#define RSETL_VAL_FMDEM_AFSAMREL                                 7

#define RSETL_VAL_FMDEM_DET_PPE                                  0
#define RSETL_VAL_FMDEM_DET_MPE                                  1
#define RSETL_VAL_FMDEM_DET_MID                                  2
#define RSETL_VAL_FMDEM_DET_RMS                                  3

#define RSETL_VAL_FMDEM_MEAS_AFR                                 0
#define RSETL_VAL_FMDEM_MEAS_FER                                 1
#define RSETL_VAL_FMDEM_MEAS_SIN                                 2
#define RSETL_VAL_FMDEM_MEAS_THD                                 3
#define RSETL_VAL_FMDEM_MEAS_CAR                                 4

#define RSETL_VAL_DTV_SPEC_SAL                                   0
#define RSETL_VAL_DTV_SPEC_SAUP                                  1

#define RSETL_VAL_FM_FEED_AM_REL                                 0
#define RSETL_VAL_FM_FEED_AM                                     1
#define RSETL_VAL_FM_FEED_SPEC                                   2
#define RSETL_VAL_FM_FEED_FM                                     3
#define RSETL_VAL_FM_FEED_PM                                     4
#define RSETL_VAL_FM_FEED_AMS_REL                                5
#define RSETL_VAL_FM_FEED_AMS                                    6
#define RSETL_VAL_FM_FEED_FMS                                    7
#define RSETL_VAL_FM_FEED_PMS                                    8
#define RSETL_VAL_FM_FEED_FM_AFSP                                9
#define RSETL_VAL_FM_FEED_PM_AFSP                                10
#define RSETL_VAL_FM_FEED_AM_REL_AFSP                            11
#define RSETL_VAL_FM_FEED_RFP                                    12

#define RSETL_VAL_FMDEM_FILTER_HP                                0
#define RSETL_VAL_FMDEM_FILTER_LP                                1
#define RSETL_VAL_FMDEM_FILTER_DEEMP                             2
#define RSETL_VAL_FMDEM_FILTER_LP_REL                            3

#define RSETL_VAL_FMDEM_RLEN                                     0
#define RSETL_VAL_FMDEM_SRATE                                    1

#define RSETL_VAL_LIM_LOW                                        0
#define RSETL_VAL_LIM_UPP                                        1

#define RSETL_VAL_ATV_VCP                                        0
#define RSETL_VAL_ATV_VCF                                        1
#define RSETL_VAL_ATV_SC1PR                                      2
#define RSETL_VAL_ATV_SC1IF                                      3
#define RSETL_VAL_ATV_SC2PR                                      4
#define RSETL_VAL_ATV_SC2IF                                      5

#define RSETL_VAL_ATV_RPC                                        1
#define RSETL_VAL_ATV_MDEP                                       2
#define RSETL_VAL_ATV_SNR                                        3
#define RSETL_VAL_ATV_LFOF                                       4
#define RSETL_VAL_ATV_SNRN                                       5

#define RSETL_VAL_STAT_DEFAULT                                   0
#define RSETL_VAL_STAT_ADJUST                                    1
#define RSETL_VAL_STAT_XRLEV                                     2
#define RSETL_VAL_STAT_XRANGE                                    3
#define RSETL_VAL_STAT_YMAX                                      4
#define RSETL_VAL_STAT_YMIN                                      5

#define RSETL_VAL_DTV_MERR                                       0
#define RSETL_VAL_DTV_MERP                                       1
#define RSETL_VAL_DTV_EVMR                                       2
#define RSETL_VAL_DTV_EVMP                                       3
#define RSETL_VAL_DTV_CFOF                                       4
#define RSETL_VAL_DTV_SROF                                       5
#define RSETL_VAL_DTV_BBV                                        6
#define RSETL_VAL_DTV_BBRS                                       7
#define RSETL_VAL_DTV_BROF                                       8
#define RSETL_VAL_DTV_LIM                                        9
#define RSETL_VAL_DTV_PER                                        10
#define RSETL_VAL_DTV_PERR                                       11
#define RSETL_VAL_DTV_BERL                                       12
#define RSETL_VAL_DTV_BBCH                                       13
#define RSETL_VAL_DTV_MRLO                                       14
#define RSETL_VAL_DTV_MPLO                                       15
#define RSETL_VAL_DTV_MRPL                                       16
#define RSETL_VAL_DTV_MPPL                                       17
#define RSETL_VAL_DTV_ERPL                                       18
#define RSETL_VAL_DTV_EPPL                                       19
#define RSETL_VAL_DTV_MPFH                                          20
#define RSETL_VAL_DTV_MPSI                                          21
#define RSETL_VAL_DTV_MRFH                                          22
#define RSETL_VAL_DTV_MRSI                                          23
#define RSETL_VAL_DTV_AMPN                                          24
#define RSETL_VAL_DTV_IRR                                           25
#define RSETL_VAL_DTV_PHIN                                          26

#define RSETL_VAL_DTV_IMB                                        4
#define RSETL_VAL_DTV_QERR                                       5
#define RSETL_VAL_DTV_SUP                                        6
#define RSETL_VAL_DTV_PJIT                                       7
#define RSETL_VAL_DTV_SNR                                        8
#define RSETL_VAL_DTV_LEVEL                                      9
#define RSETL_VAL_DTV_CPH                                        10
#define RSETL_VAL_DTV_PILV                                       11
#define RSETL_VAL_DTV_SPV                                        12
#define RSETL_VAL_DTV_PAER                                       13
#define RSETL_VAL_DTV_CNR                                        14
#define RSETL_VAL_DTV_BVF                                        15
#define RSETL_VAL_DTV_PBVF                                       16
#define RSETL_VAL_DTV_TBVF                                       17
#define RSETL_VAL_DTV_BVM                                        18
#define RSETL_VAL_DTV_PBVM                                       19
#define RSETL_VAL_DTV_TBVM                                       20
#define RSETL_VAL_DTV_MTRM                                       21
#define RSETL_VAL_DTV_MARM                                       22

#define RSETL_VAL_ATV_RES_RPOW                                   0
#define RSETL_VAL_ATV_RES_NFC                                    1
#define RSETL_VAL_ATV_RES_MFR                                    2
#define RSETL_VAL_ATV_RES_CR                                     3
#define RSETL_VAL_ATV_RES_NRBW                                   4

#define RSETL_VAL_DTV_RES_MERR                                   0
#define RSETL_VAL_DTV_RES_MERP                                   1
#define RSETL_VAL_DTV_RES_EVMR                                   2
#define RSETL_VAL_DTV_RES_EVMP                                   3
#define RSETL_VAL_DTV_RES_CFOF                                   4
#define RSETL_VAL_DTV_RES_SROF                                   5
#define RSETL_VAL_DTV_RES_CONS                                   6
#define RSETL_VAL_DTV_RES_LEV                                    7
#define RSETL_VAL_DTV_RES_BBV                                    8
#define RSETL_VAL_DTV_RES_PBBV                                   9
#define RSETL_VAL_DTV_RES_TBBV                                   10
#define RSETL_VAL_DTV_RES_BBRS                                   11
#define RSETL_VAL_DTV_RES_PBBR                                   12
#define RSETL_VAL_DTV_RES_TBBR                                   13
#define RSETL_VAL_DTV_RES_PER                                    14
#define RSETL_VAL_DTV_RES_PPER                                   15
#define RSETL_VAL_DTV_RES_TPER                                   16
#define RSETL_VAL_DTV_RES_PERR                                   17
#define RSETL_VAL_DTV_RES_BROF                                   18
#define RSETL_VAL_DTV_RES_ISR                                    19
#define RSETL_VAL_DTV_RES_MTB                                    20
#define RSETL_VAL_DTV_RES_FFTM                                   21
#define RSETL_VAL_DTV_RES_GINT                                   22
#define RSETL_VAL_DTV_RES_CRHP                                   23
#define RSETL_VAL_DTV_RES_CRLP                                   24
#define RSETL_VAL_DTV_RES_CID                                    25
#define RSETL_VAL_DTV_RES_TPSR                                   26
#define RSETL_VAL_DTV_RES_INT                                    27
#define RSETL_VAL_DTV_RES_MFECH                                  28
#define RSETL_VAL_DTV_RES_MFECL                                  29
#define RSETL_VAL_DTV_RES_TSLH                                   30
#define RSETL_VAL_DTV_RES_TSLL                                   31
#define RSETL_VAL_DTV_RES_LIND                                   32
#define RSETL_VAL_DTV_RES_BERL                                   33
#define RSETL_VAL_DTV_RES_PBER                                   34
#define RSETL_VAL_DTV_RES_TBER                                   35
#define RSETL_VAL_DTV_RES_TMOD                                   36
#define RSETL_VAL_DTV_RES_FERR                                   37
#define RSETL_VAL_DTV_RES_SBP                                    38
#define RSETL_VAL_DTV_RES_MTBR                                   39
#define RSETL_VAL_DTV_RES_CRAT                                   40
#define RSETL_VAL_DTV_RES_DEIN                                   41
#define RSETL_VAL_DTV_RES_BARS                                   42
#define RSETL_VAL_DTV_RES_PBAR                                   43
#define RSETL_VAL_DTV_RES_TBAR                                   44
#define RSETL_VAL_DTV_RES_LTB                                    45
#define RSETL_VAL_DTV_RES_MMTB                                   46
#define RSETL_VAL_DTV_RES_DCN                                    47
#define RSETL_VAL_DTV_RES_CN                                     48
#define RSETL_VAL_DTV_RES_SNRL                                   49
#define RSETL_VAL_DTV_RES_PNO                                    50
#define RSETL_VAL_DTV_RES_CIFC                                   51

#define RSETL_VAL_DTV_MLOG_SPAN_AUTO                             0
#define RSETL_VAL_DTV_MLOG_SPAN_MAN                              1

#define RSETL_VAL_CRATE                                          0
#define RSETL_VAL_CRATE_HIGH                                     1
#define RSETL_VAL_CRATE_LOW                                      2

#define RSETL_VAL_DTV_FUNC_CODE_RATE_R04                         0
#define RSETL_VAL_DTV_FUNC_CODE_RATE_R06                         1
#define RSETL_VAL_DTV_FUNC_CODE_RATE_R08                         2
#define RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R1_2                  3
#define RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R2_3                  4
#define RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R3_4                  5
#define RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R5_6                  6
#define RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R7_8                  7

#define RSETL_VAL_MLOG_COMP_LEV_1S                               0
#define RSETL_VAL_MLOG_COMP_LEV_10S                              1
#define RSETL_VAL_MLOG_COMP_LEV_60S                              2
#define RSETL_VAL_MLOG_COMP_LEV_600S                             3
#define RSETL_VAL_MLOG_COMP_LEV_3600S                            4

#define RSETL_VAL_DTV_MEAS_RES_AMPL                              0
#define RSETL_VAL_DTV_MEAS_RES_PHAS                              1
#define RSETL_VAL_DTV_MEAS_RES_GDEL                              2

#define RSETL_VAL_DTV_CONST_MERR                                 0
#define RSETL_VAL_DTV_CONST_MERP                                 1
#define RSETL_VAL_DTV_CONST_BBRS                                 2
#define RSETL_VAL_DTV_CONST_SPRO                                 3
#define RSETL_VAL_DTV_CONST_LEV                                  4

#define RSETL_VAL_USER_PORT_INP                                  0
#define RSETL_VAL_USER_PORT_OUT                                  1

#define RSETL_VAL_BURS_MEAS_MEAN                                 0
#define RSETL_VAL_BURS_MEAS_PEAK                                 1

#define RSETL_VAL_SSTAT_RESULT_MEAN                              0
#define RSETL_VAL_SSTAT_RESULT_PEAK                              1
#define RSETL_VAL_SSTAT_RESULT_CREST                             2

#define RSETL_VAL_FMDEM_RESULT_OFF                               0
#define RSETL_VAL_FMDEM_RESULT_CURR                              1
#define RSETL_VAL_FMDEM_RESULT_AVG                               2
#define RSETL_VAL_FMDEM_RESULT_MAX                               3
#define RSETL_VAL_FMDEM_RESULT_MIN                               4
#define RSETL_VAL_FMDEM_RESULT_VIEW                              5

#define RSETL_VAL_FMDEM_IMM                                      0
#define RSETL_VAL_FMDEM_AVG                                      1

#define RSETL_VAL_STAT_MEAN                                      0
#define RSETL_VAL_STAT_PEAK                                      1
#define RSETL_VAL_STAT_CFAC                                      2

#define RSETL_VAL_TRG_TV_HSYNC                                   3

#define RSETL_VAL_ATV_VME_LNL1                                   18
#define RSETL_VAL_ATV_VME_LNL2                                   19
#define RSETL_VAL_ATV_VME_LNL3                                   20
#define RSETL_VAL_ATV_VME_LNL4                                   21
#define RSETL_VAL_ATV_VME_LNL5                                   22
#define RSETL_VAL_ATV_VME_DG1S                                   25
#define RSETL_VAL_ATV_VME_DG2S                                   26
#define RSETL_VAL_ATV_VME_DG3S                                   27
#define RSETL_VAL_ATV_VME_DG4S                                   28
#define RSETL_VAL_ATV_VME_DG5S                                   29
#define RSETL_VAL_ATV_VME_DP1S                                   32
#define RSETL_VAL_ATV_VME_DP2S                                   33
#define RSETL_VAL_ATV_VME_DP3S                                   34
#define RSETL_VAL_ATV_VME_DP4S                                   35
#define RSETL_VAL_ATV_VME_DP5S                                   36
#define RSETL_VAL_ATV_VME_ICPS                                   39
#define RSETL_VAL_ATV_VME_ICPB                                   40
#define RSETL_VAL_ATV_VME_ICP1                                   41
#define RSETL_VAL_ATV_VME_ICP2                                   42
#define RSETL_VAL_ATV_VME_ICP3                                   43
#define RSETL_VAL_ATV_VME_ICP4                                   44
#define RSETL_VAL_ATV_VME_ICP5                                   45

#define RSETL_VAL_ATV_VALUE                                      0
#define RSETL_VAL_ATV_MIN                                        1
#define RSETL_VAL_ATV_MAX                                        2

#define RSETL_VAL_CATV_MAIN_MEAS_LBAR                            0
#define RSETL_VAL_CATV_MAIN_MEAS_SNR                             1
#define RSETL_VAL_CATV_MAIN_MEAS_SA                              2
#define RSETL_VAL_CATV_MAIN_MEAS_BA                              3
#define RSETL_VAL_CATV_MAIN_MEAS_CLP                             4
#define RSETL_VAL_CATV_MAIN_MEAS_CLB                             5
#define RSETL_VAL_CATV_MAIN_MEAS_BD                              6
#define RSETL_VAL_CATV_MAIN_MEAS_LTD                             7
#define RSETL_VAL_CATV_MAIN_MEAS_TTP                             8
#define RSETL_VAL_CATV_MAIN_MEAS_STD                             9
#define RSETL_VAL_CATV_MAIN_MEAS_TILT                            10
#define RSETL_VAL_CATV_MAIN_MEAS_CLIP                            11
#define RSETL_VAL_CATV_MAIN_MEAS_CLIB                            12
#define RSETL_VAL_CATV_MAIN_MEAS_GCNL                            13
#define RSETL_VAL_CATV_MAIN_MEAS_PCNL                            14
#define RSETL_VAL_CATV_MAIN_MEAS_LNL                             15
#define RSETL_VAL_CATV_MAIN_MEAS_DG                              16
#define RSETL_VAL_CATV_MAIN_MEAS_DP                              17
#define RSETL_VAL_CATV_MAIN_MEAS_MB                              18
#define RSETL_VAL_CATV_MAIN_MEAS_SX                              19
#define RSETL_VAL_CATV_MAIN_MEAS_ICPM                            20

#define RSETL_VAL_DTV_LAYER_A                                    0
#define RSETL_VAL_DTV_LAYER_B                                    1
#define RSETL_VAL_DTV_LAYER_C                                    2

#define RSETL_VAL_DTV_LIM_MERR                                   0
#define RSETL_VAL_DTV_LIM_MERP                                   1
#define RSETL_VAL_DTV_LIM_MARM                                   2
#define RSETL_VAL_DTV_LIM_MTRM                                   3
#define RSETL_VAL_DTV_LIM_BARS                                   4

#define RSETL_VAL_DTV_INFO_CURR                                  0
#define RSETL_VAL_DTV_INFO_NEXT                                  1

#define RSETL_VAL_DTV_RES_OVER_CONS                              0
#define RSETL_VAL_DTV_RES_OVER_CRAT                              1
#define RSETL_VAL_DTV_RES_OVER_TDE                               2
#define RSETL_VAL_DTV_RES_OVER_SEGM                              3

#define RSETL_VAL_EQ_DFE                                         0
#define RSETL_VAL_EQ_FFE                                         1

#define RSETL_VAL_EQ_UNIT_TAPS                                   0
#define RSETL_VAL_EQ_UNIT_SEC                                    1

#define RSETL_VAL_DTV_PLP_ID                                     0
#define RSETL_VAL_DTV_PARADE_ID                                  1

#define RSETL_VAL_DTV_LIMIT_RF_LEVEL                             0
#define RSETL_VAL_DTV_LIMIT_CF_OFFSET                            1
#define RSETL_VAL_DTV_LIMIT_AM_MOD_DEPTH                         2
#define RSETL_VAL_DTV_LIMIT_DEV_MPX                              3
#define RSETL_VAL_DTV_LIMIT_DEV_DEMOD_L                          4
#define RSETL_VAL_DTV_LIMIT_DEV_DEMOD_R                          5
#define RSETL_VAL_DTV_LIMIT_DEV_MONO                             6
#define RSETL_VAL_DTV_LIMIT_DEV_STEREO                           7
#define RSETL_VAL_DTV_LIMIT_DEV_PILOT                            8
#define RSETL_VAL_DTV_LIMIT_PILOT_FREQ_OFFSET                    9
#define RSETL_VAL_DTV_LIMIT_PILOT_PHA_TO_S                      10
#define RSETL_VAL_DTV_LIMIT_RDS_DEV                             11
#define RSETL_VAL_DTV_LIMIT_RDS_FREQ_OFFSET                     12
#define RSETL_VAL_DTV_LIMIT_RDS_PHA_TO_PILOT                    13
#define RSETL_VAL_DTV_LIMIT_RDS_BER                             14
#define RSETL_VAL_DTV_LIMIT_DEV_DARC                            15
#define RSETL_VAL_DTV_LIMIT_DEV_CARR                            16
#define RSETL_VAL_DTV_LIMIT_SCA_SC_OFFSET                       17
#define RSETL_VAL_DTV_LIMIT_SCA_DEV_SCA                         18

#define RSETL_VAL_RADIO_LIMIT_SN_R15                             0
#define RSETL_VAL_RADIO_LIMIT_SN_Q15                             1
#define RSETL_VAL_RADIO_LIMIT_SN_QI15                            2
#define RSETL_VAL_RADIO_LIMIT_SN_MR1H                            3
#define RSETL_VAL_RADIO_LIMIT_SN_AP1H                            4
#define RSETL_VAL_RADIO_LIMIT_SN_P20                             5
#define RSETL_VAL_RADIO_LIMIT_SN_AQ20                            6
#define RSETL_VAL_RADIO_LIMIT_SN_AQI2                            7
#define RSETL_VAL_RADIO_LIMIT_DFD_D2D                            8
#define RSETL_VAL_RADIO_LIMIT_DFD_D2DS                           9
#define RSETL_VAL_RADIO_LIMIT_DFD_D3                            10
#define RSETL_VAL_RADIO_LIMIT_THD                               11

#define RSETL_VAL_RADIO_CH_SINGLE                                0
#define RSETL_VAL_RADIO_CH_L                                     1
#define RSETL_VAL_RADIO_CH_R                                     2

#define RSETL_VAL_RADIO_LIMIT_MPX_POW                            0
#define RSETL_VAL_RADIO_LIMIT_MPX_PEAK_DEV                       1
#define RSETL_VAL_RADIO_LIMIT_MP_RESPONSE                        2
#define RSETL_VAL_RADIO_LIMIT_MP_GRADIENT                        3

#define RSETL_VAL_DTV_MER_PHASE_NOISE                            0
#define RSETL_VAL_DTV_MER_RESIDUAL_PM                            1
#define RSETL_VAL_DTV_MER_RESIDUAL_FM                            2
#define RSETL_VAL_DTV_MER_INTEGRATION                            3
#define RSETL_VAL_DTV_MER_RBW                                    4
#define RSETL_VAL_DTV_MER_ACQ_TIME                               5

#define RSETL_VAL_DTV_ATSC_PRI                                   0
#define RSETL_VAL_DTV_ATSC_SEC                                   1
#define RSETL_VAL_DTV_ATSC_TPC                                   2
#define RSETL_VAL_DTV_ATSC_FIC                                   3
#define RSETL_VAL_DTV_ATSC_PAYLOAD                               4
#define RSETL_VAL_DTV_ATSC_PARADE                                5

#define RSETL_VAL_RADIO_SPEC_SINAD                               0
#define RSETL_VAL_RADIO_SPEC_THD                                 1
#define RSETL_VAL_RADIO_SPEC_MOD_FREQ                            2
#define RSETL_VAL_RADIO_SPEC_SC_FREQ_OFFSET                      3

#define RSETL_VAL_RADIO_RESPONSE_FREQ                            0
#define RSETL_VAL_RADIO_RESPONSE_AMP                             1
#define RSETL_VAL_RADIO_RESPONSE_PHASE                           2

#define RSETL_VAL_RADIO_DFD_D2D                                  0
#define RSETL_VAL_RADIO_DFD_D2DS                                 1
#define RSETL_VAL_RADIO_DFD_D3                                   2
#define RSETL_VAL_RADIO_DFD_DEV                                  3
#define RSETL_VAL_RADIO_DFD_F1                                   4
#define RSETL_VAL_RADIO_DFD_F2                                   5

#define RSETL_VAL_DTV_ATSC_BBRS                                  0
#define RSETL_VAL_DTV_ATSC_BARS                                  1
#define RSETL_VAL_DTV_ATSC_PER                                   2
#define RSETL_VAL_DTV_ATSC_MPER                                  3

#define RSETL_VAL_AUDIO_FREQ_L                                   0
#define RSETL_VAL_AUDIO_FREQ_R                                   1
#define RSETL_VAL_AUDIO_FREQ_SCA                                 2
#define RSETL_VAL_AUDIO_FREQ_UPPER                               3
#define RSETL_VAL_AUDIO_FREQ_SPACING                             4

#define RSETL_VAL_AUDIO_LEVEL_L                                  0
#define RSETL_VAL_AUDIO_LEVEL_R                                  1
#define RSETL_VAL_AUDIO_LEVEL_PILOT                              2
#define RSETL_VAL_AUDIO_LEVEL_SCA                                3

#define RSETL_VAL_DTV_ECHO_MER_SHORT_EQ                          0
#define RSETL_VAL_DTV_ECHO_DET_THRESHOLD                         1

#define RSETL_VAL_RADIO_SN_R15                                   0
#define RSETL_VAL_RADIO_SN_Q15                                   1
#define RSETL_VAL_RADIO_SN_QI15                                  2
#define RSETL_VAL_RADIO_SN_MR1H                                  3
#define RSETL_VAL_RADIO_SN_AP1H                                  4
#define RSETL_VAL_RADIO_SN_P20                                   5
#define RSETL_VAL_RADIO_SN_AQ20                                  6
#define RSETL_VAL_RADIO_SN_AQI2                                  7

#define RSETL_VAL_DTV_RESULT_FFTM                                0
#define RSETL_VAL_DTV_RESULT_GINT                                1
#define RSETL_VAL_DTV_RESULT_CRAT                                2
#define RSETL_VAL_DTV_RESULT_CRHP                                3
#define RSETL_VAL_DTV_RESULT_CRLP                                4
#define RSETL_VAL_DTV_RESULT_INT                                 5
#define RSETL_VAL_DTV_RESULT_TMOD                                6
#define RSETL_VAL_DTV_RESULT_SBP                                 7
#define RSETL_VAL_DTV_RESULT_DEIN                                8
#define RSETL_VAL_DTV_RESULT_CFR                                 9
#define RSETL_VAL_DTV_RESULT_CID                                 10
#define RSETL_VAL_DTV_RESULT_TPSR                                11
#define RSETL_VAL_DTV_RESULT_LIND                                12

#define RSETL_VAL_DTV_RESULT_MTBR                                4
#define RSETL_VAL_DTV_RESULT_BBV                                 5
#define RSETL_VAL_DTV_RESULT_PBBV                                6
#define RSETL_VAL_DTV_RESULT_TBBV                                7
#define RSETL_VAL_DTV_RESULT_BBRS                                8
#define RSETL_VAL_DTV_RESULT_PBBR                                9
#define RSETL_VAL_DTV_RESULT_TBBR                                10
#define RSETL_VAL_DTV_RESULT_BARS                                11
#define RSETL_VAL_DTV_RESULT_PBAR                                12
#define RSETL_VAL_DTV_RESULT_TBAR                                13
#define RSETL_VAL_DTV_RESULT_PER                                 14
#define RSETL_VAL_DTV_RESULT_PPER                                15
#define RSETL_VAL_DTV_RESULT_TPER                                16
#define RSETL_VAL_DTV_RESULT_PERR                                17

#define RSETL_VAL_DTV_RES_MRLO                                   0
#define RSETL_VAL_DTV_RES_MPLO                                   1
#define RSETL_VAL_DTV_RES_MRPL                                   2
#define RSETL_VAL_DTV_RES_MPPL                                   3
#define RSETL_VAL_DTV_RES_ERPL                                   4
#define RSETL_VAL_DTV_RES_EPPL                                   5
#define RSETL_VAL_DTV_RES_ITLD                                   6
#define RSETL_VAL_DTV_RES_ACQ                                    7
#define RSETL_VAL_DTV_RES_BBCH                                   8
#define RSETL_VAL_DTV_RES_PBBC                                   9
#define RSETL_VAL_DTV_RES_TBBC                                   10
#define RSETL_VAL_DTV_RES_ESR                                    11
#define RSETL_VAL_DTV_RES_PESR                                   12
#define RSETL_VAL_DTV_RES_TESR                                   13
#define RSETL_VAL_DTV_RES_FER                                    14
#define RSETL_VAL_DTV_RES_PFER                                   15
#define RSETL_VAL_DTV_RES_TFER                                   16

/****************************************************************************
 *---------------- Instrument Driver Function Declarations -----------------*
 ****************************************************************************/

ViStatus rsetl_init(ViRsrc     resourceName,
                    ViBoolean  IDQuery,
                    ViBoolean  resetDevice,
                    ViSession* instrSession);

ViStatus rsetl_InitWithOptions(ViRsrc     resourceName,
                               ViBoolean  IDQuery,
                               ViBoolean  resetDevice,
                               ViString   optionString,
                               ViSession* instrSession);

ViStatus rsetl_ConfigureInstrumentMode(ViSession instrSession,
                                       ViInt32   instrumentMode);

ViStatus rsetl_QueryInstrumentMode(ViSession instrSession,
                                   ViInt32*  instrumentMode);

ViStatus rsetl_CATVMode(ViSession instrSession);

ViStatus rsetl_ConfigureCATVChannelSetup(ViSession instrSession,
                                         ViString  channelTableName,
                                         ViInt32   measurementChannel);

ViStatus rsetl_ConfigureCATVFrequencyStartStop(ViSession instrSession,
                                               ViReal64  startFrequency,
                                               ViReal64  stopFrequency);

ViStatus rsetl_ConfigureCATVFrequencyCenterSpan(ViSession instrSession,
                                                ViReal64  centerFrequency,
                                                ViReal64  span);

ViStatus rsetl_ConfigureCATVChannelFrequency(ViSession instrSession,
                                             ViReal64  RFFrequency,
                                             ViInt32   axisLabeling);

ViStatus rsetl_ConfigureCATVChannelFrequencyStepSize(ViSession instrSession,
                                                     ViReal64  stepSize);

ViStatus rsetl_ConfigureCATVFrequencySpanFull(ViSession instrSession);

ViStatus rsetl_ConfigureCATVModulationStandard(ViSession instrSession,
                                               ViString  modulationStandard,
                                               ViInt32   signalType,
                                               ViInt32   sidebandPosition);

ViStatus rsetl_ConfigureCATVSweepCouplingAuto(ViSession instrSession,
                                              ViInt32   sweepCoupling);

ViStatus rsetl_ConfigureCATVSweepCoupling(ViSession instrSession,
                                          ViInt32   sweepCoupling,
                                          ViReal64  couplingValue);

ViStatus rsetl_ConfigureCATVAcquisition(ViSession instrSession,
                                        ViBoolean sweepModeContinuous,
                                        ViInt32   numberOfSweeps);

ViStatus rsetl_ConfigureCATVVerticalScale(ViSession instrSession,
                                          ViInt32   verticalScale);

ViStatus rsetl_ConfigureCATVHorizontalScaling(ViSession instrSession,
                                              ViBoolean state);

ViStatus rsetl_ConfigureCATVCenterPosition(ViSession instrSession,
                                           ViReal64  centerPosition);

ViStatus rsetl_ConfigureCATVDivision(ViSession instrSession,
                                     ViReal64  division);

ViStatus rsetl_ConfigureCATVSweepPoints(ViSession instrSession,
                                        ViInt32   sweepPoints);

ViStatus rsetl_ConfigureCATVLevel(ViSession instrSession,
                                  ViInt32   amplitudeUnits,
                                  ViReal64  inputImpedance,
                                  ViReal64  referenceLevel,
                                  ViReal64  referenceLevelOffset,
                                  ViBoolean attenuationAuto,
                                  ViReal64  attenuation);

ViStatus rsetl_QueryCATVAttenuatorState(ViSession  instrSession,
                                        ViBoolean* attenuatorState);

ViStatus rsetl_ConfigureCATVDriveTestMode(ViSession instrSession,
                                          ViBoolean driveTestMode,
                                          ViReal64  reserve,
                                          ViReal64  hysteresis);

ViStatus rsetl_ConfigureCATVReferenceLevelAuto(ViSession instrSession);

ViStatus rsetl_ConfigureCATVLevelDisplay(ViSession instrSession,
                                         ViBoolean levelDisplay);

ViStatus rsetl_ConfigureCATVAttenuationMode(ViSession instrSession,
                                            ViInt32   attenuationMode);

ViStatus rsetl_ConfigureCATVUnits(ViSession instrSession,
                                  ViInt32   units);

ViStatus rsetl_ConfigureCATVPreselectionState(ViSession instrSession,
                                              ViBoolean preselection);

ViStatus rsetl_ConfigureCATVPreamplifierState(ViSession instrSession,
                                              ViBoolean state);

ViStatus rsetl_QueryCATVPreamplifierState(ViSession  instrSession,
                                          ViBoolean* state);

ViStatus rsetl_ConfigureCATVInputSelection(ViSession instrSession,
                                           ViBoolean iQState);

ViStatus rsetl_ConfigureCATVInputMPXState(ViSession instrSession,
                                          ViBoolean MPXState);

ViStatus rsetl_ConfigureCATVSoundChannel(ViSession instrSession,
                                         ViInt32   soundChannel);

ViStatus rsetl_ConfigureCATVAudioState(ViSession instrSession,
                                       ViBoolean state);

ViStatus rsetl_ConfigureCATVAudioVolume(ViSession instrSession,
                                        ViReal64  audioVolume);

ViStatus rsetl_ConfigureCATVVisionModulation(ViSession instrSession,
                                             ViInt32   visionModulation);

ViStatus rsetl_ConfigureCATVSpecialSettings(ViSession instrSession,
                                            ViInt32   videoClamping,
                                            ViInt32   soundDemodulation);

ViStatus rsetl_ConfigureCATVMarkerState(ViSession instrSession,
                                        ViInt32   markerNumber,
                                        ViBoolean markerState);

ViStatus rsetl_DisableCATVAllMarkers(ViSession instrSession);

ViStatus rsetl_ConfigureCATVMarkerParameter(ViSession instrSession,
                                            ViReal64  peakExcursion,
                                            ViBoolean excludeLO);

ViStatus rsetl_ConfigureCATVMarkerSearchLimits(ViSession instrSession,
                                               ViBoolean searchLimits,
                                               ViReal64  leftSearchLimit,
                                               ViReal64  rightSearchLimit);

ViStatus rsetl_ConfigureCATVMarkerPosition(ViSession instrSession,
                                           ViInt32   markerNumber,
                                           ViReal64  markerPosition);

ViStatus rsetl_SetCATVInstrumentFromMarker(ViSession instrSession,
                                           ViInt32   markerNumber,
                                           ViInt32   instrumentSetting);

ViStatus rsetl_CATVMarkerSearch(ViSession instrSession,
                                ViInt32   markerNumber,
                                ViInt32   markerSearch);

ViStatus rsetl_QueryCATVMarker(ViSession instrSession,
                               ViInt32   markerNumber,
                               ViReal64* markerPosition,
                               ViReal64* markerAmplitude);

ViStatus rsetl_ConfigureCATVDeltaMarkerState(ViSession instrSession,
                                             ViInt32   deltaMarkerNumber,
                                             ViBoolean deltaMarkerState);

ViStatus rsetl_DisableCATVAllDeltaMarkers(ViSession instrSession);

ViStatus rsetl_ConfigureCATVDeltaMarkerPosition(ViSession instrSession,
                                                ViInt32   deltaMarkerNumber,
                                                ViInt32   deltaMarkerMode,
                                                ViReal64  deltaMarkerPosition);

ViStatus rsetl_CATVDeltaMarkerSearch(ViSession instrSession,
                                     ViInt32   deltaMarker,
                                     ViInt32   markerSearch);

ViStatus rsetl_QueryCATVDeltaMarker(ViSession instrSession,
                                    ViInt32   deltaMarker,
                                    ViInt32   mode,
                                    ViReal64* position,
                                    ViReal64* amplitude);

ViStatus rsetl_ConfigureCATVTrace(ViSession instrSession,
                                  ViInt32   trace,
                                  ViInt32   traceType);

ViStatus rsetl_ConfigureCATVTraceDetector(ViSession instrSession,
                                          ViInt32   trace,
                                          ViBoolean detectorTypeAuto,
                                          ViInt32   detectorType);

ViStatus rsetl_ConfigureCATVTraceResetBehavior(ViSession instrSession,
                                               ViInt32   trace,
                                               ViBoolean resetAtChange);

ViStatus rsetl_ConfigureCATVTraceConstellationDiagramMode(ViSession instrSession,
                                                          ViInt32   trace,
                                                          ViBoolean constellationDiagramMode);

ViStatus rsetl_CATVCopyTrace(ViSession instrSession,
                             ViInt32   destinationTrace,
                             ViInt32   sourceTrace);

ViStatus rsetl_CATVStoreTraceToFile(ViSession instrSession,
                                    ViInt32   trace,
                                    ViString  fileName);

ViStatus rsetl_ConfigureCATVTriggerDelay(ViSession instrSession,
                                         ViReal64  triggerDelay);

ViStatus rsetl_ConfigureCATVDisplayLogRange(ViSession instrSession,
                                            ViReal64  range);

ViStatus rsetl_ConfigureCATVDisplayAmplitudeGridMode(ViSession instrSession,
                                                     ViInt32   yAxisGridMode);

ViStatus rsetl_ConfigureCATVDisplayReferencePosition(ViSession instrSession,
                                                     ViReal64  referencePosition);

ViStatus rsetl_ConfigureCATVDisplayChannelImpulseResponse(ViSession instrSession,
                                                          ViInt32   channelImpulseResponse);

ViStatus rsetl_ConfigureCATTDisplaySetWindowToForeground(ViSession instrSession,
                                                         ViInt32   windowState);

ViStatus rsetl_ConfigureCATTDisplayMERVsFrequency(ViSession instrSession,
                                                  ViBoolean MERInverted);

ViStatus rsetl_ConfigureCATVDisplayMERPhaseNoiseReference(ViSession instrSession,
                                                          ViReal64  referencePosition,
                                                          ViReal64  referenceDeviation);

ViStatus rsetl_ConfigureCATVDisplayMERPhaseNoiseRange(ViSession instrSession,
                                                      ViInt32   scaling,
                                                      ViReal64  deviationRange);

ViStatus rsetl_ConfigureCATVDisplayGPSPosition(ViSession instrSession,
                                               ViBoolean showGPSPosition);

ViStatus rsetl_ConfigureCATVDisplayEchoPatternPeakList(ViSession instrSession,
                                                       ViBoolean showPeakList);

ViStatus rsetl_ConfigureCATVDisplayRadioDiagramFullSize(ViSession instrSession,
                                                        ViBoolean fullSize);

ViStatus rsetl_ConfigureCATVDisplayEchoPatternMISOSignals(ViSession instrSession,
                                                          ViInt32   MISODisplay);

ViStatus rsetl_ConfigureCATVAMeasurementMode(ViSession instrSession);

ViStatus rsetl_ConfigureCATVAMeasurement(ViSession instrSession,
                                         ViInt32   measurement);

ViStatus rsetl_ConfigureCATVAModulStandard(ViSession instrSession,
                                           ViInt32   TVStandard,
                                           ViInt32   soundSystem,
                                           ViInt32   groupDelay,
                                           ViInt32   colorSystem,
                                           ViInt32   barField,
                                           ViInt32   barLine,
                                           ViInt32   barLineType,
                                           ViInt32   quietField,
                                           ViInt32   quietLine);

ViStatus rsetl_ConfigureCATVAVideoScopeLine(ViSession instrSession,
                                            ViInt32   line);

ViStatus rsetl_ConfigureCATVAVideoScopeField(ViSession instrSession,
                                             ViInt32   activeField);

ViStatus rsetl_ConfigureCATVAAveragingDepth(ViSession instrSession,
                                            ViInt32   averagingDepth);

ViStatus rsetl_ConfigureCATVAResetAveragingDepth(ViSession instrSession);

ViStatus rsetl_ConfigureCATVAResidualPictureCarrier(ViSession instrSession,
                                                    ViBoolean predefinedValue,
                                                    ViReal64  manualValue);

ViStatus rsetl_ConfigureCATVAVideoGenerator(ViSession instrSession,
                                            ViBoolean generatorState,
                                            ViInt32   IFOut,
                                            ViInt32   videoSignal,
                                            ViInt32   userLibArea,
                                            ViString  userLibImage);

ViStatus rsetl_ConfigureCATVATestSignals(ViSession instrSession,
                                         ViInt32   mainMeasurement,
                                         ViInt32   testSignal);

ViStatus rsetl_ConfigureCATVATestLines(ViSession instrSession,
                                       ViInt32   testSignal,
                                       ViInt32   lineNumber,
                                       ViInt32   field);

ViStatus rsetl_QueryCATVATestLines(ViSession instrSession,
                                   ViInt32   testSignal,
                                   ViInt32*  lineNumber,
                                   ViInt32*  field);

ViStatus rsetl_ConfigureCATVAWaveformParameter(ViSession instrSession,
                                               ViInt32   waveformParameter);

ViStatus rsetl_ConfigureCATVAWaveformLocation(ViSession instrSession,
                                              ViInt32   waveformLocation);

ViStatus rsetl_QueryAnalogTVWaveformPoints(ViSession instrSession,
                                           ViInt32*  waveformPoints);

ViStatus rsetl_QueryAnalogTVWaveformCenterWidth(ViSession instrSession,
                                                ViInt32   waveformLocation,
                                                ViReal64* waveformCenter,
                                                ViReal64* waveformWidth);

ViStatus rsetl_ConfigureCATVACNMeasurement(ViSession instrSession,
                                           ViInt32   measCarrier,
                                           ViInt32   measurementMethod,
                                           ViReal64  noiseReferenceBandwidth);

ViStatus rsetl_ConfigureCATVACNReferencePower(ViSession instrSession,
                                              ViInt32   referencePower,
                                              ViInt32   referenceChannel,
                                              ViReal64  powerManual);

ViStatus rsetl_ConfigureCATVACNMeasurementFrequencies(ViSession instrSession,
                                                      ViInt32   tableRow,
                                                      ViBoolean state,
                                                      ViReal64  centerFrequency,
                                                      ViReal64  span);

ViStatus rsetl_ConfigureCATVACNNoiseFloorCorrection(ViSession instrSession,
                                                    ViBoolean noiseFloorCorrection,
                                                    ViUInt32  timeout);

ViStatus rsetl_CATVACNNextMeasFrequency(ViSession instrSession);

ViStatus rsetl_ConfigureCATVACSOMeasurement(ViSession instrSession,
                                            ViInt32   measCarrier,
                                            ViInt32   measurementMethod);

ViStatus rsetl_ConfigureCATVACSOReferencePower(ViSession instrSession,
                                               ViInt32   referencePower,
                                               ViInt32   referenceChannel,
                                               ViReal64  powerManual);

ViStatus rsetl_ConfigureCATVACSOMeasurementFrequencies(ViSession instrSession,
                                                       ViInt32   tableRow,
                                                       ViBoolean state,
                                                       ViReal64  centerFrequency,
                                                       ViReal64  span);

ViStatus rsetl_ConfigureCATVACSONoiseFloorCorrection(ViSession instrSession,
                                                     ViBoolean noiseFloorCorrection,
                                                     ViUInt32  timeout);

ViStatus rsetl_CATVACSONextMeasFrequency(ViSession instrSession);

ViStatus rsetl_ConfigureCATVACTBMeasurement(ViSession instrSession,
                                            ViInt32   measCarrier);

ViStatus rsetl_ConfigureCATVACTBReferencePower(ViSession instrSession,
                                               ViInt32   referencePower,
                                               ViInt32   referenceChannel,
                                               ViReal64  powerManual);

ViStatus rsetl_ConfigureCATVACTBMeasurementFrequencies(ViSession instrSession,
                                                       ViInt32   tableRow,
                                                       ViBoolean state,
                                                       ViReal64  centerFrequency,
                                                       ViReal64  span);

ViStatus rsetl_ConfigureCATVACTBNoiseFloorCorrection(ViSession instrSession,
                                                     ViBoolean noiseFloorCorrection,
                                                     ViUInt32  timeout);

ViStatus rsetl_CATVACTBNextMeasFrequency(ViSession instrSession);

ViStatus rsetl_ConfigureCATVACarrierLimit(ViSession instrSession,
                                          ViInt32   measurement,
                                          ViInt32   limitType,
                                          ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVACarrierRatioLimit(ViSession instrSession,
                                               ViInt32   measurement,
                                               ViInt32   limitType,
                                               ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVAHumLimit(ViSession instrSession,
                                      ViInt32   limitType,
                                      ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVAVisionModLimit(ViSession instrSession,
                                            ViInt32   limit,
                                            ViInt32   limitType,
                                            ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVAAnalysisMeasurementLimit(ViSession instrSession,
                                                      ViInt32   measurement,
                                                      ViInt32   limitType,
                                                      ViInt32   minMax,
                                                      ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVAVisionModulationCarrierPowerUnit(
                            ViSession instrSession,
                            ViInt32   unit);

ViStatus rsetl_ConfigureCATVAVisionModulationUnit(ViSession instrSession,
                                                  ViInt32   unit);

ViStatus rsetl_ConfigureCATVAHumUnit(ViSession instrSession,
                                     ViInt32   unit);

ViStatus rsetl_ConfigureCATVDMeasurementMode(ViSession instrSession);

ViStatus rsetl_ConfigureCATVDMeasurement(ViSession instrSession,
                                         ViInt32   measurement);

ViStatus rsetl_ConfigureCATVDModulStandard(ViSession instrSession,
                                           ViInt32   TVStandard,
                                           ViInt32   rollOff,
                                           ViInt32   constellationParameter,
                                           ViReal64  symbolRate);

ViStatus rsetl_ConfigureDigitalTVT2Profile(ViSession instrSession,
                                           ViInt32   t2Profile);

ViStatus rsetl_ConfigureCATVDShoulderAttenuation(ViSession instrSession,
                                                 ViBoolean shoulderAttenuation);

ViStatus rsetl_ConfigureDigitalTVShoulderMeasurementGuideline(
                            ViSession instrSession,
                            ViInt32   guideline);

ViStatus rsetl_ConfigureCATVDOutOfBandEmissions(ViSession instrSession,
                                                ViBoolean outOfBandEmissions);

ViStatus rsetl_ConfigureCATVDOutOfBandEmissionsSetupTDMBDAB(ViSession instrSession,
                                                            ViInt32   transmitterPowerRange,
                                                            ViInt32   classification,
                                                            ViReal64  signalLevelOffset,
                                                            ViBoolean showPeaks);

ViStatus rsetl_ConfigureCATVDOutOfBandEmissionsSetupISDBT(ViSession instrSession,
                                                          ViInt32   country,
                                                          ViInt32   transmitterPowerRange,
                                                          ViReal64  transmitterPower,
                                                          ViInt32   maskType,
                                                          ViReal64  signalLevelOffset,
                                                          ViBoolean showPeaks);

ViStatus rsetl_ConfigureCATVDOutOfBandEmissionsSetupNoiseFloorCorrection(
                            ViSession instrSession,
                            ViBoolean noiseFloorCorrection,
                            ViUInt32  timeout);

ViStatus rsetl_ConfigureCATVDOutOfBandEmissionsSetupExternalNotchFilter(
                            ViSession instrSession,
                            ViBoolean externalNotchFilter,
                            ViUInt32  timeout);

ViStatus rsetl_ConfigureCATVDSFNFrequencyOffset(ViSession instrSession,
                                                ViBoolean SFNFrequencyOffset);

ViStatus rsetl_ConfigureCATVDSpectrumMarginList(ViSession instrSession,
                                                ViBoolean marginList);

ViStatus rsetl_ConfigureCATVDChannelBandwidth(ViSession instrSession,
                                              ViInt32   TVStandard,
                                              ViReal64  channelBandwidth);

ViStatus rsetl_ConfigureCATVDReferenceFrequency(ViSession instrSession,
                                                ViBoolean pilotCarrierFrequency);

ViStatus rsetl_ConfigureCATVDOverviewScreenSelect(ViSession instrSession,
                                                  ViBoolean TMCC);

ViStatus rsetl_ConfigureCATVDMERStartStop(ViSession instrSession,
                                          ViReal64  frequencyStart,
                                          ViReal64  frequencyStop);

ViStatus rsetl_ConfigureCATVDMERCenterSpan(ViSession instrSession,
                                           ViReal64  centerFrequency,
                                           ViReal64  frequencySpan);

ViStatus rsetl_ConfigureCATVDMEROptimization(ViSession instrSession,
                                             ViBoolean MEROptimization);

ViStatus rsetl_ConfigureCATVDEchoPattern(ViSession instrSession,
                                         ViBoolean zoomState,
                                         ViInt32   zoomFactor,
                                         ViReal64  velocityFactor,
                                         ViInt32   timeRangeMode);

ViStatus rsetl_ConfigureCATVDEchoPatternMeasurementSorting(ViSession instrSession,
                                                           ViBoolean sortByTime);

ViStatus rsetl_ConfigureCATVDEchoThresholdLine(ViSession instrSession,
                                               ViBoolean thresholdLine);

ViStatus rsetl_ConfigureCATVDEchoPatternOffsetThreshold(ViSession instrSession,
                                                        ViInt32   mode,
                                                        ViReal64  offsetThreshold);

ViStatus rsetl_ConfigureCATVDEchoPatternMERShortenedEQState(ViSession instrSession,
                                                            ViBoolean state);

ViStatus rsetl_ConfigureCATVDEchoPatternMERShortenedEQLength(ViSession instrSession,
                                                             ViInt32   equalizer,
                                                             ViReal64  length,
                                                             ViInt32   units);

ViStatus rsetl_ConfigureCATVDEchoPatternVelocityFactor(ViSession instrSession,
                                                       ViReal64  velocityFactor);

ViStatus rsetl_ConfigureCATVDModulErrorZoom(ViSession instrSession,
                                            ViInt32   zoom);

ViStatus rsetl_ConfigureCATVDEyeDiagramTimeSpan(ViSession instrSession,
                                                ViInt32   timeSpan);

ViStatus rsetl_ConfigureCATVDOverviewZoom(ViSession instrSession,
                                          ViInt32   zoom);

ViStatus rsetl_ConfigureCATVDConstellationDiagramZoom(ViSession instrSession,
                                                      ViInt32   zoomDiagram);

ViStatus rsetl_ConfigureCATVDISDBTConstSelect(ViSession instrSession,
                                              ViInt32   constSelect);

ViStatus rsetl_ConfigureCATVDISDBTConstellationDiagramDataCarriers(
                            ViSession instrSession,
                            ViBoolean continualAndScatteredPilots,
                            ViBoolean TMCCCarriers,
                            ViBoolean AC1Carriers,
                            ViBoolean AC2Carriers);

ViStatus rsetl_ConfigureCATVDISDBTXAxisUnit(ViSession instrSession,
                                            ViInt32   xAxisUnit);

ViStatus rsetl_ConfigureCATVDEqualizer(ViSession instrSession,
                                       ViBoolean state,
                                       ViBoolean freeze);

ViStatus rsetl_ConfigureCATVDEqualizerLearningSweeps(ViSession instrSession,
                                                     ViInt32   learningSweeps);

ViStatus rsetl_ConfigureCATVDEqualizerStepSize(ViSession instrSession,
                                               ViInt32   stepSize,
                                               ViInt32   stepSizeShrinkage);

ViStatus rsetl_ConfigureCATVDEqualizerNTSCRejectionFilter(ViSession instrSession,
                                                          ViInt32   equalizerState,
                                                          ViBoolean NTSCRejectionFilter,
                                                          ViReal64  visionCarrierFrequency,
                                                          ViInt32   notchWidth);

ViStatus rsetl_QueryCATVDSignalStatisticsNoSamples(ViSession instrSession,
                                                   ViInt32*  noOfSamples);

ViStatus rsetl_ConfigureCATVDSignalStatisticsScaling(ViSession instrSession,
                                                     ViInt32   scalingMode,
                                                     ViReal64  scalingValue);

ViStatus rsetl_ConfigureCATVDCCDFPercentMark(ViSession instrSession,
                                             ViInt32   markerNumber,
                                             ViReal64  positionValue);

ViStatus rsetl_CATVDResetEqualizer(ViSession instrSession);

ViStatus rsetl_ConfigureCATVDMinBERIntegrationSamples(ViSession instrSession,
                                                      ViInt32   samples);

ViStatus rsetl_ConfigureCATVDDisplayIQSamples(ViSession instrSession,
                                              ViInt32   IQSamples);

ViStatus rsetl_ConfigureCATVDIQSource(ViSession instrSession,
                                      ViInt32   IQSource);

ViStatus rsetl_ConfigureDigitalTVIQCarrierType(ViSession instrSession,
                                               ViInt32   carrierType);

ViStatus rsetl_ConfigureCATVDDisplayStartSymbol(ViSession instrSession,
                                                ViInt32   startSymbolIndex);

ViStatus rsetl_ConfigureCATVDDisplayFrameCount(ViSession instrSession,
                                               ViInt32   frameCount);

ViStatus rsetl_ConfigureCATVDDisplayCellCount(ViSession instrSession,
                                              ViInt32   cellCount);

ViStatus rsetl_CATVDResetBER(ViSession instrSession);

ViStatus rsetl_ConfigureCATVDFrequencyRange(ViSession instrSession,
                                            ViBoolean frequencyRange);

ViStatus rsetl_CATVDFICRetrieveDataSet(ViSession instrSession);

ViStatus rsetl_ConfigureCATVDCNMeasurement(ViSession instrSession,
                                           ViBoolean enable,
                                           ViReal64  cNFrequency,
                                           ViReal64  noiseBandwidth);

ViStatus rsetl_ConfigureCATVDTDMBDABSubchannelSettings(ViSession instrSession,
                                                       ViInt32   subchannel,
                                                       ViBoolean autoSubchannelOrganization,
                                                       ViInt32   protectionLevel,
                                                       ViInt32   startCU,
                                                       ViInt32   dataRate,
                                                       ViBoolean subchannelContainsMPEGTS);

ViStatus rsetl_ConfigureCATVDTDMBDABSynchronizationSettings(ViSession instrSession,
                                                            ViInt32   FICSync,
                                                            ViInt32   MPEGSync);

ViStatus rsetl_QueryCATVDTDMBDABNumberOfSubchannels(ViSession instrSession,
                                                    ViInt32*  noOfSubchannels);

ViStatus rsetl_QueryCATVDTDMBDABSubchannelOrganization(ViSession instrSession,
                                                       ViInt32   dataSetsToQuery,
                                                       ViInt32*  actualNumberOfDataSets,
                                                       ViInt32   subchannelIndex[],
                                                       ViInt32   dataRate[],
                                                       ViInt32   startCU[],
                                                       ViInt32   sizeCU[],
                                                       ViChar    protectionLevel[]);

ViStatus rsetl_QueryCATVDTDMBDABNumberOfServices(ViSession instrSession,
                                                 ViInt32*  noOfServices);

ViStatus rsetl_QueryCATVDTDMBDABEnsembleInformationServices(ViSession instrSession,
                                                            ViInt32   servicesToQuery,
                                                            ViInt32*  actualNumberOfServices,
                                                            ViChar    services[]);

ViStatus rsetl_QueryCATVDTDMBDABNumberOfServiceComponents(ViSession instrSession,
                                                          ViInt32   subchannel,
                                                          ViInt32*  noOfServiceComponents);

ViStatus rsetl_QueryCATVDTDMBDABEnsembleInformationServiceComponents(
                            ViSession instrSession,
                            ViInt32   subchannel,
                            ViInt32   serviceComponentsToQuery,
                            ViInt32*  actualNumberOfServComponent,
                            ViChar    serviceComponentIndex[],
                            ViInt32   transportMechanism[],
                            ViInt32   subchannelIndex[],
                            ViInt32   dataRate[],
                            ViChar    protectionLevel[],
                            ViInt32   startCU[],
                            ViInt32   sizeCU[],
                            ViInt32   conditionalAccess[]);

ViStatus rsetl_ConfigureCATVDMeasurementLog(ViSession instrSession,
                                            ViInt32   trace,
                                            ViBoolean measLogState,
                                            ViInt32   measLogParameter);

ViStatus rsetl_ConfigureCATVDMeasurementLogSpan(ViSession instrSession,
                                                ViInt32   span,
                                                ViInt32   manualSpan);

ViStatus rsetl_ConfigureCATVDMeasurementLogGPS(ViSession instrSession,
                                               ViInt32   COMPort,
                                               ViBoolean enableGPS);

ViStatus rsetl_CATVDResetMeasurementLog(ViSession instrSession);

ViStatus rsetl_QueryCATVDGPSReceiverState(ViSession instrSession,
                                          ViInt32*  state);

ViStatus rsetl_QueryCATVDGPSSignalQuality(ViSession  instrSession,
                                          ViReal64*  HDOP,
                                          ViInt32*   satellites,
                                          ViBoolean* valid);

ViStatus rsetl_QueryCATVDGPSPosition(ViSession instrSession,
                                     ViReal64* longitude,
                                     ViReal64* latitude,
                                     ViReal64* altitude);

ViStatus rsetl_QueryDigitalTVMeasLogGPSStatus(ViSession instrSession,
                                              ViInt32   *status);

ViStatus rsetl_ConfigureDigitalTVMeasLogGPSDevice(ViSession instrSession,
                                                  ViInt32   device);

ViStatus rsetl_ConfigureDigitalTVMeasLogGPSTSMX(ViSession instrSession,
                                                ViBoolean enabled,
                                                ViBoolean deadReckoning,
                                                ViInt32   pinDirection);

ViStatus rsetl_QueryDigitalTVMeasLogGPSTSMXGyroscopeStatus(ViSession instrSession,
                                                           ViInt32   *status);

ViStatus rsetl_QueryDigitalTVMeasLogGPSTSMXSpeedPulseStatus(ViSession instrSession,
                                                            ViInt32   *status);

ViStatus rsetl_QueryDigitalTVMeasLogGPSTSMXGyroscopeCalibrationStatus(
                            ViSession instrSession,
                            ViInt32   *status);

ViStatus rsetl_QueryDigitalTVMeasLogGPSTSMXSpeedPulseCalibrationStatus(
                            ViSession instrSession,
                            ViInt32   *status);

ViStatus rsetl_ConfigureCATVDAutoDetection(ViSession instrSession,
                                           ViBoolean autoDetection);

ViStatus rsetl_ConfigureCATVDTransmissionMode(ViSession instrSession,
                                              ViInt32   transmissionMode);

ViStatus rsetl_ConfigureCATVDCarrierStartStop(ViSession instrSession,
                                              ViReal64  carrierStart,
                                              ViReal64  carrierStop);

ViStatus rsetl_ConfigureCATVDCarrierCenterSpan(ViSession instrSession,
                                               ViReal64  carrierCenter,
                                               ViReal64  carrierSpan);

ViStatus rsetl_ConfigureCATVDDisplayCarrier(ViSession instrSession,
                                            ViBoolean dataCarriers,
                                            ViBoolean TRCarriers);

ViStatus rsetl_ConfigureCATVDCarrier(ViSession instrSession,
                                     ViInt32   carrierModulation,
                                     ViInt32   carrierLoops);

ViStatus rsetl_ConfigureCATVDCodeRate(ViSession instrSession,
                                      ViInt32   codeRateSelect,
                                      ViInt32   codeRate);

ViStatus rsetl_ConfigureCATVDFECSyncRequired(ViSession instrSession,
                                             ViInt32   FECSync);

ViStatus rsetl_ConfigureCATVDCoding(ViSession instrSession,
                                    ViInt32   FFTMode,
                                    ViInt32   guardInterval);

ViStatus rsetl_ConfigureCATVDGuardIntervalPN(ViSession instrSession,
                                             ViInt32   guardIntervalPN);

ViStatus rsetl_ConfigureCATVDInterleaver(ViSession instrSession,
                                         ViInt32   interleaver);

ViStatus rsetl_ConfigureCATVDLDPCMode(ViSession instrSession,
                                      ViInt32   LDPCMode);

ViStatus rsetl_ConfigureCATVDSymbolLoops(ViSession instrSession,
                                         ViInt32   symbolLoops);

ViStatus rsetl_ConfigureCATVDAGCLoops(ViSession instrSession,
                                      ViInt32   AGCLoops);

ViStatus rsetl_ConfigureCATVDSystemOptimation(ViSession instrSession,
                                              ViInt32   systemOptimationTo);

ViStatus rsetl_ConfigureCATVDTimeDeinterleaver(ViSession instrSession,
                                               ViInt32   timeDeinterleaver);

ViStatus rsetl_ConfigureCATVDMPEGTSOutput(ViSession instrSession,
                                          ViInt32   MPEGTSOutput);

ViStatus rsetl_ConfigureCATVDDisplayTMCCNextValues(ViSession instrSession,
                                                   ViBoolean displayTMCCNextValues);

ViStatus rsetl_ConfigureCATVDDataID(ViSession instrSession,
                                    ViInt32   standard,
                                    ViInt32   autoDetection,
                                    ViInt32   ID);

ViStatus rsetl_QueryCATVDDataID(ViSession instrSession,
                                ViInt32   standard,
                                ViInt32*  ID);

ViStatus rsetl_ConfigureCATVDISDBTPartialReception(ViSession instrSession,
                                                   ViBoolean partialReception);

ViStatus rsetl_ConfigureCATVDISDBTModulation(ViSession instrSession,
                                             ViInt32   hierarchicalLayer,
                                             ViInt32   modulation);

ViStatus rsetl_ConfigureCATVDISDBTCodeRate(ViSession instrSession,
                                           ViInt32   hierarchicalLayer,
                                           ViInt32   codeRate);

ViStatus rsetl_ConfigureCATVDISDBTTimeDeinterleaver(ViSession instrSession,
                                                    ViInt32   hierarchicalLayer,
                                                    ViInt32   timeDeinterleaver);

ViStatus rsetl_ConfigureCATVDISDBTSegments(ViSession instrSession,
                                           ViInt32   hierarchicalLayer,
                                           ViInt32   segments);

ViStatus rsetl_QueryCATVDISDBTSegments(ViSession instrSession,
                                       ViInt32   hierarchicalLayer,
                                       ViInt32*  segments);

ViStatus rsetl_ConfigureCATVDISDBTFFTWindow(ViSession instrSession,
                                            ViInt32   FFTWindowPosition,
                                            ViInt32   FFTWindowOffset);

ViStatus rsetl_ConfigureDigitalTVDTMB(ViSession instrSession,
                                      ViInt32   SIPowerNormalization,
                                      ViInt32   FHPowerBoost,
                                      ViInt32   FHPowerReference,
                                      ViInt32   ESRTimebase,
                                      ViInt32   BERIndication);

ViStatus rsetl_ConfigureDigitalTVDVBISSYProcessing(ViSession instrSession,
                                                   ViInt32   ISSYProcessingN);

ViStatus rsetl_ConfigureCATVDDVBT2FrameParameters(ViSession instrSession,
                                                  ViInt32   transmissionSystem,
                                                  ViInt32   pilotPattern,
                                                  ViBoolean PAPR,
                                                  ViInt32   dataSymbols,
                                                  ViInt32   l1PostConstellarion);

ViStatus rsetl_ConfigureCATVDDVBT2PLP(ViSession instrSession,
                                      ViInt32   payloadType,
                                      ViInt32   codeRate,
                                      ViInt32   modulation,
                                      ViBoolean rotation,
                                      ViInt32   FECType,
                                      ViInt32   numBlockMax,
                                      ViInt32   TIBlocksInterleavingFrame);

ViStatus rsetl_DigitalTVATSCMHScanSLT(ViSession instrSession);

ViStatus rsetl_ConfigureDigitalTVATSCSortList(ViSession instrSession,
                                              ViBoolean sortList);

ViStatus rsetl_ConfigureDigitalTVATSCSelectParadeByService(ViSession instrSession,
                                                           ViInt32   selectParadeByService);

ViStatus rsetl_ConfigureCATVDCN(ViSession instrSession,
                                ViBoolean CNState,
                                ViReal64  CN);

ViStatus rsetl_ConfigureCATVDOverLimit(ViSession instrSession,
                                       ViInt32   measurement,
                                       ViInt32   limitType,
                                       ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVDATSCMHOverviewLimit(ViSession instrSession,
                                                 ViInt32   channel,
                                                 ViInt32   measurement,
                                                 ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVDModErrLimit(ViSession instrSession,
                                         ViInt32   measurement,
                                         ViInt32   limitType,
                                         ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVDISDBTLimit(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViInt32   limitType,
                                        ViReal64  limitValue);

ViStatus rsetl_ConfigureCATVDEchoPatternUnit(ViSession instrSession,
                                             ViInt32   unit);

ViStatus rsetl_ConfigureCATVDUnit(ViSession instrSession,
                                  ViInt32   measurement,
                                  ViInt32   unit);

ViStatus rsetl_ConfigureCATVDRootMeanSquareUnit(ViSession instrSession,
                                                ViInt32   units);

ViStatus rsetl_ConfigureCATVTVMeasurement(ViSession instrSession,
                                          ViInt32   measurement);

ViStatus rsetl_ConfigureCATVTVStandardForTitlMeasurement(ViSession instrSession,
                                                         ViString  modulationStandard,
                                                         ViBoolean state);

ViStatus rsetl_ConfigureRadioMeasurementMode(ViSession instrSession);

ViStatus rsetl_ConfigureRadioMeasurement(ViSession instrSession,
                                         ViInt32   measurement);

ViStatus rsetl_ConfigureRadioSpectrumMask(ViSession instrSession,
                                          ViInt32   mask);

ViStatus rsetl_ConfigureRadioModulation(ViSession instrSession,
                                        ViInt32   radioStandard,
                                        ViInt32   channelBandwidth,
                                        ViInt32   dataSystem,
                                        ViInt32   SCAMode,
                                        ViReal64  SCAFrequnecy);

ViStatus rsetl_ConfigureRadioStereoDecoder(ViSession instrSession,
                                           ViReal64  pilotDevThreshold);

ViStatus rsetl_ConfigureRadioStereoPilotNoise(ViSession instrSession,
                                              ViBoolean pilotNoise);

ViStatus rsetl_ConfigureRadioOutput(ViSession instrSession,
                                    ViInt32   output,
                                    ViInt32   deemphasis,
                                    ViReal64  outputDeviation,
                                    ViInt32   CCVSOutput);

ViStatus rsetl_ConfigureRadioDUT(ViSession instrSession,
                                 ViReal64  inputLevel,
                                 ViReal64  AESEBU,
                                 ViReal64  deviation);

ViStatus rsetl_ConfigureRadioVerticalScale(ViSession instrSession,
                                           ViInt32   verticalScale);

ViStatus rsetl_ConfigureRadioSweep(ViSession instrSession,
                                   ViInt32   sweepPoints,
                                   ViReal64  startFrequency,
                                   ViReal64  stopFrequency);

ViStatus rsetl_ConfigureRadioCenterSpan(ViSession instrSession,
                                        ViReal64  centerFrequency,
                                        ViReal64  frequencySpan);

ViStatus rsetl_ConfigureRadioZoom(ViSession instrSession,
                                  ViInt32   zoom);

ViStatus rsetl_ConfigureRadioFrequencyResponseSetup(ViSession instrSession,
                                                    ViInt32   type,
                                                    ViReal64  referenceFrequency,
                                                    ViReal64  phaseRange);

ViStatus rsetl_ConfigureRadioFrequencyRange(ViSession instrSession,
                                            ViReal64  frequencyRange,
                                            ViReal64  refPosition);

ViStatus rsetl_ConfigureRadioCrosstalkSetup(ViSession instrSession,
                                            ViInt32   type,
                                            ViInt32   reference);

ViStatus rsetl_ConfigureRadioSNSetup(ViSession instrSession,
                                     ViReal64  referenceDeviation,
                                     ViBoolean weightingFilter);

ViStatus rsetl_ConfigureRadioReferenceDeviation(ViSession instrSession,
                                                ViReal64  referenceDeviation);

ViStatus rsetl_ConfigureRadioMPXPowerPeakMeasurement(ViSession instrSession,
                                                     ViInt32   measurement);

ViStatus rsetl_ConfigureRadioMPXPowerPeakRange(ViSession instrSession,
                                               ViInt32   trace,
                                               ViReal64  MPXPowerRefPosition,
                                               ViReal64  MPXPowerRange,
                                               ViReal64  peakDevReference,
                                               ViReal64  peakDevRange);

ViStatus rsetl_ConfigureRadioMPXDevDistrbSampleCount(ViSession instrSession,
                                                     ViInt32   sampleCount);

ViStatus rsetl_ConfigureRadioMPXPowerTimeSpan(ViSession instrSession,
                                              ViInt32   timeSpan);

ViStatus rsetl_ConfigureRadioMPXPowerTimeSpanAuto(ViSession instrSession,
                                                  ViBoolean autoTimeSpan);

ViStatus rsetl_ConfigureRadioMPXSamples(ViSession instrSession,
                                        ViInt32   samples);

ViStatus rsetl_ConfigureRadioTHDRange(ViSession instrSession,
                                      ViInt32   trace,
                                      ViReal64  topLimit,
                                      ViReal64  bottomLimit);

ViStatus rsetl_ConfigureRadioDFDRange(ViSession instrSession,
                                      ViInt32   trace,
                                      ViReal64  topLimit,
                                      ViReal64  bottomLimit);

ViStatus rsetl_ConfigureRadioDemodulator(ViSession instrSession,
                                         ViInt32   signalPath,
                                         ViInt32   deemphasis);

ViStatus rsetl_RadioOBWAdjustSettings(ViSession instrSession);

ViStatus rsetl_ConfigureRadioMarkerProbability(ViSession instrSession,
                                               ViInt32   markerNumber,
                                               ViReal64  probability);

ViStatus rsetl_ConfigureRadioMarkerProbabilityValue(ViSession instrSession,
                                                    ViInt32   markerNumber,
                                                    ViReal64  value);

ViStatus rsetl_QueryRadioMarkerDeviation(ViSession instrSession,
                                         ViInt32   markerNumber,
                                         ViReal64  *deviation);

ViStatus rsetl_ConfigureRadioAudioGenerator(ViSession instrSession,
                                            ViInt32   type,
                                            ViInt32   signal,
                                            ViInt32   connectorConfig,
                                            ViInt32   ampDefinition);

ViStatus rsetl_ConfigureRadioAudioGeneratorWaveform(ViSession instrSession,
                                                    ViInt32   waveform);

ViStatus rsetl_ConfigureRadioAudioGeneratorLevel(ViSession instrSession,
                                                 ViInt32   signal,
                                                 ViReal64  level);

ViStatus rsetl_ConfigureRadioAudioGeneratorFrequency(ViSession instrSession,
                                                     ViInt32   signal,
                                                     ViReal64  frequency);

ViStatus rsetl_ConfigureRadioAudioGeneratorSubcarrierDeviation(
                            ViSession instrSession,
                            ViBoolean state,
                            ViReal64  deviation);

ViStatus rsetl_ConfigureRadioAudioGeneratorAlternateChannelState(
                            ViSession instrSession,
                            ViBoolean enable);

ViStatus rsetl_ConfigureRadioAudioGeneratorDUT(ViSession instrSession,
                                               ViInt32   preemphasis,
                                               ViInt32   channelFrequency,
                                               ViReal64  desiredDeviation);

ViStatus rsetl_ConfigureRadioOverviewLimit(ViSession instrSession,
                                           ViInt32   measurement,
                                           ViInt32   limitType,
                                           ViReal64  limitValue);

ViStatus rsetl_ConfigureRadioAudioMeasurementLimit(ViSession instrSession,
                                                   ViInt32   measurement,
                                                   ViInt32   channel,
                                                   ViInt32   limitType,
                                                   ViReal64  limitValue);

ViStatus rsetl_ConfigureRadioModulationMeasurementLimit(ViSession instrSession,
                                                        ViInt32   measurement,
                                                        ViInt32   limitType,
                                                        ViReal64  limitValue);

ViStatus rsetl_ConfigureRadioMPXDeviationLimit(ViSession instrSession,
                                               ViReal64  limit);

ViStatus rsetl_ConfigureRadioMPXDeviationLimitRatio(ViSession instrSession,
                                                    ViReal64  ratio);

ViStatus rsetl_ConfigureRadioOBWUpperLimit(ViSession instrSession,
                                           ViReal64  limit);

ViStatus rsetl_ConfigureRadioDFDUnit(ViSession instrSession,
                                     ViInt32   units);

ViStatus rsetl_ConfigureRadioTHDUnit(ViSession instrSession,
                                     ViInt32   units);

ViStatus rsetl_ReadCATVYTrace(ViSession instrSession,
                              ViInt32   trace,
                              ViUInt32  maximumTime_ms,
                              ViInt32   arrayLength,
                              ViInt32*  actualPoints,
                              ViReal64  amplitude[]);

ViStatus rsetl_CATVChannelAdjustAtt(ViSession instrSession);

ViStatus rsetl_CATVAutoscale(ViSession instrSession);

ViStatus rsetl_QueryCATVTriggerSource(ViSession instrSession,
                                      ViInt32*  triggerSource);

ViStatus rsetl_SaveCATVMeasurementLogResults(ViSession instrSession,
                                             ViString  startTime,
                                             ViString  stopTime,
                                             ViInt32   compressionLevel,
                                             ViString  fileName);

ViStatus rsetl_ReadCATVMeasurementLogResults(ViSession instrSession,
                                             ViString  startTime,
                                             ViString  stopTime,
                                             ViInt32   compressionLevel,
                                             ViString  measurement,
                                             ViUInt32* existingRecords,
                                             ViUInt32* transferredRecords,
                                             ViInt32*  startTimeReturned,
                                             ViInt32*  stopTimeReturned,
                                             ViUInt32* measurementMode1,
                                             ViUInt32* measurementMode2,
                                             ViUInt32* measurementMode3,
                                             ViInt32   timestamp[],
                                             ViReal64  values[]);

ViStatus rsetl_ReadCATVAAchievedAveragingDepth(ViSession instrSession,
                                               ViInt32*  achievedAveragingDepth);

ViStatus rsetl_CATVInitiate(ViSession instrSession,
                            ViUInt32  timeout);

ViStatus rsetl_CATVAbort(ViSession instrSession);

ViStatus rsetl_CATVContinue(ViSession instrSession,
                            ViUInt32  timeout);

ViStatus rsetl_CATVSendSoftwareTrigger(ViSession instrSession,
                                       ViUInt32  timeout);

ViStatus rsetl_QueryCATVASignal(ViSession instrSession,
                                ViInt32*  lockedSignal);

ViStatus rsetl_QueryCATVACarrierResult(ViSession instrSession,
                                       ViInt32   measurement,
                                       ViReal64* result);

ViStatus rsetl_QueryCATVACarrierContinuousResults(ViSession instrSession,
                                                  ViReal64  results[]);

ViStatus rsetl_QueryCATVACarrierAllResults(ViSession instrSession,
                                           ViReal64  results[]);

ViStatus rsetl_QueryCATVACarrierRatioResult(ViSession instrSession,
                                            ViInt32   measurement,
                                            ViInt32   resultType,
                                            ViReal64* result);

ViStatus rsetl_QueryCATVACarrierAllRatioResults(ViSession instrSession,
                                                ViInt32   measurement,
                                                ViReal64  results[]);

ViStatus rsetl_QueryCATVAHumResult(ViSession instrSession,
                                   ViReal64* result);

ViStatus rsetl_QueryCATVAVisionModulationResult(ViSession instrSession,
                                                ViInt32   measurement,
                                                ViReal64* result);

ViStatus rsetl_QueryCATVAVisionAllModulationResults(ViSession instrSession,
                                                    ViReal64  results[]);

ViStatus rsetl_QueryCATVAAnalysisMeasurementResult(ViSession instrSession,
                                                   ViInt32   measurement,
                                                   ViReal64* result);

ViStatus rsetl_QueryCATVACarrierLimitResult(ViSession instrSession,
                                            ViInt32   measurement,
                                            ViInt32   limitType,
                                            ViInt32*  result);

ViStatus rsetl_QueryCATVACarrierRatioLimitResult(ViSession instrSession,
                                                 ViInt32   measurement,
                                                 ViInt32   limitType,
                                                 ViInt32*  result);

ViStatus rsetl_QueryCATVAHumLimitResult(ViSession instrSession,
                                        ViInt32   limitType,
                                        ViInt32*  result);

ViStatus rsetl_QueryCATVAVisionModulationLimitResult(ViSession instrSession,
                                                     ViInt32   measurement,
                                                     ViInt32   limitType,
                                                     ViInt32*  result);

ViStatus rsetl_QueryCATVAAnalysisMeasurementLimitResult(ViSession instrSession,
                                                        ViInt32   measurement,
                                                        ViInt32   limitType,
                                                        ViInt32*  result);

ViStatus rsetl_QueryCATVDSignal(ViSession instrSession,
                                ViInt32*  lockedSignal);

ViStatus rsetl_QueryCATVDMPEGSignal(ViSession instrSession,
                                    ViInt32*  lockedSignal);

ViStatus rsetl_QueryCATVDFICSyncStatus(ViSession instrSession,
                                       ViInt32*  FICSyncStatus);

ViStatus rsetl_QueryCATVDSpectrumResult(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViReal64* result);

ViStatus rsetl_QueryCATVDOverviewSettingsDVBT(ViSession instrSession,
                                              ViInt32*  constellation,
                                              ViInt32*  FFTMode,
                                              ViInt32*  guardInterval,
                                              ViInt32*  codeRateHighPriority,
                                              ViInt32*  codeRateLowPriority,
                                              ViInt32*  interleaver);

ViStatus rsetl_QueryCATVDOverviewSettingsDMBT(ViSession instrSession,
                                              ViInt32*  constellation,
                                              ViInt32*  guardInterval,
                                              ViInt32*  codeRate,
                                              ViInt32*  timeDeinterleaver);

ViStatus rsetl_QueryCATVDOverviewResult(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViReal64* result,
                                        ViInt32*  constellationResult);

ViStatus rsetl_QueryCATVDOverviewLevelContinuousResults(ViSession instrSession,
                                                        ViReal64  result[]);

ViStatus rsetl_QueryCATVDOverviewAllResults(ViSession instrSession,
                                            ViReal64  results[]);

ViStatus rsetl_QueryCATVDMeasurementResult(ViSession instrSession,
                                           ViInt32   measurement,
                                           ViInt32*  result);

ViStatus rsetl_QueryCATVDConstellationResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViReal64* result);

ViStatus rsetl_QueryCATVDModulationErrorsResult(ViSession instrSession,
                                                ViInt32   measurement,
                                                ViReal64* result);

ViStatus rsetl_QueryCATVDModulationErrorsAllResults(ViSession instrSession,
                                                    ViReal64  results[]);

ViStatus rsetl_QueryCATVDMERVsCarrierResult(ViSession instrSession,
                                            ViReal64* result);

ViStatus rsetl_QueryCATVDMERPhaseNoiseResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViReal64* result);

ViStatus rsetl_QueryCATVDIQImbalanceResult(ViSession instrSession,
                                           ViReal64* result);

ViStatus rsetl_QueryCATVDSignalStatisticsResult(ViSession instrSession,
                                                ViInt32   traceNumber,
                                                ViInt32   resultType,
                                                ViReal64* result);

ViStatus rsetl_QueryCATVDSignalStatisticsAllResults(ViSession instrSession,
                                                    ViInt32   traceNumber,
                                                    ViReal64  results[]);

ViStatus rsetl_ConfigureCATVDEchoPatternResult(ViSession instrSession,
                                               ViInt32   measurement,
                                               ViReal64* result);

ViStatus rsetl_QueryCATVDEPPVMeasurementResult(ViSession instrSession,
                                               ViInt32   arrayLength,
                                               ViInt32*  actualPoints,
                                               ViReal64  level[],
                                               ViReal64  time[],
                                               ViReal64  SFN[]);

ViStatus rsetl_QueryCATVDMarginList(ViSession instrSession,
                                    ViInt32   sequencesToQuery,
                                    ViInt32*  actualNumberOfSequences,
                                    ViReal64  interval1[],
                                    ViReal64  interval2[],
                                    ViReal64  frequency[],
                                    ViReal64  margin[]);

ViStatus rsetl_QueryCATVDTransmitterIdentificationInformation(
                            ViSession instrSession,
                            ViInt32   arrayLength,
                            ViInt32*  numberOfDetectedTransmitters,
                            ViInt32   carrierPhaseInfo[],
                            ViInt32   mainID[],
                            ViInt32   subID[],
                            ViReal64  time[]);

ViStatus rsetl_QueryCATVDAmplitudePhaseGroupDelayResult(ViSession instrSession,
                                                        ViInt32   measurement,
                                                        ViReal64* result);

ViStatus rsetl_QueryCATVDIngressDiagramEquivalentNoiseBandwidthResult(
                            ViSession instrSession,
                            ViReal64* result);

ViStatus rsetl_QueryCATVDISDBTLayerSpecificResult(ViSession instrSession,
                                                  ViInt32   measurement,
                                                  ViInt32   hierarchicalLayer,
                                                  ViReal64* result);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCSystemIdentification(
                            ViSession instrSession,
                            ViChar    systemIdentification[]);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCParameterSwitchingIndicator(
                            ViSession instrSession,
                            ViChar    parameterSwitchingIndicator[]);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCEmergencyAlarmBroadcasting(
                            ViSession  instrSession,
                            ViBoolean* emergencyAlarmBroadcasting);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCCurrentPartialReception(
                            ViSession  instrSession,
                            ViBoolean* currentPartialReception);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCNextPartialReception(
                            ViSession  instrSession,
                            ViBoolean* nextPartialReception);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCPhaseShiftCorrection(
                            ViSession instrSession,
                            ViInt32*  phaseShiftCorrection);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCReservedBits(ViSession instrSession,
                                                       ViInt32*  reservedBits);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCModulation(ViSession instrSession,
                                                     ViInt32   information,
                                                     ViInt32   hierarchicalLayer,
                                                     ViInt32*  modulation);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCCodeRate(ViSession instrSession,
                                                   ViInt32   information,
                                                   ViInt32   hierarchicalLayer,
                                                   ViInt32*  codeRate);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCTimeDeinterleaver(ViSession instrSession,
                                                            ViInt32   information,
                                                            ViInt32   hierarchicalLayer,
                                                            ViInt32*  timeDeinterleaver);

ViStatus rsetl_QueryCATVDISDBTOverviewTMCCNumberOfSegments(ViSession instrSession,
                                                           ViInt32   information,
                                                           ViInt32   hierarchicalLayer,
                                                           ViInt32*  numberOfSegments);

ViStatus rsetl_QueryCATVDVBT2PLPSyncState(ViSession  instrSession,
                                          ViBoolean* state);

ViStatus rsetl_QueryCATVDVBT2OverviewResult(ViSession instrSession,
                                            ViInt32   measurement,
                                            ViReal64* result);

ViStatus rsetl_QueryCATVDVBT2EPPVMeasurementResult(ViSession instrSession,
                                                   ViInt32   arrayLength,
                                                   ViInt32*  actualPoints,
                                                   ViReal64  level[],
                                                   ViReal64  time[],
                                                   ViReal64  group[],
                                                   ViReal64  SFN[]);

ViStatus rsetl_QueryCATVDL1PreBandwidthExtension(ViSession  instrSession,
                                                 ViBoolean* state);

ViStatus rsetl_QueryCATVDL1PreGuardInterval(ViSession instrSession,
                                            ViInt32*  guardInterval);

ViStatus rsetl_QueryCATVDL1PrePilotPattern(ViSession instrSession,
                                           ViInt32*  pattern);

ViStatus rsetl_QueryCATVDL1PreTransmissionSystem(ViSession instrSession,
                                                 ViInt32*  transmissionSystem);

ViStatus rsetl_QueryCATVDL1PreT2Version(ViSession instrSession,
                                        ViInt32   bufferSize,
                                        ViChar    version[]);

ViStatus rsetl_QueryCATVDL1PreT2Frame(ViSession instrSession,
                                      ViInt32*  frameCount,
                                      ViInt32*  symbolsPerFrame);

ViStatus rsetl_QueryCATVDL1PreL1Post(ViSession  instrSession,
                                     ViInt32*   constellation,
                                     ViInt32*   size,
                                     ViBoolean* extension,
                                     ViBoolean* repetition,
                                     ViInt32*   codeRate,
                                     ViInt32*   FECType,
                                     ViInt32*   infoSize);

ViStatus rsetl_QueryCATVDL1PrePAPR(ViSession instrSession,
                                   ViInt32*  PAPR);

ViStatus rsetl_QueryCATVDL1PreStreamType(ViSession instrSession,
                                         ViInt32*  streamType);

ViStatus rsetl_QueryCATVDL1PreSBits(ViSession instrSession,
                                    ViInt32*  s1,
                                    ViInt32*  s2);

ViStatus rsetl_QueryCATVDL1PreID(ViSession instrSession,
                                 ViInt32*  systemID,
                                 ViInt32*  cellID,
                                 ViInt32*  networkID,
                                 ViInt32*  TXIDAvailability);

ViStatus rsetl_QueryCATVDL1PreRegenerationFlag(ViSession instrSession,
                                               ViInt32*  regenerationFlag);

ViStatus rsetl_QueryCATVDL1PreFrequenciesCount(ViSession instrSession,
                                               ViInt32*  frequenciesCount);

ViStatus rsetl_QueryCATVDL1PreRFIndex(ViSession instrSession,
                                      ViInt32*  RFIndex);

ViStatus rsetl_QueryCATVDL1PreCRC(ViSession instrSession,
                                  ViUInt32* CRC);

ViStatus rsetl_QueryCATVDL1PreReservedBits(ViSession instrSession,
                                           ViInt32*  reservedBits);

ViStatus rsetl_QueryCATVDL1PostDecodedPLP(ViSession instrSession,
                                          ViInt32   bufferSize,
                                          ViChar    decodedPLP[]);

ViStatus rsetl_QueryCATVDL1PostAllDecodedPLP(ViSession instrSession,
                                             ViInt32   bufferSize,
                                             ViChar    allDecodedPLP[]);

ViStatus rsetl_QueryCATVDL1PostSignallingParameters(ViSession instrSession,
                                                    ViInt32   bufferSize,
                                                    ViChar    signallingParameters[]);

ViStatus rsetl_QueryCATVDATSCMHSyncState(ViSession  instrSession,
                                         ViInt32    channel,
                                         ViBoolean* state);

ViStatus rsetl_QueryCATVDATSCMHOverviewResult(ViSession instrSession,
                                              ViInt32   channel,
                                              ViInt32   measurement,
                                              ViReal64* result,
                                              ViReal64* target,
                                              ViReal64* progress);

ViStatus rsetl_QueryCATVDATSCMHBitRate(ViSession instrSession,
                                       ViInt32   channel,
                                       ViReal64* bitRate);

ViStatus rsetl_QueryCATVDATSCMHServicesCount(ViSession instrSession,
                                             ViInt32*  count);

ViStatus rsetl_QueryCATVDATSCMHOverviewServices(ViSession instrSession,
                                                ViInt32   numberOfServices,
                                                ViReal64  serviceID[],
                                                ViString* serviceName,
                                                ViInt32   category[],
                                                ViInt32   ensembleID[],
                                                ViInt32   paradeID[],
                                                ViInt32*  returnedValues);

ViStatus rsetl_QueryCATVDTPCDecodedParade(ViSession instrSession,
                                          ViInt32   parade,
                                          ViInt32   arraySize,
                                          ViInt32   result[],
                                          ViInt32*  FICVersion,
                                          ViReal64* TPCVersion,
                                          ViInt32*  returnedValues);

ViStatus rsetl_QueryCATVDTPCAllDecodedParades(ViSession instrSession,
                                              ViInt32   numberOfParades,
                                              ViInt32   arraySize,
                                              ViInt32   result[],
                                              ViInt32   FICVersion[],
                                              ViReal64  TPCVersion[],
                                              ViInt32*  returnedValues,
                                              ViInt32*  returnedParades);

ViStatus rsetl_QueryCATVDTPCAllSubframesStructure(ViSession instrSession,
                                                  ViInt32   numberOfSubframes,
                                                  ViInt32   numberOfSlots,
                                                  ViInt32   result[],
                                                  ViReal64* subframeUsage,
                                                  ViInt32*  returnedSlots,
                                                  ViInt32*  returnedSubframes);

ViStatus rsetl_QueryCATVDFICParametersDecodedParade(ViSession instrSession,
                                                    ViInt32   bufferSize,
                                                    ViChar    FICParameters[]);

ViStatus rsetl_QueryCATVDFICParametersAllParades(ViSession instrSession,
                                                 ViInt32   bufferSize,
                                                 ViChar    FICParameters[]);

ViStatus rsetl_QueryCATVDOverviewLimitResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViInt32   limitType,
                                             ViInt32*  result);

ViStatus rsetl_QueryCATVDATSCMHOverviewLimit(ViSession instrSession,
                                             ViInt32   channel,
                                             ViInt32   measurement,
                                             ViInt32*  result);

ViStatus rsetl_QueryCATVDModulationErrorsLimitResult(ViSession instrSession,
                                                     ViInt32   measurement,
                                                     ViInt32   limitType,
                                                     ViInt32*  result);

ViStatus rsetl_QueryCATVDISDBTLimitResult(ViSession instrSession,
                                          ViInt32   measurement,
                                          ViInt32   limitType,
                                          ViInt32   hierarchicalLayer,
                                          ViInt32*  result);

ViStatus rsetl_QueryRadioOverviewResult(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViReal64* result);

ViStatus rsetl_QueryRadioAudioScopeMeasurementResult(ViSession instrSession,
                                                     ViReal64* positivePeak,
                                                     ViReal64* negativePeak,
                                                     ViReal64* meanPeak,
                                                     ViReal64* RMS);

ViStatus rsetl_QueryRadioAudioSpectrumMeasurementResult(ViSession instrSession,
                                                        ViInt32   measurementType,
                                                        ViInt32   channel,
                                                        ViReal64* result);

ViStatus rsetl_QueryRadioMPXPowerPeakMeasurementResult(ViSession instrSession,
                                                       ViInt32   measurement,
                                                       ViReal64* minimum,
                                                       ViReal64* current,
                                                       ViReal64* maximum);

ViStatus rsetl_QueryRadioMPXPowerPeakLimitExcessResult(ViSession instrSession,
                                                       ViInt32   measurement,
                                                       ViReal64* tempExcess);

ViStatus rsetl_QueryRadioMPXDeviationViolationResult(ViSession instrSession,
                                                     ViReal64  *ratio,
                                                     ViInt32   *samplesViolating,
                                                     ViInt32   *samplesTotal);

ViStatus rsetl_QueryRadioMPXDeviationRawSamplesResult(ViSession instrSession,
                                                      ViInt32   *rawSamples);

ViStatus rsetl_QueryRadioMultipathDetectionMeasurementResult(ViSession instrSession,
                                                             ViReal64* freqResponseGradient,
                                                             ViReal64* frequencyResponse);

ViStatus rsetl_QueryRadioOBWResult(ViSession instrSession,
                                   ViReal64  *OBWResult);

ViStatus rsetl_QueryRadioRDSSyncStatus(ViSession instrSession,
                                       ViInt32*  syncStatus);

ViStatus rsetl_QueryRadioRDSService(ViSession instrSession,
                                    ViInt32   bufferSize,
                                    ViInt32*  PID,
                                    ViChar    name[],
                                    ViInt32*  ECC,
                                    ViChar    country[]);

ViStatus rsetl_QueryRadioRDSServiceDetails(ViSession  instrSession,
                                           ViInt32    bufferSize,
                                           ViBoolean* LAFlag,
                                           ViBoolean* TPFlag,
                                           ViBoolean* TAFlag,
                                           ViBoolean* MSFlag,
                                           ViChar     PTy_s[]);

ViStatus rsetl_QueryRadioRDSDecoderInformation(ViSession  instrSession,
                                               ViBoolean* stereo,
                                               ViBoolean* artificialHead,
                                               ViBoolean* compressed,
                                               ViBoolean* dynamicallySwitchedPTY);

ViStatus rsetl_QueryRadioRDSDateTime(ViSession instrSession,
                                     ViInt32   bufferSize,
                                     ViChar    date[],
                                     ViChar    localTime[],
                                     ViChar    UTC[]);

ViStatus rsetl_QueryRadioFrequencyResponseMeasurementResult(ViSession instrSession,
                                                            ViInt32   responseType,
                                                            ViInt32   channel,
                                                            ViReal64* positive,
                                                            ViReal64* negative);

ViStatus rsetl_QueryRadioCrosstalkMeasurementResult(ViSession instrSession,
                                                    ViInt32   channel,
                                                    ViReal64* crosstalk,
                                                    ViReal64* frequency);

ViStatus rsetl_QueryRadioSNMeasurementResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViInt32   channel,
                                             ViReal64* result);

ViStatus rsetl_QueryRadioTHDMeasurementResult(ViSession instrSession,
                                              ViInt32   channel,
                                              ViReal64* audioFrequency,
                                              ViReal64* deviation,
                                              ViReal64* THD);

ViStatus rsetl_QueryRadioTHDMeasurementAllResults(ViSession instrSession,
                                                  ViReal64  resultsLeftChannel[],
                                                  ViReal64  resultsRightChannel[]);

ViStatus rsetl_QueryRadioDFDMeasurementResult(ViSession instrSession,
                                              ViInt32   measurement,
                                              ViInt32   channel,
                                              ViReal64* result);

ViStatus rsetl_QueryRadioDFDMeasurementAllResults(ViSession instrSession,
                                                  ViReal64  resultsLeftChannel[],
                                                  ViReal64  resultsRightChannel[]);

ViStatus rsetl_QueryRadioOverviewLimitResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViInt32   limitType,
                                             ViInt32*  result);

ViStatus rsetl_QueryRadioModulationMeasurementLimitResult(ViSession instrSession,
                                                          ViInt32   measurement,
                                                          ViInt32   limitType,
                                                          ViInt32*  result);

ViStatus rsetl_QueryRadioAurdioMeasurementLimitResult(ViSession instrSession,
                                                      ViInt32   measurement,
                                                      ViInt32   channel,
                                                      ViInt32   limitType,
                                                      ViInt32*  result);

ViStatus rsetl_QueryRadioOBWUpperLimitResult(ViSession instrSession,
                                             ViInt32   *result);

ViStatus rsetl_ConfigureSANFrequencyStartStop(ViSession instrSession,
                                              ViReal64  startFrequency,
                                              ViReal64  stopFrequency);

ViStatus rsetl_ConfigureSANFrequencyCenter(ViSession instrSession,
                                           ViReal64  centerFrequency);

ViStatus rsetl_ConfigureSANFrequencyCenterSpan(ViSession instrSession,
                                               ViReal64  centerFrequency,
                                               ViReal64  span);

ViStatus rsetl_ConfigureSANFrequencyStepSize(ViSession instrSession,
                                             ViReal64  stepSize);

ViStatus rsetl_ConfigureSANFrequencyStepSizeCoupling(ViSession instrSession,
                                                     ViBoolean state);

ViStatus rsetl_ConfigureSANFrequencyCouplingFactor(ViSession instrSession,
                                                   ViInt32   coupling,
                                                   ViInt32   couplingFactor);

ViStatus rsetl_ConfigureSANFrequencySpanFull(ViSession instrSession);

ViStatus rsetl_ConfigureSANFrequencyMode(ViSession instrSession,
                                         ViInt32   frequencyMode);

ViStatus rsetl_ConfigureSANFrequencyOffset(ViSession instrSession,
                                           ViReal64  frequencyOffset);

ViStatus rsetl_ConfigureSANSweepCouplingAuto(ViSession instrSession,
                                             ViInt32   sweepCoupling);

ViStatus rsetl_ConfigureSANSweepCoupling(ViSession instrSession,
                                         ViInt32   sweepCoupling,
                                         ViReal64  couplingValue);

ViStatus rsetl_ConfigureSANSweepCouplingAdvanced(ViSession instrSession,
                                                 ViInt32   ratioSelection,
                                                 ViReal64  value);

ViStatus rsetl_ConfigureSANFilterType(ViSession instrSession,
                                      ViInt32   filterType);

ViStatus rsetl_ConfigureSANVBWMode(ViSession instrSession,
                                   ViInt32   videoFilterType);

ViStatus rsetl_ConfigureSANAveraging(ViSession instrSession,
                                     ViInt32   trace,
                                     ViBoolean state);

ViStatus rsetl_ConfigureSANAveragingType(ViSession instrSession,
                                         ViInt32   averagingType);

ViStatus rsetl_ConfigureSANAveragingCount(ViSession instrSession,
                                          ViInt32   averagingCount);

ViStatus rsetl_ConfigureSANAveragingAutoCount(ViSession instrSession,
                                              ViBoolean state);

ViStatus rsetl_ConfigureSANAcquisition(ViSession instrSession,
                                       ViBoolean sweepModeContinuous,
                                       ViInt32   numberOfSweeps);

ViStatus rsetl_ConfigureSANVerticalScale(ViSession instrSession,
                                         ViInt32   verticalScale);

ViStatus rsetl_ConfigureSANSweepPoints(ViSession instrSession,
                                       ViInt32   sweepPoints);

ViStatus rsetl_ConfigureSANAttenuation(ViSession instrSession,
                                       ViBoolean attenuationAuto,
                                       ViReal64  attenuation);

ViStatus rsetl_ConfigureSANReferenceLevel(ViSession instrSession,
                                          ViReal64  referenceLevel);

ViStatus rsetl_ConfigureSANLevel(ViSession instrSession,
                                 ViInt32   amplitudeUnits,
                                 ViReal64  inputImpedance,
                                 ViReal64  referenceLevel,
                                 ViReal64  referenceLevelOffset,
                                 ViBoolean attenuationAuto,
                                 ViReal64  attenuation);

ViStatus rsetl_ConfigureSANIQState(ViSession instrSession,
                                   ViBoolean IQState);

ViStatus rsetl_ConfigureSANUnits(ViSession instrSession,
                                 ViInt32   units);

ViStatus rsetl_ConfigureSANTrace(ViSession instrSession,
                                 ViInt32   trace,
                                 ViInt32   traceType);

ViStatus rsetl_ConfigureSANTraceDetector(ViSession instrSession,
                                         ViInt32   trace,
                                         ViBoolean detectorTypeAuto,
                                         ViInt32   detectorType);

ViStatus rsetl_ConfigureSANTraceResetBehavior(ViSession instrSession,
                                              ViInt32   trace,
                                              ViBoolean resetAtChange);

ViStatus rsetl_SANStoreTraceToFile(ViSession instrSession,
                                   ViInt32   trace,
                                   ViString  fileName);

ViStatus rsetl_SANTraceIQSet(ViSession instrSession,
                             ViReal64  samplingRate,
                             ViInt32   triggerMode,
                             ViInt32   triggerSlope,
                             ViInt32   pretriggerSamples,
                             ViInt32   noOfSamples);

ViStatus rsetl_ConfigureSANTraceIQSampleRate(ViSession instrSession,
                                             ViReal64  samplingRate);

ViStatus rsetl_ConfigureSANTraceIQDataAcquisition(ViSession instrSession,
                                                  ViBoolean traceState);

ViStatus rsetl_ConfigureSANTraceIQDataAveraging(ViSession instrSession,
                                                ViBoolean averagingState,
                                                ViInt32   averagingCount);

ViStatus rsetl_ConfigureSANTraceIQDataSynchronization(ViSession instrSession,
                                                      ViBoolean synchronization);

ViStatus rsetl_SANCopyTrace(ViSession instrSession,
                            ViInt32   destinationTrace,
                            ViInt32   sourceTrace);

ViStatus rsetl_ConfigureSANSubtractTraces(ViSession instrSession,
                                          ViReal64  position,
                                          ViBoolean traceMathState);

ViStatus rsetl_SANSubtractTraces(ViSession instrSession,
                                 ViInt32   trace2);

ViStatus rsetl_ConfigureSANMarker(ViSession instrSession,
                                  ViInt32   marker,
                                  ViBoolean markerEnabled,
                                  ViInt32   trace);

ViStatus rsetl_ConfigureSANSignalTrack(ViSession instrSession,
                                       ViBoolean signalTrackEnabled,
                                       ViReal64  signalTrackBandwidth,
                                       ViReal64  signalTrackThreshold,
                                       ViInt32   trace);

ViStatus rsetl_SANDisableAllMarkers(ViSession instrSession);

ViStatus rsetl_SANMarkerSearch(ViSession instrSession,
                               ViInt32   marker,
                               ViInt32   markerSearch);

ViStatus rsetl_SANMarkerPeakAuto(ViSession instrSession,
                                 ViInt32   markerSearch,
                                 ViBoolean autoPeak);

ViStatus rsetl_SANMoveMarker(ViSession instrSession,
                             ViInt32   marker,
                             ViReal64  markerPosition);

ViStatus rsetl_SetSANFromMarker(ViSession instrSession,
                                ViInt32   marker,
                                ViInt32   instrumentSetting);

ViStatus rsetl_ConfigureSANMarkerZoom(ViSession instrSession,
                                      ViReal64  markerZoom,
                                      ViUInt32  timeout);

ViStatus rsetl_QuerySANMarker(ViSession instrSession,
                              ViInt32   marker,
                              ViReal64* markerPosition,
                              ViReal64* markerAmplitude);

ViStatus rsetl_ConfigureSANPercentMarker(ViSession instrSession,
                                         ViInt32   markerNumber,
                                         ViReal64  positionValue);

ViStatus rsetl_ConfigureSANMarkerSearchThreshold(ViSession instrSession,
                                                 ViBoolean thresholdState,
                                                 ViReal64  markerThreshold);

ViStatus rsetl_ConfigureSANMarkerSearchPeakExcursion(ViSession instrSession,
                                                     ViReal64  peakExcursion);

ViStatus rsetl_ConfigureSANMarkerSearchLocalOscillator(ViSession instrSession,
                                                       ViBoolean localOscillatorSupression);

ViStatus rsetl_ConfigureSANMarkerSearchLimits(ViSession instrSession,
                                              ViBoolean searchLimits,
                                              ViReal64  searchLimitLeft,
                                              ViReal64  searchLimitRight);

ViStatus rsetl_ConfigureSANMarkerDemodulation(ViSession instrSession,
                                              ViInt32   marker,
                                              ViBoolean state,
                                              ViInt32   demodulationType,
                                              ViReal64  markerStopTime,
                                              ViBoolean continuousDemodulation);

ViStatus rsetl_ConfigureSANMarkerPeakList(ViSession instrSession,
                                          ViInt32   marker,
                                          ViInt32   peakListCount,
                                          ViInt32   peakListSort);

ViStatus rsetl_QuerySANMarkerPeakListFound(ViSession instrSession,
                                           ViInt32   marker,
                                           ViInt32*  peakListFound);

ViStatus rsetl_QuerySANMarkerPeakList(ViSession instrSession,
                                      ViInt32   marker,
                                      ViInt32   arraySize,
                                      ViInt32   peakListSelection,
                                      ViReal64  peakList[]);

ViStatus rsetl_ConfigureSANDeltaMarker(ViSession instrSession,
                                       ViInt32   deltaMarker,
                                       ViBoolean state,
                                       ViInt32   trace);

ViStatus rsetl_ConfigureSANDeltaMarkerPosition(ViSession instrSession,
                                               ViInt32   deltaMarker,
                                               ViInt32   mode,
                                               ViReal64  position);

ViStatus rsetl_SANDisableAllDeltaMarkers(ViSession instrSession);

ViStatus rsetl_SANDeltaMarkerSearch(ViSession instrSession,
                                    ViInt32   deltaMarker,
                                    ViInt32   markerSearch);

ViStatus rsetl_QuerySANDeltaMarker(ViSession instrSession,
                                   ViInt32   deltaMarker,
                                   ViInt32   mode,
                                   ViReal64* position,
                                   ViReal64* amplitude);

ViStatus rsetl_ConfigureSANReferenceFixed(ViSession instrSession,
                                          ViBoolean fixedReference);

ViStatus rsetl_ConfigureSANReferenceFixedPoint(ViSession instrSession,
                                               ViReal64  refPointLevel,
                                               ViReal64  refPointLevelOffset,
                                               ViReal64  refPointFrequencyTime);

ViStatus rsetl_SANReferenceFixedPeakSearch(ViSession instrSession);

ViStatus rsetl_SANSpeakerVolume(ViSession instrSession,
                                ViReal64  speakerVolume);

ViStatus rsetl_ConfigureSANExternGainCorrection(ViSession instrSession,
                                                ViReal64  gain);

ViStatus rsetl_ConfigureSANTriggerSource(ViSession instrSession,
                                         ViInt32   triggerSource);

ViStatus rsetl_ConfigureSANTrigger(ViSession instrSession,
                                   ViReal64  triggerDelay,
                                   ViInt32   triggerPolarity);

ViStatus rsetl_ConfigureSANVideoTrigger(ViSession instrSession,
                                        ViReal64  videoTriggerLevel);

ViStatus rsetl_ConfigureSANIFPowerTrigger(ViSession instrSession,
                                          ViReal64  triggerLevel);

ViStatus rsetl_ConfigureSANIFPowerTriggerParameters(ViSession instrSession,
                                                    ViReal64  triggerLevel,
                                                    ViReal64  holdoff,
                                                    ViReal64  hysteresis);

ViStatus rsetl_ConfigureSANTVTrigger(ViSession instrSession,
                                     ViInt32   lineSystem,
                                     ViInt32   synchronization,
                                     ViInt32   horizontalSyncLine,
                                     ViInt32   polarity);

ViStatus rsetl_ConfigureSANTVTriggerFreeRunState(ViSession instrSession,
                                                 ViBoolean TVFreeRunState);

ViStatus rsetl_ConfigureSANExternalGate(ViSession instrSession,
                                        ViBoolean gating,
                                        ViInt32   gateSource,
                                        ViInt32   mode,
                                        ViInt32   polarity,
                                        ViReal64  delay,
                                        ViReal64  length);

ViStatus rsetl_ConfigureSANPreamplifierState(ViSession instrSession,
                                             ViBoolean state);

ViStatus rsetl_CreateSANLimitLine(ViSession instrSession,
                                  ViInt32   limit,
                                  ViString  name,
                                  ViInt32   domain,
                                  ViString  comment,
                                  ViInt32   assignToTrace,
                                  ViBoolean deleteExistingLimitLine);

ViStatus rsetl_ConfigureSANLimitLine(ViSession instrSession,
                                     ViInt32   limit,
                                     ViInt32   type,
                                     ViInt32   units,
                                     ViInt32   xAxisInterpolation,
                                     ViInt32   yAxisInterpolation,
                                     ViInt32   xAxisScaling,
                                     ViReal64  margin,
                                     ViReal64  threshold);

ViStatus rsetl_DefineSANLimitLine(ViSession instrSession,
                                  ViInt32   limit,
                                  ViInt32   type,
                                  ViInt32   count,
                                  ViReal64  xAxis[],
                                  ViReal64  amplitude[]);

ViStatus rsetl_SelectSANLimitLine(ViSession instrSession,
                                  ViInt32   limit,
                                  ViString  name,
                                  ViBoolean limitEnabled);

ViStatus rsetl_EnableSANLimitCheck(ViSession instrSession,
                                   ViInt32   limit,
                                   ViInt32   type,
                                   ViBoolean limitEnabled,
                                   ViBoolean checkEnabled);

ViStatus rsetl_MoveSANLimitLine(ViSession instrSession,
                                ViInt32   limit,
                                ViInt32   type,
                                ViInt32   method,
                                ViReal64  value);

ViStatus rsetl_CopySANLimitLine(ViSession instrSession,
                                ViInt32   limit,
                                ViInt32   copyTo);

ViStatus rsetl_DeleteSANLimitLine(ViSession instrSession,
                                  ViInt32   limit);

ViStatus rsetl_ClearSANLimitLineResults(ViSession instrSession,
                                        ViInt32   limit);

ViStatus rsetl_ConfigureSANDisplayLineState(ViSession instrSession,
                                            ViInt32   line,
                                            ViInt32   type,
                                            ViBoolean state);

ViStatus rsetl_ConfigureSANDisplayLinePosition(ViSession instrSession,
                                               ViInt32   line,
                                               ViInt32   type,
                                               ViReal64  position);

ViStatus rsetl_ConfigureSANDisplayControl(ViSession instrSession,
                                          ViBoolean frequency,
                                          ViBoolean time);

ViStatus rsetl_ConfigureSANDisplayLogo(ViSession instrSession,
                                       ViBoolean state);

ViStatus rsetl_ConfigureSANDisplayComment(ViSession instrSession,
                                          ViBoolean state,
                                          ViString  comment);

ViStatus rsetl_ConfigureSANDisplayPowerSave(ViSession instrSession,
                                            ViBoolean state,
                                            ViInt32   holdoff);

ViStatus rsetl_ConfigureSANDisplayWindowSize(ViSession instrSession,
                                             ViInt32   windowSize);

ViStatus rsetl_ConfigureSANDisplayLogRange(ViSession instrSession,
                                           ViReal64  range);

ViStatus rsetl_ConfigureSANDisplayAmplitudeGridMode(ViSession instrSession,
                                                    ViInt32   yAxisGridMode);

ViStatus rsetl_ConfigureSANDisplayReferenceValue(ViSession instrSession,
                                                 ViReal64  referenceValue);

ViStatus rsetl_ConfigureSANDisplayCoupledReferenceLevel(ViSession instrSession,
                                                        ViBoolean coupledReferenceLevel);

ViStatus rsetl_ConfigureSANDisplayReferencePosition(ViSession instrSession,
                                                    ViReal64  referencePosition);

ViStatus rsetl_ConfigureSANDisplaySingleSweep(ViSession instrSession,
                                              ViBoolean state);

ViStatus rsetl_ConfigureSANDisplayUpdate(ViSession instrSession,
                                         ViBoolean displayInRemote);

ViStatus rsetl_ConfigureSANDisplaySoftFrontpanel(ViSession instrSession,
                                                 ViBoolean softFrontpanel);

ViStatus rsetl_SANDisplayColorDefault(ViSession instrSession,
                                      ViInt32   defaultSetting);

ViStatus rsetl_ConfigureSANDisplayColor(ViSession instrSession,
                                        ViInt32   colorMap,
                                        ViReal64  TINT,
                                        ViReal64  SATURATION,
                                        ViReal64  BRIGHTNESS);

ViStatus rsetl_ConfigureSANDisplayColorByPredefined(ViSession instrSession,
                                                    ViInt32   colorMap,
                                                    ViInt32   predefinedColors);

ViStatus rsetl_SelectSANTransducerFactor(ViSession instrSession,
                                         ViBoolean transducerState,
                                         ViString  transducerName);

ViStatus rsetl_ConfigureSANTransducerFactor(ViSession instrSession,
                                            ViString  name,
                                            ViInt32   unit,
                                            ViInt32   interpolation,
                                            ViString  comment,
                                            ViInt32   noOfTestPoints,
                                            ViReal64  frequencyData[],
                                            ViReal64  levelData[]);

ViStatus rsetl_ConfigureSANTransducerFactorRefLevAdj(ViSession instrSession,
                                                     ViBoolean refLevAdj);

ViStatus rsetl_ConfigureSANDisplayTransducerState(ViSession instrSession,
                                                  ViBoolean state);

ViStatus rsetl_DeleteSANTransducerFactor(ViSession instrSession,
                                         ViString  transducerName);

ViStatus rsetl_ConfigureSANHardcopyDevice(ViSession instrSession,
                                          ViInt32   device,
                                          ViInt32   destination,
                                          ViInt32   pageOrientation);

ViStatus rsetl_SANHardcopyAbort(ViSession instrSession);

ViStatus rsetl_SANHardcopyPrint(ViSession instrSession,
                                ViInt32   device,
                                ViInt32   items);

ViStatus rsetl_SANHardcopyPrintNext(ViSession instrSession,
                                    ViInt32   device);

ViStatus rsetl_SANHardcopySetFileName(ViSession instrSession,
                                      ViString  name);

ViStatus rsetl_SANHardcopyGetPrinterList(ViSession instrSession,
                                         ViInt32   bufferSize,
                                         ViChar    printerList[]);

ViStatus rsetl_SANHardcopySetPrinter(ViSession instrSession,
                                     ViInt32   device,
                                     ViString  printerName);

ViStatus rsetl_SANHardcopyComment(ViSession instrSession,
                                  ViString  comment);

ViStatus rsetl_SANHardcopyColor(ViSession instrSession,
                                ViBoolean color,
                                ViInt32   defaultSetting);

ViStatus rsetl_ConfigureSANHardcopyColor(ViSession instrSession,
                                         ViInt32   colorMap,
                                         ViReal64  TINT,
                                         ViReal64  SATURATION,
                                         ViReal64  BRIGHTNESS);

ViStatus rsetl_ConfigureSANHardcopyColorByPredefined(ViSession instrSession,
                                                     ViInt32   colorMap,
                                                     ViInt32   predefinedColors);

ViStatus rsetl_SANCalibration(ViSession instrSession,
                              ViBoolean sync,
                              ViUInt32  timeoutms,
                              ViInt32*  result);

ViStatus rsetl_SANCalibrationAbort(ViSession instrSession);

ViStatus rsetl_SANCalibrationResult(ViSession instrSession,
                                    ViInt32   arraySize,
                                    ViChar    result[]);

ViStatus rsetl_SANCalibrationState(ViSession instrSession,
                                   ViBoolean state);

ViStatus rsetl_ConfigureSANUserPortsState(ViSession instrSession,
                                          ViBoolean userPortsState);

ViStatus rsetl_ConfigureSANOutputControlLines(ViSession instrSession,
                                              ViString  controlLines);

ViStatus rsetl_GetSANUserPortsControlLine(ViSession instrSession,
                                          ViInt32   lines,
                                          ViChar    controlLines[]);

ViStatus rsetl_ConfigureSANServiceInput(ViSession instrSession,
                                        ViInt32   input);

ViStatus rsetl_ConfigureSANServiceCombFrequency(ViSession instrSession,
                                                ViInt32   frequency);

ViStatus rsetl_ConfigureSANServiceNoiseSource(ViSession instrSession,
                                              ViBoolean noiseSource);

ViStatus rsetl_ConfigureSANServiceHWInfo(ViSession instrSession,
                                         ViInt32   bufferSize,
                                         ViChar    HWInfo[]);

ViStatus rsetl_ReadSANYTrace(ViSession instrSession,
                             ViInt32   trace,
                             ViUInt32  maximumTime_ms,
                             ViInt32   arrayLength,
                             ViInt32*  actualPoints,
                             ViReal64  amplitude[]);

ViStatus rsetl_FetchSANYTrace(ViSession instrSession,
                              ViInt32   trace,
                              ViInt32   arrayLength,
                              ViInt32*  actualPoints,
                              ViReal64  amplitude[]);

ViStatus rsetl_ReadSANTraceIQData(ViSession instrSession,
                                  ViUInt32  timeout,
                                  ViInt32   bufferSize,
                                  ViInt32*  noOfPoints,
                                  ViReal64  realPartsI[],
                                  ViReal64  imaginaryPartsQ[]);

ViStatus rsetl_FetchSANTraceIQData(ViSession instrSession,
                                   ViInt32   offsetSamples,
                                   ViInt32   noOfSamples,
                                   ViInt32   bufferSize,
                                   ViInt32*  noOfPoints,
                                   ViReal64  realPartsI[],
                                   ViReal64  imaginaryPartsQ[]);

ViStatus rsetl_GetSANLimitCheckResult(ViSession instrSession,
                                      ViInt32   limit,
                                      ViInt32*  state);

ViStatus rsetl_SANInitiate(ViSession instrSession,
                           ViUInt32  timeout);

ViStatus rsetl_SANAbort(ViSession instrSession);

ViStatus rsetl_SANContinue(ViSession instrSession,
                           ViUInt32  timeout);

ViStatus rsetl_SANSendSoftwareTrigger(ViSession instrSession,
                                      ViUInt32  timeout);

ViStatus rsetl_GetSANSweepNumber(ViSession instrSession,
                                 ViInt32*  numberOfSweeps);

ViStatus rsetl_ConfigureSANTrackingGeneratorState(ViSession instrSession,
                                                  ViBoolean trackingGenerator);

ViStatus rsetl_ConfigureSANTrackingGeneratorCorrState(ViSession instrSession,
                                                      ViBoolean corrState);

ViStatus rsetl_ConfigureSANTrackingGeneratorCorr(ViSession instrSession,
                                                 ViInt32   sourceCalibration,
                                                 ViInt32   timeoutms);

ViStatus rsetl_ConfigureSANTrackingGeneratorOutputLevel(ViSession instrSession,
                                                        ViReal64  outputLevel);

ViStatus rsetl_ConfigureSANTrackingGeneratorOutputLevelOffset(
                            ViSession instrSession,
                            ViReal64  outputLevelOffset);

ViStatus rsetl_ConfigureSANMarkerNoiseMeasurement(ViSession instrSession,
                                                  ViInt32   marker,
                                                  ViBoolean state);

ViStatus rsetl_QuerySANMarkerNoiseMeasurementResult(ViSession instrSession,
                                                    ViInt32   marker,
                                                    ViReal64* result);

ViStatus rsetl_ConfigureSANMarkerPhaseNoiseMeasurement(ViSession instrSession,
                                                       ViBoolean state);

ViStatus rsetl_SANPhaseNoisePeakSearch(ViSession instrSession);

ViStatus rsetl_QuerySANPhaseNoiseResult(ViSession instrSession,
                                        ViReal64* phaseNoiseResult);

ViStatus rsetl_ConfigureSANMarkerFrequencyCounter(ViSession instrSession,
                                                  ViInt32   marker,
                                                  ViBoolean markerFrequencyCounter,
                                                  ViReal64  frequencyCounterResolution);

ViStatus rsetl_QuerySANMarkerFrequencyCounterResult(ViSession instrSession,
                                                    ViInt32   marker,
                                                    ViReal64* counterFrequency);

ViStatus rsetl_ConfigureSANNdBPoints(ViSession instrSession,
                                     ViBoolean nDBState,
                                     ViReal64  nDBLevel);

ViStatus rsetl_QuerySANNdBResult(ViSession instrSession,
                                 ViReal64* nDBResult);

ViStatus rsetl_QuerySANNdBFrequencies(ViSession instrSession,
                                      ViReal64* nDBFrequencyLower,
                                      ViReal64* nDBFrequencyHigher);

ViStatus rsetl_QuerySANNdBTimes(ViSession instrSession,
                                ViReal64* nDBTimeLower,
                                ViReal64* nDBTimeHigher);

ViStatus rsetl_ConfigureSANListPowerSequence(ViSession instrSession,
                                             ViInt32   noOfListItems,
                                             ViReal64  analyzerFrequency[],
                                             ViReal64  referenceLevel[],
                                             ViReal64  RFInputAttenuation[],
                                             ViReal64  RFInputElectronicAttn[],
                                             ViInt32   filterType[],
                                             ViReal64  resolutionBandwidth[],
                                             ViReal64  videoBandwidth[],
                                             ViReal64  measTime[],
                                             ViReal64  triggerLevel[]);

ViStatus rsetl_ConfigureSANListPowerSet(ViSession instrSession,
                                        ViBoolean peakMeas,
                                        ViBoolean RMSMeas,
                                        ViBoolean AVGMeas,
                                        ViInt32   triggerMode,
                                        ViInt32   triggerSlope,
                                        ViReal64  triggerOffset,
                                        ViReal64  gateLength);

ViStatus rsetl_SANListPowerMeasurementOff(ViSession instrSession);

ViStatus rsetl_QuerySANListPowerSequence(ViSession instrSession,
                                         ViInt32   noOfListItems,
                                         ViReal64  analyzerFrequency[],
                                         ViReal64  referenceLevel[],
                                         ViReal64  RFInputAttenuation[],
                                         ViReal64  RFInputElectronicAttn[],
                                         ViInt32   filterType[],
                                         ViReal64  resolutionBandwidth[],
                                         ViReal64  videoBandwidth[],
                                         ViReal64  measTime[],
                                         ViReal64  triggerLevel[],
                                         ViReal64  listPowerResults[]);

ViStatus rsetl_QuerySANListPowerResult(ViSession instrSession,
                                       ViInt32   noOfResults,
                                       ViReal64  listPowerResults[],
                                       ViInt32*  returnedValues);

ViStatus rsetl_ConfigureSANTimeDomainPowerMeasurementState(ViSession instrSession,
                                                           ViBoolean state);

ViStatus rsetl_ConfigureSANTimeDomainPowerMeasurement(ViSession instrSession,
                                                      ViBoolean peak,
                                                      ViBoolean RMS,
                                                      ViBoolean mean,
                                                      ViBoolean standardDeviation,
                                                      ViBoolean average,
                                                      ViBoolean maxHold,
                                                      ViInt32   power);

ViStatus rsetl_SANTimeDomainPowerMeasurementAllOff(ViSession instrSession);

ViStatus rsetl_SANTimeDomainPowerMeasurementSetReference(ViSession instrSession);

ViStatus rsetl_QuerySANTDomPowerResult(ViSession instrSession,
                                       ViInt32   measurement,
                                       ViInt32   resultType,
                                       ViReal64* result);

ViStatus rsetl_QuerySANTDomPowerPulseSequenceResult(ViSession instrSession,
                                                    ViReal64  timeOffsetOfFirstPulse,
                                                    ViReal64  measurementTime,
                                                    ViReal64  period,
                                                    ViInt32   numberOfPulses,
                                                    ViReal64  results[]);

ViStatus rsetl_SelectSANPowerMeasurement(ViSession instrSession,
                                         ViBoolean state,
                                         ViInt32   powerMeasurement);

ViStatus rsetl_ConfigureSANPowerMeasurement(ViSession instrSession,
                                            ViInt32   noOfAdjChannels,
                                            ViInt32   channelMode,
                                            ViInt32   powerMode,
                                            ViBoolean resultMode);

ViStatus rsetl_ConfigureSANPowerChannelSpacing(ViSession instrSession,
                                               ViInt32   channel,
                                               ViInt32   channelNumber,
                                               ViReal64  spacing);

ViStatus rsetl_ConfigureSANPowerChannelBandwidth(ViSession instrSession,
                                                 ViInt32   channel,
                                                 ViInt32   channelNumber,
                                                 ViReal64  bandwidth);

ViStatus rsetl_ConfigureSANChannelPowerTrace(ViSession instrSession,
                                             ViInt32   traceNumber);

ViStatus rsetl_ConfigureSANChannelPowerStandard(ViSession instrSession,
                                                ViInt32   ACPStandard);

ViStatus rsetl_SANPowerAdjustReferenceLevel(ViSession instrSession,
                                            ViUInt32  timeout);

ViStatus rsetl_SANPowerPresetMeasurement(ViSession instrSession,
                                         ViInt32   channelPowerType,
                                         ViUInt32  timeout);

ViStatus rsetl_QuerySANPowerResults(ViSession instrSession,
                                    ViInt32   powerMeasurement,
                                    ViInt32   arraySize,
                                    ViReal64  results[],
                                    ViInt32*  returnedValues);

ViStatus rsetl_ConfigureSANACPFastACPState(ViSession instrSession,
                                           ViBoolean fastACPState);

ViStatus rsetl_SANACPChannelPowerAutoAdjust(ViSession instrSession,
                                            ViUInt32  timeout);

ViStatus rsetl_ConfigureSANACPLimitState(ViSession instrSession,
                                         ViBoolean state);

ViStatus rsetl_ConfigureSANACPAdjacentChannelLimit(ViSession instrSession,
                                                   ViInt32   limitCheck,
                                                   ViReal64  limitValue);

ViStatus rsetl_ConfigureSANACPAlternateChannelLimit(ViSession instrSession,
                                                    ViInt32   alternateChannelNumber,
                                                    ViInt32   limitCheck,
                                                    ViReal64  limitValue);

ViStatus rsetl_QuerySANACPAdjacentChannelLimitCheckResults(ViSession instrSession,
                                                           ViInt32*  lowerResult,
                                                           ViInt32*  upperResult);

ViStatus rsetl_QuerySANACPAlternateChannelLimitCheckResults(ViSession instrSession,
                                                            ViInt32   alternateChannelNumber,
                                                            ViInt32*  lowerResult,
                                                            ViInt32*  upperResult);

ViStatus rsetl_ConfigureSANMulticarrierACPPower(ViSession instrSession,
                                                ViInt32   noOfAdjChannels,
                                                ViInt32   noOfTXChannels,
                                                ViInt32   channelMode,
                                                ViInt32   powerMode,
                                                ViBoolean resultMode);

ViStatus rsetl_ConfigureSANACPReferenceChannelAuto(ViSession instrSession,
                                                   ViInt32   reference);

ViStatus rsetl_ConfigureSANACPReferenceChannelMan(ViSession instrSession,
                                                  ViInt32   channel);

ViStatus rsetl_ConfigureSANOccupiedBandwidth(ViSession instrSession,
                                             ViReal64  powerBandwidth,
                                             ViReal64  channelBandwidth);

ViStatus rsetl_ConfigureSANSignalStatisticMeasurement(ViSession instrSession,
                                                      ViInt32   measurement,
                                                      ViInt32   numberOfSamples,
                                                      ViReal64  resolutionBandwidth);

ViStatus rsetl_ConfigureSANSignalStatisticMeasurementXAxis(ViSession instrSession,
                                                           ViReal64  xAxisRefLevel,
                                                           ViReal64  xAxisRange);

ViStatus rsetl_ConfigureSANSignalStatisticMeasurementYAxis(ViSession instrSession,
                                                           ViReal64  yAxisMaxValue,
                                                           ViReal64  yAxisMinValue);

ViStatus rsetl_ConfigureSANSignalStatisticSweep(ViSession instrSession,
                                                ViBoolean sweepModeContinuous);

ViStatus rsetl_SANSignalStatisticMeasurementAdjustSettings(ViSession instrSession,
                                                           ViUInt32  timeout);

ViStatus rsetl_SANSignalStatisticMeasurementPresetScaling(ViSession instrSession);

ViStatus rsetl_QuerySANSignalStatisticResult(ViSession instrSession,
                                             ViInt32   trace,
                                             ViInt32   resultType,
                                             ViReal64* result);

ViStatus rsetl_QuerySANSignalStatisticAllResults(ViSession instrSession,
                                                 ViInt32   trace,
                                                 ViReal64  result[]);

ViStatus rsetl_ConfigureSANModDepthMeasurement(ViSession instrSession,
                                               ViBoolean state);

ViStatus rsetl_QuerySANModulationDepth(ViSession instrSession,
                                       ViReal64* modulationDepth);

ViStatus rsetl_SANModulationDepthSignalSearch(ViSession instrSession);

ViStatus rsetl_ConfigureSANTOIMeasurement(ViSession instrSession,
                                          ViBoolean state);

ViStatus rsetl_QuerySANTOI(ViSession instrSession,
                           ViReal64* TOIMeasurement);

ViStatus rsetl_SANTOISignalSearch(ViSession instrSession);

ViStatus rsetl_ConfigureSANHDistMeasurement(ViSession instrSession,
                                            ViBoolean state,
                                            ViInt32   noOfHarmonics,
                                            ViBoolean harmonicRBWAuto);

ViStatus rsetl_SANAdjustHDistSettings(ViSession instrSession,
                                      ViUInt32  timeout);

ViStatus rsetl_QuerySANHDist(ViSession instrSession,
                             ViReal64* harmonicDistortionInPercent,
                             ViReal64* harmonicDistortionInDB);

ViStatus rsetl_QuerySANHDistHarmonicsList(ViSession instrSession,
                                          ViInt32   arraySize,
                                          ViReal64  harmonicsList[],
                                          ViInt32*  returnedValues);

ViStatus rsetl_ConfigureSANBurstPowerSequence(ViSession instrSession,
                                              ViReal64  analyzerFrequencyHz,
                                              ViReal64  resolutionBandwidthHz,
                                              ViReal64  measTimes,
                                              ViInt32   triggerSource,
                                              ViReal64  triggerLevel,
                                              ViReal64  triggerOffsets,
                                              ViInt32   typeOfMeas,
                                              ViInt32   noOfMeasurements);

ViStatus rsetl_ConfigureSANBurstPowerFilterType(ViSession instrSession,
                                                ViInt32   filterType);

ViStatus rsetl_GetSANBurstPowerSequence(ViSession instrSession,
                                        ViReal64  analyzerFrequencyHz,
                                        ViReal64  resolutionBandwidthHz,
                                        ViReal64  measTimes,
                                        ViInt32   triggerSource,
                                        ViReal64  triggerLevel,
                                        ViReal64  triggerOffsets,
                                        ViInt32   typeOfMeas,
                                        ViInt32   noOfMeasurements,
                                        ViUInt32  timeout,
                                        ViReal64  burstPowerResults[]);

ViStatus rsetl_GetSANBurstPowerResults(ViSession instrSession,
                                       ViInt32   noOfResults,
                                       ViReal64  burstPowerResults[]);

ViStatus rsetl_GetSANBurstPwrResultMin(ViSession instrSession,
                                       ViReal64* powerResultMin);

ViStatus rsetl_SetADemodState(ViSession instrSession,
                              ViBoolean state);

ViStatus rsetl_SelectADemodResult(ViSession instrSession,
                                  ViInt32   operatingMode,
                                  ViInt32   trace);

ViStatus rsetl_ConfigureADemodTrigger(ViSession instrSession,
                                      ViInt32   triggerSource,
                                      ViReal64  triggerOffset,
                                      ViInt32   triggerPolarity,
                                      ViReal64  triggerLevel);

ViStatus rsetl_ConfigureADemodSet(ViSession instrSession,
                                  ViReal64  sampleRate,
                                  ViInt32   recordLength,
                                  ViInt32   triggerSource,
                                  ViInt32   triggerSlope,
                                  ViInt32   pretriggerSamples,
                                  ViInt32   numberOfMeas);

ViStatus rsetl_ConfigureADemodFilter(ViSession instrSession,
                                     ViInt32   filterType,
                                     ViBoolean filterState,
                                     ViReal64  filterFrequency,
                                     ViReal64  AMFMDeemphasisValue);

ViStatus rsetl_ConfigureADemodZoom(ViSession instrSession,
                                   ViBoolean zoomState,
                                   ViReal64  startTime);

ViStatus rsetl_ConfigureADemodFrequencyCoupling(ViSession instrSession,
                                                ViInt32   coupling);

ViStatus rsetl_ConfigureADemodMarkerSearchPeakExcursion(ViSession instrSession,
                                                        ViReal64  peakExcursion);

ViStatus rsetl_ConfigureADemodSweepTime(ViSession instrSession,
                                        ViReal64  sweepTime);

ViStatus rsetl_ConfigureADemodDisplayWindowSize(ViSession instrSession,
                                                ViInt32   windowSize);

ViStatus rsetl_ConfigureADemodDisplayYScaling(ViSession instrSession,
                                              ViReal64  yScaling);

ViStatus rsetl_ConfigureADemodDisplayReferencePosition(ViSession instrSession,
                                                       ViReal64  referencePosition);

ViStatus rsetl_ConfigureADemodDisplayReferenceValue(ViSession instrSession,
                                                    ViReal64  referenceValue);

ViStatus rsetl_ConfigureADemodVerticalScale(ViSession instrSession,
                                            ViInt32   verticalScale);

ViStatus rsetl_ConfigureADemodBandwidth(ViSession instrSession,
                                        ViReal64  demodulationBandwidth);

ViStatus rsetl_ConfigureADemodAFCoupling(ViSession instrSession,
                                         ViInt32   AFCoupling);

ViStatus rsetl_ConfigureADemodMeasuringTime(ViSession instrSession,
                                            ViReal64  measuringTime);

ViStatus rsetl_ConfigureADemodAFFrequencyStartStop(ViSession instrSession,
                                                   ViReal64  startFrequency,
                                                   ViReal64  stopFrequency);

ViStatus rsetl_ConfigureADemodAFFrequencyCenterSpan(ViSession instrSession,
                                                    ViReal64  centerFrequency,
                                                    ViReal64  span);

ViStatus rsetl_ConfigureADemodAFFullSpan(ViSession instrSession);

ViStatus rsetl_ConfigureADemodAFParam(ViSession instrSession,
                                      ViReal64  resolutionBandwidth);

ViStatus rsetl_ConfigureADemodRFParam(ViSession instrSession,
                                      ViReal64  resolutionBandwidth,
                                      ViReal64  span);

ViStatus rsetl_ConfigureADemodRFZoom(ViSession instrSession,
                                     ViReal64  zoom);

ViStatus rsetl_ConfigureADemodPMPhaseWrap(ViSession instrSession,
                                          ViInt32   phaseWrap);

ViStatus rsetl_ConfigureADemodPMPhaseUnits(ViSession instrSession,
                                           ViInt32   PMUnits);

ViStatus rsetl_ConfigureADemodPMZeroPhaseReferencePoint(ViSession instrSession,
                                                        ViReal64  referencePoint);

ViStatus rsetl_GetADemodMarkerAmpliltude(ViSession instrSession,
                                         ViInt32   marker,
                                         ViReal64* markerAmplitude);

ViStatus rsetl_GetADemodDeltaMarkerAmplitude(ViSession instrSession,
                                             ViInt32   deltaMarker,
                                             ViReal64* deltaMarkerAmplitude);

ViStatus rsetl_ConfigureADemodResultType(ViSession instrSession,
                                         ViInt32   demodulationType,
                                         ViInt32   resultTypes[]);

ViStatus rsetl_GetADemodCurrentlySetValue(ViSession instrSession,
                                          ViInt32   value,
                                          ViReal64* result);

ViStatus rsetl_GetADemodResultValues(ViSession instrSession,
                                     ViInt32   demodulationType,
                                     ViInt32   resultType,
                                     ViUInt32  timeout,
                                     ViInt32   arraySize,
                                     ViReal64  resultValues[],
                                     ViInt32*  returnedValues);

ViStatus rsetl_GetADemodOffset(ViSession instrSession,
                               ViInt32   resultType,
                               ViReal64* value);

ViStatus rsetl_GetADemodMarkerModulationValue(ViSession instrSession,
                                              ViInt32   demodulationType,
                                              ViInt32   detectorType,
                                              ViInt32   trace,
                                              ViReal64* value);

ViStatus rsetl_GetADemodMarkerMeasValue(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViInt32   trace,
                                        ViReal64* value);

ViStatus rsetl_ReadADemodYTrace(ViSession instrSession,
                                ViInt32   trace,
                                ViUInt32  maximumTime_ms,
                                ViInt32   arrayLength,
                                ViInt32*  actualPoints,
                                ViReal64  amplitude[]);

ViStatus rsetl_PWMMode(ViSession instrSession,
                       ViBoolean state);

ViStatus rsetl_ConfigurePWMMeasurement(ViSession instrSession,
                                       ViInt32   measurementTime,
                                       ViInt32   coupling,
                                       ViReal64  frequency);

ViStatus rsetl_ConfigurePWMRelative(ViSession instrSession,
                                    ViReal64  referenceValue,
                                    ViInt32   unit);

ViStatus rsetl_ConfigurePWMAbsolute(ViSession instrSession,
                                    ViInt32   unit);

ViStatus rsetl_ConfigurePWMBarGraphView(ViSession instrSession,
                                        ViBoolean barGraphView);

ViStatus rsetl_ConfigurePWMReferenceLevelOffsetState(ViSession instrSession,
                                                     ViBoolean state);

ViStatus rsetl_ConfigurePWMAveraging(ViSession instrSession,
                                     ViBoolean manualAveraging,
                                     ViInt32   averagingCount);

ViStatus rsetl_ConfigurePWMMeasToRef(ViSession instrSession);

ViStatus rsetl_ConfigurePWMZero(ViSession instrSession);

ViStatus rsetl_ReadPWMResult(ViSession instrSession,
                             ViUInt32  timeout,
                             ViReal64* result);

ViStatus rsetl_FetchPWMResult(ViSession instrSession,
                              ViReal64* result);

ViStatus rsetl_ConfigureReferenceOscillator(ViSession instrSession,
                                            ViInt32   reference);

ViStatus rsetl_ConfigureOutputMeasurementMode(ViSession instrSession,
                                              ViInt32   measurementMode);

ViStatus rsetl_QueryPowerSupply(ViSession instrSession,
                                ViInt32*  powerSupply);

ViStatus rsetl_setStatusRegister(ViSession instrSession,
                                 ViInt32   registerOperation,
                                 ViInt32   selStatusReg,
                                 ViInt32   enable,
                                 ViInt32   pTransition,
                                 ViInt32   nTransition);

ViStatus rsetl_getStatusRegister(ViSession instrSession,
                                 ViInt32   statusRegistersQuery,
                                 ViInt32*  registerValue);

ViStatus rsetl_FileDecimalSeparator(ViSession instrSession,
                                    ViInt32   decimalSeparator);

ViStatus rsetl_DataSetFileSelectItems(ViSession instrSession,
                                      ViInt32   itemSelector,
                                      ViBoolean itemState);

ViStatus rsetl_FileManagerOperations(ViSession instrSession,
                                     ViInt32   operation,
                                     ViString  source,
                                     ViString  destination);

ViStatus rsetl_FileDirectory(ViSession instrSession,
                             ViString  directory,
                             ViInt32   bufferSize,
                             ViChar    output[]);

ViStatus rsetl_GetCurrentDirectory(ViSession instrSession,
                                   ViChar    currentDirectory[]);

ViStatus rsetl_DataSetFileOperations(ViSession instrSession,
                                     ViInt32   operation,
                                     ViString  path);

ViStatus rsetl_DataSetFileClearAll(ViSession instrSession,
                                   ViString  directory);

ViStatus rsetl_SetAttributeViInt32(ViSession instrSession,
                                   ViString  repeatedCapabilityName,
                                   ViUInt32  attributeID,
                                   ViInt32   attributeValue);

ViStatus rsetl_SetAttributeViReal64(ViSession instrSession,
                                    ViString  repeatedCapabilityName,
                                    ViUInt32  attributeID,
                                    ViReal64  attributeValue);

ViStatus rsetl_SetAttributeViString(ViSession instrSession,
                                    ViString  repeatedCapabilityName,
                                    ViUInt32  attributeID,
                                    ViString  attributeValue);

ViStatus rsetl_SetAttributeViBoolean(ViSession instrSession,
                                     ViString  repeatedCapabilityName,
                                     ViUInt32  attributeID,
                                     ViBoolean attributeValue);

ViStatus rsetl_GetAttributeRepeatedCapabilityIds(ViSession instrSession,
                                                 ViUInt32  attributeID,
                                                 ViInt32   bufferSize,
                                                 ViChar    repeatedCapabilityIds[]);

ViStatus rsetl_GetAttributeRepeatedCapabilityIdNames(ViSession instrSession,
                                                     ViUInt32  attributeID,
                                                     ViString  repeatedCapabilityId,
                                                     ViInt32   bufferSize,
                                                     ViChar    repeatedCapabilityIdNames[]);

ViStatus rsetl_GetAttributeViInt32(ViSession instrSession,
                                   ViString  repeatedCapabilityName,
                                   ViUInt32  attributeID,
                                   ViInt32*  attributeValue);

ViStatus rsetl_GetAttributeViReal64(ViSession instrSession,
                                    ViString  repeatedCapabilityName,
                                    ViUInt32  attributeID,
                                    ViReal64* attributeValue);

ViStatus rsetl_GetAttributeViString(ViSession instrSession,
                                    ViString  repeatedCapabilityName,
                                    ViUInt32  attributeID,
                                    ViInt32   bufferSize,
                                    ViChar    value[]);

ViStatus rsetl_GetAttributeViBoolean(ViSession  instrSession,
                                     ViString   repeatedCapabilityName,
                                     ViUInt32   attributeID,
                                     ViBoolean* attributeValue);

ViStatus rsetl_setCheckOption(ViSession instrSession,
                              ViBoolean optionChecking);

ViStatus rsetl_setCheckRange(ViSession instrSession,
                             ViBoolean rangeChecking);

ViStatus rsetl_setCheckStatus(ViSession instrSession,
                              ViBoolean statusChecking);

ViStatus rsetl_reset(ViSession instrSession);

ViStatus rsetl_self_test(ViSession instrSession,
                         ViInt16*  selfTestResult,
                         ViChar    selfTestMessage[]);

ViStatus rsetl_SelfTestResults(ViSession instrSession,
                               ViInt32   bufferSize,
                               ViChar    results[]);

ViStatus rsetl_revision_query(ViSession instrSession,
                              ViChar    instrumentDriverRevision[],
                              ViChar    firmwareRevision[]);

ViStatus rsetl_SystemVersion(ViSession instrSession,
                             ViInt32   length,
                             ViChar    systemVersion[]);

ViStatus rsetl_error_query(ViSession instrSession,
                           ViInt32*  errorCode,
                           ViChar    errorMessage[]);

ViStatus rsetl_ErrorList(ViSession instrSession,
                         ViInt32   bufferSize,
                         ViChar    errors[]);

ViStatus rsetl_error_message(ViSession instrSession,
                             ViStatus  errorCode,
                             ViChar    errorMessage[]);

ViStatus rsetl_ClearInstrumentErrors(ViSession instrSession);

ViStatus rsetl_Preset(ViSession instrSession);

ViStatus rsetl_GetError(ViSession instrSession,
                        ViStatus* code,
                        ViInt32   bufferSize,
                        ViChar    description[]);

ViStatus rsetl_ClearError(ViSession instrSession);

ViStatus rsetl_WriteInstrData(ViSession instrSession,
                              ViString  writeBuffer);

ViStatus rsetl_WriteFromFileToInstrument(ViSession instrSession,
                                         ViString  source,
                                         ViString  destination);

ViStatus rsetl_ReadToFileFromInstrument(ViSession instrSession,
                                        ViString  source,
                                        ViString  destination);

ViStatus rsetl_QueryViBoolean(ViSession  instrSession,
                              ViString   cmd,
                              ViBoolean* value);

ViStatus rsetl_QueryViInt32(ViSession instrSession,
                            ViString  cmd,
                            ViInt32*  value);

ViStatus rsetl_QueryViReal64(ViSession instrSession,
                             ViString  cmd,
                             ViReal64* value);

ViStatus rsetl_QueryViString(ViSession instrSession,
                             ViString  cmd,
                             ViInt32   bufferSize,
                             ViChar    value[]);

ViStatus rsetl_SetOPCTimeout(ViSession instrSession,
                             ViInt32   timeout);

ViStatus rsetl_GetOPCTimeout(ViSession instrSession,
                             ViInt32*  timeout);

ViStatus rsetl_ClearStatus(ViSession instrSession);

ViStatus rsetl_IDQueryResponse(ViSession instrSession,
                               ViUInt32  bufferSize,
                               ViChar    IDQueryResponse[]);

ViStatus rsetl_ProcessAllPreviousCommands(ViSession instrSession);

ViStatus rsetl_SetVISATimeout(ViSession instrSession,
                              ViUInt32  VISATimeout);

ViStatus rsetl_GetVISATimeout(ViSession instrSession,
                              ViUInt32* VISATimeout);

ViStatus rsetl_QueryOPC(ViSession instrSession,
                        ViInt32*  opc);

ViStatus rsetl_WriteCommandWithOPCSync(ViSession instrSession,
                                       ViString  writeBuffer,
                                       ViUInt32  timeout);

ViStatus rsetl_QueryWithOPCSync(ViSession instrSession,
                                ViString  writeBuffer,
                                ViUInt32  timeout,
                                ViUInt32  bufferSize,
                                ViChar    readBuffer[],
                                ViUInt32* numBytesRead);

ViStatus rsetl_ConfigureAutoSystemErrQuery(ViSession instrSession,
                                           ViBoolean autoSystErrQuery);

ViStatus rsetl_ConfigureMultiThreadLocking(ViSession instrSession,
                                           ViBoolean multiThreadLocking);

ViStatus rsetl_close(ViSession instrSession);

/****************************************************************************
 *------------------------ Error And Completion Codes ----------------------*
 ****************************************************************************/

#define RSETL_WARN_MEASURE_UNCALIBRATED    (RS_CLASS_WARN_BASE + 0x0001L)
#define RSETL_WARN_OVER_RANGE              (RS_CLASS_WARN_BASE + 0x0002L)

#define RSETL_ERROR_MARKER_NOT_ENABLED     (RS_CLASS_ERROR_BASE + 0x0003L)
#define RSETL_ERROR_NOT_DELTA_MARKER       (RS_CLASS_ERROR_BASE + 0x0002L)
#define RSETL_ERROR_MAX_TIME_EXCEEDED      (RS_CLASS_ERROR_BASE + 0x0001L)

#define RSETL_WARNMSG_MEASURE_UNCALIBRATED "Uncalibrated measurement"
#define RSETL_WARNMSG_OVER_RANGE           "Measurement overrange"

#define RSETL_ERRMSG_MARKER_NOT_ENABLED    "Marker Not Enabled"
#define RSETL_ERRMSG_NOT_DELTA_MARKER      "Not Delta Marker"
#define RSETL_ERRMSG_MAX_TIME_EXCEEDED     "Max Time Exceeded"

#define RSETL_ERROR_CODES_AND_MSGS \
    {RSETL_WARN_MEASURE_UNCALIBRATED,  RSETL_WARNMSG_MEASURE_UNCALIBRATED},\
    {RSETL_WARN_OVER_RANGE,            RSETL_WARNMSG_OVER_RANGE},\
    {RSETL_ERROR_MARKER_NOT_ENABLED,   RSETL_ERRMSG_MARKER_NOT_ENABLED},\
    {RSETL_ERROR_NOT_DELTA_MARKER,     RSETL_ERRMSG_NOT_DELTA_MARKER},\
    {RSETL_ERROR_MAX_TIME_EXCEEDED,    RSETL_ERRMSG_MAX_TIME_EXCEEDED}

/****************************************************************************
 *---------------------------- End Include File ----------------------------*
 ****************************************************************************/

#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif
#endif /* RSETL_HEADER */
