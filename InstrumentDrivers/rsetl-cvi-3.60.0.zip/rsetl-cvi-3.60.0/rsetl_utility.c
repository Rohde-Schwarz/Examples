/*****************************************************************************
 *------------------------ Utility  -----------------------------------------*
 *****************************************************************************/
#include "rsetl.h"
#include "rscore.h"


 /*****************************************************************************
  * Function: rsetl_InitAttributes
  * Purpose:  This function inits attributes to the desired values if needed.
  *****************************************************************************/
ViStatus rsetl_InitAttributes(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    // - Driver Identification -
    checkErr(RsCore_SetAttributeViString(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_DESCRIPTION, 0, RSETL_SPECIFIC_DRIVER_DESCRIPTION));
    checkErr(RsCore_SetAttributeViString(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_PREFIX, 0, RSETL_SPECIFIC_DRIVER_PREFIX));
    checkErr(RsCore_SetAttributeViString(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_LOCATOR, 0, RSETL_SPECIFIC_DRIVER_LOCATOR));
    checkErr(RsCore_SetAttributeViString(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_VENDOR, 0, RSETL_SPECIFIC_DRIVER_VENDOR));
    checkErr(RsCore_SetAttributeViInt32(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MAJOR_VERSION, 0, RSETL_CLASS_SPEC_MAJOR_VERSION));
    checkErr(RsCore_SetAttributeViInt32(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MINOR_VERSION, 0, RSETL_CLASS_SPEC_MINOR_VERSION));

    // - Driver Capabilities -
    checkErr(RsCore_SetAttributeViString(instrSession, "", RS_ATTR_SUPPORTED_INSTRUMENT_MODELS, 0, RSETL_SUPPORTED_INSTRUMENT_MODELS));
    checkErr(RsCore_SetAttributeViString(instrSession, "", RS_ATTR_GROUP_CAPABILITIES, 0, RSETL_GROUP_CAPABILITIES));
    checkErr(RsCore_SetAttributeViString(instrSession, "", RS_ATTR_FUNCTION_CAPABILITIES, 0, RSETL_FUNCTION_CAPABILITIES));

    // - Version Info -
    checkErr(RsCore_SetAttributeViInt32(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_MAJOR_VERSION, 0, RSETL_MAJOR_VERSION));
    checkErr(RsCore_SetAttributeViInt32(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_MINOR_VERSION, 0, RSETL_MINOR_VERSION));
    checkErr(RsCore_SetAttributeViInt32(instrSession, "", RS_ATTR_SPECIFIC_DRIVER_MINOR_MINOR_VERSION, 0, RSETL_MINOR_MINOR_VERSION));

    checkErr(RsCore_SetAttributeViInt32(instrSession, "", RS_ATTR_CLASS_DRIVER_MAJOR_VERSION, 0, RSETL_CLASS_SPEC_MAJOR_VERSION));
    checkErr(RsCore_SetAttributeViInt32(instrSession, "", RS_ATTR_CLASS_DRIVER_MINOR_VERSION, 0, RSETL_CLASS_SPEC_MINOR_VERSION));

    checkErr(RsCore_SetSpecificDriverRevision(instrSession, RS_ATTR_SPECIFIC_DRIVER_REVISION));

Error:
    return error;
}

/*****************************************************************************
 * Function: rsetl_DefaultInstrSetup
 * Purpose:  This function sends a default setup to the instrument. The
 *           rsetl_reset function calls this function. The
 *           rsetl_RsInit function calls this function when the
 *           user passes VI_FALSE for the reset parameter. This function is
 *           useful for configuring settings that other instrument driver
 *           functions require.
 *
 *           Note:  Call this function only when the session is locked.
 *****************************************************************************/
ViStatus rsetl_DefaultInstrSetup(ViSession instrSession)
{
    ViStatus         error = VI_SUCCESS;
    RsCoreSessionPtr rsSession = NULL;

    checkErr(RsCore_GetRsSession(instrSession, &rsSession));

    // Set all the attributes to the default state. Do not update inherent attributes!
    checkErr(RsCore_ApplyAttributeDefaults(instrSession, VI_FALSE));

    // Init attributes
    checkErr(rsetl_InitAttributes(instrSession));

    rsSession->fastSweepInstrument = 0;
    checkErr(RsCore_ResetRegistersEseSre(instrSession));
    checkErr(RsCore_Write(instrSession, "syst:disp:upd on"));
    checkErr(RsCore_QueryViInt32(instrSession, "*OPC?", NULL));

Error:
    return error;
}

/*****************************************************************************
 * Function: rsetl_CheckStatus
 * Purpose:  This function checks the status of the instrument to detect
 *           whether the instrument has encountered an error. This function
 *           is called at the end of most exported driver functions. If the
 *           instrument reports an error, this function returns
 *           RS_ERROR_INSTRUMENT_SPECIFIC. The user can set the
 *           rsetl_ATTR_QUERY_INSTRUMENT_STATUS attribute to VI_FALSE to disable this
 *           check and increase execution speed.
 *
 *           Note:  Call this function only when the session is locked.
 *****************************************************************************/
ViStatus rsetl_CheckStatus(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    if (RsCore_QueryInstrStatus(instrSession) && !RsCore_Simulating(instrSession))
    {
        checkErr(RsCore_CheckStatus(instrSession, VI_SUCCESS));
    }

Error:
    return error;
}

/*****************************************************************************
 * Function: Read Trace Data
 * Purpose:  This function reads out trace data from the instrument.
*****************************************************************************/
ViStatus rsetl_dataReadTrace(ViSession         instrSession,
                             ViString          cmd,
                             ViInt32           arrayLength,
                             /*@out@*/ViReal64 traceData[],
                             ViPInt32          noofPoints)
{  
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, cmd, arrayLength, traceData, noofPoints));
    checkErr(RsCore_Write(instrSession, ":FORM ASC"));

Error:
    return error;
}


/****************************************************************************************************
*  rsspecan_dataQueryInterleavedData
   Queries two Float arrays that are interleaved (ItemA_0, ItemB_0, ItemA_1, ItemB_1, ... ItemA_n, Item B_n)
   Use it e.g. for IQ data read
   arraySize = arrayA size = arrayB size
******************************************************************************************************/
ViStatus rsetl_dataReadInterleaved(ViSession instrSession,
                                   ViString  cmd,
                                   ViInt32   timeout,
                                   ViInt32   arraySize,
                                   ViReal64  arrayA[],
                                   ViReal64  arrayB[],
                                   ViPInt32  actualPoints)
{  
    ViStatus  error = VI_SUCCESS;
    ViInt32   i = 0;
    ViInt32   dataSize = 0;
    ViInt32   noofPoints = 0;
    ViReal64* data = NULL;

    checkErr(RsCore_QueryFloatArrayWithOpc(instrSession, cmd, timeout, &data, &dataSize));

    noofPoints = dataSize / 2;
    if (actualPoints)
        *actualPoints = noofPoints;

    if (noofPoints > arraySize)
        noofPoints = arraySize;

    for (i = 0; i < noofPoints; i++)
    {
        arrayA[i] = data[i * 2];
        arrayB[i] = data[i * 2 + 1];
    }

Error:
    if (data)
        free(data);

    return error;
}

/*****************************************************************************
 *- Callback Declarations ---------------------------------------------------*
 *****************************************************************************/

/*****************************************************************************
 * Function: rsetl_stringToBin_ReadCallback
 * Purpose:  This function overrides standard calback funtion.
 *****************************************************************************/
ViStatus rsetl_stringToBin_ReadCallback(ViSession          instrSession,
                                        ViConstString      repCapName,
                                        RsCoreAttributePtr attr)
{
    return RsCore_SpecialCallback_BinPatternRead(instrSession, repCapName, attr);
}

/*****************************************************************************
 * Function: rsetl_quotedString_ReadCallback
 * Purpose:  This function overrides standard calback funtion. Reads string
 *           returned with apostrophes
 *****************************************************************************/
 ViStatus rsetl_quotedString_ReadCallback(ViSession          instrSession,
                                         ViConstString      repCapName,
                                         RsCoreAttributePtr attr)
{
     return RsCore_ReadCallback(instrSession, repCapName, attr);
}

/*****************************************************************************
 * Function: rsetl_stringToBin_WriteCallback
 * Purpose:  This function overrides standard calback funtion.
 *****************************************************************************/
 ViStatus rsetl_stringToBin_WriteCallback(ViSession          instrSession,
                                         ViConstString      repCapName,
                                         RsCoreAttributePtr attr,
                                         void*              value)
{
    return RsCore_SpecialCallback_BinPatternWrite(instrSession, repCapName, attr, value);
}

/*****************************************************************************
 * Function: rsetl_quotedString_WriteCallback
 * Purpose:  This function overrides standard calback funtion. Writes string
 *           with apostrophes
 *****************************************************************************/
 ViStatus rsetl_quotedString_WriteCallback(ViSession          instrSession,
                                          ViConstString      repCapName,
                                          RsCoreAttributePtr attr,
                                          void*              value)
{
     return RsCore_SpecialCallback_SurroundParamWrite(instrSession, repCapName, attr, " '", value, "'");
 }

/*****************************************************************************
 * Function: rsetl_FileStateSpecialFormat_WriteCallback
 * Purpose:  This function formats 1, before the argument string
 *****************************************************************************/
ViStatus rsetl_FileStateSpecialFormat_WriteCallback(ViSession          instrSession,
                                                    ViConstString      repCapName,
                                                    RsCoreAttributePtr attr,
                                                    void*              value)
{
    return RsCore_SpecialCallback_SurroundParamWrite(instrSession, repCapName, attr, " 1,'", value, "'");
}

/*****************************************************************************
 * Function: rsetl_dashString_ReadCallback
 * Purpose:  This function overrides standard calback funtion. Reads dashes
 *           returned
 *****************************************************************************/
 ViStatus rsetl_dashString_ReadCallback(ViSession          instrSession,
                                       ViConstString      repCapName,
                                       RsCoreAttributePtr attr)
 {
     return RsCore_ReadCallback(instrSession, repCapName, attr);
 }

/*****************************************************************************
 * Function: rsetl_quotedInt_ReadCallback
 * Purpose:  This function overrides standard calback funtion. Reads int
 *           returned with apostrophes
 *****************************************************************************/
 ViStatus rsetl_quotedInt_ReadCallback(ViSession          instrSession,
                                      ViConstString      repCapName,
                                      RsCoreAttributePtr attr)
{
    return RsCore_SpecialCallback_AnyQuotedParamRead(instrSession, repCapName, attr);
}

/*****************************************************************************
 * Function: rsetl_quotedInt_WriteCallback
 * Purpose:  This function overrides standard calback funtion. Writes int
 *           with apostrophes
 *****************************************************************************/
ViStatus rsetl_quotedInt_WriteCallback(ViSession          instrSession,
                                       ViConstString      repCapName,
                                       RsCoreAttributePtr attr,
                                       void*              value)
{
    return RsCore_SpecialCallback_SurroundParamWrite(instrSession, repCapName, attr, " '", value, "'");
}

/*****************************************************************************
* Function: rsetl_HcopyColorDef_WriteCallback
* Purpose:  Writes int without a space: "<cmd>%ld"
*****************************************************************************/
ViStatus rsetl_HcopyColorDef_WriteCallback(ViSession          instrSession,
                                           ViConstString      repCapName,
                                           RsCoreAttributePtr attr,
                                           void*              value)
{
    return RsCore_SpecialCallback_SurroundParamWrite(instrSession, repCapName, attr, "", value, "");
}

/*****************************************************************************
 * Function: rsetl_hex_ReadCallback
 * Purpose:  This function overrides standard calback funtion.
 *****************************************************************************/
ViStatus rsetl_hex_ReadCallback(ViSession          instrSession,
                                ViConstString      repCapName,
                                RsCoreAttributePtr attr)
{
    return RsCore_SpecialCallback_HexPatternRead(instrSession, repCapName, attr);
}

/*****************************************************************************
 * Function: rsetl_bin_ReadCallback
 * Purpose:  This function overrides standard calback funtion.
 *****************************************************************************/
ViStatus rsetl_bin_ReadCallback(ViSession          instrSession,
                                ViConstString      repCapName,
                                RsCoreAttributePtr attr)
{
    return RsCore_ReadCallback(instrSession, repCapName, attr);
}

/*****************************************************************************
 * Function: rsetl_dashInt_ReadCallback
 * Purpose:  This function overrides standard calback funtion. Returns NAN if
 *           instrument returns "---" or "n/a".
 *****************************************************************************/
ViStatus rsetl_dashInt_ReadCallback(ViSession          instrSession,
                                    ViConstString      repCapName,
                                    RsCoreAttributePtr attr)
{
    return rsetl_dashString_ReadCallback(instrSession, repCapName, attr);
}

/*****************************************************************************
 * Function: rsetl_dashReal_ReadCallback
 * Purpose:  This function overrides standard calback funtion. Returns NAN if
 *           instrument returns "---" or "n/a".
 *****************************************************************************/
ViStatus rsetl_dashReal_ReadCallback(ViSession          instrSession,
                                     ViConstString      repCapName,
                                     RsCoreAttributePtr attr)
{
    return rsetl_dashString_ReadCallback(instrSession, repCapName, attr);
}

/*****************************************************************************
 * Function: rsetl_dashBoolean_ReadCallback
 * Purpose:  This function overrides standard calback funtion. Returns NAN if
 *           instrument returns "---" or "n/a".
 *****************************************************************************/
ViStatus rsetl_dashBoolean_ReadCallback(ViSession          instrSession,
                                        ViConstString      repCapName,
                                        RsCoreAttributePtr attr)
{
    return rsetl_dashString_ReadCallback(instrSession, repCapName, attr);
}
