/*****************************************************************************
 *  Rohde&Schwarz ETL TV Analyzer instrument driver
 *  VXIpnp Style Instrument Driver
 *  Original Release: February 2008
 *  By: Martin Krcmar
 *
 *  Should you have any technical questions please contact the hotline of
 *  Rohde & Schwarz Vertriebs-GmbH Rohde & Schwarz Support Center
 *
 *  e-mail: CustomerSupport@rsd.rohde-schwarz.com
 *
 *  Modification History:
 *
 *  see rsetl_vxi.chm
 *
 *****************************************************************************/
#include "rsetl.h"
#include "visatype.h"
#if (defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__))
#define ANSI
#endif
#ifndef ANSI                /* UNIX compatible */
#include <sys/timeb.h>
#include <sys/types.h>
#include <unistd.h>
#define Sleep sleep
#else                       /* ANSI compatible */
#include <Windows.h>
#endif
#if defined (_CVI_)
#include <utility.h>
#endif


/*****************************************************************************
 *- Value Definition and Range Tables ---------------------------------------*
 *****************************************************************************/
static ViString selStatusRegArr[] = {"",":POW",":LIM1",":LMAR1",":SYNC",":ACPL",":FREQ",":LIM2",":LMAR2", NULL};
static ViString statusRegArr[] = {"OPER:EVEN","OPER:COND","QUES:EVEN","QUES:COND",
                                  "QUES:POW:EVEN","QUES:POW:COND","QUES:LIM1:EVEN","QUES:LIM1:COND",
                                  "QUES:LMAR1:EVEN","QUES:LMAR1:COND","QUES:SYNC:EVEN","QUES:SYNC:COND",
                                  "QUES:ACPL:EVEN","QUES:ACPL:COND","QUES:FREQ:EVEN","QUES:FREQ:COND",
                                  "QUE","QUES:LIM2:EVEN","QUES:LIM2:COND","QUES:LMAR2:EVEN","QUES:LMAR2:COND",NULL};
static ViString limTypeArr[] = {"", "UPP","LOW", NULL};
static ViString listFilterTypeArr[] = {"NORM","CFIL","RRC","FFT","PULS"};
static ViString switchArr[] = {"OFF","ON"};
static ViString measTypeArr[] = {"MEAN","PEAK","CFAC"};
static ViString ADEMTypeArr[] = {"AM","FM","PM","FM:AFSP","PM:AFSP","SPEC","AM:REL","AM:REL:AFSP", NULL};
static ViString resultTypeArr[] = {"OFF", "WRIT", "AVER", "MAXH", "MINH", "VIEW", NULL};
static ViString detectorTypeArr[] = {"PosPeak","NegPeak","AverPeak","RMS"};
static ViString ADemMeasResArr[] = {"XTIM:AM:REL","XTIM:AM","XTIM:SPEC","XTIM:FM",
                                    "XTIM:PM","XTIM:AMS","XTIM:AMS","XTIM:FMS","XTIM:PMS",
                                    "XTIM:FM:AFSP","XTIM:PM:AFSP","XTIM:AM:REL:AFSP","XTIM:RFP",
                                    NULL};

static ViString DTVMeasArr[] = {"MERRms","MERPeak","EVMRms","EVMPeak"};

static ViString ATVCarrierResultArr[] = {"RefPow","NoiseFloorCorr","FreqRel","","NoiseRefBw"};
static ViString compressionLevelArr[] = {"0","1","2","3","4",NULL};
static ViString DtvOverviewArr[] = {"","","","","","","",
                                    "OvLEV","OvBBV","OvPBBV","OvTBBV",
                                    "OvBBRS","OvPBBR","OvTBBR","OvPER","OvPPER",
                                    "OvTPER","OvPERR","OvBROF","OvISR","OvMTB",
                                    "OvFFTM","OvGINT","OvCRHP","OvCRLP","OvCID",
                                    "OvTPSR","OvINT","","","","",
                                    "OvLIND","OvBERL","OvPBER","OvTBER",
                                    "OvTMOD","OvFERR","OvSBP","OvMTBR","OvCRAT",
                                    "OvDEIN","OvBARS","OvPBAR","OvTBAR","OvLTB",
                                    "OvMMTB","OvDCN","OvCN","OvSNRL","OvPNO","OvCIFC", NULL};
static ViString DtvModErrorsArr[] = {"","","","","","","","","MeSNR","MeLEV","MeCPH",
                                     "MePILV","MeSPV","MePAER","MeCNR","MeBVF",
                                     "MePBVF","MeTBVF","MeBVM","MePBVM","MeTBVM",
                                     "MeMTRM","MeMARM"};
static ViString DtvConstellationArr[] = {"CoMERR","CoMERP","CoBBRS","CoSPROC","CoLEV"};
static ViString DtvAPGDResultArr[] = {"APGDResAMPL","APGDResPHAS","APGDResGDEL"};
static ViString ATVMainMeas[] = {"TestSigLBA","TestSigSNR","TestSigSA","TestSigBA",
                                 "TestSigCLP","TestSigCLB","TestSigBD","TestSigLTD",
                                 "TestSigTTP","TestSigSTD","TestSigTILT","TestSigCLIP",
                                 "TestSigCLIB","TestSigGCNL","TestSigPCNL","TestSigLNL",
                                 "TestSigDG","TestSigDP","TestSigMB","TestSigSX","TestSigICPM"};
static ViString ATVTestSignal[] = {"T17C","T15K","T250","T184","T186",
                                   "T330","T331","TBUR","TCBN","TCPF",
                                   "TCPN","TMOD","TMUL","TQU","TSIN",
                                   "TSYN","TTTP","TUK1","TUK2","TUK"};
static ViString ATVAnalysisMeasValue[] = {"VmeLBAR","VmeSARB","VmeBARB","VmeCLDP",
                                          "VmeCLGB","VmeCLGP","VmeBD","VmeTTPA",
                                          "VmeTTPK","VmeTILT","VmeSTRE","VmeSTFE",
                                          "VmeLTD","VmeCLIP","VmeCLI3","VmeGPPC",
                                          "VmePPPC","VmeLNL","VmeLNL1","VmeLNL2",
                                          "VmeLNL3","VmeLNL4","VmeLNL5","VmeDGP",
                                          "VmeDGN","VmeDG1S","VmeDG2S","VmeDG3S",
                                          "VmeDG4S","VmeDG5S","VmeDPP","VmeDPN",
                                          "VmeDP1S","VmeDP2S","VmeDP3S","VmeDP4S",
                                          "VmeDP5S","VmeICPH","VmeICPL","VmeICPS",
                                          "VmeICPB","VmeICP1","VmeICP2","VmeICP3",
                                          "VmeICP4","VmeICP5","VmeMRB","VmeM05P",
                                          "VmeM10P","VmeM20P","VmeM40P","VmeM48P",
                                          "VmeM58P","VmeNRB","VmeN05P","VmeN15P",
                                          "VmeN30P","VmeN44P","VmeSXAP","VmeSXAN",
                                          "VmeSXGP","VmeSXGN","VmeFRB","VmeF05P",
                                          "VmeF12P","VmeF20P","VmeF30P","VmeF35P",
                                          "VmeF41P","VmeTRB","VmeT05P","VmeT10P",
                                          "VmeT20P","VmeT30P","VmeT35P","VmeT42P"};

static ViString hierarchicalLayerArr[] = {"LayerA","LayerB", "LayerC",NULL};
static ViString ISDBTmerrArr[] = {"MerrRMS","MerrPEAK","MerrARM","MerrTRM",
                                  "MerrMTBR","MerrBBV","MerrPBBV","MerrTBBV",
                                  "MerrBBRS","MerrPBBR","MerrTBBR","MerrBARS",
                                  "MerrPBAR","MerrTBAR","MerrPER","MerrPPER",
                                  "MerrTPER","MerrPERR", NULL};
static ViString TMCCNextCurrArr[] = {"TMCCCurr","TMCCNext",NULL};
static ViString ATSCChannelArr[] = {"Primary","Secondary","TPC","FIC","","Parade",NULL};
static ViString ATSCMeasurementArr[] = {"BBRS","BARS","PER","MPER",NULL};
static ViString audioLeveltArr[] = {"Left","Right","Pilot","SCA",NULL};
static ViString audioFrequencyArr[] = {"Left","Right","SCA","","",NULL};
static ViString audioFrequencyDUTArr[] = {"Left","Right","","SCA",NULL};
static ViString measOverviewArr [] = {"","","","MPX","Left","Right","Mono","Stereo",
                                    "Deviation","Offset","Phase",
                                    "Deviation","Offset","Phase","BER","",
                                    "MainDeviation","Offset","SubcDeviation",NULL};
static ViString audioMeasArr [] = {"R15","Q15","QI15","MR1H","AP1H","AP20","AQ20","AQI2",
                                    "D2D","D2DS","D3","THD",NULL};
static ViString DTVMPnoiseArr [] = {"MPNoise","ResPM","ResFM","Integration","RBW","AcqTime",NULL};
static ViString DTVEchoPattArr [] = {"MERShortEq","EchoDet",NULL};
static ViString frameModeArr [] = {"SING","DUAL",NULL};
static ViString codeModeArr [] = {"211_187","223_187","235_187",NULL};
static ViString blockModeArr [] = {"SEP","PAIR",NULL};
static ViString SCCCModeArr [] = {"1_2","1_4",NULL};
static ViString audioChannelArr [] = {"Single","LeftMono","RightStereo",NULL};
static ViString audioDFDArr [] = {"D2D","D2DS","D3","DEV","F1","F2",NULL};
static ViString dtvDVBT2Res[] = {"dvbt2ResMRLO","dvbt2ResMPLO","dvbt2ResMRPL","dvbt2ResMPPL",
                                 "dvbt2ResERPL","dvbt2ResEPPL","dvbt2ResITLD","dvbt2ResACQ",
                                 "dvbt2ResBBCH","dvbt2ResPBBC","dvbt2ResTBBC","dvbt2ResESR",
                                 "dvbt2ResPESR","dvbt2ResTESR","dvbt2ResFER","dvbt2ResPFER",
                                 "dvbt2ResTFER", NULL};

/*****************************************************************************
 * Function: rsetl_init
 * Purpose:  VXIplug&play required function. Calls the
 *           rsetl_InitWithOptions function.
 *****************************************************************************/
ViStatus rsetl_init(ViRsrc     resourceName,
                    ViBoolean  IDQuery,
                    ViBoolean  resetDevice,
                    ViSession* newInstrSession)
{
    ViStatus error = VI_SUCCESS;

    if (newInstrSession == NULL)
    {
        (void)RsCore_SetErrorInfo(0, VI_FALSE, RS_ERROR_INVALID_PARAMETER,
            VI_ERROR_PARAMETER4, "Null address for Instrument Handle");

        checkErr(RS_ERROR_INVALID_PARAMETER);
    }

    checkErr(rsetl_InitWithOptions(resourceName, IDQuery, resetDevice, "", newInstrSession));

Error:
    return error;
}

/*****************************************************************************
 * Function: rsetl_InitWithOptions
 * Purpose:  This function creates a new RS session and calls the
 *           RsInit function.
 *****************************************************************************/
ViStatus rsetl_InitWithOptions(
               ViRsrc     resourceName,
			   ViBoolean  IDQuery,
               ViBoolean  resetDevice,
               ViString   optionString,
               ViSession* newInstrSession
)
{
    ViStatus error = VI_SUCCESS;
    RsCoreAttributePtr* attrList = NULL;
    ViSession instrSession = 0;
    RsCoreSessionPtr sessionProperties = NULL;

    if (newInstrSession == NULL)
    {
        (void)RsCore_SetErrorInfo(0, VI_FALSE, RS_ERROR_INVALID_PARAMETER, VI_ERROR_PARAMETER5,
            "Null address for Instrument Handle");
        checkErr(RS_ERROR_INVALID_PARAMETER);
    }

    attrList = (RsCoreAttributePtr*)rsetl_RsCoreAttributeList;

    *newInstrSession = 0;

    checkErr(RsCore_NewSpecificDriver(
        resourceName, // VISA Resource Name
        "rsetl", // driver prefix
        optionString, // Init Options string, is applied to the session settings
        attrList, // List of all attributes from the rsxxx_AttrPropertiesList
        rsetl_RsCoreAttributeListLength, // Attributes count
        VI_FALSE, //idnModelFullName Model has the full *IDN? query name e.g. true: "CMA180", VI_FALSE: "CMA" Used in CheckInstrument()
        0, // WriteDelay
        0, // ReadDelay
        100000, // IO Segment Size
        RS_VAL_OPCWAIT_STBPOLLING, // OPC Wait Mode
        RSETL_OPC_TIMEOUT, // OPC timeout
        10000, // VISA Timeout
        600000, // Self-test timeout
        RS_VAL_BIN_FLOAT_FORMAT_SINGLE_4BYTES, // BinaryFloatNumbersFormat
        RS_VAL_BIN_INTEGER_FORMAT_INT32_4BYTES, // binaryIntegerNumbersFormat
        &instrSession));

    // Minimal allowed rscore version is 4.0.0
    checkErr(RsCore_CheckMinimalEngineVersion(instrSession, 4, 0, 0));


    checkErr(RsCore_GetRsSession(instrSession, &sessionProperties));

    // No SCPI command has been sent yet.
    // Call viClear before sending any SCPI command
    checkErr(RsCore_ViClear(instrSession));

    // Here perform settings that are default for this driver, but can be overwritten by the optionsString settings
    sessionProperties->autoSystErrQuery = VI_FALSE;

    // Parse option string and optionally sets the initial state of the following session attributes
    checkErr(RsCore_ApplyOptionString(instrSession, optionString));
    checkErr(RsCore_BuildRepCapTable(instrSession, rsetl_RsCoreRepCapTable, rsetl_RsCoreRepCapTableCount));

    // Query *IDN? string, parse it and set the following attributes:
    // - RS_ATTR_INSTRUMENT_MANUFACTURER
    // - RS_ATTR_INSTRUMENT_MODEL - based on the idnModelFullName true: "SMW200A", false : "SMW"
    // - RS_ATTR_INSTRUMENT_FIRMWARE_REVISION
    checkErr(RsCore_QueryAndParseIDNstring(instrSession, RSETL_SIMULATION_ID_QUERY, NULL));

    // Query *OPT? string, parse the options, remove the duplicates, sort them and store the result string to RS_ATTR_OPTIONS_LIST
    checkErr(RsCore_QueryAndParseOPTstring(instrSession, RSETL_SIMULATION_OPT_QUERY, RS_VAL_OPTIONS_PARSING_AUTO));

    // Default Instrument Setup + optional *RST
    if (resetDevice == VI_TRUE)
    {
        checkErr(rsetl_reset(instrSession));
    }
    else
    {
        checkErr(rsetl_DefaultInstrSetup(instrSession));
    }

    if (IDQuery == VI_TRUE)
    {
        checkErr(RsCore_FitsIDNpattern(instrSession, RSETL_VALID_ID_RESPONSE_STRING, NULL));
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (error < VI_SUCCESS)
    {
        if (error == RS_ERROR_INSTRUMENT_STATUS && sessionProperties->autoSystErrQuery == VI_FALSE)
        {
            sessionProperties->autoSystErrQuery = VI_TRUE;
            (void)rsetl_CheckStatus(instrSession);
            sessionProperties->autoSystErrQuery = VI_FALSE;
        }

        if (instrSession != 0)
            (void)RsCore_ViClose(instrSession);
    }
    else
    {
        *newInstrSession = instrSession;
    }

    return error;
}

/*****************************************************************************
 * Function: Configure Instrument Mode
 * Purpose:  This function switches between the measurement modes by means of
 *           text parameters.
 *****************************************************************************/
ViStatus rsetl_ConfigureInstrumentMode(ViSession instrSession,
                                       ViInt32   instrumentMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_INSTR_MODE, instrumentMode),
            2, "Instrument Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Instrument Mode
 * Purpose:  This function returns the measurement mode.
 *****************************************************************************/
ViStatus rsetl_QueryInstrumentMode(ViSession instrSession,
                                   ViInt32*  instrumentMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_INSTR_MODE, instrumentMode),
            2, "Instrument Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Select Analog Demod State
 * Purpose:  This function activates the FM demodulator of the instrument.
 *           The instrument will be set to timedomain measurement (span = 0)
 *           at the current center frequency. The detector will be set to
 *           SAMPle, the demodulator itself will be set up according to the
 *           parameters of command [SENSe:]ADEMod:SET.
 *****************************************************************************/
ViStatus rsetl_SetADemodState(ViSession instrSession,
                              ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FMDEM_STATE, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Select Analog Demod Result
 * Purpose:  This function selects Analog Demod demodulator measurement.
 *****************************************************************************/
ViStatus rsetl_SelectADemodResult(ViSession instrSession,
                                  ViInt32   operatingMode,
                                  ViInt32   trace)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_CheckInstrumentOptions(instrSession, "K7"));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, operatingMode, 0, 12),
            2, "Operating Mode");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 0, 4),
            3, "Trace");
    switch (operatingMode)
    {
        case RSETL_VAL_FM_FEED_AM_REL:
        case RSETL_VAL_FM_FEED_AM:
        case RSETL_VAL_FM_FEED_SPEC:
        case RSETL_VAL_FM_FEED_FM:
        case RSETL_VAL_FM_FEED_PM:
        case RSETL_VAL_FM_FEED_RFP:
             snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":CALC1:FEED '%s'", ADemMeasResArr[operatingMode]);
        break;
        case RSETL_VAL_FM_FEED_AMS_REL:
            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":CALC1:FEED '%s%ld:REL'", ADemMeasResArr[operatingMode], trace);
        break;
        case RSETL_VAL_FM_FEED_AMS:
        case RSETL_VAL_FM_FEED_FMS:
        case RSETL_VAL_FM_FEED_PMS:
        case RSETL_VAL_FM_FEED_FM_AFSP:
        case RSETL_VAL_FM_FEED_PM_AFSP:
        case RSETL_VAL_FM_FEED_AM_REL_AFSP:
            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":CALC1:FEED '%s%ld'", ADemMeasResArr[operatingMode], trace);
        break;
    }

    checkErr(RsCore_Write(instrSession, cmd));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Trigger
 * Purpose:  This function configures the Analog Demodulation Trigger
 *****************************************************************************/
 ViStatus rsetl_ConfigureADemodTrigger(ViSession instrSession,
                                      ViInt32   triggerSource,
                                      ViReal64  triggerOffset,
                                      ViInt32   triggerPolarity,
                                      ViReal64  triggerLevel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_FMDEM_TRIGGER_SOURCE, triggerSource),
            2, "Trigger Source");

    switch (triggerSource){
        case RSETL_VAL_TRG_IMM:
        case RSETL_VAL_TRG_EXT:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_DELAY, triggerOffset),
                    3, "Trigger Offset");
        break;
        case RSETL_VAL_TRG_IFP:
           viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_DELAY, triggerOffset),
                   3, "Trigger Offset");

           viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_IFP_LEVEL, triggerLevel),
                   5, "Trigger Level");
        break;
        case RSETL_VAL_TRG_FM:
                viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ADEM_TRIGGER_FM_LEVEL, triggerLevel),
                        5, "Trigger Level");
        break;
        case RSETL_VAL_TRG_AM:
             viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_ABS, triggerLevel),
                     5, "Trigger Level");
        break;
        case RSETL_VAL_TRG_PM:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ADEM_TRIGGER_PM_LEVEL, triggerLevel),
                    5, "Trigger Level");
        break;
        case RSETL_VAL_TRG_AMR:
             viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_REL, triggerLevel),
                     5, "Trigger Level");
        break;
    }

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_SLOPE, triggerPolarity),
            4, "Trigger Polarity");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod
 * Purpose:  This function configures the Analog Demod demodulator.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodSet(ViSession instrSession,
                                  ViReal64  sampleRate,
                                  ViInt32   recordLength,
                                  ViInt32   triggerSource,
                                  ViInt32   triggerSlope,
                                  ViInt32   pretriggerSamples,
                                  ViInt32   numberOfMeas)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_CheckInstrumentOptions(instrSession, "K7"));

    viCheckParm(RsCore_InvalidViReal64Range(instrSession, sampleRate, 122.0703125, 32.0e+6), 2, "Sample Rate");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, recordLength, 1, 480001),
            3, "Record Length");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, triggerSource, 0, 1),
            4, "Trigger Source");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, triggerSlope, 0, 1),
            5, "Trigger Slope");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, pretriggerSamples, -65024, 130560), 6, "Pretrigger Samples");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, numberOfMeas, 0, 32767),
            7, "Number of Measurements");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "SENS:ADEM:SET %.12fHZ,%ld,%s,%s,%ld,%ld", sampleRate, recordLength, rsetl_rngFmTriggerSource.entries[triggerSource].cmdString,
        rsetl_rngPolarity.entries[triggerSlope].cmdString, pretriggerSamples, numberOfMeas);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod PM Phase Wrap
 * Purpose:  This function sets PM phase wrap.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodPMPhaseWrap(ViSession instrSession,
                                          ViInt32   phaseWrap)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_ADEM_PHASE_WRAP, phaseWrap),
            2, "Phase Wrap");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod PM Phase Units
 * Purpose:  This function sets PM phase unit.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodPMPhaseUnits(ViSession instrSession,
                                           ViInt32   PMUnits)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_ADEM_UNIT_ANGLE, PMUnits),
            2, "PM Units");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod PM Zero Phase Reference Point
 * Purpose:  This function sets PM zero phase reference point.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodPMZeroPhaseReferencePoint(ViSession instrSession,
                                                        ViReal64  referencePoint)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ADEM_PM_RPO_X, referencePoint),
            2, "Reference Point");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get Analog Demod Marker Amplitude
 * Purpose:  This function eturns the marker amplitude level of the selected
 *           marker.
 *****************************************************************************/
ViStatus rsetl_GetADemodMarkerAmpliltude(ViSession instrSession,
                                         ViInt32   marker,
                                         ViReal64  *markerAmplitude)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_AMPLITUDE, markerAmplitude),
            3, "Marker Amplitude");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get Analog Demod Delta Marker Amplitude
 * Purpose:  This function returns the marker amplitude level of the selected
 *           delta marker.
 *****************************************************************************/
ViStatus rsetl_GetADemodDeltaMarkerAmplitude(ViSession instrSession,
                                             ViInt32   deltaMarker,
                                             ViReal64  *deltaMarkerAmplitude)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarker, 1, 4),
            2, "Delta Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarker);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_AMPLITUDE, deltaMarkerAmplitude),
            3, "Delta Marker Amplitude");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Result Type
 * Purpose:  This function sets the result types to be measured
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodResultType(ViSession instrSession,
                                         ViInt32   demodulationType,
                                         ViInt32   resultTypes[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_CheckInstrumentOptions(instrSession, "K7"));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, demodulationType, 0, 7),
            2, "Demodulation Type");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "SENS:ADEM:%s:TYPE %s,%s,%s", ADEMTypeArr[demodulationType], resultTypeArr[resultTypes[0]],
            resultTypeArr[resultTypes[1]], resultTypeArr[resultTypes[2]]);
    checkErr(RsCore_Write(instrSession, cmd));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Filter
 * Purpose:  This function selects demodulation bandwidth AF filters of Analog Demod
 *           demodulation.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodFilter(ViSession instrSession,
                                     ViInt32   filterType,
                                     ViBoolean filterState,
                                     ViReal64  filterFrequency,
                                     ViReal64  amfmDeemphasisValue)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    switch (filterType)
    {
        case RSETL_VAL_FMDEM_FILTER_HP:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FMDEM_FILT_HPAS_STAT, filterState),
                    3, "Filter State");
            if (filterState)
                viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_FILT_HPAS_FREQ, filterFrequency),
                        4, "Filter Frequency");
            break;

        case RSETL_VAL_FMDEM_FILTER_LP:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FMDEM_FILT_LPAS_STAT, filterState),
                    3, "Filter State");
            if (filterState)
                viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_FILT_LPAS_FREQ, filterFrequency),
                        4, "Filter Frequency");
            break;

        case RSETL_VAL_FMDEM_FILTER_DEEMP:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FMDEM_FILT_DEMP_STAT, filterState),
                    3, "Filter State");
            if (filterState)
                viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_FILT_DEMP_TCON, amfmDeemphasisValue),
                        5, "Deemphasis Value");
            break;
        case RSETL_VAL_FMDEM_FILTER_LP_REL:

            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FMDEM_FILT_LPAS_STAT, filterState),
                    3, "Filter State");
            if (filterState)
            {
                viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ADEM_FILT_LPAS_FREQ_REL, filterFrequency),
                        4, "Filter Frequency");
            }
        break;

        default: viCheckParm(RsCore_InvalidViInt32Value(instrSession, filterType), 2, "Filter Type");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Zoom
 * Purpose:  This function sets analog demodulation parameters such as zoom
 *           state, start time.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodZoom(ViSession instrSession,
                                   ViBoolean zoomState,
                                   ViReal64  startTime)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FMDEM_ZOOM, zoomState),
            2, "Zoom State");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_ZOOM_START, startTime),
            3, "Start Time");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod PM Phase Wrap
 * Purpose:  This function sets PM phase wrap
 *****************************************************************************/
ViStatus rsetl_ConfigureAnalogDemodPMPhaseWrap(ViSession instrSession,
                                               ViInt32   phaseWrap)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_ADEM_PHASE_WRAP, phaseWrap),
            2, "Phase Wrap");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod PM Phase Units
 * Purpose:  This function sets PM phase units
 *****************************************************************************/
ViStatus rsetl_ConfigureAnalogDemodPMPhaseUnits(ViSession instrSession,
                                                ViInt32   PMUnits)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_ADEM_UNIT_ANGLE, PMUnits),
            2, "PM Units");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod PM Zero Phase Reference Point
 * Purpose:  This function sets PM zero phase reference point
 *****************************************************************************/
ViStatus rsetl_ConfigureAnalogDemodPMZeroPhaseReferencePoint(ViSession instrSession,
                                                             ViReal64  referencePoint)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ADEM_PM_RPO_X, referencePoint),
            2, "Reference Point");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Frequency Coupling
 * Purpose:  This function sets PM zero phase reference point
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodFrequencyCoupling(ViSession instrSession,
                                                ViInt32   coupling)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_FREQUENCY_CENTER_LINK, coupling),
            2, "Coupling");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Marker Search Peak Excursion
 * Purpose:  This function configures the marker peak excursion The marker
 *           peak excursion specifies the minimum amplitude variation that can
 *           be recognized as a peak or minimum by the marker.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodMarkerSearchPeakExcursion(ViSession instrSession,
                                                        ViReal64  peakExcursion)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_PEAK_EXCURSION, peakExcursion),
            2, "Peak Excursion");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Sweep Time
 * Purpose:  This function configures the sweep time of the analog demodulator.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodSweepTime(ViSession instrSession,
                                        ViReal64  sweepTime)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViReal64Range(instrSession, sweepTime, 1.0e-6, 6.0e-3), 2, "Sweep Time");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_SWEEP_TIME, sweepTime),
            2, "Sweep Time");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Vision Modulation
 * Purpose:  This function defines the vision modulation.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVVisionModulation(ViSession instrSession,
                                             ViInt32   visionModulation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_VISION_MODULATION, visionModulation),
            2, "Vision Modulation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Display Window Size
 * Purpose:  This function switches the measurement window for channel and
 *           adjacent-channel power measurements to full screen or half screen.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodDisplayWindowSize(ViSession instrSession,
                                                ViInt32   windowSize)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISP_WINDOW_SIZE, windowSize),
            2, "Window Size");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Display Y Scaling
 * Purpose:  This function defines the scaling of the Y axis in the current unit.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodDisplayYScaling(ViSession instrSession,
                                              ViReal64  yScaling)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_DISPLAY_PDIV, yScaling),
            2, "Y Scaling");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Display Reference Position
 * Purpose:  This function defines the position of the reference value.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodDisplayReferencePosition(ViSession instrSession,
                                                       ViReal64  referencePosition)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_REF_POSITION, referencePosition),
            2, "Reference Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Display Reference Value
 * Purpose:  This function defines the reference value assigned to the
 *           reference position. Separate reference values are maintained for
 *           the various displays.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodDisplayReferenceValue(ViSession instrSession,
                                                    ViReal64  referenceValue)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_REF_VALUE, referenceValue),
            2, "Reference Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Vertical Scale
 * Purpose:  This function configures the vertical scale of analyzer.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodVerticalScale(ViSession instrSession,
                                            ViInt32   verticalScale)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, verticalScale, RSETL_VAL_TRACE_SPACE_LIN, RSETL_VAL_TRACE_SPACE_LOG), 2, "Vertical Scale");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_VERTICAL_SCALE, verticalScale),
            2, "Vertical Scale");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod Bandwidth
 * Purpose:  This function configures analog demodulator bandwidth parameters.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodBandwidth(ViSession instrSession,
                                        ViReal64  demodulationBandwidth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_BAND_DEM, demodulationBandwidth),
            2, "Demodulation Bandwidth");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod AF Coupling
 * Purpose:  This function configures analog demodulator AF Coupling.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodAFCoupling(ViSession instrSession,
                                         ViInt32   afCoupling)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_FMDEM_AF_COUP, afCoupling),
            2, "AF Coupling");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Configure Analog Demod Measuring Time
 * Purpose:  This function configures analog demodulator measuring time.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodMeasuringTime(ViSession instrSession,
                                            ViReal64  measuringTime)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_MTIM, measuringTime),
            2, "Measuring Time");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod AF Frequency Start Stop
 * Purpose:  This function configures the frequency range of the result
 *           display AF spectrum using start frequency and stop frequency.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodAFFrequencyStartStop(ViSession instrSession,
                                                   ViReal64  startFrequency,
                                                   ViReal64  stopFrequency)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_AF_START, startFrequency),
            2, "Start Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_AF_STOP, stopFrequency),
            3, "Stop Frequency");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod AF Frequency Center Span
 * Purpose:  This function configures the frequency range of the result
 *           display AF spectrum using the center frequency and the frequency
 *           span. This function modifies the AF Frequency Start and AF
 *           Frequency Stop attributes as follows:
 *
 *               AF Frequency Start = CenterFrequency - span/2
 *               AF Frequency Stop = CenterFrequency + span/2
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodAFFrequencyCenterSpan(ViSession instrSession,
                                                    ViReal64  centerFrequency,
                                                    ViReal64  span)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_AF_CENTER, centerFrequency),
            2, "Center Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_AF_SPAN, span),
            3, "Span");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}
/*****************************************************************************
 * Function: Configure Analog Demod AF Full Span
 * Purpose:  This function sets the maximum span for the display of the AF spectrum.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodAFFullSpan(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FMDEM_AF_FULL_SPAN, ""));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod AF Param
 * Purpose:  This function configures bandwidth resolution and span for
 *           display of the AF spectrum.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodAFParam(ViSession instrSession,
                                      ViReal64  resolutionBandwidth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_BAND_RES, resolutionBandwidth),
            2, "Resolution Bandwidth");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}
/*****************************************************************************
 * Function: Configure Analog Demod RF Param
 * Purpose:  This function configures bandwidth resolution and span for
 *           display of the RF spectrum.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodRFParam(ViSession instrSession,
                                      ViReal64  resolutionBandwidth,
                                      ViReal64  span)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_BAND_RES, resolutionBandwidth),
            2, "Resolution Bandwidth");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_SPEC_SPAN, span),
            3, "Span");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog Demod RF Zoom
 * Purpose:  This function configures the frequency range for result display
 *           of RF spectrum determined from Analog Demod demodulation data.
 *****************************************************************************/
ViStatus rsetl_ConfigureADemodRFZoom(ViSession instrSession,
                                     ViReal64  zoom)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_SPEC_ZOOM, zoom),
            2, "Zoom");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get Analog Demod Currently Set Value
 * Purpose:  This function reads selected value from instrument.
 *****************************************************************************/
ViStatus rsetl_GetADemodCurrentlySetValue(ViSession instrSession,
                                          ViInt32   value,
                                          ViReal64* result)
{
    ViStatus error = VI_SUCCESS;
    ViReal64 l_value = 0;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, result), 3, "Result");
    switch (value)
    {
        case RSETL_VAL_FMDEM_RLEN:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_RLEN, &l_value),
                    3, "Result");
            break;

        case RSETL_VAL_FMDEM_SRATE:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_FMDEM_SRATE, &l_value),
                    3, "Result");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, value), 2, "Value");
    }

    *result = l_value;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get Analog Demod Result Values
 * Purpose:  This function returns analog demodulation result values.
 *****************************************************************************/
ViStatus rsetl_GetADemodResultValues(ViSession instrSession,
                                     ViInt32   demodulationType,
                                     ViInt32   resultType,
                                     ViUInt32  timeout,
                                     ViInt32   arraySize,
                                     ViReal64  resultValues[],
                                     ViInt32*  returnedValues)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_CheckInstrumentOptions(instrSession, "K7"));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, demodulationType, 0, 7),
            2, "Demodulation Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, resultType, 1, 4),
            3, "Result Type");
    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 4, "Timeout");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":FORM REAL,32;:SENS:ADEM:%s:RES? %s", ADEMTypeArr[demodulationType], resultTypeArr[resultType]);
    checkErr(RsCore_QueryFloatArrayToUserBufferWithOpc(instrSession, cmd, timeout, arraySize, resultValues, returnedValues));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get Analog Demod Offset
 * Purpose:  This function calculates the Analog Demod offset of the current measured
 *           data set.
 *****************************************************************************/
ViStatus rsetl_GetADemodOffset(ViSession instrSession,
                               ViInt32   resultType,
                               ViReal64* value)
{
    ViStatus error = VI_SUCCESS;
    ViString fmOffsetArr[]={"Imm", "Aver"};
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_CheckInstrumentOptions(instrSession, "K7"));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, resultType, 0, 1),
            2, "Result Type");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "FMOff%s", fmOffsetArr[resultType]);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_ADEM_FM_OFFSET, value),
            3, "Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/*****************************************************************************
 * Function: Get Analog Demod Marker Modulation Value
 * Purpose:  This function returns analog modulation measurement summary.
 *****************************************************************************/
ViStatus rsetl_GetADemodMarkerModulationValue(ViSession instrSession,
                                              ViInt32   demodulationType,
                                              ViInt32   detectorType,
                                              ViInt32   trace,
                                              ViReal64* value)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_CheckInstrumentOptions(instrSession, "K7"));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, demodulationType, 0, 2),
            2, "Demodulation Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, detectorType, 0, 3),
            3, "Detector Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            4, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "Analog%s,TR%ld,ResDet%s", ADEMTypeArr[demodulationType], trace,detectorTypeArr[detectorType]);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_ADEM_SUMM_RES, value),
            5, "Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/*****************************************************************************
 * Function: Get Analog Demod Marker Measurement Value
 * Purpose:  This function returns analog modulation measurement summary.
 *****************************************************************************/
ViStatus rsetl_GetADemodMarkerMeasValue(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViInt32   trace,
                                        ViReal64* value)
{
    ViStatus                  error = VI_SUCCESS;
    ViChar                    buf1[RS_MAX_MESSAGE_BUF_SIZE];
    ViInt32                   attribute;
    ViInt32                   attrs[] = {RSETL_ATTR_FMDEM_AFR_RES,RSETL_ATTR_FMDEM_FERR_RES,
    RSETL_ATTR_FMDEM_SIN_RES, RSETL_ATTR_FMDEM_THD_RES,
                              RSETL_ATTR_FMDEM_CARR_RES};

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 4),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            3, "Trace");


    checkErr(RsCore_LockSession(instrSession));

    attribute = attrs[measurement];

    sprintf (buf1,"TR%ld", trace);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, buf1, attribute, value),
            4, "Value");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Read Analog Demod Y Trace
 * Purpose:  This function initiates a signal acquisition based on the present
 *           instrument configuration.  It then waits for the acquisition to
 *           complete, and returns the trace as an array of amplitude values.
 *           The amplitude array returns data that represent the amplitude of
 *           the signals of the sweep from the start frequency to the stop
 *           frequency (in frequency domain, in time domain the amplitude
 *           array is ordered from beginning of sweep to end).  The Amplitude
 *           Units attribute determines the units of the points in the
 *           amplitude array.  This function resets the sweep count.
 *****************************************************************************/
ViStatus rsetl_ReadADemodYTrace(ViSession instrSession,
                                ViInt32   trace,
                                ViUInt32  maximumTime,
                                ViInt32   arrayLength,
                                ViInt32   *actualPoints,
                                ViReal64  amplitude[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, maximumTime, 0, 4294967295), 3, "Maximum Time");

    checkErr(rsetl_CATVInitiate(instrSession, maximumTime));

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":TRAC? TRACE%ld", trace);
    checkErr(rsetl_dataReadTrace(instrSession, cmd, arrayLength,
                    amplitude, actualPoints));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================
 * Function: PWM Mode
 * Purpose:  This function switches measurements with a power sensor on or
 *           off.
 *===========================================================================*/
ViStatus rsetl_PWMMode(ViSession instrSession,
                       ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_PMET_STATE, state),
            2, "State");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Configure PWM Measurement
 * Purpose:  This function configures the power meter measurement
 *===========================================================================*/
ViStatus rsetl_ConfigurePWMMeasurement(ViSession instrSession,
                                       ViInt32   measurementTime,
                                       ViInt32   coupling,
                                       ViReal64  frequency)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_PMET_MEAS_TIME, measurementTime),
            2, "Measurement Time");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_PMET_COUPLING, coupling),
            3, "Coupling");

    if (coupling == RSETL_VAL_PMET_COUP_OFF)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_PMET_FREQ, frequency),
                4, "Frequency");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Configure PWM Relative
 * Purpose:  This function configures the relative measurement.
 *===========================================================================*/
ViStatus rsetl_ConfigurePWMRelative(ViSession instrSession,
                                    ViReal64  referenceValue,
                                    ViInt32   unit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_PMET_RELATIVE, VI_TRUE));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_PMET_REL, referenceValue),
            2, "Reference Value");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_PMET_UNIT_REL, unit),
            3, "Unit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Configure PWM Absolute
 * Purpose:  This function configures the relative measurement.
 *===========================================================================*/
ViStatus rsetl_ConfigurePWMAbsolute(ViSession instrSession,
                                    ViInt32   unit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_PMET_RELATIVE, VI_FALSE));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_PMET_UNIT_ABS, unit),
            2, "Unit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Configure PWM Bar Graph View
 * Purpose:  This function switches bargraph display on or off for measurements
 *           with a power sensor. If bargraph display is switched off, the
 *           measurement value appears in the Marker Info field.
 *===========================================================================*/
ViStatus rsetl_ConfigurePWMBarGraphView(ViSession instrSession,
                                        ViBoolean barGraphView)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_PMET_BARGRAPH_STATE, barGraphView),
            2, "Bar Graph View");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Configure PWM Reference Level Offset State
 * Purpose:  This function defines whether the reference level offset set for
 *           the analyzer is taken into account for the measured power or not.
 *===========================================================================*/
ViStatus rsetl_ConfigurePWMReferenceLevelOffsetState(ViSession instrSession,
                                                     ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_PMET_REF_LEVEL_OFFSET_STATE, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Configure PWM Averaging
 * Purpose:  This function configures the averaging.
 *===========================================================================*/
ViStatus rsetl_ConfigurePWMAveraging(ViSession instrSession,
                                     ViBoolean manualAveraging,
                                     ViInt32   averagingCount)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_PMET_AVERAGE_AUTO, manualAveraging),
            2, "Manual Averaging");

    if (manualAveraging == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_PMET_AVERAGE_COUNT, averagingCount),
                3, "Averaging Count");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: ConfigurePWM Measure To Reference
 * Purpose:  This function accepts the current result as a reference value
 *           for relative measurements.
 *===========================================================================*/
ViStatus rsetl_ConfigurePWMMeasToRef(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_PMET_REL_AUTO, ""));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Configure PWM Zero
 * Purpose:  This function zeroes the power sensor.
 *===========================================================================*/
ViStatus rsetl_ConfigurePWMZero(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_PMET_ZERO, ""));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Read PWM Result
 * Purpose:  This function triggers a measurement with the power sensor and
 *           then outputs the result.
 *===========================================================================*/
ViStatus rsetl_ReadPWMResult(ViSession instrSession,
                             ViUInt32  timeout,
                             ViReal64* result)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = -1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_PMET_READ, result),
            3, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout >= 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*===========================================================================*
 * Function: Fetch PWM Result
 * Purpose:  This function outputs the result of the power sensor.
 *===========================================================================*/
ViStatus rsetl_FetchPWMResult(ViSession instrSession,
                              ViReal64* result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_PMET_FETCH, result),
            2, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Mode
 * Purpose:  This function sets the Cable TV Measurements operating mode.
 *****************************************************************************/
ViStatus rsetl_CATVMode(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_MODE, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Channel Setup
 * Purpose:  This function selects TV channel table.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVChannelSetup(ViSession instrSession,
                                         ViString  channelTableName,
                                         ViInt32   measurementChannel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_TV_CHANNEL, channelTableName),
            2, "Channel Table Name");

    if (strlen(channelTableName)>0)
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_CHANNEL, measurementChannel),
                3, "Measurement Channel");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Frequency Start Stop
 * Purpose:  This function configures the frequency range of the spectrum
 *           analyzer using start frequency and stop frequency. If start
 *           frequency is equal to the stop frequency, then the spectrum
 *           analyzer is in time-domain mode.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVFrequencyStartStop(ViSession instrSession,
                                               ViReal64  startFrequency,
                                               ViReal64  stopFrequency)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_START, startFrequency),
            2, "Start Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_STOP, stopFrequency),
            3, "Stop Frequency");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Frequency Center Span
 * Purpose:  This function configures the frequency range of the cable TV
 *           analyzer usingthe center frequency and the frequency span.  If
 *           spancorresponds to zero hertz, then the cable TV analyzer is in
 *           time-domain.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVFrequencyCenterSpan(ViSession instrSession,
                                                ViReal64  centerFrequency,
                                                ViReal64  span)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_CENTER, centerFrequency),
            2, "Center Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_SPAN, span),
            3, "Span");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Channel Frequency
 * Purpose:  This function configures TV channel frequency.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVChannelFrequency(ViSession instrSession,
                                             ViReal64  RFFrequency,
                                             ViInt32   axisLabeling)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_RF_FREQUENCY, RFFrequency),
            2, "RF Frequency");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_SWEEP_SPACING, axisLabeling),
            3, "Axis Labeling");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Channel Frequency Step Size
 * Purpose:  This function configures TV channel frequency.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVChannelFrequencyStepSize(ViSession instrSession,
                                                     ViReal64  stepSize)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_RF_FREQUENCY_STEP_SIZE, stepSize),
            2, "Step Size");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Frequency Span Full
 * Purpose:  This function sets the frequency span to its maximum.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVFrequencySpanFull(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FREQUENCY_SPAN_FULL, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Modulation Standard
 * Purpose:  This function configures modulation standard.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVModulationStandard(ViSession instrSession,
                                               ViString  modulationStandard,
                                               ViInt32   signalType,
                                               ViInt32   sidebandPosition)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_MODUL_STANDARD, modulationStandard),
            2, "Modulation Standard");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_MODUL_STANDARD_SIG_TYPE, signalType),
            3, "Signal Type");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_SIDE_BAND, sidebandPosition),
            4, "Sideband Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Radio Measurement Mode
 * Purpose:  This function switches to Radio measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureRadioMeasurementMode(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_MEAS_MODE, RSETL_VAL_CATV_MEAS_MODE_RAD),
            2, "Measurement Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function selects the radio measurement type.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
ViStatus rsetl_ConfigureRadioMeasurement(ViSession instrSession,
                                         ViInt32   measurement)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_MEASUREMENT, measurement),
            2, "Measurement");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Selects a protection mask in line with ITU-R SM.1268-1 or -2
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR mask/Selects a protection mask in line with ITU-R SM.1268-1 or -2
ViStatus rsetl_ConfigureRadioSpectrumMask(ViSession instrSession,
                                          ViInt32   mask)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_SPECTRUM_SELECT_MASK, mask),
            2, "Mask");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures Radio modulation standard parameters.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR radioStandard/Selects the way the audio information is modulated.
/// HIPAR channelBandwidth/Selects the selects a channel filter (BW).
/// HIPAR dataSystem/Sets the transmission system used for additional data, so that
/// HIPAR dataSystem/specific parameters of the system can be measured.
/// HIPAR SCAMode/Selects the transmission system used for auxiliary audio channel, so that specific
/// HIPAR SCAMode/parameters of the system can be measured (SCA = subsidiary communications authorization).
/// HIPAR SCAFrequnecy/Sets SCA Frequency.
ViStatus rsetl_ConfigureRadioModulation(ViSession instrSession,
                                        ViInt32   radioStandard,
                                        ViInt32   channelBandwidth,
                                        ViInt32   dataSystem,
                                        ViInt32   SCAMode,
                                        ViReal64  SCAFrequnecy)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_STANDARD, radioStandard),
            2, "Radio Standard");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_CHANNEL_BANDWIDTH, channelBandwidth),
            3, "Channel Bandwidth");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_DATA_SYSTEM, dataSystem),
            4, "Data System");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_SCA_MODE, SCAMode),
            5, "SCA Mode");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_SCA_FREQUENCY, SCAFrequnecy),
            6, "SCA Frequnecy");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures pilot deviation threshold for automatic
/// HIFN stereo switching of the audio output.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR pilotDevThreshold/Sets the pilot deviation threshold for automatic stereo
/// HIPAR pilotDevThreshold/switching of the audio output.
ViStatus rsetl_ConfigureRadioStereoDecoder(ViSession instrSession,
                                           ViReal64  pilotDevThreshold)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_PILOT_DEVIATION_TRESHOLD, pilotDevThreshold),
            2, "Pilot Dev Threshold");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Sets the noise criterion for the stereo indicator and automatic stereo
/// HIFN  switching of the audio output.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR pilotNoise/Sets the noise criterion for the stereo indicator and automatic stereo
/// HIPAR pilotNoise/switching of the audio output.
ViStatus rsetl_ConfigureRadioStereoPilotNoise(ViSession instrSession,
                                              ViBoolean pilotNoise)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_RADIO_PILOT_NOISE, pilotNoise),
            2, "Pilot Noise");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the radio audio outputs 1/L and 2/R, and at the headphones output.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR output/Selects the desired output signal at audio outputs 1/L and 2/R, and the headphones output.
/// HIPAR deemphasis/Specifies the effective deemphasis at audio outputs 1/L and 2/R, and at the headphones output
/// HIPAR outputDeviation/Sets the deviation of the FM transmitter being received.
/// HIPAR CCVSOutput/Selects the demodulated multiplex signal (MPX) is to be output at CCVS output.
ViStatus rsetl_ConfigureRadioOutput(ViSession instrSession,
                                    ViInt32   output,
                                    ViInt32   deemphasis,
                                    ViReal64  outputDeviation,
                                    ViInt32   CCVSOutput)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_OUTPUT_SIGNAL, output),
            2, "Output");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_OUTPUT_DEEMPHASIS, deemphasis),
            3, "Deemphasis");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_OUTPUT_DEVIATION, outputDeviation),
            4, "Output Deviation");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_OUTPUT_CCVS, CCVSOutput),
            5, "CCVS Output");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures DUT.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR inputLevel/Sets the nominal input level of the FM transmitter that is to be tested.
/// HIPAR AESEBU/Sets the AES/EBU.
/// HIPAR deviation/Sets the nominal deviation of the FM transmitter that is to be tested.
ViStatus rsetl_ConfigureRadioDUT(ViSession instrSession,
                                 ViReal64  inputLevel,
                                 ViReal64  AESEBU,
                                 ViReal64  deviation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_DUT_INPUT_LEVEL, inputLevel),
            2, "Input Level");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_DUT_AES_EBU, AESEBU),
            3, "AES/EBU");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_DUT_DEVIATION, deviation),
            4, "Deviation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the scaling for the level display range for radio measurements.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR verticalScale/Selects the scaling.
ViStatus rsetl_ConfigureRadioVerticalScale(ViSession instrSession,
                                           ViInt32   verticalScale)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_VERTICAL_SCALING, verticalScale),
            2, "Vertical Scale");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the audio generator settings.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR sweepPoints/Sets the number of measurement frequencies.
/// HIPAR startFrequency/Sets the start frequency of measurement range.
/// HIPAR stopFrequency/Sets the stop frequency of measurement range.
ViStatus rsetl_ConfigureRadioSweep(ViSession instrSession,
                                   ViInt32   sweepPoints,
                                   ViReal64  startFrequency,
                                   ViReal64  stopFrequency)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_SWEEP_POINTS, sweepPoints),
            2, "Sweep Points");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_START_FREQUENCY, startFrequency),
            3, "Start Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_STOP_FREQUENCY, stopFrequency),
            4, "Stop Frequency");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the span and center frequnecy.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR centerFrequency/This function configures the span and center frequnecy.
/// HIPAR frequencySpan/Sets the frequency span.
ViStatus rsetl_ConfigureRadioCenterSpan(ViSession instrSession,
                                        ViReal64  centerFrequency,
                                        ViReal64  frequencySpan)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_CENTER_FREQUENCY, centerFrequency),
            2, "Center Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_FREQUENCY_SPAN, frequencySpan),
            3, "Frequency Span");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the Zoom.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR zoom/This control selects the measurement to be displayed for zoom.
ViStatus rsetl_ConfigureRadioZoom(ViSession instrSession,
                                  ViInt32   zoom)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_ZOOM, zoom),
            2, "Zoom");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures Frequnecy response measurement type.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR type/Selects the type of response to be measured.
/// HIPAR referenceFrequency/Sets the reference frequency for the Frequency.
/// HIPAR phaseRange/Sets the phase range of the Frequency response radio measurement.
ViStatus rsetl_ConfigureRadioFrequencyResponseSetup(ViSession instrSession,
                                                    ViInt32   type,
                                                    ViReal64  referenceFrequency,
                                                    ViReal64  phaseRange)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_FREQ_RESPONSE_TYPE, type),
            2, "Type");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_FREQ_RESPONSE_REFERENCE, referenceFrequency),
            3, "Reference Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_FREQ_RESPONSE_PHASE_RANGE, phaseRange),
            4, "Phase Range");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures diagram range for Frequency response and Crosstalk radio measurements.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR frequencyRange/Sets the amplitude range.
/// HIPAR refPosition/Sets the zero dB position of the y-axis in units of display height (%)
ViStatus rsetl_ConfigureRadioFrequencyRange(ViSession instrSession,
                                            ViReal64  frequencyRange,
                                            ViReal64  refPosition)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_FREQUENCY_RANGE, frequencyRange),
            2, "Frequency Range");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_REFERENCE_POSITION, refPosition),
            3, "Ref Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures Crosstalk measurement options.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR type/Selects the type of crosstalk to be measured.
/// HIPAR reference/Selects whether the crosstalk attenuation is measured relative
/// HIPAR reference/to the frequency response of the corresponding stereo channel
ViStatus rsetl_ConfigureRadioCrosstalkSetup(ViSession instrSession,
                                            ViInt32   type,
                                            ViInt32   reference)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_CROSSTALK_TYPE, type),
            2, "Type");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_CROSSTALK_REFERENCE, reference),
            3, "Reference");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures S/N measurement options.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR referenceDeviation/Sets the the deviation of a notional reference signal for the
/// HIPAR referenceDeviation/signal-to-noise ratio for the S/N radio measurement.
/// HIPAR weightingFilter/Sets state of the weighting filter (ITU-R BS.468-4) for the S/N radio measurement.
ViStatus rsetl_ConfigureRadioSNSetup(ViSession instrSession,
                                     ViReal64  referenceDeviation,
                                     ViBoolean weightingFilter)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_SN_REFERENCE_DEVIATION, referenceDeviation),
            2, "Reference Deviation");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_RADIO_SN_WEIGHTING_FILTER, weightingFilter),
            3, "Weighting Filter");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures reference deviation.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR referenceDeviation/Sets the the reference deviation.
ViStatus rsetl_ConfigureRadioReferenceDeviation(ViSession instrSession,
                                                ViReal64  referenceDeviation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_REFERENCE_DEVIATION, referenceDeviation),
            2, "Reference Deviation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the active measurement for the MPX Power & Peak Deviation radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/Selects the active measurement for the MPX Power & Peak Deviation radio measurement.
ViStatus rsetl_ConfigureRadioMPXPowerPeakMeasurement(ViSession instrSession,
                                                     ViInt32   measurement)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT, measurement),
            2, "Measurement");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures MER-PhaseNoise measurement reference.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR trace/Selects the trace.
/// HIPAR MPXPowerRefPosition/Sets the MPX power value displayed at the upper edge of the diagram.
/// HIPAR MPXPowerRange/Sets the MPX power diagram range.
/// HIPAR peakDevReference/Sets the MPX peak deviation value displayed at the upper edge of the diagram.
/// HIPAR peakDevRange/Sets the Sets the MPX peak deviation diagram range.
ViStatus rsetl_ConfigureRadioMPXPowerPeakRange(ViSession instrSession,
                                               ViInt32   trace,
                                               ViReal64  MPXPowerRefPosition,
                                               ViReal64  MPXPowerRange,
                                               ViReal64  peakDevReference,
                                               ViReal64  peakDevRange)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_MPX_POWER_REF_POSITION, MPXPowerRefPosition),
            3, "MPX Power Reference Position");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_MPX_POWER_RANGE, MPXPowerRange),
            4, "MPX Power Range");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_MPX_PEAK_DEV_REFERENCE, peakDevReference),
            5, "Peak Deviation Reference");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_MPX_PEAK_DEV_RANGE, peakDevRange),
            6, "peak Deviation Range");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the number of samples used for the MPX Deviation Distribution measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR sampleCount/Sets the samples count.
ViStatus rsetl_ConfigureRadioMPXDevDistrbSampleCount(ViSession instrSession,
                                                     ViInt32   sampleCount)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_SAMPLE_COUNT, sampleCount),
            2, "Sample Count");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN   Defines the MPX power time span.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR timeSpan/Defines the MPX power time span.
ViStatus rsetl_ConfigureRadioMPXPowerTimeSpan(ViSession instrSession,
                                              ViInt32   timeSpan)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN, timeSpan),
            2, "Time Span");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Configures the MPX power time span. It activates or deactivates the
/// HIFN  automatic scaling in time domain. If activated, the time span will
/// HIFN  automatically be increased, starting at 1 minute, until the manually
/// HIFN  selected time span is reached
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR auto/Configures the MPX power time span. It activates or deactivates the
/// HIPAR auto/automatic scaling in time domain. If activated, the time span will
/// HIPAR auto/automatically be increased, starting at 1 minute, until the manually
/// HIPAR auto/selected time span is reached
ViStatus rsetl_ConfigureRadioMPXPowerTimeSpanAuto(ViSession instrSession,
                                                  ViBoolean autoTimeSpan)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN_AUTO, autoTimeSpan),
            2, "Auto Time Span");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Selects the type of samples to be used in the MPX deviation
/// HIFN  distribution radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR samples/Selects the type of samples to be used in the MPX deviation
/// HIPAR samples/distribution radio measurement.
ViStatus rsetl_ConfigureRadioMPXSamples(ViSession instrSession,
                                        ViInt32   samples)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_MPX_SAMPLES, samples),
            2, "Samples");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the top/bottom range limit of the
/// HIFN display for the THD radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR trace/Selects the trace.
/// HIPAR topLimit/Sets the top range limit.
/// HIPAR bottomLimit/Sets the bottom range limit.
ViStatus rsetl_ConfigureRadioTHDRange(ViSession instrSession,
                                      ViInt32   trace,
                                      ViReal64  topLimit,
                                      ViReal64  bottomLimit)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_THD_TOP_LIMIT, topLimit),
            3, "Top Limit");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_THD_BOTTOM_LIMIT, bottomLimit),
            4, "Bottom Limit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the top/bottom range limit of the
/// HIFN display for the DFD radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR trace/Selects the trace.
/// HIPAR topLimit/Sets the top range limit.
/// HIPAR bottomLimit/Sets the bottom range limit.
ViStatus rsetl_ConfigureRadioDFDRange(ViSession instrSession,
                                      ViInt32   trace,
                                      ViReal64  topLimit,
                                      ViReal64  bottomLimit)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_DFD_TOP_LIMIT, topLimit),
            3, "Top Limit");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_DFD_BOTTOM_LIMIT, bottomLimit),
            4, "Bottom Limit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures demodulator.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR signalPath/Selects the signal to be measured for all radio measurements.
/// HIPAR deemphasis/Selects deemphasis that affects the displayed signal for all radio measurements.
ViStatus rsetl_ConfigureRadioDemodulator(ViSession instrSession,
                                         ViInt32   signalPath,
                                         ViInt32   deemphasis)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_SIGNAL_PATH, signalPath),
            2, "Signal Path");

    if (signalPath != RSETL_VAL_RADIO_PATH_MPX)
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_DEEMPHASIS, deemphasis),
                3, "Deemphasis");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Readjusts the settings for the radio occupied bandwidth measurement.
/// HIFN  To obtain correct results, perform a complete sweep with
/// HIFN  synchronization to the end of the sweep after the adjustment.
/// HIFN  Synchronization is only possible in the single sweep mode.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
ViStatus rsetl_RadioOBWAdjustSettings(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_RADIO_OBW_ADJUST_SETTINGS, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Positions the percent marker to the given probability expressed in
/// HIFN  percent.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR markerNumber/Selects the marker to configure.
/// HIPAR probability/Positions the percent marker to the given probability expressed in
/// HIPAR probability/percent.
ViStatus rsetl_ConfigureRadioMarkerProbability(ViSession instrSession,
                                               ViInt32   markerNumber,
                                               ViReal64  probability)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, markerNumber, 1, 4),
            2, "Marker Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", markerNumber);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_RADIO_PROBABILITY, probability),
            3, "Probability");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Positions the percent marker to the given probability expressed as
/// HIFN  value.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR markerNumber/Selects the marker to configure.
/// HIPAR value/Positions the percent marker to the given probability expressed as
/// HIPAR value/value.
ViStatus rsetl_ConfigureRadioMarkerProbabilityValue(ViSession instrSession,
                                                    ViInt32   markerNumber,
                                                    ViReal64  value)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, markerNumber, 1, 4),
            2, "Marker Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", markerNumber);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_RADIO_PROBABILITY_VALUE, value),
            3, "Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Queries the measured deviation value of the percent marker.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR markerNumber/Selects the marker to configure.
/// HIPAR deviation/Queries the measured deviation value of the percent marker.
ViStatus rsetl_QueryRadioMarkerDeviation(ViSession instrSession,
                                         ViInt32   markerNumber,
                                         ViReal64* deviation)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, markerNumber, 1, 4),
            2, "Marker Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", markerNumber);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_RADIO_DEVIATION, deviation),
            3, "Deviation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the audio generator settings.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR type/Selects the generator.
/// HIPAR signal/Selects the generator output at which a signal is to be applied.
/// HIPAR connectorConfig/Specifies the connection between the R&S�ETL and the modulation
/// HIPAR connectorConfig/inputs of the FM transmitter that is to be measured.
/// HIPAR ampDefinition/Selects the range within which the generator amplitude is to be selected.
ViStatus rsetl_ConfigureRadioAudioGenerator(ViSession instrSession,
                                            ViInt32   type,
                                            ViInt32   signal,
                                            ViInt32   connectorConfig,
                                            ViInt32   ampDefinition)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_AGEN_TYPE, type),
            2, "Type");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_AGEN_SIGNAL, signal),
            3, "Signal");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_AGEN_CONNECTOR_CONFIG, connectorConfig),
            4, "Connector Config");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_AGEN_AMPLITUDE_DEFINITION, ampDefinition),
            5, "Amplitude Definition");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures specifies whether a single sinusoidal tone or a dual
/// HIFN tone will be generated, and how the frequency will be set.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR waveform/Selects the waveform.
ViStatus rsetl_ConfigureRadioAudioGeneratorWaveform(ViSession instrSession,
                                                    ViInt32   waveform)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_AGEN_WAVEFORM, waveform),
            2, "Waveform");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the audio generator Level.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR signal/Selects the configured generator output.
/// HIPAR level/Sets the level according to the selected amplitude definition.
ViStatus rsetl_ConfigureRadioAudioGeneratorLevel(ViSession instrSession,
                                                 ViInt32   signal,
                                                 ViReal64  level)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, signal, 0, 3),
            2, "Signal");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", audioLeveltArr[signal]);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_AGEN_LEVEL, level),
            3, "Level");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the audio generator frequency.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR signal/Selects the configured generator output.
/// HIPAR frequency/Sets the frequency.
ViStatus rsetl_ConfigureRadioAudioGeneratorFrequency(ViSession instrSession,
                                                     ViInt32   signal,
                                                     ViReal64  frequency)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, signal, 0, 4),
            2, "Signal");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", audioFrequencyArr[signal]);

    switch (signal){
        case RSETL_VAL_AUDIO_FREQ_L:
        case RSETL_VAL_AUDIO_FREQ_R:
        case RSETL_VAL_AUDIO_FREQ_SCA:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_AGEN_FREQUENCY, frequency),
                    3, "Frequency");
        break;
        case RSETL_VAL_AUDIO_FREQ_UPPER:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_AGEN_FREQUENCY_SPACING, frequency),
                    3, "Frequency");
        break;
        case RSETL_VAL_AUDIO_FREQ_SPACING:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_AGEN_FREQUENCY_UPPER, frequency),
                    3, "Frequency");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the audio generator subcarrier deviation.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR state/Sets deviation state.
/// HIPAR deviation/Sets the audio generator subcarrier deviation.
ViStatus rsetl_ConfigureRadioAudioGeneratorSubcarrierDeviation(
                            ViSession instrSession,
                            ViBoolean state,
                            ViReal64  deviation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_RADIO_AGEN_SUBCARRIER_STATE, state),
            2, "State");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_AGEN_SUBCARRIER_DEVIATION, deviation),
            3, "Deviation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures that the L and R audio channels are measured alternately.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR enable/Sets alternate channel state.
ViStatus rsetl_ConfigureRadioAudioGeneratorAlternateChannelState(
                            ViSession instrSession,
                            ViBoolean enable)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_RADIO_AGEN_ALTERNATE_CHANNEL, enable),
            2, "Enable");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures DUT.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR preemphasis/Selects the generator level as a function of the frequency in accordance with the selected time constant to compensate a corresponding DUT preemphasis.
/// HIPAR channelFrequency/Selects the configured level.
/// HIPAR desiredDeviation/Sets the desired deviation.
ViStatus rsetl_ConfigureRadioAudioGeneratorDUT(ViSession instrSession,
                                               ViInt32   preemphasis,
                                               ViInt32   channelFrequency,
                                               ViReal64  desiredDeviation)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channelFrequency, 0, 3),
            3, "Channel/Frequency");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", audioFrequencyDUTArr[channelFrequency]);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_AGEN_DUT_PREEMPHASIS, preemphasis),
            4, "Preemphasis");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_AGEN_DUT_DEVIATION, desiredDeviation),
            4, "Desired Deviation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function sets the limit of the Radio Overview measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR limitType/This control selects the type of the limit.
/// HIPAR limitValue/This control sets the limit value.
ViStatus rsetl_ConfigureRadioOverviewLimit(ViSession instrSession,
                                           ViInt32   measurement,
                                           ViInt32   limitType,
                                           ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 18),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Lower");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upper");
        break;
    }
    switch (measurement){
        case RSETL_VAL_DTV_LIMIT_RF_LEVEL:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_LIMIT_CF_OFFSET:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_LIMIT_AM_MOD_DEPTH:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_MPX:
        case RSETL_VAL_DTV_LIMIT_DEV_DEMOD_L:
        case RSETL_VAL_DTV_LIMIT_DEV_DEMOD_R:
        case RSETL_VAL_DTV_LIMIT_DEV_MONO:
        case RSETL_VAL_DTV_LIMIT_DEV_STEREO:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", measOverviewArr[measurement], NULL);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_PILOT:
        case RSETL_VAL_DTV_LIMIT_PILOT_FREQ_OFFSET:
        case RSETL_VAL_DTV_LIMIT_PILOT_PHA_TO_S:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", measOverviewArr[measurement], NULL);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_LIMIT_RDS_DEV:
        case RSETL_VAL_DTV_LIMIT_RDS_FREQ_OFFSET:
        case RSETL_VAL_DTV_LIMIT_RDS_PHA_TO_PILOT:
        case RSETL_VAL_DTV_LIMIT_RDS_BER:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", measOverviewArr[measurement], NULL);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_DARC:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_CARR:
        case RSETL_VAL_DTV_LIMIT_SCA_SC_OFFSET:
        case RSETL_VAL_DTV_LIMIT_SCA_DEV_SCA:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", measOverviewArr[measurement], NULL);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT, limitValue),
                    4, "Limit Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function sets the limit of the Radio S/N measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR channel/This control selects the channel.
/// HIPAR limitType/This control selects the type of the limit.
/// HIPAR limitValue/This control sets the limit value.
ViStatus rsetl_ConfigureRadioAudioMeasurementLimit(ViSession instrSession,
                                                   ViInt32   measurement,
                                                   ViInt32   channel,
                                                   ViInt32   limitType,
                                                   ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 11),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 1, 2),
            3, "Channel");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            4, "Limit Type");

    switch (channel){
        case RSETL_VAL_RADIO_CH_L:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Left");
        break;
        case RSETL_VAL_RADIO_CH_R:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Right");
        break;
    }

    RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", audioMeasArr[measurement], NULL);

    switch (measurement){
        case RSETL_VAL_RADIO_LIMIT_SN_R15:
        case RSETL_VAL_RADIO_LIMIT_SN_Q15:
        case RSETL_VAL_RADIO_LIMIT_SN_QI15:
        case RSETL_VAL_RADIO_LIMIT_SN_MR1H:
        case RSETL_VAL_RADIO_LIMIT_SN_AP1H:
        case RSETL_VAL_RADIO_LIMIT_SN_P20:
        case RSETL_VAL_RADIO_LIMIT_SN_AQ20:
        case RSETL_VAL_RADIO_LIMIT_SN_AQI2:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_AUDIO_SN_LIMIT, limitValue),
                    5, "Limit Value");
        break;
        case RSETL_VAL_RADIO_LIMIT_DFD_D2D:
        case RSETL_VAL_RADIO_LIMIT_DFD_D2DS:
        case RSETL_VAL_RADIO_LIMIT_DFD_D3:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT, limitValue),
                    5, "Limit Value");
        break;
        case RSETL_VAL_RADIO_LIMIT_THD:
            switch (channel){
                case RSETL_VAL_RADIO_CH_L:
                    snprintf(repCap, RS_REPCAP_BUF_SIZE, "Left");
                break;
                case RSETL_VAL_RADIO_CH_R:
                    snprintf(repCap, RS_REPCAP_BUF_SIZE, "Right");
                break;
            }
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_AUDIO_THD_LIMIT, limitValue),
                    5, "Limit Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function sets the limit of the Radio modulation measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR limitType/This control selects the type of the limit.
/// HIPAR limitValue/This control sets the limit value.
ViStatus rsetl_ConfigureRadioModulationMeasurementLimit(ViSession instrSession,
                                                        ViInt32   measurement,
                                                        ViInt32   limitType,
                                                        ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 3),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 1, 1),
            3, "Limit Type");
    switch (measurement){
        case RSETL_VAL_RADIO_LIMIT_MPX_POW:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_MPX_POW_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_RADIO_LIMIT_MPX_PEAK_DEV:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_MPX_PEAK_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_RADIO_LIMIT_MP_RESPONSE:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "Resp", RSETL_ATTR_RADIO_MP_DETECTION_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_RADIO_LIMIT_MP_GRADIENT:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "Grad", RSETL_ATTR_RADIO_MP_DETECTION_LIMIT, limitValue),
                    4, "Limit Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Sets or queries the deviation limit for the MPX deviation violation
/// HIFN  measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR limit/Sets or queries the deviation limit for the MPX deviation violation
/// HIPAR limit/measurement.
ViStatus rsetl_ConfigureRadioMPXDeviationLimit(ViSession instrSession,
                                               ViReal64  limit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT, limit),
            2, "Limit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Sets or queries the limit for the ratio result in the MPX deviation
/// HIFN  violation measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR ratio/Sets or queries the limit for the ratio result in the MPX deviation
/// HIPAR ratio/violation measurement.
ViStatus rsetl_ConfigureRadioMPXDeviationLimitRatio(ViSession instrSession,
                                                    ViReal64  ratio)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT_RATIO, ratio),
            2, "Ratio");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Sets or queries the upper limit for the OBW radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR limit/Sets or queries the upper limit for the OBW radio measurement.
ViStatus rsetl_ConfigureRadioOBWUpperLimit(ViSession instrSession,
                                           ViReal64  limit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_OBW_UPPER_LIMIT, limit),
            2, "Limit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the unit of the difference frequency
/// HIFN distortions for the DFD radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR units/Select units.
ViStatus rsetl_ConfigureRadioDFDUnit(ViSession instrSession,
                                     ViInt32   units)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_DFD_UNIT, units),
            2, "Units");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the unit of the difference frequency
/// HIFN distortions for the THD radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR units/Select units.
ViStatus rsetl_ConfigureRadioTHDUnit(ViSession instrSession,
                                     ViInt32   units)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_THD_UNIT, units),
            2, "Units");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Read CATV Y Trace
 * Purpose:  This function initiates a signal acquisition based on the present
 *           instrument configuration.  It then waits for the acquisition to
 *           complete, and returns the trace as an array of amplitude values.
 *           The amplitude array returns data that represent the amplitude of
 *           the signals of the sweep from the start frequency to the stop
 *           frequency (in frequency domain, in time domain the amplitude
 *           array is ordered from beginning of sweep to end).  The Amplitude
 *           Units attribute determines the units of the points in the
 *           amplitude array.  This function resets the sweep count.
 *****************************************************************************/
ViStatus rsetl_ReadCATVYTrace(ViSession instrSession,
                              ViInt32   trace,
                              ViUInt32  maximumTime,
                              ViInt32   arrayLength,
                              ViInt32   *actualPoints,
                              ViReal64  amplitude[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, maximumTime, 0, 4294967295), 3, "Maximum Time");

    checkErr(rsetl_CATVInitiate(instrSession, maximumTime));

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":TRAC? TRACE%ld", trace);
    checkErr(rsetl_dataReadTrace(instrSession, cmd, arrayLength,
                    amplitude, actualPoints));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Channel Adjust Attenuation
 * Purpose:  This function adjusts the input attenuator.
 *****************************************************************************/
ViStatus rsetl_CATVChannelAdjustAtt(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_ACP_PRESET_REF_LEVEL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Autoscale
 * Purpose:  This function activates the automatic scaling for the Hum and Tilt
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_CATVAutoscale(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_Y_SCALE_AUTO, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Sweep Coupling Auto
 * Purpose:  This function activates auto coupling of selected coupling
 *           method.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVSweepCouplingAuto(ViSession instrSession,
                                              ViInt32   sweepCoupling)
{
    ViStatus error = VI_SUCCESS;
    ViAttr   attribute = 0;

    checkErr(RsCore_LockSession(instrSession));

    switch (sweepCoupling)
    {
        case  RSETL_VAL_COUPLING_RBW:
            attribute = RSETL_ATTR_RESOLUTION_BANDWIDTH_AUTO;
            break;

        case RSETL_VAL_COUPLING_VBW:
            attribute = RSETL_ATTR_VIDEO_BANDWIDTH_AUTO;
            break;

        case RSETL_VAL_COUPLING_SWEEP_TIME:
            attribute = RSETL_ATTR_SWEEP_TIME_AUTO;
            break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, sweepCoupling), 2, "Sweep Coupling");
    }

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", attribute, VI_TRUE),
            1, "Dummy");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Sweep Coupling
 * Purpose:  This function configures the coupling values of the spectrum
 *           analyzer.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVSweepCoupling(ViSession instrSession,
                                          ViInt32   sweepCoupling,
                                          ViReal64  couplingValue)
{
    ViStatus error = VI_SUCCESS;
    ViAttr   attribute = 0;

    checkErr(RsCore_LockSession(instrSession));

    switch (sweepCoupling)
    {
        case RSETL_VAL_COUPLING_RBW:
            attribute = RSETL_ATTR_RESOLUTION_BANDWIDTH;
            break;

        case RSETL_VAL_COUPLING_VBW:
            attribute = RSETL_ATTR_VIDEO_BANDWIDTH;
            break;

        case RSETL_VAL_COUPLING_SWEEP_TIME:
            attribute = RSETL_ATTR_SWEEP_TIME;
            break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, sweepCoupling), 2, "Sweep Coupling");
    }

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", attribute, couplingValue),
            3, "Coupling Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Acquisition
 * Purpose:  This function configures the acquisition attributes of the
 *           spectrum analyzer.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAcquisition(ViSession instrSession,
                                        ViBoolean sweepModeContinuous,
                                        ViInt32   numberOfSweeps)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_SWEEP_MODE_CONTINUOUS, sweepModeContinuous),
            2, "Sweep Mode Continuous");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_NUMBER_OF_SWEEPS, numberOfSweeps),
            3, "Number Of Sweeps");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Vertical Scale
 * Purpose:  This function configures the vertical scale of analyzer.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVVerticalScale(ViSession instrSession,
                                          ViInt32   verticalScale)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_VERTICAL_SCALE, verticalScale),
            2, "Vertical Scale");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Horizontal Scaling
 * Purpose:  This function selects the Center and Division settings
 *           automatically, depending on FFT size, Channel Bandwidth, and
 *           Guard Interval.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVHorizontalScaling(ViSession instrSession,
                                              ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_X_AXIS_AUTO_SCALING, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Center Position
 * Purpose:  This function configures the center position of the display in
 *           time domain, or in distance domain.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVCenterPosition(ViSession instrSession,
                                           ViReal64  centerPosition)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DISPLAY_CENTER_POSITION, centerPosition),
            2, "Center Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Division
 * Purpose:  This function configures the time (in seconds) or distance (in
 *           km or miles) per division. In total, always 10 divisions are
 *           displayed.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDivision(ViSession instrSession,
                                     ViReal64  division)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DISPAY_DIVISION, division),
            2, "Division");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Sweep Points
 * Purpose:  This function defines the number of measurement points for one
 *           sweep run.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVSweepPoints(ViSession instrSession,
                                        ViInt32   sweepPoints)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_SWEEP_POINTS, sweepPoints),
            2, "Sweep Points");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Level
 * Purpose:  This function configures the vertical attributes of the spectrum
 *           analyzer.  This corresponds to attributes like amplitude units,
 *           input attenuation, input impedance, reference level, and reference
 *           level offset.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVLevel(ViSession instrSession,
                                  ViInt32   amplitudeUnits,
                                  ViReal64  inputImpedance,
                                  ViReal64  referenceLevel,
                                  ViReal64  referenceLevelOffset,
                                  ViBoolean attenuationAuto,
                                  ViReal64  attenuation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_AMPLITUDE_UNITS, amplitudeUnits),
            2, "Amplitude Units");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_INPUT_IMPEDANCE, inputImpedance),
            3, "Input Impedance");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_REFERENCE_LEVEL_OFFSET, referenceLevelOffset),
            5, "Reference Level Offset");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_ATTENUATION_AUTO, attenuationAuto),
            6, "Attenuation Auto");
    if (attenuationAuto == VI_FALSE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ATTENUATION, attenuation),
                7, "Attenuation");
    }
    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_REFERENCE_LEVEL, referenceLevel),
            4, "Reference Level");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function reads whether the state of the attenuator has been
/// HIFN  changed. After reading out, the state is reset to unchanged.
/// HIFN     Prerequisite is that the input attenuation is automatically coupled to
/// HIFN  the reference level (INPut<1|2>:ATTenuation:AUTO, attribute
/// HIFN  RSETL_ATTR_ATTENUATION_AUTO).
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR attenuatorState/Returns whether the state of the attenuator has been changed. After
/// HIPAR attenuatorState/reading out, the state is reset to unchanged.
ViStatus rsetl_QueryCATVAttenuatorState(ViSession  instrSession,
                                        ViBoolean* attenuatorState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_ATTENUATOR_STATE, attenuatorState),
            2, "Attenuator State");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function configures the drive test mode state of the automatic
/// HIFN  attenuation control algorithm. Changing these values allows to set a
/// HIFN  different tradeoff between signal quality and attenuation switching
/// HIFN  frequency.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR driveTestMode/Specifies the drive test mode state of the automatic attenuation
/// HIPAR driveTestMode/control algorithm
/// HIPAR reserve/Specifies the reserve of the automatic attenuation control algorithm.
/// HIPAR reserve/The higher the reserve, the more the signal is attenuated at the
/// HIPAR reserve/minimum to prevent overloads caused by sporadic peaks.
/// HIPAR hysteresis/Sets the hysteresis of the automatic attenuation control algorithm. he
/// HIPAR hysteresis/higher the hysteresis, the wider the level range in which the
/// HIPAR hysteresis/attenuation state remains unchanged.
ViStatus rsetl_ConfigureCATVDriveTestMode(ViSession instrSession,
                                          ViBoolean driveTestMode,
                                          ViReal64  reserve,
                                          ViReal64  hysteresis)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_ATTENUATION_DRIVE_MODE, driveTestMode),
            2, "Drive Test Mode");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATTENUATION_DRIVE_RESERVE, reserve),
            3, "Reserve");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATTENUATION_DRIVE_HYSTERESIS, hysteresis),
            4, "Hysteresis");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Reference Level Auto
 * Purpose:  This function enables the R&S ETL to automatically set the signal
 *           level. On receiving this command, the R&S ETL once performs a full
 *           span spectrum sweep and reads the total signal power at the RF
 *           input. Afterwards, the R&S ETL uses both the measured signal level
 *           and the setting of the pre-amplifier to continuously control the
 *           step attenuation. Changes of the step attenuation or
 *           pre-amplifier setting cause a short interruption of the input
 *           signal.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVReferenceLevelAuto(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_REFERENCE_LEVEL_AUTO, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Level Display
 * Purpose:  This function defines the level display.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVLevelDisplay(ViSession instrSession,
                                         ViBoolean levelDisplay)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_LEVEL_DISPLAY, levelDisplay),
            2, "Level Display");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Attenuation Mode
 * Purpose:  This function swicthes the behaviour for the attenuator. "Normal"
 *           means that the mechanical attenuator is switch as early as possible
 *           ("Low Noise") and "Low distortion" means the mechanical attenuator
 *           is switched as late as possible for Low Distortion.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAttenuationMode(ViSession instrSession,
                                            ViInt32   attenuationMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATT_MODE, attenuationMode),
            2, "Attenuation Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Unit
 * Purpose:  This function configures the unit for power.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVUnits(ViSession instrSession,
                                  ViInt32   units)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_UNIT_POWER, units),
            2, "Units");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Preselection State
 * Purpose:  This function switches on the preselection for the instrument.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVPreselectionState(ViSession instrSession,
                                              ViBoolean preselection)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_PRES_STATE, preselection),
            2, "Preselection");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Preamplifier State
 * Purpose:  This function switches on the preamplifier for the instrument.
 *           The switchable gain is fixed to 20 dB.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVPreamplifierState(ViSession instrSession,
                                              ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_AMPL_PREAMPLIFIER, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function reads the actual state of the preamplifier.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR state/Returns the actual state of the preamplifier
ViStatus rsetl_QueryCATVPreamplifierState(ViSession  instrSession,
                                          ViBoolean* state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_QUERY_CATV_AMPL_PREAMPLIFIER_STATE, state),
            2, "State");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Input Selection
 * Purpose:  This function toggles the input between RF and I/Q. With ON, the
 *           input is switched to I/Q, with OFF to RF.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVInputSelection(ViSession instrSession,
                                           ViBoolean iQState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_INPUT_SELECT, iQState),
            2, "IQ State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function toggles the input between RF and MPX.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR MPXState/Toggles the input between RF and MPX.
ViStatus rsetl_ConfigureCATVInputMPXState(ViSession instrSession,
                                          ViBoolean MPXState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_INPUT_SELECT_MPX, MPXState),
            2, "MPX State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Sound Channel
 * Purpose:  This function select the sound channel.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVSoundChannel(ViSession instrSession,
                                         ViInt32   soundChannel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_SOUND_CHAN, soundChannel),
            2, "Sound Channel");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Audio State
 * Purpose:  This function switches on or off the sound for analog and digital
 *           TV measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAudioState(ViSession instrSession,
                                       ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_AUDIO_STATE, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Audio Volume
 * Purpose:  This function sets the audio volume.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAudioVolume(ViSession instrSession,
                                        ViReal64  audioVolume)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_AUDIO_VOLUME, audioVolume),
            2, "Audio Volume");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Special Settings
 * Purpose:  This function defines the special settings that do not have to be
 *           changed during normal operation.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVSpecialSettings(ViSession instrSession,
                                            ViInt32   videoClamping,
                                            ViInt32   soundDemodulation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_VIDEO_CLAMPING_MODE, videoClamping),
            2, "Video Clamping");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_SOUND_DEMOD_MODE, soundDemodulation),
            3, "Sound Demodulation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Marker State
 * Purpose:  This function enables or disables selected marker.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVMarkerState(ViSession instrSession,
                                        ViInt32   markerNumber,
                                        ViBoolean markerState)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, markerNumber, 1, 4),
            2, "Marker Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", markerNumber);

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MARKER_ENABLED, markerState),
            2, "Marker State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Disable CATV All Markers
 * Purpose:  This function switches off all active markers in the specified
 *           measurement window.
 *****************************************************************************/
ViStatus rsetl_DisableCATVAllMarkers(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MARKER_AOFF, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Marker Parameter
 * Purpose:  This function configures the marker parameters.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVMarkerParameter(ViSession instrSession,
                                            ViReal64  peakExcursion,
                                            ViBoolean excludeLO)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_PEAK_EXCURSION, peakExcursion),
            2, "Peak Excursion");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_LOEX, excludeLO),
            3, "Exclude LO");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Marker Search Limits
 * Purpose:  This function configures marker search limits.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVMarkerSearchLimits(ViSession instrSession,
                                               ViBoolean searchLimits,
                                               ViReal64  leftSearchLimit,
                                               ViReal64  rightSearchLimit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_SEARCH_LIMITS_STATE, searchLimits),
            2, "Serach Limits");

    if (searchLimits == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_SEARCH_LIMITS_LEFT, leftSearchLimit),
                3, "Left Search Limit");

        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_SEARCH_LIMITS_RIGHT, rightSearchLimit),
                4, "Right Search Limit");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Marker Position
 * Purpose:  This function positions the selected marker to the indicated
 *           frequency.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVMarkerPosition(ViSession instrSession,
                                           ViInt32   markerNumber,
                                           ViReal64  markerPosition)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, markerNumber, 1, 4),
            2, "Marker Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", markerNumber);
    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_POSITION, markerPosition),
            3, "Marker Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Delta Marker State
 * Purpose:  This function enables or disables selected delta marker.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDeltaMarkerState(ViSession instrSession,
                                             ViInt32   deltaMarkerNumber,
                                             ViBoolean deltaMarkerState)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarkerNumber, 1, 4),
            2, "Delta Marker Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarkerNumber);

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_STATE, deltaMarkerState),
            2, "Delta Marker State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Disable CATV All Delta Markers
 * Purpose:  This function turns off all the delta markers in selected
 *           measurement window.
 *****************************************************************************/
ViStatus rsetl_DisableCATVAllDeltaMarkers(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_REFERENCE_MARKER_AOFF, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Delta Marker Position
 * Purpose:  This function configures the delta marker position.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDeltaMarkerPosition(ViSession instrSession,
                                                ViInt32   deltaMarkerNumber,
                                                ViInt32   deltaMarkerMode,
                                                ViReal64  deltaMarkerPosition)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarkerNumber, 1, 4),
            2, "Delta Marker Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarkerNumber);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MODE, deltaMarkerMode),
            3, "Delta Marker Mode");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_POSITION, deltaMarkerPosition),
            4, "Delta Marker Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Trace
 * Purpose:  This function configures the trace to acquire.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVTrace(ViSession instrSession,
                                  ViInt32   trace,
                                  ViInt32   traceType)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);

    switch (traceType){
        case RSETL_TRAC_MOD_BLANK:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_TRACE_STATE, VI_FALSE));
        break;
        default:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_TRACE_STATE, VI_TRUE));

        viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_TRACE_TYPE, traceType),
                3, "Trace Type");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Trace Detector
 * Purpose:  This function configures the trace detector.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVTraceDetector(ViSession instrSession,
                                          ViInt32   trace,
                                          ViBoolean detectorTypeAuto,
                                          ViInt32   detectorType)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_DETECTOR_TYPE_AUTO, detectorTypeAuto),
            3, "Detector Type Auto");
    if (detectorTypeAuto == VI_FALSE)
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_DETECTOR_TYPE, detectorType),
                4, "Detector Type");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Trace Reset Behavior
 * Purpose:  This function specifies whether or not the traces with peak or
 *           minimum value detection are reset after specific parameter
 *           changes.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVTraceResetBehavior(ViSession instrSession,
                                               ViInt32   trace,
                                               ViBoolean resetAtChange)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_TRACE_RESET_BEHAVIOR, resetAtChange),
            3, "Reset At Change");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Trace Constellation Diagram Mode
 * Purpose:  This function configures the display mode of the constallation
 *           diagram.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVTraceConstellationDiagramMode(ViSession instrSession,
                                                          ViInt32   trace,
                                                          ViBoolean constellationDiagramMode)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_CATV_TRACE_MODE_FREEZE, constellationDiagramMode),
            3, "Constellation Diagram Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Copy Trace
 * Purpose:  This function copies one trace array to another trace array.  Any
 *           data in the destination trace is over written.
 *****************************************************************************/
ViStatus rsetl_CATVCopyTrace(ViSession instrSession,
                             ViInt32   destinationTrace,
                             ViInt32   sourceTrace)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, destinationTrace, 1, 4),
            2, "Destination Trace");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, sourceTrace, 1, 4),
            3, "Source Trace");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "TRAC:COPY TRACE%ld,TRACE%ld", destinationTrace, sourceTrace);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Store Trace to File
 * Purpose:  This function stores the selected trace (1 to 4) in the
 *           measurement window indicated by window in a file with ASCII
 *           format.
 *****************************************************************************/
ViStatus rsetl_CATVStoreTraceToFile(ViSession instrSession,
                                    ViInt32   trace,
                                    ViString  fileName)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, fileName), 3, "File Name");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "MMEM:STOR:TRAC %ld,'%s'", trace, fileName);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Trigger Delay
 * Purpose:  This function specifies the delayfor triggering.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVTriggerDelay(ViSession instrSession,
                                         ViReal64  triggerDelay)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_DELAY, triggerDelay),
            2, "Trigger Delay");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Display Log Range
 * Purpose:  This function defines the display range of the Y axis (level
 *           axis) in the selected measurement window with logarithmic scaling
 *           (DISP:TRAC:Y:SPAC LOG).
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDisplayLogRange(ViSession instrSession,
                                            ViReal64  range)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_LOG_RANGE, range),
            2, "Range");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Display Amplitude Grid Mode
 * Purpose:  This function defines the scale type of the Y axis (absolute or
 *           relative) in the selected measurement window.
 *           When SYSTem:DISPlay is set to OFF, this command has no immediate
 *           effect on the screen.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDisplayAmplitudeGridMode(ViSession instrSession,
                                                     ViInt32   yAxisGridMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISP_AMPLITUDE_GRID_MODE, yAxisGridMode),
            2, "Y Axis Grid Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Display Reference Position
 * Purpose:  This function defines the position of the reference value.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDisplayReferencePosition(ViSession instrSession,
                                                     ViReal64  referencePosition)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_REF_POSITION, referencePosition),
            2, "Reference Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Display Channel Impulse Response
 * Purpose:  This function configures the display of the channel impulse
 *           response (echo pattern).
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDisplayChannelImpulseResponse(ViSession instrSession,
                                                          ViInt32   channelImpulseResponse)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISP_CHANNEL_IMPULSE_RESPONSE, channelImpulseResponse),
            2, "Channel Impulse Response");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Display Set Window To Foreground
 * Purpose:  This function sets the ETL window in the foreground.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATTDisplaySetWindowToForeground(ViSession instrSession,
                                                         ViInt32   windowState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISPL_SET_TO_FOREGROUND, windowState),
            2, "Window State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure CATV Display MER Vs Frequency
 * Purpose:  This function configures the graphical display of MER vs
 *           frequency. It is available only for the OFDM modes.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATTDisplayMERVsFrequency(ViSession instrSession,
                                                  ViBoolean MERInverted)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_MER_VS_FREQ, MERInverted),
            2, "MER Inverted");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures MER-PhaseNoise measurement refernce.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR referencePosition/Sets the reference position.
/// HIPAR referenceDeviation/Sets the reference deviation.
ViStatus rsetl_ConfigureCATVDisplayMERPhaseNoiseReference(ViSession instrSession,
                                                          ViReal64  referencePosition,
                                                          ViReal64  referenceDeviation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_MER_PHASE_REFERENCE_POSITION, referencePosition),
            2, "Reference Position");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_MER_PHASE_REFERENCE_DEVIATION, referenceDeviation),
            3, "Reference Deviation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures MER-PhaseNoise deviation range.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR scaling/Selects scaling for deviation range.
/// HIPAR deviationRange/Sets the deviation range.
ViStatus rsetl_ConfigureCATVDisplayMERPhaseNoiseRange(ViSession instrSession,
                                                      ViInt32   scaling,
                                                      ViReal64  deviationRange)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISP_MER_PHASE_DEVIATION_SCALING, scaling),
            2, "Scaling");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_MER_PHASE_DEVIATION_RANGE, deviationRange),
            3, "Deviation Range");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures display of GPS data in the Overview measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR showGPSPosition/Switch display of GPS position On/Off.
ViStatus rsetl_ConfigureCATVDisplayGPSPosition(ViSession instrSession,
                                               ViBoolean showGPSPosition)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_GPS_POSITION, showGPSPosition),
            2, "Show GPS Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures whether the Peak List table is displayed in Echo Pattern measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR showPeakList/Switch display of the Peak List table On/Off.
ViStatus rsetl_ConfigureCATVDisplayEchoPatternPeakList(ViSession instrSession,
                                                       ViBoolean showPeakList)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_PEAK_LIST, showPeakList),
            2, "Show Peak List");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function removes the table with numerical results from the
/// HIFN display. Instead of it, the diagram is vertically stretched.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR fullSize/witch full size of diagram On/Off.
ViStatus rsetl_ConfigureCATVDisplayRadioDiagramFullSize(ViSession instrSession,
                                                        ViBoolean fullSize)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_DIAGRAM_FULL_SIZE, fullSize),
            2, "Full Size");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function configures the Echo Pattern measurement result display
/// HIFN  for MISO signals. It defines how the echo paths from within different
/// HIFN  MISO groups shall be displayed.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR misoDisplay/This control selects the Echo Pattern measurement result display for
/// HIPAR misoDisplay/MISO signals. It defines how the echo paths from within different MISO
/// HIPAR misoDisplay/groups shall be displayed.
ViStatus rsetl_ConfigureCATVDisplayEchoPatternMISOSignals(ViSession instrSession,
                                                          ViInt32   misoDisplay)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISP_MISO, misoDisplay),
            2, "MISO Display");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Measurement Mode
 * Purpose:  This function switches to analog TV measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAMeasurementMode(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_MEAS_MODE, RSETL_VAL_CATV_MEAS_MODE_ATV),
            2, "Measurement Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Measurement
 * Purpose:  This function defines the analog TV measurement type.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAMeasurement(ViSession instrSession,
                                         ViInt32   measurement)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_MEAS, measurement),
            2, "Measurement");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Modulation Standard
 * Purpose:  This function defines the analog TV standard options.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAModulStandard(ViSession instrSession,
                                           ViInt32   TVStandard,
                                           ViInt32   soundSystem,
                                           ViInt32   groupDelay,
                                           ViInt32   colorSystem,
                                           ViInt32   barField,
                                           ViInt32   barLine,
                                           ViInt32   barLineType,
                                           ViInt32   quietField,
                                           ViInt32   quietLine)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, TVStandard, 0, 6),
            2, "Delta Marker Number");

    switch (TVStandard){
        case RSETL_VAL_ATV_STAN_BG:    //B/G
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, soundSystem, 0, 2),
                    3, "Sound System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, groupDelay, 0, 7),
                    4, "Group Delay");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorSystem, 0, 2),
                    5, "Color System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barLineType, 0, 0),
                    8, "Bar Line Type");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barField, 1, 1),
                    6, "Bar Field");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, quietField, 1, 1),
                    9, "Quiet Field");
        break;
        case RSETL_VAL_ATV_STAN_DK:   //D/K
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, soundSystem, 3, 6),
                    3, "Sound System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, groupDelay, 7, 10),
                    4, "Group Delay");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorSystem, 0, 2),
                    5, "Color System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barLineType, 0, 0),
                    8, "Bar Line Type");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barField, 1, 1),
                    6, "Bar Field");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, quietField, 1, 1),
                    9, "Quiet Field");
        break;
        case RSETL_VAL_ATV_STAN_I:    //I
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, soundSystem, 7, 8),
                    3, "Sound System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, groupDelay, 7, 7),
                    4, "Group Delay");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorSystem, 0, 0),
                    5, "Color System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barLineType, 0, 0),
                    8, "Bar Line Type");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barField, 1, 1),
                    6, "Bar Field");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, quietField, 1, 1),
                    9, "Quiet Field");
        break;
        case RSETL_VAL_ATV_STAN_K1:     //K1
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, soundSystem, 3, 6),
                    3, "Sound System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, groupDelay, 7, 13),
                    4, "Group Delay");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorSystem, 2, 2),
                    5, "Color System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barLineType, 0, 0),
                    8, "Bar Line Type");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barField, 1, 1),
                    6, "Bar Field");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, quietField, 1, 1),
                    9, "Quiet Field");
        break;
        case RSETL_VAL_ATV_STAN_L:     //L
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, soundSystem, 9, 10),
                    3, "Sound System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, groupDelay, 7, 11),
                    4, "Group Delay");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorSystem, 2, 2),
                    5, "Color System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barLineType, 0, 0),
                    8, "Bar Line Type");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barField, 1, 1),
                    6, "Bar Field");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, quietField, 1, 1),
                    9, "Quiet Field");
        break;
        case RSETL_VAL_ATV_STAN_M:      //M
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, soundSystem, 11, 14),
                    3, "Sound System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, groupDelay, 7, 12),
                    4, "Group Delay");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorSystem, 0, 1),
                    5, "Color System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barLineType, 1, 2),
                    8, "Bar Line Type");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barField, 1, 2),
                    6, "Bar Field");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, quietField, 1, 2),
                    9, "Quiet Field");
        break;
        case RSETL_VAL_ATV_STAN_N:      //N
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, soundSystem, 11, 14),
                    3, "Sound System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, groupDelay, 7, 12),
                    4, "Group Delay");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorSystem, 0, 0),
                    5, "Color System");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barLineType, 0, 0),
                    8, "Bar Line Type");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, barField, 1, 1),
                    6, "Bar Field");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, quietField, 1, 1),
                    9, "Quiet Field");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, TVStandard), 2, "TV Standard");
    }

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_STANDARD, TVStandard),
            2, "TV STandard");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_SOUND_SYSTEM, soundSystem),
            3, "Sound System");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_MODUL_STANDARD_GDELAY, groupDelay),
            4, "Group Delay");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_COLOR, colorSystem),
            5, "Color System");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_TRIGGER_BAR_FIELD, barField),
            6, "Bar Field");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE, barLine),
            7, "Bar Line");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE_TYPE, barLineType),
            7, "Bar Line Type");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_TRIGGER_QUIET_LINE, quietLine),
            8, "Quiet Line");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_TRIGGER_QLINE_FIELD,
                    quietField), 9, "Quiet Field")

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Video Scope Line
 * Purpose:  This function configures the Video Scope line
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAVideoScopeLine(ViSession instrSession,
                                            ViInt32   line)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_LINE, line),
            2, "Line");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Configure Analog TV Video Scope Field
 * Purpose:  This function configures the Video Scope field
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAVideoScopeField(ViSession instrSession,
                                             ViInt32   activeField)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_FIELD, activeField),
            2, "Active Field");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV C/N Noise Floor Correction
 * Purpose:  This function configures the noise floor correction
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACNNoiseFloorCorrection(ViSession instrSession,
                                                    ViBoolean noiseFloorCorrection,
                                                    ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = 0;

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "CN", RSETL_ATTR_CATV_ATV_NOISE_FLOOR_CORRECTION, noiseFloorCorrection),
            5, "Noise Floor Correction");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Averaging Depth
 * Purpose:  This function configures the averaging depth of the Analog TV
 *           Analysis.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAAveragingDepth(ViSession instrSession,
                                            ViInt32   averagingDepth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_AVER_DEPTH, averagingDepth),
            2, "Averaging Depth");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Reset Averaging Depth
 * Purpose:  This function clears and resets (restarts) the averaging depth of
 *           the Analog TV Analysis.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAResetAveragingDepth(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_ATV_AVER_RESET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Residual Picture Carrier
 * Purpose:  This function configures the residual carrier.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAResidualPictureCarrier(ViSession instrSession,
                                                    ViBoolean predefinedValue,
                                                    ViReal64  manualValue)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_RESIDUAL_CARRIER_STATE, predefinedValue),
            2, "Predefined Value");

    if (predefinedValue == VI_FALSE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_RESIDUAL_CARRIER_VALUE, manualValue),
                3, "Manual Value");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Video Generator
 * Purpose:  This function configures the video generator.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAVideoGenerator(ViSession instrSession,
                                            ViBoolean generatorState,
                                            ViInt32   IFOut,
                                            ViInt32   videoSignal,
                                            ViInt32   userLibArea,
                                            ViString  userLibImage)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_VIDEO_GEN_STATE, generatorState),
            2, "Generator State");

    if (generatorState == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_VIDEO_GEN_IF_OUT, IFOut),
                3, "IF Out");

        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_VIDEO_GEN_TEST_PATTERN, videoSignal),
                4, "Video Signal");

        snprintf(repCap, RS_REPCAP_BUF_SIZE, "U%ld", userLibArea);
        viCheckParm(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_CATV_VIDEO_GEN_USER_DEFINED_IMAGE, userLibImage),
                5, "User Lib Image");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Test Signals
 * Purpose:  This function assigns the test signals to the main measurement
 *           parameters.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVATestSignals(ViSession instrSession,
                                         ViInt32   mainMeasurement,
                                         ViInt32   testSignal)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, mainMeasurement, RSETL_VAL_CATV_MAIN_MEAS_LBAR, RSETL_VAL_CATV_MAIN_MEAS_ICPM),
            2, "Main Measurement");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", ATVMainMeas[mainMeasurement]);
    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_MEAS_TEST_SIGNAL, testSignal),
            2, "Test Signal");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Test Lines
 * Purpose:  This function assigns the video line and the field (optional) to
 *           the test signal. A video line may be assigned to one test signal
 *           only.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVATestLines(ViSession instrSession,
                                       ViInt32   testSignal,
                                       ViInt32   lineNumber,
                                       ViInt32   field)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, testSignal, RSETL_VAL_CATV_TEST_SIGNAL_T17C, RSETL_VAL_CATV_TEST_SIGNAL_TUK),
            2, "Test Signal");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, lineNumber, 0, 625),
            3, "Line Number");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, field, 0, 2),
            4, "Field");

    if (field == 0)
    {
        snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "SENS:ATV:VME:TSIG:LINE %s,%ld", ATVTestSignal[testSignal], lineNumber);
        checkErr(RsCore_Write(instrSession, cmd));
    }
    else
    {
        snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "SENS:ATV:VME:TSIG:LINE %s,%ld,%s",
            ATVTestSignal[testSignal], lineNumber, (field == 1)? "F1" : "F2");
        checkErr(RsCore_Write(instrSession, cmd));
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Test Lines
 * Purpose:  This function returns the assigned video line and field of the
 *           test signal.
 *****************************************************************************/
ViStatus rsetl_QueryCATVATestLines(ViSession instrSession,
                                   ViInt32   testSignal,
                                   ViInt32   *lineNumber,
                                   ViInt32   *field)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];
    ViChar   response[RS_MAX_MESSAGE_BUF_SIZE];
    ViChar   parsed[RS_MAX_MESSAGE_LEN] = "";

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, testSignal, RSETL_VAL_CATV_TEST_SIGNAL_T17C, RSETL_VAL_CATV_TEST_SIGNAL_TUK),
            2, "Test Signal");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "SENS:ATV:VME:TSIG:LINE? %s", ATVTestSignal[testSignal]);
    checkErr(RsCore_QueryViString(instrSession, cmd, response));
    (void)sscanf(response, "%ld,%s", lineNumber, parsed);

    if (strncmp (parsed, "F1", 2) == 0)
        *field = 1;
    else
        *field = 2;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Waveform Parameter
 * Purpose:  This function configures the waveform parameter.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAWaveformParameter(ViSession instrSession,
                                               ViInt32   waveformParameter)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_WAV_PARAM, waveformParameter),
            2, "Waveform Parameter");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Waveform Location
 * Purpose:  This function configures the waveform location.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAWaveformLocation(ViSession instrSession,
                                              ViInt32   waveformLocation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_WAV_LOC, waveformLocation),
            2, "Waveform Location");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function:  Query Analog TV Waveform Points !!!!
 * Purpose:   This function queries the number of waveform points.
 *****************************************************************************/
ViStatus rsetl_QueryAnalogTVWaveformPoints(ViSession instrSession,
                                           ViInt32   *waveformPoints)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_ATV_WAV_POINTS, waveformPoints),
            2, "Waveform Points");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Waveform Center Width
 * Purpose:  This function queries the waveform center and width.
 *****************************************************************************/
ViStatus rsetl_QueryAnalogTVWaveformCenterWidth(ViSession instrSession,
                                                ViInt32   waveformLocation,
                                                ViReal64  *waveformCenter,
                                                ViReal64  *waveformWidth)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, waveformLocation, 1, 15),
            2, "Waveform Location");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "LOC%ld", waveformLocation);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_GET_ATV_WAV_CENTER, waveformCenter),
            3, "Waveform Center");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_GET_ATV_WAV_WIDTH, waveformWidth),
            4, "Waveform Width");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV C/N Measurement
 * Purpose:  This function configures the Carrier to Noise Ratio measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACNMeasurement(ViSession instrSession,
                                           ViInt32   measCarrier,
                                           ViInt32   measurementMethod,
                                           ViReal64  noiseReferenceBandwidth)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = 0;

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, 60000));


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CN", RSETL_ATTR_CATV_ATV_CARR_MEAS, measCarrier),
            2, "Meas Carrier");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CN", RSETL_ATTR_CATV_ATV_MEAS_MODE, measurementMethod),
            3, "Measurement Method");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "CN", RSETL_ATTR_CATV_ATV_BWID, noiseReferenceBandwidth),
            4, "Noise Reference Bandwidth");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV C/N Reference Power
 * Purpose:  This function configures the reference power for Carrier to
 *           Noise Ratio measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACNReferencePower(ViSession instrSession,
                                              ViInt32   referencePower,
                                              ViInt32   referenceChannel,
                                              ViReal64  powerManual)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CN", RSETL_ATTR_CATV_ATV_REF_POWER_MODE, referencePower),
            2, "Reference Power");
    switch (referencePower){
        case RSETL_VAL_ATV_RPOW_MODE_RCH:
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CN", RSETL_ATTR_CATV_ATV_REF_CHANNEL_MANUAL, referenceChannel),
                    3, "Reference Channel");
        break;
        case RSETL_VAL_ATV_RPOW_MODE_MAN:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "CN", RSETL_ATTR_CATV_ATV_REF_POWER_MANUAL, powerManual),
                    4, "Power Manual");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV C/N Measurement Frequencies
 * Purpose:  This function defines the measurement frequencies
 *           (center frequencies and span values), and activates or deactivates
 *           them for the C/N measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACNMeasurementFrequencies(ViSession instrSession,
                                                      ViInt32   tableRow,
                                                      ViBoolean state,
                                                      ViReal64  centerFrequency,
                                                      ViReal64  span)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, tableRow, 1, 10),
            2, "Table Row");
    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, state), 3, "State");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":ATV:CN:TABL%ld:MFR %d,%.12lf,%.12lf", tableRow, state == VI_FALSE ? 0 : 1, centerFrequency, span);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Analog TV C/N Next Meas Frequency
 * Purpose:  This function switches from one frequency range to the next
 *           according to the defined measurement frequencies.
 *****************************************************************************/
ViStatus rsetl_CATVACNNextMeasFrequency(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "CN", RSETL_ATTR_CATV_ATV_FREQ_NEXT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV CSO Measurement
 * Purpose:  This function configures the Carrier to Second Order Beat
 *           Ratio measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACSOMeasurement(ViSession instrSession,
                                            ViInt32   measCarrier,
                                            ViInt32   measurementMethod)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CSO", RSETL_ATTR_CATV_ATV_CARR_MEAS, measCarrier),
            2, "Meas Carrier");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CSO", RSETL_ATTR_CATV_ATV_MEAS_MODE, measurementMethod),
            3, "Measurement Method");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV CSO Reference Power
 * Purpose:  This function configures the reference power for Carrier to
 *           Second Order Beat Ratio measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACSOReferencePower(ViSession instrSession,
                                               ViInt32   referencePower,
                                               ViInt32   referenceChannel,
                                               ViReal64  powerManual)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CSO", RSETL_ATTR_CATV_ATV_REF_POWER_MODE, referencePower),
            2, "Reference Power");
    switch (referencePower){
        case RSETL_VAL_ATV_RPOW_MODE_RCH:
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CSO", RSETL_ATTR_CATV_ATV_REF_CHANNEL_MANUAL, referenceChannel),
                    3, "Reference Channel");
        break;
        case RSETL_VAL_ATV_RPOW_MODE_MAN:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "CSO", RSETL_ATTR_CATV_ATV_REF_POWER_MANUAL, powerManual),
                    4, "Power Manual");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV CSO Measurement Frequencies
 * Purpose:  This function defines the measurement frequencies
 *           (center frequencies and span values), and activates or deactivates
 *           them for the CSO measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACSOMeasurementFrequencies(ViSession instrSession,
                                                       ViInt32   tableRow,
                                                       ViBoolean state,
                                                       ViReal64  centerFrequency,
                                                       ViReal64  span)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, tableRow, 1, 10),
            2, "Table Row");
    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, state), 3, "State");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":ATV:CSO:TABL%ld:MFR %d,%.12lf,%.12lf",
        tableRow, state == VI_FALSE ? 0 : 1, centerFrequency, span);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV CSO Noise Floor Correction
 * Purpose:  This function configures the noise floor correction
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACSONoiseFloorCorrection(ViSession instrSession,
                                                     ViBoolean noiseFloorCorrection,
                                                     ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = 0;

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "CSO", RSETL_ATTR_CATV_ATV_NOISE_FLOOR_CORRECTION, noiseFloorCorrection),
            5, "Noise Floor Correction");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Analog TV CSO Next Meas Frequency
 * Purpose:  This function switches from one frequency range to the next
 *           according to the defined measurement frequencies.
 *****************************************************************************/
ViStatus rsetl_CATVACSONextMeasFrequency(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "CSO", RSETL_ATTR_CATV_ATV_FREQ_NEXT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV CTB Measurement
 * Purpose:  This function configures the Carrier to Composite Triple Beat
 *           Ratio measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACTBMeasurement(ViSession instrSession,
                                            ViInt32   measCarrier)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CTB", RSETL_ATTR_CATV_ATV_CARR_MEAS, measCarrier),
            2, "Meas Carrier");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV CTB Reference Power
 * Purpose:  This function configures the reference power for Carrier to
 *           Composite Triple Beat Ratio measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACTBReferencePower(ViSession instrSession,
                                               ViInt32   referencePower,
                                               ViInt32   referenceChannel,
                                               ViReal64  powerManual)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CTB", RSETL_ATTR_CATV_ATV_REF_POWER_MODE, referencePower),
            2, "Reference Power");
    switch (referencePower){
        case RSETL_VAL_ATV_RPOW_MODE_RCH:
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "CTB", RSETL_ATTR_CATV_ATV_REF_CHANNEL_MANUAL, referenceChannel),
                    3, "Reference Channel");
        break;
        case RSETL_VAL_ATV_RPOW_MODE_MAN:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "CTB", RSETL_ATTR_CATV_ATV_REF_POWER_MANUAL, powerManual),
                    4, "Power Manual");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV CTB Measurement Frequencies
 * Purpose:  This function defines the measurement frequencies
 *           (center frequencies and span values), and activates or deactivates
 *           them for the CTB measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACTBMeasurementFrequencies(ViSession instrSession,
                                                       ViInt32   tableRow,
                                                       ViBoolean state,
                                                       ViReal64  centerFrequency,
                                                       ViReal64  span)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, tableRow, 1, 10),
            2, "Table Row");
    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, state), 3, "State");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":ATV:CTB:TABL%ld:MFR %d,%.12lf,%.12lf",
        tableRow, state == VI_FALSE ? 0 : 1, centerFrequency, span);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV CTB Noise Floor Correction
 * Purpose:  This function configures the noise floor correction
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACTBNoiseFloorCorrection(ViSession instrSession,
                                                     ViBoolean noiseFloorCorrection,
                                                     ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = 0;

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "CTB", RSETL_ATTR_CATV_ATV_NOISE_FLOOR_CORRECTION, noiseFloorCorrection),
            5, "Noise Floor Correction");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Analog TV CTB Next Meas Frequency
 * Purpose:  This function switches from one frequency range to the next
 *           according to the defined measurement frequencies.
 *****************************************************************************/
ViStatus rsetl_CATVACTBNextMeasFrequency(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "CTB", RSETL_ATTR_CATV_ATV_FREQ_NEXT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Carrier Limit
 * Purpose:  This function sets the limit of the carrier power measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACarrierLimit(ViSession instrSession,
                                          ViInt32   measurement,
                                          ViInt32   limitType,
                                          ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 5),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");
    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }

    switch (measurement){
        case RSETL_VAL_ATV_VCP:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_VCP, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_VCF:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_VCF, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_SC1PR:
            strcat (repCap, ",SC1");
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_SC1IF:
            strcat (repCap, ",SC1");
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_SC2PR:
            strcat (repCap, ",SC2");
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_SC2IF:
            strcat (repCap, ",SC2");
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET, limitValue),
                    4, "Limit Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Carrier Ratio Limit
 * Purpose:  This function sets the limit for the carrier-to-noise,
 *           carrier-to-second order beat or carrier-to-composite triple beat
 *           ratio.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVACarrierRatioLimit(ViSession instrSession,
                                               ViInt32   measurement,
                                               ViInt32   limitType,
                                               ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 2, 4),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");
    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }
    switch (measurement){
        case RSETL_VAL_ATV_MEAS_CN:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_CN, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_MEAS_CSO:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_CSO, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_MEAS_CTB:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_CTB, limitValue),
                    4, "Limit Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Hum Limit
 * Purpose:  This function sets the limit for the hum values
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAHumLimit(ViSession instrSession,
                                      ViInt32   limitType,
                                      ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            2, "Limit Type");
    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_HUM_UNIT, RSETL_VAL_UNIT_DB));
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATV_LIM_HUM_LOW, limitValue),
                    3, "Limit Value");
        break;
        case RSETL_VAL_LIM_UPP:
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_HUM_UNIT, RSETL_VAL_UNIT_PCT));
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATV_LIM_HUM_UPP, limitValue),
                    3, "Limit Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Vision Modulation Limit
 * Purpose:  This function sets the limit for the vision modulation.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAVisionModLimit(ViSession instrSession,
                                            ViInt32   limit,
                                            ViInt32   limitType,
                                            ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");
    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }
    switch (limit){
        case RSETL_VAL_ATV_VCP:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_VMOD_VCP, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_RPC:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_VMOD_RPC, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_MDEP:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_ATV_LFOF:
              viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_VMOD_LFOF, limitValue),
                      4, "Limit Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Analysis Measurement Limit
 * Purpose:  This function sets the limit for the vision modulation.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAAnalysisMeasurementLimit(ViSession instrSession,
                                                      ViInt32   measurement,
                                                      ViInt32   limitType,
                                                      ViInt32   minMax,
                                                      ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, RSETL_VAL_ATV_VME_LBAR, RSETL_VAL_ATV_VME_T42P),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, RSETL_VAL_LIM_LOW, RSETL_VAL_LIM_UPP),
            3, "Limit Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, minMax, RSETL_VAL_ATV_VALUE, RSETL_VAL_ATV_MAX),
            4, "Min Max");
    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low,%s", ATVAnalysisMeasValue[measurement]);
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp,%s", ATVAnalysisMeasValue[measurement]);
        break;
    }

    switch (minMax)
    {
        case RSETL_VAL_ATV_VALUE:
        {
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS, limitValue),
                    5, "Limit Value");
            break;
        }
        case RSETL_VAL_ATV_MIN:
        {
            strcat (repCap, ",Min");
            checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_MIN_MAX, NULL));
            break;
        }
        case RSETL_VAL_ATV_MAX:
        {
            strcat (repCap, ",Max");
            checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_MIN_MAX, NULL));
            break;
        }
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Vision Modulation Carrier Power Unit
 * Purpose:  This function defines the unit of the absolute vision carrier power.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAVisionModulationCarrierPowerUnit(
                            ViSession instrSession,
                            ViInt32   unit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_VCP_UNIT, unit),
            2, "Unit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Vision Modulation Unit
 * Purpose:  This function defines the unit of the Vision Modulation measurement
 *           values.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAVisionModulationUnit(ViSession instrSession,
                                                  ViInt32   unit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_VMOD_UNIT, unit),
            2, "Unit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Analog TV Hum Unit
 * Purpose:  This function defines the unit of the Hum measurement values.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVAHumUnit(ViSession instrSession,
                                     ViInt32   unit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_HUM_UNIT, unit),
            2, "Unit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Measurement Mode
 * Purpose:  This function switches to digital TV measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDMeasurementMode(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_MEAS_MODE, RSETL_VAL_CATV_MEAS_MODE_DTV),
            2, "Measurement Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

// Digital TV
/*****************************************************************************
 * Function: Configure Digital TV Measurement
 * Purpose:  This function defines the digital measurement type.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDMeasurement(ViSession instrSession,
                                         ViInt32   measurement)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS, measurement),
            2, "Measurement");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Modulation Standard
 * Purpose:  This function defines the modulation properties of a TV signal
 *           (as used in a TV channel). The signal type is the characteristic
 *           parameter of this set.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDModulStandard(ViSession instrSession,
                                           ViInt32   TVStandard,
                                           ViInt32   rollOff,
                                           ViInt32   constellationParameter,
                                           ViReal64  symbolRate)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_STANDARD, TVStandard),
            2, "TV Standard");

    if ((TVStandard != RSETL_VAL_DTV_STAN_TDMB) && (TVStandard != RSETL_VAL_DTV_STAN_ISDBT))
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_FORMAT, constellationParameter),
                4, "Constellation Parameter");
    }

    if ((TVStandard != RSETL_VAL_DTV_STAN_DVBT) && (TVStandard != RSETL_VAL_DTV_STAN_TDMB) && (TVStandard != RSETL_VAL_DTV_STAN_ISDBT) && (TVStandard != RSETL_VAL_DTV_STAN_DVBT2))
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_SRATE, symbolRate),
                5, "Symbol Rate");
    }

    if ((TVStandard != RSETL_VAL_DTV_STAN_DMBT) && (TVStandard != RSETL_VAL_DTV_STAN_DVBT) && (TVStandard != RSETL_VAL_DTV_STAN_TDMB) && (TVStandard != RSETL_VAL_DTV_STAN_ISDBT) && (TVStandard != RSETL_VAL_DTV_STAN_DVBT2))
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_FILTER_ALPHA, rollOff),
                3, "Roll Off");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Sets the T2 profile to be received.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR t2Profile/Sets the T2 profile to be received.
ViStatus rsetl_ConfigureDigitalTVT2Profile(ViSession instrSession,
                                           ViInt32   t2Profile)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_T2_PROFILE, t2Profile),
            2, "T2 Profile");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Shoulder Attenuation
 * Purpose:  This function configures the Shoulder Attenuation for Spectrum
 *           measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDShoulderAttenuation(ViSession instrSession,
                                                 ViBoolean shoulderAttenuation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_SATT, shoulderAttenuation),
            2, "Shoulder Attenuation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Selects the measurement guideline for the shoulder attenuation
/// HIFN  measurement in Spectrum measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR guideline/Selects the measurement guideline for the shoulder attenuation
/// HIPAR guideline/measurement in Spectrum measurement.
ViStatus rsetl_ConfigureDigitalTVShoulderMeasurementGuideline(
                            ViSession instrSession,
                            ViInt32   guideline)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_SATT_GUIDELINE, guideline),
            2, "guideline");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Out Of Band Emissions
 * Purpose:  This function configures the out-of-band emissions measurement
 *           in the Spectrum measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDOutOfBandEmissions(ViSession instrSession,
                                                ViBoolean outOfBandEmissions)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_STATE, outOfBandEmissions),
            2, "Out Of Band Emissions");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Out Of Band Emissions Setup T-DMB DAB
 * Purpose:  This function configures the out-of-band emissions setup in the
 *           Spectrum measurement for the T-DMB/DAB standard.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDOutOfBandEmissionsSetupTDMBDAB(ViSession instrSession,
                                                            ViInt32   transmitterPowerRange,
                                                            ViInt32   classification,
                                                            ViReal64  signalLevelOffset,
                                                            ViBoolean showPeaks)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER_RANGE, transmitterPowerRange),
            2, "Transmitter Power Range");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_MASK_TYPE, classification),
            3, "Classification");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_REFERENCE_LEVEL_OFFSET, signalLevelOffset),
            4, "Signal Level Offset");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_SHOW_PEAKS, showPeaks),
            5, "Show Peaks");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Out Of Band Emissions Setup ISDB-T
 * Purpose:  This function configures the out-of-band emissions setup in the
 *           Spectrum measurement for the ISDB-T standard.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDOutOfBandEmissionsSetupISDBT(ViSession instrSession,
                                                          ViInt32   country,
                                                          ViInt32   transmitterPowerRange,
                                                          ViReal64  transmitterPower,
                                                          ViInt32   maskType,
                                                          ViReal64  signalLevelOffset,
                                                          ViBoolean showPeaks)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_COUNTRY, country),
            2, "Country");

    if(country==RSETL_VAL_DTV_COUNTRY_JAPAN)
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER_RANGE, transmitterPowerRange),
                3, "Transmitter Power Range");

        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER, transmitterPower),
                4, "Transmitter Power");
    }
    else if(country==RSETL_VAL_DTV_COUNTRY_BRAZIL)
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_MASK_TYPE, maskType),
                5, "CATV Digital TV Out Of Band Emissions Mask Type");
    }

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_REFERENCE_LEVEL_OFFSET, signalLevelOffset),
            6, "Signal Level Offset");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_SHOW_PEAKS, showPeaks),
            7, "Show Peaks");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Out Of Band Emissions Setup Noise Floor
 *           Correction
 * Purpose:  This function configures the Noise Floor Correction in out-of-band
 *           emissions setup in the Spectrum measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDOutOfBandEmissionsSetupNoiseFloorCorrection(
                            ViSession instrSession,
                            ViBoolean noiseFloorCorrection,
                            ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = 0;

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_NOISE_FLOOR_CORRECTION, noiseFloorCorrection),
            2, "Noise Floor Correction");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Out Of Band Emissions Setup External Notch
 *           Filter
 * Purpose:  This function configures the External Notch Filter in out-of-band
 *           emissions setup in the Spectrum measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDOutOfBandEmissionsSetupExternalNotchFilter(
                            ViSession instrSession,
                            ViBoolean externalNotchFilter,
                            ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = 0;

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_EXTERNAL_NOTCH_FILTER, externalNotchFilter),
            2, "External Notch Filter");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV SFN Frequency Offset
 * Purpose:  This function configures the measurement of the frequency offset
 *           in the Echo Pattern measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDSFNFrequencyOffset(ViSession instrSession,
                                                ViBoolean SFNFrequencyOffset)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_FREQ_OFFSET, SFNFrequencyOffset),
            2, "SFN Frequency Offset");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Spectrum Margin List
 * Purpose:  This function displays the margin list under the spectrum. The
 *           spectrum is displayed vertically compressed.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDSpectrumMarginList(ViSession instrSession,
                                                ViBoolean marginList)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_SPECTRUM_MARGIN_LIST, marginList),
            2, "Margin List");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Channel Bandwidth
 * Purpose:  This function sets the channel bandwidth parameter for digital TV
 *           measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDChannelBandwidth(ViSession instrSession,
                                              ViInt32   TVStandard,
                                              ViReal64  channelBandwidth)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  ch_bwid = 0;

    checkErr(RsCore_LockSession(instrSession));

    switch (TVStandard)
    {
        case RSETL_VAL_DTV_STAN_DMBT:
        {
            //ch_bwid = (ViInt32)(channelBandwidth / 1.0e6) - 5;

            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_CHAN_BAND, channelBandwidth),
                    3, "Channel Bandwidth");
            break;
        }
        case RSETL_VAL_DTV_STAN_DVBT:
        {
            ch_bwid = (ViInt32)(channelBandwidth / 1.0e6) - 5;

            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_CHAN_BAND_DVBT, ch_bwid),
                    3, "Channel Bandwidth");
            break;
        }
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, TVStandard), 2, "TV Standard");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Reference Frequency
 * Purpose:  This function configures the reference frequency for the receiver.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDReferenceFrequency(ViSession instrSession,
                                                ViBoolean pilotCarrierFrequency)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_REFERENCE_FREQUENCY, pilotCarrierFrequency),
            2, "Pilot Carrier Frequency");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Overview Screen Select
 * Purpose:  This function configures the overview measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDOverviewScreenSelect(ViSession instrSession,
                                                  ViBoolean TMCC)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_OVERVIEW_SCREEN_SELECT, TMCC),
            2, "TMCC");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the frequency range of the MER-PhaseNoise measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR frequencyStart/Sets the start frequency.
/// HIPAR frequencyStop/Sets the stop frequency.
ViStatus rsetl_ConfigureCATVDMERStartStop(ViSession instrSession,
                                          ViReal64  frequencyStart,
                                          ViReal64  frequencyStop)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_FREQUENCY_START, frequencyStart),
            2, "Frequency Start");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_FREQUENCY_STOP, frequencyStop),
            3, "Frequency Stop");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the span and center frequnecy of the MER-PhaseNoise measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR centerFrequency/Sets the center frequency.
/// HIPAR frequencySpan/Sets the frequency span.
ViStatus rsetl_ConfigureCATVDMERCenterSpan(ViSession instrSession,
                                           ViReal64  centerFrequency,
                                           ViReal64  frequencySpan)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_FREQUENCY_CENTER, centerFrequency),
            2, "Center Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_FREQUENCY_SPAN, frequencySpan),
            3, "Frequency Span");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function configures the MER optimization for the step attenuation
/// HIFN  adjustment. It combines the function of the adjust attenuation feature
/// HIFN  with an additional search for the best MER, by searching the optimum
/// HIFN  attenuation value. It is only applicable for multichannel systems with
/// HIFN  J.83/A/B/C modulation.
/// HIFN
/// HIFN     Note(s):
/// HIFN
/// HIFN     (1) Available for: J83A/B/C
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR merOptimization/This control activates or deactivates the MER optimization for the
/// HIPAR merOptimization/step attenuation adjustment.
ViStatus rsetl_ConfigureCATVDMEROptimization(ViSession instrSession,
                                             ViBoolean merOptimization)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_MER_OPTIMIZATION, merOptimization),
            2, "MER Optimization");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Echo Pattern
 * Purpose:  This function configures the Echo Pattern measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEchoPattern(ViSession instrSession,
                                         ViBoolean zoomState,
                                         ViInt32   zoomFactor,
                                         ViReal64  velocityFactor,
                                         ViInt32   timeRangeMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_EPAT_ZOOM_STATE, zoomState),
            2, "Zoom State");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_EPAT_ZOOM_FACTOR, zoomFactor),
            3, "Zoom Factor");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_EPAT_RVEL, velocityFactor),
            4, "Velocity Factor");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TIME_RANGE_MODE, timeRangeMode),
            5, "Time Range Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Echo Pattern Measurement Sorting
 * Purpose:  This function defines the sorting of the Echo Pattern measurement
 *           results.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEchoPatternMeasurementSorting(ViSession instrSession,
                                                           ViBoolean sortByTime)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_EPAT_MEAS_SORT, sortByTime),
            2, "Sort By Time");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Echo Threshold Line
 * Purpose:  This function activates or deactivates the display of a
 *           horizontal line called "EchoDetectionThreshold" in the Echo
 *           Pattern measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEchoThresholdLine(ViSession instrSession,
                                               ViBoolean thresholdLine)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_THRESHOLD_LINE, thresholdLine),
            2, "Threshold Line");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the measurement of the frequency offset in the Echo Pattern measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR mode/This control selects SFN frequency offset threshold value is set automatically or manually.
/// HIPAR offsetThreshold/This control sets the SFN frequency offset threshold value in the SFN.
ViStatus rsetl_ConfigureCATVDEchoPatternOffsetThreshold(ViSession instrSession,
                                                        ViInt32   mode,
                                                        ViReal64  offsetThreshold)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, mode, 0, 3),
            2, "Scaling Mode");

    switch (mode){
        case RSETL_VAL_STATE_OFF:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "",
                    RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_STATE, mode != 0), 2, "Mode");
        break;
        case RSETL_VAL_STATE_ON:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "",
                    RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_STATE, mode != 0), 2, "Mode");

            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_TRESHOLD, offsetThreshold),
                    3, "Offset Threshold");
        break;
        case RSETL_VAL_STATE_AUTO:
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_MODE, mode),
                    2, "Mode");
        break;
        case RSETL_VAL_STATE_MAN:
             viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_MODE, mode),
                     2, "Mode");

             viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_TRESHOLD, offsetThreshold),
                     3, "Offset Threshold");
        break;
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function activates and deactivates the MER shortened equalizer in the Echo Pattern measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR state/This control sets state of the MER shortened equalizer.
ViStatus rsetl_ConfigureCATVDEchoPatternMERShortenedEQState(ViSession instrSession,
                                                            ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQUALIZER_STATE, state),
            2, "State");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the length of the hypothetical
/// HIFN equalizer�s DFE (FFE) part for the calculation of the MER ShortenedEQ.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR equalizer/Selects configured equalizer.
/// HIPAR length/Sets the equalizer length.
/// HIPAR units/Selects units for equalier length.
ViStatus rsetl_ConfigureCATVDEchoPatternMERShortenedEQLength(ViSession instrSession,
                                                             ViInt32   equalizer,
                                                             ViReal64  length,
                                                             ViInt32   units)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, equalizer, 0, 1),
            2, "Equalizer");

    switch (equalizer){
        case RSETL_VAL_EQ_DFE:
            switch (units){
                case RSETL_VAL_EQ_UNIT_TAPS:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_TAPS, length),
                            2, "Length");
                break;
                case RSETL_VAL_EQ_UNIT_SEC:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_SECONDS, length),
                            2, "Length");

                break;
            }
        break;
        case RSETL_VAL_EQ_FFE:
            switch (units){
                case RSETL_VAL_EQ_UNIT_TAPS:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_TAPS, length),
                            2, "Length");
                break;
                case RSETL_VAL_EQ_UNIT_SEC:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_SECONDS, length),
                            2, "Length");
                break;
            }
        break;
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the velocity factor.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR velocityFactor/Configures the velocity factor.
ViStatus rsetl_ConfigureCATVDEchoPatternVelocityFactor(ViSession instrSession,
                                                       ViReal64  velocityFactor)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_FREQ_VELOCITY_FACTOR, velocityFactor),
            2, "Velocity Factor");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Modul Error Zoom
 * Purpose:  This function configures the Modulation Errors Zoom.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDModulErrorZoom(ViSession instrSession,
                                            ViInt32   zoom)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_MERR_ZOOM, zoom),
            2, "Zoom");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Eye Diagram Time Span
 * Purpose:  This function scales the time axis. The time is set in symbols.
 *           To zoom into the "eyes", set a time span of smaller than 1
 *           symbol.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEyeDiagramTimeSpan(ViSession instrSession,
                                                ViInt32   timeSpan)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_EYE_DIAGRAM_TIME_SPAN, timeSpan),
            2, "Time Span");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Overview Zoom
 * Purpose:  This function configures the Overview Zoom.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDOverviewZoom(ViSession instrSession,
                                          ViInt32   zoom)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_OVER_ZOOM, zoom),
            2, "Zoom");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Constellation Diagram Zoom
 * Purpose:  This function configures the Constellatin Diagram Zoom.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDConstellationDiagramZoom(ViSession instrSession,
                                                      ViInt32   zoomDiagram)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_QUAD_ZOOM, zoomDiagram),
            2, "Zoom");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T Const Select
 * Purpose:  This function configures the display of the single hierarchical
 *           layers in the Constellation Diagram measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTConstSelect(ViSession instrSession,
                                              ViInt32   constSelect)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_CONST_SELECT, constSelect),
            2, "Const Select");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T Constellation Diagram Data Carriers
 * Purpose:  This function configures the data carriers in the Constellation
 *           Diagram measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTConstellationDiagramDataCarriers(
                            ViSession instrSession,
                            ViBoolean continualAndScatteredPilots,
                            ViBoolean TMCCCarriers,
                            ViBoolean AC1Carriers,
                            ViBoolean AC2Carriers)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_CONTINUAL_SCATTERED_PILOTS, continualAndScatteredPilots),
            2, "Constellation AND Scattered Pilots");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_TMCC, TMCCCarriers),
            3, "TMCC Carriers");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC1, AC1Carriers),
            4, "AC1 Carriers");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC2, AC2Carriers),
            5, "CATV Digital TV ISDB-T Constellation Diagram Data Carriers AC2");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T X-Axis Unit
 * Purpose:  This function configures the unit of the x-axis for the MER(f)
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTXAxisUnit(ViSession instrSession,
                                            ViInt32   xAxisUnit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_XAXIS_UNIT, xAxisUnit),
            2, "X-Axis Unit");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Equalizer
 * Purpose:  This function configures the digital TV equalizer.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEqualizer(ViSession instrSession,
                                       ViBoolean state,
                                       ViBoolean freeze)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_EQUALIZER_STATE, state),
            2, "State");
    if (state == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_EQUALIZER_FREEZE, freeze),
                3, "Freeze");
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Equalizer Learning Sweeps
 * Purpose:  This function defines the equalizer learning sweeps.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEqualizerLearningSweeps(ViSession instrSession,
                                                     ViInt32   learningSweeps)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_EQUALIZER_COUNT, learningSweeps),
            2, "Learning Sweeps");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Equalizer Step Size
 * Purpose:  This function defines the equalizer step size and step size
 *           shrinkage.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEqualizerStepSize(ViSession instrSession,
                                               ViInt32   stepSize,
                                               ViInt32   stepSizeShrinkage)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE, stepSize),
            2, "Step Size");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE_SHRINK, stepSizeShrinkage),
            3, "Step Size Shrinkage");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Equalizer NTSC Rejection Filter
 * Purpose:  This function configures the equalizer and NTSC rejection filter
 *           settings for ATSC standard.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEqualizerNTSCRejectionFilter(ViSession instrSession,
                                                          ViInt32   equalizerState,
                                                          ViBoolean NTSCRejectionFilter,
                                                          ViReal64  visionCarrierFrequency,
                                                          ViInt32   notchWidth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_EQUALIZER_MODE, equalizerState),
            2, "Equalizer State");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_NOTCH_FILTER, NTSCRejectionFilter),
            3, "NTSC Rejection Filter");

    if (NTSCRejectionFilter == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_NOTCH_FILTER_FREQ, visionCarrierFrequency),
                4, "Vision Carrier Frequency");

        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_NOTCH_FILTER_BWIDTH, notchWidth),
                5, "Notch Width");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Signal Statistics No Samples
 * Purpose:  This function sets the number of measurement points to be acquired
 *           for the statistical measurement functions.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDSignalStatisticsNoSamples(ViSession instrSession,
                                                   ViInt32   *noOfSamples)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_STAT_SAMPLES, noOfSamples),
            2, "No of Samples");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Signal Statistics Scaling
 * Purpose:  This function changes the scaling parameters for statistical
 *           measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDSignalStatisticsScaling(ViSession instrSession,
                                                     ViInt32   scalingMode,
                                                     ViReal64  scalingValue)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, scalingMode, 0, 6),
            2, "Scaling Mode");

    switch (scalingMode){
        case RSETL_VAL_STAT_DEFAULT:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_STAT_PRESET, NULL));
        break;
        case RSETL_VAL_STAT_ADJUST:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_STAT_ADJ, NULL));
        break;
        case RSETL_VAL_STAT_XRLEV:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_STAT_X_REF, scalingValue),
                    3, "Scaling Value");
        break;
        case RSETL_VAL_STAT_XRANGE:
             viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_STAT_X_RANGE, scalingValue),
                     3, "Scaling Value");
        break;
        case RSETL_VAL_STAT_YMAX:
             viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_STAT_Y_MAX, scalingValue),
                     3, "Scaling Value");
        break;
        case RSETL_VAL_STAT_YMIN:
             viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_STAT_Y_MIN, scalingValue),
                     3, "Scaling Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV CCDF Percent Marker
 * Purpose:  This function positions the selected marker in the selected window
 *           to the given probability.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDCCDFPercentMark(ViSession instrSession,
                                             ViInt32   markerNumber,
                                             ViReal64  positionValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, markerNumber, 1, 4),
            2, "Marker Number");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", markerNumber);
    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_PROBABILITY, positionValue),
            3, "Position Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Digital TV Reset Equalizer
 * Purpose:  This function resets the equalizer and all equalizer parameters
 *           are set to their default values.
 *****************************************************************************/
ViStatus rsetl_CATVDResetEqualizer(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_EQUALIZER_RESET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital CATV Min BER Integration Samples
 * Purpose:  This function defines the samples of the Min BER Integration.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDMinBERIntegrationSamples(ViSession instrSession,
                                                      ViInt32   samples)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MIN_BER_SAMPLES, samples),
            2, "Samples");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital CATV Display IQ Samples
 * Purpose:  This function defines the number of I/Q samples that are shown
 *           on display. In case that the Softkey "Hold" is pressed the
 *           display at the softkey "Symbol Count" changes to "Symbol Count:
 *           infinite". If the softkey "Symbol Count" is pressed in this
 *           "infinite" mode then Hold becomes deactivated and the value of
 *           symbol count can be edited. In case that the constellation is in
 *           "Freeze" mode and the softkey "Symbol Count" is pressed the
 *           constellation becomes unfreezed.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDDisplayIQSamples(ViSession instrSession,
                                              ViInt32   IQSamples)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DISP_IQ_SAMPLES, IQSamples),
            2, "IQ Samples");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV IQ Source
 * Purpose:  This function configures the I/Q source parameter for digital TV
 *           measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDIQSource(ViSession instrSession,
                                      ViInt32   IQSource)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_IQ_SOURCE, IQSource),
            2, "IQ Source");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Sets the I/Q source parameter for Constellation measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR carrierType/Sets the I/Q source parameter for Constellation measurement.
ViStatus rsetl_ConfigureDigitalTVIQCarrierType(ViSession instrSession,
                                               ViInt32   carrierType)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_IQ_CARRIER_TYPE, carrierType),
            2, "Carrier Type");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function defines the index of the first OFDM symbol within
/// HIFN a T2 frame to be displayed in the Constellation measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR startSymbolIndex/Sets index of the first OFDM symbol within a T2 frame.
ViStatus rsetl_ConfigureCATVDDisplayStartSymbol(ViSession instrSession,
                                                ViInt32   startSymbolIndex)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DISPLAY_START_SYMBOL, startSymbolIndex),
            2, "Start Symbol Index");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the number of T2 frames displayed in the Constellation measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR frameCount/Sets number of frames displayed.
ViStatus rsetl_ConfigureCATVDDisplayFrameCount(ViSession instrSession,
                                               ViInt32   frameCount)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DISPLAY_FRAME_COUNT, frameCount),
            2, "Frame Count");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the number of I/Q cells to be displayed in the Constellation measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR cellCount/Sets number of I/Q cells displayed.
ViStatus rsetl_ConfigureCATVDDisplayCellCount(ViSession instrSession,
                                              ViInt32   cellCount)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DISPLAY_CELL_COUNT, cellCount),
            2, "Cell Count");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Digital TV Reset BER
 * Purpose:  This function resets the BER calculation.
 *****************************************************************************/
ViStatus rsetl_CATVDResetBER(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_BER_RESET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Frequency Range
 * Purpose:  This function switches between two different measurement ranges for
 *           amplitude, phase and group delay measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDFrequencyRange(ViSession instrSession,
                                            ViBoolean frequencyRange)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_FREQ_RANGE, frequencyRange),
            2, "Frequency Range");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Digital TV FIC Retrieve Data Set
 * Purpose:  This function retrieves the set of measurement data on which basis
 *           the subchannel organization and ensemble information queries
 *           ([SENSe<1|2>:]DDEMod:FIC:...) are carried out. To update your
 *           data set, send this attribute again.
 *****************************************************************************/
ViStatus rsetl_CATVDFICRetrieveDataSet(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_FIC_RETRIEVE_DATA_SET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function activates or deactivates the C/N measurement and
/// HIFN set the measurement frequency (position of the window).
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR enable/This control activates or deactivates the C/N measurement.
/// HIPAR cNFrequency/This control defines the measurement frequency (position of the window).
/// HIPAR noiseBandwidth/This control defines the noise bandwidth.
ViStatus rsetl_ConfigureCATVDCNMeasurement(ViSession instrSession,
                                           ViBoolean enable,
                                           ViReal64  cNFrequency,
                                           ViReal64  noiseBandwidth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_CN_MEAS_STATE, enable),
            2, "Enable");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_CN_MEAS_FREQUENCY, cNFrequency),
            3, "C/N Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_CN_MEAS_NOISE_BANDWIDTH, noiseBandwidth),
            4, "Noise Bandwidth");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV T-DMB DAB Subchannel Settings
 * Purpose:  This function configures the subchannel settings for T-DMB DAB.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDTDMBDABSubchannelSettings(ViSession instrSession,
                                                       ViInt32   subchannel,
                                                       ViBoolean autoSubchannelOrganization,
                                                       ViInt32   protectionLevel,
                                                       ViInt32   startCU,
                                                       ViInt32   dataRate,
                                                       ViBoolean subchannelContainsMPEGTS)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_FIC_SUBCH_SELECT, subchannel),
            2, "Subchannel");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_AUTO_SUBCH_ORG, autoSubchannelOrganization),
            3, "Auto Subchannel Organization");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_SUBCH_PROTECTION_LEVEL, protectionLevel),
            4, "Protection Level");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_SUBCH_FIRST_CUNIT, startCU),
            5, "Start CU");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_SUBCH_DATA_RATE, dataRate),
            6, "Data Rate");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_SUBCH_USE_MPEG, subchannelContainsMPEGTS),
            7, "Subchannel Contains MPEG-TS");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV T-DMB DAB Synchronization Settings
 * Purpose:  This function defines if the FIC and MPEG sync is required or not.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDTDMBDABSynchronizationSettings(ViSession instrSession,
                                                            ViInt32   FICSync,
                                                            ViInt32   MPEGSync)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_FIC_SYNC_REQUIRED, FICSync),
            2, "FIC Sync");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MPEG_SYNC_REQUIRED, MPEGSync),
            3, "MPEG Sync");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV T-DMB DAB Number Of Subchannels
 * Purpose:  This function queries the number of subchannels within the
 *           T-DMB/DAB signal.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDTDMBDABNumberOfSubchannels(ViSession instrSession,
                                                    ViInt32   * noOfSubchannels)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_FIC_SUBCH_NUMBER, noOfSubchannels),
            2, "No Of Subchannels");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV T-DMB DAB Subchannel Organization
 * Purpose:  This function outputs the Subchannel Organization results. Every
 *           subchannel forms one data set
 *****************************************************************************/
ViStatus rsetl_QueryCATVDTDMBDABSubchannelOrganization(ViSession instrSession,
                                                       ViInt32   dataSetsToQuery,
                                                       ViInt32*  actualNumberOfDataSets,
                                                       ViInt32   subchannelIndex[],
                                                       ViInt32   dataRate[],
                                                       ViInt32   startCU[],
                                                       ViInt32   sizeCU[],
                                                       ViChar    protectionLevel[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   *response = NULL;
    ViInt32  i = 0;
    ViChar   *p2buf;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, dataSetsToQuery, 1), 2, "Data Sets To Query");

    checkErr(RsCore_QueryViStringUnknownLength(instrSession, "SENS:DDEM:FIC:SUBC:LIST?", &response));

    p2buf = strtok(response, ",");
    while(p2buf && (dataSetsToQuery > i))
    {
        subchannelIndex[i] = RsCore_Convert_String_To_ViInt32(p2buf);
        p2buf = strtok(NULL, ",");

        dataRate[i] = RsCore_Convert_String_To_ViInt32(p2buf);
        p2buf = strtok(NULL, ",");

        startCU[i] = RsCore_Convert_String_To_ViInt32(p2buf);
        p2buf = strtok(NULL, ",");

        sizeCU[i] = RsCore_Convert_String_To_ViInt32(p2buf);
        p2buf = strtok(NULL, ",");

        if (i != 0)
            strcat (protectionLevel, ",");
        strcat (protectionLevel, p2buf);
        p2buf = strtok(NULL, ",");
        i++;
    };

    if (actualNumberOfDataSets)
        *actualNumberOfDataSets = i;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (response)
        free(response);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV T-DMB DAB Number Of Services
 * Purpose:  This function queries the number of services within the T-DMB/DAB
 *           signal.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDTDMBDABNumberOfServices(ViSession instrSession,
                                                 ViInt32   * noOfServices)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_NUMBER, noOfServices),
            2, "No Of Services");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV T-DMB DAB Ensemble Information Services
 * Purpose:  This function outputs the services results, part of the Ensemble
 *           Information results.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDTDMBDABEnsembleInformationServices(ViSession instrSession,
                                                            ViInt32   servicesToQuery,
                                                            ViInt32   * actualNumberOfServices,
                                                            ViChar    services[])
{
    ViStatus error = VI_SUCCESS;
    ViChar*  response = NULL;
    ViChar*  p2buf;
    ViInt32  i = 0;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, servicesToQuery, 1), 2, "Services To Query");

    checkErr(RsCore_QueryViStringUnknownLength(instrSession, "SENS:DDEM:FIC:SERV:LIST?", &response));

    p2buf = strtok(response, ",");
    while(p2buf && (servicesToQuery > i))
    {
        if (i != 0)
            strcat (services, ",");
        strcat (services, p2buf);
        p2buf = strtok(NULL, ",");
        i++;
    };

    if (actualNumberOfServices)
        *actualNumberOfServices = i;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (response)
        free(response);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV T-DMB DAB Number Of Service Components
 * Purpose:  This function queries the number of service components within the
 *           T-DMB/DAB signal.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDTDMBDABNumberOfServiceComponents(ViSession instrSession,
                                                          ViInt32   subchannel,
                                                          ViInt32   *noOfServiceComponents)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "SCH%ld", subchannel);
    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_COMP_NUMBER, noOfServiceComponents),
            2, "No Of Service Components");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV T-DMB DAB Ensemble Information Service Components
 * Purpose:  This function outputs the service component results, part of the
 *           Ensemble Information results.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDTDMBDABEnsembleInformationServiceComponents(
                            ViSession instrSession,
                            ViInt32   subchannel,
                            ViInt32   serviceComponentsToQuery,
                            ViInt32*  actualNumberOfServComponent,
                            ViChar    serviceComponentIndex[],
                            ViInt32   transportMechanism[],
                            ViInt32   subchannelIndex[],
                            ViInt32   dataRate[],
                            ViChar    protectionLevel[],
                            ViInt32   startCU[],
                            ViInt32   sizeCU[],
                            ViInt32   conditionalAccess[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];
    ViChar*  response = NULL;
    ViChar*  p2buf;
    ViInt32  i = 0;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, subchannel, 1, 64),
            2, "Subchannel");
    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, serviceComponentsToQuery, 1), 3, "Service Components To Query");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "SENS:DDEM:FIC:SCOM%ld:LIST?", subchannel);
    checkErr(RsCore_QueryViStringUnknownLength(instrSession, cmd, &response));

    p2buf = strtok(response, ",");

    while(p2buf && (serviceComponentsToQuery > i))
    {
        if (i != 0)
            strcat (serviceComponentIndex, ",");
        strcat (serviceComponentIndex, p2buf);
        p2buf = strtok (NULL, ",");

        transportMechanism[i] = RsCore_Convert_String_To_ViInt32(p2buf);
        p2buf = strtok(NULL, ",");

        subchannelIndex[i] = RsCore_Convert_String_To_ViInt32(p2buf);
        p2buf = strtok(NULL, ",");

        dataRate[i] = RsCore_Convert_String_To_ViInt32(p2buf);
        p2buf = strtok(NULL, ",");

        if (p2buf != NULL)
        {
            if (i != 0)
                strcat (protectionLevel, ",");
            strcat (protectionLevel, p2buf);
            p2buf = strtok(NULL, ",");

            startCU[i] = RsCore_Convert_String_To_ViInt32(p2buf);
            p2buf = strtok(NULL, ",");

            sizeCU[i] = RsCore_Convert_String_To_ViInt32(p2buf);
            p2buf = strtok(NULL, ",");

            conditionalAccess[i] = RsCore_Convert_String_To_ViInt32(p2buf);
            p2buf = strtok(NULL, ",");
        }

        i++;
    };

    if (actualNumberOfServComponent)
        *actualNumberOfServComponent = i;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (response)
        free(response);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Measurement Log
 * Purpose:  This function configures the measurement log settings.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDMeasurementLog(ViSession instrSession,
                                            ViInt32   trace,
                                            ViBoolean measLogState,
                                            ViInt32   measLogParameter)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_STATE, measLogState),
            3, "Meas Log State");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "MTR%ld", trace);
    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_MEAS_LOG_DISP_PARAM, measLogParameter),
            4, "Meas Log Parameter");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Measurement Log Span
 * Purpose:  This function configures the measurement log span.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDMeasurementLogSpan(ViSession instrSession,
                                                ViInt32   span,
                                                ViInt32   manualSpan)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, span, RSETL_VAL_DTV_MLOG_SPAN_AUTO, RSETL_VAL_DTV_MLOG_SPAN_MAN),
            2, "Span");

    if (span == RSETL_VAL_DTV_MLOG_SPAN_MAN)
    {
        checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_AUTO, VI_FALSE));

        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_MAN, manualSpan),
                3, "Manual Span");
    }
    else
    {
        checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_AUTO, VI_TRUE));
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the external USB GPS device.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR COMPort/Sets the virtual serial port number of the GPS unit.
/// HIPAR enableGPS/Actives a connected external USB GPS device.
ViStatus rsetl_ConfigureCATVDMeasurementLogGPS(ViSession instrSession,
                                               ViInt32   COMPort,
                                               ViBoolean enableGPS)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_PORT, COMPort),
            2, "COM Port");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_STATE, enableGPS),
            3, "enableGPS");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Digital TV Reset Measurement Log
 * Purpose:  This function clears and resets the Measurement Log calculation.
 *****************************************************************************/
ViStatus rsetl_CATVDResetMeasurementLog(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_MLOG_RESET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries if the R&S ETL is currently connected to the GPS receiver.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR state/Returns connection state.
ViStatus rsetl_QueryCATVDGPSReceiverState(ViSession instrSession,
                                          ViInt32   *state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_CONNECTION_STATE, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the parameters related to quality of received GPS signal.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR HDOP/Returns HDOP (horizontal dilution of precision).
/// HIPAR satellites/Returns the number of currently received satellites.
/// HIPAR valid/Returns the validity of the position information.
ViStatus rsetl_QueryCATVDGPSSignalQuality(ViSession instrSession,
                                          ViReal64  *HDOP,
                                          ViInt32   *satellites,
                                          ViBoolean *valid)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_HDOP, HDOP),
            2, "HDOP");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_SATELLITES, satellites),
            3, "Satellites");

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_VALID_INFO, valid),
            4, "Valid");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the current R&S ETL position.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR longitude/Returns longitude of current position.
/// HIPAR latitude/Returns latitude of current position.
/// HIPAR altitude/Returns altitude of current position in meters.
ViStatus rsetl_QueryCATVDGPSPosition(ViSession instrSession,
                                     ViReal64  *longitude,
                                     ViReal64  *latitude,
                                     ViReal64  *altitude)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LONGITUDE, longitude),
            2, "Longitude");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LATITUDE, latitude),
            3, "Latitude");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_ALTITUDE, altitude),
            4, "Altitude");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Queries the status of GPS device.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR status/Queries the status of GPS device.
ViStatus rsetl_QueryDigitalTVMeasLogGPSStatus(ViSession instrSession,
                                              ViInt32*  status)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_STATUS, status),
            2, "Status");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN   Selects the USB GPS receiver. Before selecting the GPS receiver,
/// HIFN  ensure that the GPS receiver is connected to the R&S ETL using USB.
/// HIFN  Third party NMEA GPS receivers require proper device driver
/// HIFN  installation beforehand.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR device/Selects the USB GPS receiver. Before selecting the GPS receiver,
/// HIPAR device/ensure that the GPS receiver is connected to the R&S ETL using USB.
/// HIPAR device/Third party NMEA GPS receivers require proper device driver
/// HIPAR device/installation beforehand.
ViStatus rsetl_ConfigureDigitalTVMeasLogGPSDevice(ViSession instrSession,
                                                  ViInt32   device)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_DEVICE, device),
            2, "device");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Configures GPS TSMX.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR enabled/Activates or deactivates the automatic configuration for using the R&S
/// HIPAR enabled/TSMX-PPS GPS receiver. Note that the R&S TSMX-PPS GPS receiver only
/// HIPAR enabled/works if it is connected to the R&S ETL by USB and its device drivers
/// HIPAR enabled/have been installed.
/// HIPAR deadReckoning/Requires the Measurement Log option, R&S ETL-K208. For the R&S
/// HIPAR deadReckoning/TSMX-PPS2 GPS receiver, this control switches the dead reckoning
/// HIPAR deadReckoning/feature on or off.
/// HIPAR pinDirection/Requires the Measurement Log option, R&S ETL-K208. For the dead
/// HIPAR pinDirection/reckoning feature of the R&S TSMX-PPS2 GPS receiver, this command
/// HIPAR pinDirection/determines how the direction pin input is evaluated.
ViStatus rsetl_ConfigureDigitalTVMeasLogGPSTSMX(ViSession instrSession,
                                                ViBoolean enabled,
                                                ViBoolean deadReckoning,
                                                ViInt32   pinDirection)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_ENABLED, enabled),
            2, "Enabled");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_DEAD_RECKONING, deadReckoning),
            3, "Dead Reckoning");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_PIN_DIRECTION, pinDirection),
            4, "Pin Direction");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  For the dead reckoning feature of the R&S TSMX-PPS2 GPS receiver, this
/// HIFN  command queries the state of the internal gyroscope.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR status/For the dead reckoning feature of the R&S TSMX-PPS2 GPS receiver, this
/// HIPAR status/command queries the state of the internal gyroscope.
ViStatus rsetl_QueryDigitalTVMeasLogGPSTSMXGyroscopeStatus(ViSession instrSession,
                                                           ViInt32*  status)
{
     ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_STATUS, status),
            2, "Status");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  For the dead reckoning feature of the R&S TSMX-PPS2 GPS receiver, this
/// HIFN  command queries the state of the speed pulse detection.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR status/For the dead reckoning feature of the R&S TSMX-PPS2 GPS receiver, this
/// HIPAR status/command queries the state of the speed pulse detection.
ViStatus rsetl_QueryDigitalTVMeasLogGPSTSMXSpeedPulseStatus(ViSession instrSession,
                                                            ViInt32*  status)
{
     ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_STATUS, status),
            2, "Status");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN   For the dead reckoning feature of the R&S TSMX-PPS2 GPS receiver,
/// HIFN  this command queries the state of the internal gyroscope calibration.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR status/For the dead reckoning feature of the R&S TSMX-PPS2 GPS receiver, this
/// HIPAR status/command queries the state of the internal gyroscope calibration.
ViStatus rsetl_QueryDigitalTVMeasLogGPSTSMXGyroscopeCalibrationStatus(
                            ViSession instrSession,
                            ViInt32*  status)
{
     ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_CALIBRATION_STATUS, status),
            2, "Status");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  For the dead reckoning feature of the R&S TSMX-PPS2 GPS receiver, this
/// HIFN  command queries the state of the speed pulse calibration.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR status/For the dead reckoning feature of the R&S TSMX-PPS2 GPS receiver, this
/// HIPAR status/command queries the state of the speed pulse calibration.
ViStatus rsetl_QueryDigitalTVMeasLogGPSTSMXSpeedPulseCalibrationStatus(
                            ViSession instrSession,
                            ViInt32*  status)
{
     ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_CALIBRATION_STATUS, status),
            2, "Status");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Auto Detection
 * Purpose:  This function sets the auto detection.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDAutoDetection(ViSession instrSession,
                                           ViBoolean autoDetection)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_AUTO_DETECTION, autoDetection),
            2, "Auto Detection");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Transmission Mode
 * Purpose:  This function selects the transmission mode, if it is not determined
 *           automatically.
 *
 *           Note(s):
 *
 *           (1) This function is only available if
 *           ConfigureCATVDAutoDetection is set to Off (attribute
 *           RSETL_ATTR_CATV_DTV_AUTO_DETECTION).
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDTransmissionMode(ViSession instrSession,
                                              ViInt32   transmissionMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TRANS_MODE, transmissionMode),
            2, "Transmission Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Carrier Start Stop
 * Purpose:  This function defines the carrier start and stop.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDCarrierStartStop(ViSession instrSession,
                                              ViReal64  carrierStart,
                                              ViReal64  carrierStop)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_CARRIER_START, carrierStart),
            2, "Carrier Start");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_CARRIER_STOP, carrierStop),
            3, "Carrier Stop");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Carrier Center Span
 * Purpose:  This function defines the carrier center and span.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDCarrierCenterSpan(ViSession instrSession,
                                               ViReal64  carrierCenter,
                                               ViReal64  carrierSpan)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_CARRIER_CENTER, carrierCenter),
            2, "Carrier Center");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_CARRIER_SPAN, carrierSpan),
            3, "Carrier Span");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function defines whether data carriers shall be displayed
/// HIFN in OFDM Symbols before Freq Deinterleaving Constellation measurement.
/// HIRET Returns the status code of this operation.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR dataCarriers/Sets display state of data carriers.
/// HIPAR TRCarriers/Sets the display state tone reservation carriers is displayed in
/// HIPAR TRCarriers/the Constellation measurement.
ViStatus rsetl_ConfigureCATVDDisplayCarrier(ViSession instrSession,
                                            ViBoolean dataCarriers,
                                            ViBoolean TRCarriers)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_CARRIER_DATA_STATE, dataCarriers),
            2, "data Carriers");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_CARRIER_TR_STATE, TRCarriers),
            3, "TR Carriers");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Carrier
 * Purpose:  This function defines the modulation carrier and carrier loops.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDCarrier(ViSession instrSession,
                                     ViInt32   carrierModulation,
                                     ViInt32   carrierLoops)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_CARRIER_MODULATION, carrierModulation),
            2, "Carrier Modulation");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_CARRIER_LOOPS, carrierLoops),
            3, "Carrier Loops");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Code Rate
 * Purpose:  This function defines the code rate, high and low priority.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDCodeRate(ViSession instrSession,
                                      ViInt32   codeRateSelect,
                                      ViInt32   codeRate)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  code_rate[8] = {RSETL_VAL_DTV_CODE_RATE_R04,
             RSETL_VAL_DTV_CODE_RATE_R06,
             RSETL_VAL_DTV_CODE_RATE_R08,
             RSETL_VAL_DTV_CODE_RATE_PRIOR_R1_2,
             RSETL_VAL_DTV_CODE_RATE_PRIOR_R2_3,
             RSETL_VAL_DTV_CODE_RATE_PRIOR_R3_4,
             RSETL_VAL_DTV_CODE_RATE_PRIOR_R5_6,
             RSETL_VAL_DTV_CODE_RATE_PRIOR_R7_8};

    checkErr(RsCore_LockSession(instrSession));

    switch (codeRateSelect)
    {
        case  RSETL_VAL_CRATE:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, codeRate, RSETL_VAL_DTV_FUNC_CODE_RATE_R04, RSETL_VAL_DTV_FUNC_CODE_RATE_R08),
                    3, "Code Rate");

            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_CODE_RATE, code_rate[codeRate]),
                    3, "Code Rate");
            break;

        case RSETL_VAL_CRATE_HIGH:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, codeRate, RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R1_2, RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R7_8),
                    3, "Code Rate");

            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_CODE_RATE_HIGH_PRIOR, code_rate[codeRate]),
                    3, "Code Rate");
            break;

        case RSETL_VAL_CRATE_LOW:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, codeRate, RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R1_2, RSETL_VAL_DTV_FUNC_CODE_RATE_PRIOR_R7_8),
                    3, "Code Rate");

            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_CODE_RATE_LOW_PRIOR, code_rate[codeRate]),
                    3, "Code Rate");
            break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, codeRateSelect), 2, "Code Rate Select");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV FEC Sync Required
 * Purpose:  This function defines if the FEC sync is required or not.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDFECSyncRequired(ViSession instrSession,
                                             ViInt32   FECSync)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_FEC_SYNC_REQUIRED, FECSync),
            2, "FEC Sync");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Coding
 * Purpose:  This function defines the digital TV coding.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDCoding(ViSession instrSession,
                                    ViInt32   FFTMode,
                                    ViInt32   guardInterval)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_FFT_MODE, FFTMode),
            2, "FFT Mode");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_GUARD_INTERVAL, guardInterval),
            3, "Guard Interval");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Guard Interval PN
 * Purpose:  This function defines the initial condition of the PN sequences
 *           for the receiver.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDGuardIntervalPN(ViSession instrSession,
                                             ViInt32   guardIntervalPN)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_GUARD_INTERVAL_PN, guardIntervalPN),
            2, "Guard Interval PN");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Interleaver
 * Purpose:  This function defines the interleaver.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDInterleaver(ViSession instrSession,
                                         ViInt32   interleaver)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_INTERLEAVER, interleaver),
            2, "Interleaver");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV LDPC Mode
 * Purpose:  This function defines the LDPC mode.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDLDPCMode(ViSession instrSession,
                                      ViInt32   LDPCMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LDPC_MODE, LDPCMode),
            2, "LDPC Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Symbol Loops
 * Purpose:  This function defines the symbol loop.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDSymbolLoops(ViSession instrSession,
                                         ViInt32   symbolLoops)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_SYMBOL_LOOPS, symbolLoops),
            2, "Symbol Loops");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV AGC Loops
 * Purpose:  This function defines the loop AGC.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDAGCLoops(ViSession instrSession,
                                      ViInt32   AGCLoops)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_AGC_LOOPS, AGCLoops),
            2, "AGC Loops");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV System Optimation
 * Purpose:  This function defines the system optimation.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDSystemOptimation(ViSession instrSession,
                                              ViInt32   systemOptimationTo)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_SYSTEM_OPTIMATION, systemOptimationTo),
            2, "System Optimation To");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Time Deinterleaver
 * Purpose:  This function defines the time deinterleaver.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDTimeDeinterleaver(ViSession instrSession,
                                               ViInt32   timeDeinterleaver)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TIME_DEINTERLEAVER, timeDeinterleaver),
            2, "Time Deinterleaver");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV MPEG TS Output
 * Purpose:  This function defines the MPEG TS output.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDMPEGTSOutput(ViSession instrSession,
                                          ViInt32   MPEGTSOutput)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MPEG_TS_OUTPUT, MPEGTSOutput),
            2, "MPEG TS Output");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Display TMCC Next Values
 * Purpose:  This function shows or hides the "TMCC next" information
 *           transmitted in the TMCC (transmission and multiplexing
 *           configuration control) carriers of the overview measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDDisplayTMCCNextValues(ViSession instrSession,
                                                   ViBoolean displayTMCCNextValues)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_DISPLAY_TMCC_NEXT_VALUES, displayTMCCNextValues),
            2, "Display TMCC Next Values");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T Code Rate
 * Purpose:  This function defines the code rate of the data stream in
 *           hierarchical layer A, B or C.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTCodeRate(ViSession instrSession,
                                           ViInt32   hierarchicalLayer,
                                           ViInt32   codeRate)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            2, "Hierarchical Layer");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", hierarchicalLayerArr[hierarchicalLayer]);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_CODE_RATE, codeRate),
            3, "Code Rate");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T Time Deinterleaver
 * Purpose:  This function defines the time interleaving length for
 *           hierarchical layer A, B, C.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTTimeDeinterleaver(ViSession instrSession,
                                                    ViInt32   hierarchicalLayer,
                                                    ViInt32   timeDeinterleaver)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            2, "Hierarchical Layer");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", hierarchicalLayerArr[hierarchicalLayer]);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_TIME_DEINTERLEAVER, timeDeinterleaver),
            3, "Time Deinterleaver");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T Segments
 * Purpose:  This function defines the number of segments covered by
 *           hierarchical layer A or B.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTSegments(ViSession instrSession,
                                           ViInt32   hierarchicalLayer,
                                           ViInt32   segments)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_B),
            2, "Hierarchical Layer");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", hierarchicalLayerArr[hierarchicalLayer]);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_SEGMENTS, segments),
            3, "Segments");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Segments
 * Purpose:  This function returns the number of segments covered by
 *           hierarchical layer A, B or C.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTSegments(ViSession instrSession,
                                       ViInt32   hierarchicalLayer,
                                       ViInt32   *segments)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            2, "Hierarchical Layer");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", hierarchicalLayerArr[hierarchicalLayer]);

    if(hierarchicalLayer==RSETL_VAL_DTV_LAYER_C)
    {
        viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_ISDBT_SEGMENT_C, segments),
                3, "Segment");  }
    else
    {
        viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_SEGMENTS, segments),
                3, "Segments");
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T Modulation
 * Purpose:  This function defines the modulation type of the data carriers
 *           within the corresponding hierarchical layer A, B or C.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTModulation(ViSession instrSession,
                                             ViInt32   hierarchicalLayer,
                                             ViInt32   modulation)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            2, "Hierarchical Layer");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", hierarchicalLayerArr[hierarchicalLayer]);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_MODULATION, modulation),
            3, "Modulation");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the detection of data according to ID.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR standard/Select configured data ID.
/// HIPAR autoDetection/Switches between automatic detection of a ID and manual setting of the decoded ID.
/// HIPAR ID/Sets the ID to be decoded.
ViStatus rsetl_ConfigureCATVDDataID(ViSession instrSession,
                                    ViInt32   standard,
                                    ViInt32   autoDetection,
                                    ViInt32   ID)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, standard, 0, 1),
            2, "Standard");

    switch (standard){
        case RSETL_VAL_DTV_PLP_ID:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "PLP");
        break;
        case RSETL_VAL_DTV_PARADE_ID:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Parade");
        break;
    }
    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_DATA_ID_MODE, autoDetection),
            3, "Auto Detection");

    if (autoDetection == RSETL_VAL_DTV_MANUAL){
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_DATA_ID_MAN, ID),
                4, "ID");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the automatically selected ID for decoding.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR standard/Selects Standard.
/// HIPAR ID/Returns ID.
ViStatus rsetl_QueryCATVDDataID(ViSession instrSession,
                                ViInt32   standard,
                                ViInt32   *ID)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, standard, 0, 1),
            3, "Standard");

    switch (standard){
        case RSETL_VAL_DTV_PLP_ID:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "PLP");
        break;
        case RSETL_VAL_DTV_PARADE_ID:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Parade");
        break;
    }

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_QUERY_CATV_DTV_DATA_ID, ID),
            3, "ID");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T Partial Reception
 * Purpose:  This function configures the reception of the ISDB-T signal by a
 *           one-segment receiver.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTPartialReception(ViSession instrSession,
                                                   ViBoolean partialReception)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_PARTIAL_RECEPTION, partialReception),
            2, "Partial Reception");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T FFT Window
 * Purpose:  This function configures the FFT window special settings of the
 *           ISDB-T TV standard.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTFFTWindow(ViSession instrSession,
                                            ViInt32   FFTWindowPosition,
                                            ViInt32   FFTWindowOffset)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_POSITION, FFTWindowPosition),
            2, "FFT Window Position");

    if( FFTWindowPosition == RSETL_VAL_DTV_WPOS_MAN)
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_OFFSET, FFTWindowOffset),
                3, "FFT Window Offset");
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Configures DTMB Special Settings.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR siPowerNormalization/Sets the reference (system information carriers, ideal constellation
/// HIPAR siPowerNormalization/points) for Constellation and MER measurements.
/// HIPAR fhPowerBoost/Sets the reference (frame header, ideal points of constellation) for
/// HIPAR fhPowerBoost/Constellation and MER measurement.
/// HIPAR fhPowerReference/Sets the power reference for the frame header power boost.
/// HIPAR esrTimebase/Sets the timebase for the errored seconds ratio measurement.
/// HIPAR berIndication/Selects the displayed BER type measurement in the status bar.
ViStatus rsetl_ConfigureDigitalTVDTMB(ViSession instrSession,
                                      ViInt32   siPowerNormalization,
                                      ViInt32   fhPowerBoost,
                                      ViInt32   fhPowerReference,
                                      ViInt32   esrTimebase,
                                      ViInt32   berIndication)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DTMB_SI_POWER_NORMALIZATION, siPowerNormalization),
            2, "SI Power Normalization");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_BOOST, fhPowerBoost),
            3, "FH Power Boost");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_REFERENCE, fhPowerReference),
            4, "FH Power Reference");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DTMB_ESR_TIMEBASE, esrTimebase),
            5, "ESR Timebase");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DTMB_BER_INDICATION, berIndication),
            6, "BER Indication");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Sets the input stream synchronization (ISSY).
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR issyProcessing/Sets the input stream synchronization (ISSY).
ViStatus rsetl_ConfigureDigitalTVDVBISSYProcessing(ViSession instrSession,
                                                   ViInt32   issyProcessing)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_DVB_ISSY_PROCESSING, issyProcessing),
            2, "ISSY Processing");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures DVB-T2 transmission system.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR transmissionSystem/Selects the DVB-T2 transmission system.
/// HIPAR pilotPattern/Selects the pilot pattern.
/// HIPAR PAPR/Sets whether tone reservation carriers are used in the data
/// HIPAR PAPR/symbols in order to reduce the peak to average power ratio.
/// HIPAR dataSymbols/Sets the the number of data symbols covered by one DVB-T2 frame.
/// HIPAR l1PostConstellarion/This control sets the constellation parameter.
ViStatus rsetl_ConfigureCATVDDVBT2FrameParameters(ViSession instrSession,
                                                  ViInt32   transmissionSystem,
                                                  ViInt32   pilotPattern,
                                                  ViBoolean PAPR,
                                                  ViInt32   dataSymbols,
                                                  ViInt32   l1PostConstellarion)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_TRANSMISSION_SYSTEM, transmissionSystem),
            2, "Transmission System");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PILOT_PATTERN, pilotPattern),
            3, "Pilot Pattern");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PAPR, PAPR),
            4, "PAPR");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_DATA_SYMBOLS, dataSymbols),
            5, "Data Symbols");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_FORMAT, l1PostConstellarion),
            6, "L-1 Post Constellarion");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the physical layer pipe (PLP).
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR payloadType/Selects the payload type carried by the decoded PLP.
/// HIPAR codeRate/Selects the code rate.
/// HIPAR modulation/Selects the constellation parameter.
/// HIPAR rotation/Sets whether constellation rotation is used.
/// HIPAR FECType/Selects the EFC type.
/// HIPAR numBlockMax/Sets the FEC blocks within one interleaving frame.
/// HIPAR TIBlocksInterleavingFrame/Sets the number of time interleaving blocks per interleaving frame.
ViStatus rsetl_ConfigureCATVDDVBT2PLP(ViSession instrSession,
                                      ViInt32   payloadType,
                                      ViInt32   codeRate,
                                      ViInt32   modulation,
                                      ViBoolean rotation,
                                      ViInt32   FECType,
                                      ViInt32   numBlockMax,
                                      ViInt32   TIBlocksInterleavingFrame)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_PAYLOAD_TYPE, payloadType),
            2, "Ppayload Type");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_CODE_RATE, codeRate),
            3, "Code Rate");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MODULATION, modulation),
            4, "Modulation");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_ROTATION, rotation),
            5, "Rotation");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_FEC_TYPE, FECType),
            6, "FEC Type");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MAX_BLOCKS, numBlockMax),
            7, "Num Block Max");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_TI_BLOCKS, TIBlocksInterleavingFrame),
            8, "TI Blocks/Interleaving Frame");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN This function gather SLT information from another parade that
/// HIFN contains a SLT, if the actual decoded parade ID does not contain an SLT.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
ViStatus rsetl_DigitalTVATSCMHScanSLT(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DIGITAL_TV_ATSC_SCAN_SLT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Sorts the M/H Service Overview list by parade ID or service ID.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR sortList/Sorts the M/H Service Overview list by parade ID or service ID.
ViStatus rsetl_ConfigureDigitalTVATSCSortList(ViSession instrSession,
                                              ViBoolean sortList)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ATSC_SORT_LIST, sortList),
            2, "Sort List");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Use this command to browse through the lines of the M/H Services
/// HIFN  Overview table.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR selectParadeByService/Use this command to browse through the lines of the M/H Services
/// HIPAR selectParadeByService/Overview table.
ViStatus rsetl_ConfigureDigitalTVATSCSelectParadeByService(ViSession instrSession,
                                                           ViInt32   selectParadeByService)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ATSC_SELECT_PARADE_BY_SERVICE, selectParadeByService),
            2, "Select Parade By Service");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV CN
 * Purpose:  This function configures the noise generator state and parameter
 *           for digital TV measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDCN(ViSession instrSession,
                                ViBoolean CNState,
                                ViReal64  CN)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    if (CNState == VI_TRUE)
    {
        checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_NOISE_GEN_CN_STATE, VI_TRUE));

        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_NOISE_GEN_CN, CN),
                3, "CN");
    }
    else
    {
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_NOISE_GEN_CN_STATE, VI_FALSE));
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Overview Limit
 * Purpose:  This function sets the limit of the overview measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDOverLimit(ViSession instrSession,
                                       ViInt32   measurement,
                                       ViInt32   limitType,
                                       ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 19),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }

    switch (measurement){
        case RSETL_VAL_DTV_MERR:
        case RSETL_VAL_DTV_MERP:
        case RSETL_VAL_DTV_EVMR:
        case RSETL_VAL_DTV_EVMP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DTVMeasArr[measurement]);
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ERROR_UNIT, RSETL_VAL_UNIT_DB));
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ERR_LOW, limitValue),
                            4, "Limit Value");
                break;
                case RSETL_VAL_LIM_UPP:
                    checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ERROR_UNIT, RSETL_VAL_UNIT_PCT));
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ERR_UPP, limitValue),
                            4, "Limit Value");
                break;
            }
        break;
        case RSETL_VAL_DTV_CFOF:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_SROF:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_BBV:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BBV, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_BBRS:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BBRS, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_BROF:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_BIT_RATE_OFFSET, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_LIM:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_LEVEL, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_PER:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_PER, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_PERR:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_PERR, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_BERL:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BER_LDPC, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_BBCH:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BER_BBCH, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_MRLO:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_MRLO_LOW, limitValue),
                            4, "Limit Value");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_MRLO_UPP, limitValue),
                            4, "Limit Value");
                break;
            }
        break;
        case RSETL_VAL_DTV_MPLO:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_MPLO_LOW, limitValue),
                            4, "Limit Value");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_MPLO_UPP, limitValue),
                            4, "Limit Value");
                break;
            }
        break;
        case RSETL_VAL_DTV_MRPL:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_MRPL, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_MPPL:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_MPPL, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_ERPL:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_ERPL, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_EPPL:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_EPPL, limitValue),
                    4, "Limit Value");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function sets the limit of the ATSC-M/H TV standard in the overview.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR channel/This control selects the channel/ensemble.
/// HIPAR measurement/This control selects the type of the measurement.
/// HIPAR limitValue/This control sets the limit value.
ViStatus rsetl_ConfigureCATVDATSCMHOverviewLimit(ViSession instrSession,
                                                 ViInt32   channel,
                                                 ViInt32   measurement,
                                                 ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 3),
            2, "Channel");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 3),
            3, "Measurement");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", ATSCChannelArr[channel], ATSCMeasurementArr[measurement]);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW, limitValue),
            4, "Limit Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV Modulation Errors Limit
 * Purpose:  This function sets the limit of the modulation errors measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDModErrLimit(ViSession instrSession,
                                         ViInt32   measurement,
                                         ViInt32   limitType,
                                         ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }

    switch (measurement){
        case RSETL_VAL_DTV_MERR:
        case RSETL_VAL_DTV_MERP:
        case RSETL_VAL_DTV_EVMR:
        case RSETL_VAL_DTV_EVMP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DTVMeasArr[measurement]);
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ERROR_UNIT, RSETL_VAL_UNIT_DB));
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ERR_LOW, limitValue),
                            4, "Limit Value");
                break;
                case RSETL_VAL_LIM_UPP:
                    checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ERROR_UNIT, RSETL_VAL_UNIT_PCT));
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ERR_UPP, limitValue),
                            4, "Limit Value");
                break;
            }
        break;
        case RSETL_VAL_DTV_IMB:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_IMB, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_QERR:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_QERR, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_SUP:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_SUPP, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_PJIT:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_PJIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_SNR:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_SNR, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_PILV:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_SPV:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_PAER:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_CNR:
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_CNR,
                        (ViInt32) limitValue), 4, "Limit Value");
        break;
        case RSETL_VAL_DTV_BVF:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BVF, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_BVM:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BVM, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_MPFH:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT, limitValue),
                            4, "Limit Value");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT, limitValue),
                            4, "Limit Value");
                break;
            }
        break;
        case RSETL_VAL_DTV_MPSI:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT, limitValue),
                            4, "Limit Value");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT, limitValue),
                            4, "Limit Value");
                break;
            }
        break;
        case RSETL_VAL_DTV_MRFH:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT, limitValue),
                            4, "Limit Value");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT, limitValue),
                            4, "Limit Value");
                break;
            }
        break;
        case RSETL_VAL_DTV_MRSI:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT, limitValue),
                            4, "Limit Value");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT, limitValue),
                            4, "Limit Value");
                break;
            }
        break;
        case RSETL_VAL_DTV_AMPN:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_IRR:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        case RSETL_VAL_DTV_PHIN:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT, limitValue),
                    4, "Limit Value");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, measurement), 2, "Measurement");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Digital TV ISDB-T Limit
 * Purpose:  This function sets the limit of the ISDB-T TV standard in the
 *           overview and modulation errors measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDISDBTLimit(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViInt32   limitType,
                                        ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    if(measurement==RSETL_VAL_DTV_LIM_BARS)
    {
        switch (limitType){
            case RSETL_VAL_LIM_LOW:
                snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
            break;
            case RSETL_VAL_LIM_UPP:
                snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
            break;
        }

        viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS, limitValue),
                4, "Limit Value");
    }
    else
    {
        snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", ISDBTmerrArr[measurement]);
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATE, limitValue),
                4, "Limit Value");
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Digital TV Echo Pattern Unit
 * Purpose:  This function defines the unit of the Echo Pattern measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDEchoPatternUnit(ViSession instrSession,
                                             ViInt32   unit)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_EPAT_UNIT, unit),
            2, "Unit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Digital TV Units
 * Purpose:  This function defines the unit of measured values in
 *           Overview/Modulation Errors measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDUnit(ViSession instrSession,
                                  ViInt32   measurement,
                                  ViInt32   unit)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 3),
            2, "Measurement");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DTVMeasArr[measurement]);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ERROR_UNIT, unit),
            2, "Unit");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Digital TV Root Mean Square Unit
 * Purpose:  This function defines the unit of the root mean square value of
 *           the level in the overview measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVDRootMeanSquareUnit(ViSession instrSession,
                                                ViInt32   units)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_POW_LEV_UNIT, units),
            2, "Units");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure TV Analyzer Measurement
 * Purpose:  This function defines the TV analyzer measurement type.
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVTVMeasurement(ViSession instrSession,
                                          ViInt32   measurement)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_TV_MEAS, measurement),
            2, "Measurement");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Configure TV Analyzer Standard for Titl Measurement
 * Purpose:  This function activates/deactivates a modulation standard for
 *           the Tilt measurement
 *****************************************************************************/
ViStatus rsetl_ConfigureCATVTVStandardForTitlMeasurement(ViSession instrSession,
                                                         ViString  modulationStandard,
                                                         ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, state), 3, "State");
    if (state == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_ACTIVATE, modulationStandard),
                2, "Modulation Standard");
    }
    else
    {
        viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_DEACTIVATE, modulationStandard),
                2, "Modulation Standard");
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Query CATV Trigger Source
 * Purpose:  This function queries the result of the trigger gate source.
 *****************************************************************************/
ViStatus rsetl_QueryCATVTriggerSource(ViSession instrSession,
                                      ViInt32   *triggerSource)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_TRIGGER_SOURCE, triggerSource),
            2, "Trigger Source");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function exports all available measurement values (not only the
/// HIFN  values of the two selected traces) to a comma separated values (.csv)
/// HIFN  file. For every measurement value, the maximum, minimum and average
/// HIFN  value is saved. The *.csv file format can
/// HIFN     be imported in programs like Microsoft Excel for interpretation.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR startTime/This control sets the start time.
/// HIPAR stopTime/This control sets the stop time.
/// HIPAR compressionLevel/This control selects the compression level.
/// HIPAR fileName/Path and file name of the log file.
ViStatus rsetl_SaveCATVMeasurementLogResults(ViSession instrSession,
                                             ViString  startTime,
                                             ViString  stopTime,
                                             ViInt32   compressionLevel,
                                             ViString  fileName)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_CheckInstrumentOptions(instrSession, "K208"));

    snprintf (cmd, RS_MAX_MESSAGE_BUF_SIZE, "MMEM:STOR:MLOG:DATA \"%s\",\"%s\",\"%s\",\"%s\"", startTime, stopTime, compressionLevelArr[compressionLevel], fileName);

    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/*****************************************************************************
 * Function: Read CATV Measurement Log Results
 * Purpose:  This function reads the results of the ETL Measurement Log.
 *****************************************************************************/
ViStatus rsetl_ReadCATVMeasurementLogResults(ViSession instrSession,
                                             ViString  startTime,
                                             ViString  stopTime,
                                             ViInt32   compressionLevel,
                                             ViString  measurement,
                                             ViUInt32  *existingRecords,
                                             ViUInt32  *transferredRecords,
                                             ViInt32   *startTimeReturned,
                                             ViInt32   *stopTimeReturned,
                                             ViUInt32  *measurementMode1,
                                             ViUInt32  *measurementMode2,
                                             ViUInt32  *measurementMode3,
                                             ViInt32   timestamp[],
                                             ViReal64  values[])
{
    ViStatus   error = VI_SUCCESS;
    ViChar     cmd[RS_MAX_MESSAGE_BUF_SIZE];
    ViUInt32   *p2U32;
    ViInt32    *p2I32;
    ViReal32   *p2F32;
    ViInt32    i = 0,
    loop_count = 0;
    ViUInt32   num;
    ViInt64    len,
    rec        = 0;
    ViByte     *pbuffer = NULL;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_CheckInstrumentOptions(instrSession, "K208"));
    snprintf (cmd, RS_MAX_MESSAGE_BUF_SIZE, "READ:MLOG:DATA? \"%s\",\"%s\",\"%s\",\"%s\"", startTime, stopTime, compressionLevelArr[compressionLevel], measurement);

    checkErr(RsCore_QueryBinaryDataBlock(instrSession, cmd, VI_TRUE, NULL, &pbuffer, &len));

    checkErr(rsetl_CheckStatus(instrSession));

    num = ((ViInt32)len) / 4;
    p2U32 = (ViUInt32 *)pbuffer;
    p2I32 = (ViInt32 *)pbuffer;
    p2F32 = (ViReal32 *)pbuffer;

    *existingRecords    = p2U32[0];
    *transferredRecords = p2U32[1];
    *startTimeReturned  = p2I32[2];
    *stopTimeReturned   = p2I32[3];
    *measurementMode1   = p2U32[4];
    *measurementMode2   = p2U32[5];
    *measurementMode3   = p2U32[6];

    if (num > 7)
    {
        loop_count = (num-7) / *transferredRecords;

        while (rec < *transferredRecords)
        {
            timestamp[rec] = p2I32[7 + rec*loop_count];

            for (i=0; i < loop_count-1; i++)
            {
                values[i + rec*(loop_count-1)] = (ViReal64) p2F32[i + 8 + rec*loop_count];
            }

            rec++;
        }
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (pbuffer)
        free(pbuffer);
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/*****************************************************************************
 * Function: Read Analog TV Achieved Averaging Depth
 * Purpose:  This function reads the current value of the averaging depth just
 *           achieved with the averaging mode switched on in the Analog TV
 *           Analysis.
 *****************************************************************************/
ViStatus rsetl_ReadCATVAAchievedAveragingDepth(ViSession instrSession,
                                               ViInt32   *achievedAveragingDepth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_ATV_ACHIEVED_AVER_DEPTH, achievedAveragingDepth),
            2, "Achieved Averaging Depth");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
   return error;
}

/*****************************************************************************
 * Function: CATV Initiate
 * Purpose:  This function initiates an acquisition. After calling this
 *           function, the spectrum analyzer leaves the idle state and waits
 *           for a trigger.
 *
 *           This function does not check the instrument status. Typically,
 *           the end-user calls this function only in a sequence of calls to
 *           other low-level driver functions. The sequence performs one
 *           operation. The end-user uses the low-level functions to optimize
 *           one or more aspects of interaction with the instrument.
 *****************************************************************************/
ViStatus rsetl_CATVInitiate(ViSession instrSession,
                            ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 3, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_INIT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout > 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Abort
 * Purpose:  This function aborts a previously initiated measurement and
 *           returns the spectrum analyzer to the idle state.
 *****************************************************************************/
ViStatus rsetl_CATVAbort(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_ABORT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Continue
 * Purpose:  This function continues a stopped measurement at the current
 *           position in single sweep mode. The function is useful especially
 *           for trace functions MAXHold, MINHold and AVERage if the previous
 *           results are not to be cleared with Sweep Count > 0 or Average
 *           Count > 0 on restarting the measurement (INIT:IMMediate resets the
 *           previous results on restarting the measurement).
 *           The single-sweep mode is automatically switched on.
 *           Synchronization to the end of the indicated number of measurements
 *           can then be performed with the command *OPC, *OPC? or *WAI. In the
 *           continuous-sweep mode, synchronization to the sweep end is not
 *           possible since the overall measurement never ends.
 *****************************************************************************/
ViStatus rsetl_CATVContinue(ViSession instrSession,
                            ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_INIT_CONMEAS, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout > 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Send Software Trigger
 * Purpose:  This function sends a command to trigger the SpecAn.  Call this
 *           function if the trigger source is set to software trigger.
 *****************************************************************************/
ViStatus rsetl_CATVSendSoftwareTrigger(ViSession instrSession,
                                       ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_INIT_SW_TRIGGER, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout > 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Set CATV Instrument From Marker
 * Purpose:  This function makes the selected marker frequency to be the
 *           center frequency or step width of center frequency. It can also
 *           make the active marker amplitude to be the reference level.
 *****************************************************************************/
ViStatus rsetl_SetCATVInstrumentFromMarker(ViSession instrSession,
                                           ViInt32   markerNumber,
                                           ViInt32   instrumentSetting)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, markerNumber, 1, 4),
            2, "Marker Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", markerNumber);
    switch(instrumentSetting)
    {
        case RSETL_VAL_INSTRUMENT_SETTING_FREQUENCY_CENTER:
            checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_TO_CENTER, NULL));
        break;
        case RSETL_VAL_INSTRUMENT_SETTING_REFERENCE_LEVEL:
            checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_TO_REFERENCE, NULL));
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, instrumentSetting), 3, "Instrument Setting");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Marker Search
 * Purpose:  This function specifies the type of marker search and performs
 *           the search.
 *****************************************************************************/
ViStatus rsetl_CATVMarkerSearch(ViSession instrSession,
                                ViInt32   marker,
                                ViInt32   markerSearch)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    switch (markerSearch)
    {
            case RSETL_VAL_MARKER_SEARCH_HIGHEST:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_PEAK, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_PEAK_NEXT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_LEFT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_PEAK_LEFT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_RIGHT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_PEAK_RIGHT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_MINIMUM:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_MIN, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_MIN_NEXT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_LEFT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_MIN_LEFT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_RIGHT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_MIN_RIGHT, NULL));
            break;

            default:
                viCheckParm(RsCore_InvalidViInt32Value(instrSession, markerSearch), 3, "Marker Set");
            break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query CATV Marker
 * Purpose:  This function returns the horizontal position and the marker
 *           amplitude level of the selected marker.
 *****************************************************************************/
ViStatus rsetl_QueryCATVMarker(ViSession instrSession,
                               ViInt32   marker,
                               ViReal64  *markerPosition,
                               ViReal64  *markerAmplitude)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_POSITION, markerPosition),
            3, "Marker Position");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_AMPLITUDE, markerAmplitude),
            4, "Marker Amplitude");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: CATV Delta Marker Search
 * Purpose:  This function specifies the type of delta marker search and
 *           performs the search.
 *****************************************************************************/
ViStatus rsetl_CATVDeltaMarkerSearch(ViSession instrSession,
                                     ViInt32   deltaMarker,
                                     ViInt32   markerSearch)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarker, 1, 4),
            2, "Delta Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarker);
    switch (markerSearch)
    {
            case RSETL_VAL_MARKER_SEARCH_HIGHEST:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_PEAK, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT, NULL));
            break;

            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_LEFT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_LEFT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_RIGHT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_RIGHT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_MINIMUM:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MIN, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_LEFT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_LEFT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_RIGHT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_RIGHT, NULL));
            break;
            default:
                viCheckParm(RsCore_InvalidViInt32Value(instrSession, markerSearch), 3, "Marker Search");
            break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query CATV Delta Marker
 * Purpose:  This function returns the horizontal position and the marker
 *           amplitude level of the selected delta marker.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDeltaMarker(ViSession instrSession,
                                    ViInt32   deltaMarker,
                                    ViInt32   mode,
                                    ViReal64  *position,
                                    ViReal64  *amplitude)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarker, 1, 4),
            2, "Delta Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarker);
    switch (mode){
        case RSETL_VAL_ABS:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_POSITION, position),
                    4, "Position");
        break;
        case RSETL_VAL_REL:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_REL_POSITION, position),
                    4, "Position");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, mode), 3, "Mode");
    }

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_AMPLITUDE, amplitude),
            5, "Amplitude");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Signal
 * Purpose:  This function queries if TV signal is available and locked.
 *****************************************************************************/
ViStatus rsetl_QueryCATVASignal(ViSession instrSession,
                                ViInt32   *lockedSignal)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_ATV_SIGNAL_LOCKED, lockedSignal),
            2, "Locked Signal");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Carrier Result
 * Purpose:  This function reads the measurement values (power, frequency)
 *           of the Carrier Power measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVACarrierResult(ViSession instrSession,
                                       ViInt32   measurement,
                                       ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 5),
            2, "Measurement");
    switch (measurement){
        case RSETL_VAL_ATV_VCP:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATV_CARR_VCPA, result),
                    3, "Result");
        break;
        case RSETL_VAL_ATV_VCF:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATV_CARR_VCF_VALUE, result),
                    3, "Result");
        break;
        case RSETL_VAL_ATV_SC1PR:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "SC1", RSETL_ATTR_CATV_ATV_CARR_REL_POWER_VALUE, result),
                    3, "Result");
        break;
        case RSETL_VAL_ATV_SC1IF:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "SC1", RSETL_ATTR_CATV_ATV_CARR_FREQ_OFFSET_VALUE, result),
                    3, "Result");
        break;
        case RSETL_VAL_ATV_SC2PR:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "SC2", RSETL_ATTR_CATV_ATV_CARR_REL_POWER_VALUE, result),
                    3, "Result");
        break;
        case RSETL_VAL_ATV_SC2IF:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "SC2", RSETL_ATTR_CATV_ATV_CARR_FREQ_OFFSET_VALUE, result),
                    3, "Result");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Carrier Continuous Results
 * Purpose:  This function reads the 100 continuous values of the vision carrier
 *           power measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVACarrierContinuousResults(ViSession instrSession,
                                                  ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 2, "Results");

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, "CALC:ATV:RES:CARR? VCPC", 100, results, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Carrier All Results
 * Purpose:  This function reads all measurement values (power, frequency) of
 *           the Carrier Power measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVACarrierAllResults(ViSession instrSession,
                                           ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 2, "Results");

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, "CALC:ATV:RES:CARR? ALL", 6, results, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Carrier Ratio Result
 * Purpose:  This function returns the resultfor the carrier-to-noise,
 *           carrier-to-second order beat or carrier-to-composite triple beat
 *           ratio measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVACarrierRatioResult(ViSession instrSession,
                                            ViInt32   measurement,
                                            ViInt32   resultType,
                                            ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 2, 4),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, resultType, 0, 4),
            3, "Result Type");
    switch (resultType){
        case RSETL_VAL_ATV_RES_CR:
            switch (measurement){
                case RSETL_VAL_ATV_MEAS_CN:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATV_CN_CN_VALUE, result),
                            4, "Result");
                break;
                case RSETL_VAL_ATV_MEAS_CSO:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATV_CSO_CSO_VALUE, result),
                            4, "Result");
                break;
                case RSETL_VAL_ATV_MEAS_CTB:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATV_CTB_CTB_VALUE, result),
                            4, "Result");
                break;
            }
        break;
        default:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", rsetl_rngCatvAtvMeas.entries[measurement].cmdString,ATVCarrierResultArr[resultType]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_ATV_VALUE, result),
                    4, "Result");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Carrier All Ratio Results
 * Purpose:  This function reads all measurement values.
 *****************************************************************************/
ViStatus rsetl_QueryCATVACarrierAllRatioResults(ViSession instrSession,
                                                ViInt32   measurement,
                                                ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 2, 4),
            2, "Measurement");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 3, "Results");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":CALC:ATV:RES:%s? ALL", rsetl_rngCatvAtvMeas.entries[measurement].cmdString);
    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, cmd, 1024, results, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Hum Result
 * Purpose:  This function reads the measurement values of the Hum measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVAHumResult(ViSession instrSession,
                                   ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_ATV_HUM_VALUE, result),
            2, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Vision Modulation Result
 * Purpose:  This function reads the measurement values of the Vision
 *           Modulation measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVAVisionModulationResult(ViSession instrSession,
                                                ViInt32   measurement,
                                                ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, RSETL_VAL_ATV_VCP, RSETL_VAL_ATV_SNRN),
            2, "Measurement");
    switch (measurement){
        case RSETL_VAL_ATV_VCP:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "VisCarrPow", RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE, result),
                    2, "Result");
        break;
        case RSETL_VAL_ATV_RPC:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "ResPicture", RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE, result),
                    2, "Result");
        break;
        case RSETL_VAL_ATV_MDEP:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "Depth", RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE, result),
                    2, "Result");
        break;
        case RSETL_VAL_ATV_SNR:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "SigNoiseRatio", RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE, result),
                    2, "Result");
        break;
        case RSETL_VAL_ATV_LFOF:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "FreqOffset", RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE, result),
                    2, "Result");
        break;
        case RSETL_VAL_ATV_SNRN:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "SNRNominal", RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE, result),
                    2, "Result");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Query Analog TV Vision All Modulation Results
 * Purpose:  This function reads the measurement values of the Vision Modulation
 *           measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVAVisionAllModulationResults(ViSession instrSession,
                                                    ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 2, "Results");

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, "CALC:ATV:RES:VMOD? ALL", 1024, results, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Analysis Measurement Result
 * Purpose:  This function reads the measurement values of the Analog TV Analysis.
 *****************************************************************************/
ViStatus rsetl_QueryCATVAAnalysisMeasurementResult(ViSession instrSession,
                                                   ViInt32   measurement,
                                                   ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, RSETL_VAL_ATV_VME_LBAR, RSETL_VAL_ATV_VME_T42P),
            2, "Measurement");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", ATVAnalysisMeasValue[measurement]);
    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_GET_ATV_ANALYSIS_MEAS_VALUE, result),
            3, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Carrier Limit Result
 * Purpose:  This function returns the check limit result.
 *****************************************************************************/
ViStatus rsetl_QueryCATVACarrierLimitResult(ViSession instrSession,
                                            ViInt32   measurement,
                                            ViInt32   limitType,
                                            ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 5),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");
    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }

    switch (measurement){
        case RSETL_VAL_ATV_VCP:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_VCP_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_ATV_VCF:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_VCF_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_ATV_SC1PR:
            strcat (repCap,",SC1");
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_ATV_SC1IF:
            strcat (repCap,",SC1");
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_ATV_SC2PR:
            strcat (repCap,",SC2");
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_ATV_SC2IF:
            strcat (repCap,",SC2");
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET_RESULT, result),
                    4, "Result");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Carrier Ratio Limit Result
 * Purpose:  This function returns the check limit result.
 *****************************************************************************/
ViStatus rsetl_QueryCATVACarrierRatioLimitResult(ViSession instrSession,
                                                 ViInt32   measurement,
                                                 ViInt32   limitType,
                                                 ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 2, 4),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 0),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }
    switch (measurement){
        case RSETL_VAL_ATV_MEAS_CN:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_CN_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_ATV_MEAS_CSO:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_CSO_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_ATV_MEAS_CTB:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_CTB_RESULT, result),
                    4, "Result");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Hum Limit Result
 * Purpose:  This function returns the limit check for the Hum measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVAHumLimitResult(ViSession instrSession,
                                        ViInt32   limitType,
                                        ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "Low", RSETL_ATTR_CATV_ATV_LIM_HUM_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_LIM_UPP:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "Upp", RSETL_ATTR_CATV_ATV_LIM_HUM_RESULT, result),
                    4, "Result");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, limitType), 2, "Limit Type");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Query Analog TV Vision Modulation Limit Result
 * Purpose:  This function returns the check limit result.
 *****************************************************************************/
ViStatus rsetl_QueryCATVAVisionModulationLimitResult(ViSession instrSession,
                                                     ViInt32   measurement,
                                                     ViInt32   limitType,
                                                     ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }
    switch (measurement){
        case RSETL_VAL_ATV_VCP:
            strcat (repCap, ",VisCarrPow");
        break;
        case RSETL_VAL_ATV_RPC:
            strcat (repCap, ",ResPicture");
        break;
        case RSETL_VAL_ATV_MDEP:
            strcat (repCap, ",Depth");
        break;
        case RSETL_VAL_ATV_LFOF:
            strcat (repCap, ",FreqOffset");
        break;
    }
    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP_RESULT, result),
            4, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Analog TV Analysis Measurement Limit Result
 * Purpose:  This function returns a limit check for the specified measurement
 *           parameter of the Analog TV Analysis.
 *****************************************************************************/
ViStatus rsetl_QueryCATVAAnalysisMeasurementLimitResult(ViSession instrSession,
                                                        ViInt32   measurement,
                                                        ViInt32   limitType,
                                                        ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 75),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low,%s", ATVAnalysisMeasValue[measurement]);
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp,%s", ATVAnalysisMeasValue[measurement]);
        break;
    }

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_RESULT, result),
            4, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Signal
 * Purpose:  This function queries if TV signal is available and locked.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDSignal(ViSession instrSession,
                                ViInt32   *lockedSignal)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_SIGNAL_LOCKED, lockedSignal),
            2, "Locked Signal");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV MPEG Signal
 * Purpose:  This function queries if mpeg signal is available and locked.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDMPEGSignal(ViSession instrSession,
                                    ViInt32   *lockedSignal)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MPEG_SIGNAL_LOCKED, lockedSignal),
            2, "Locked Signal");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Overview Settings DVBT
 * Purpose:  This function reads the measurement values for the digital TV
 *           measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDOverviewSettingsDVBT(ViSession instrSession,
                                              ViInt32   *constellation,
                                              ViInt32   *FFTMode,
                                              ViInt32   *guardInterval,
                                              ViInt32   *codeRateHighPriority,
                                              ViInt32   *codeRateLowPriority,
                                              ViInt32   *interleaver)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_CONST_SETTING, constellation),
            2, "Constellation");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_FFT_MODE_SETTING, FFTMode),
            3, "FFT Mode");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_GUARD_INTERVAL_SETTING, guardInterval),
            4, "Guard Interval");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_HIGH_PRIOR_SETTING, codeRateHighPriority),
            5, "Code Rate High Priority");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_LOW_PRIOR_SETTING, codeRateLowPriority),
            6, "Code Rate Low Priority");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_INTERLEAVER_SETTING, interleaver),
            7, "Interleaver");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Overview Settings DMBT
 * Purpose:  This function reads the measurement values for the digital TV
 *           measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDOverviewSettingsDMBT(ViSession instrSession,
                                              ViInt32   *constellation,
                                              ViInt32   *guardInterval,
                                              ViInt32   *codeRate,
                                              ViInt32   *timeDeinterleaver)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_CONST_SETTING, constellation),
            2, "Constellation");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_GUARD_INTERVAL_SETTING, guardInterval),
            3, "Guard Interval");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_SETTING, codeRate),
            4, "Code Rate");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_TPS_MEAS_DEINTERLEAVER_SETTING, timeDeinterleaver),
            5, "Time Deinterleaver");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function configures the result of the Echo Pattern measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR result/Returns the result value.
ViStatus rsetl_ConfigureCATVDEchoPatternResult(ViSession instrSession,
                                               ViInt32   measurement,
                                               ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 1),
            2, "Measurement");


    checkErr(RsCore_LockSession(instrSession));

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DTVEchoPattArr[measurement]);

    checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQUALIZER_STATE, VI_TRUE));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_GET_DIGITAL_TV_ECHO_PATTERN_RESULT, result),
            3, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Echo Pattern Peak Values Measurement Result
 * Purpose:  This function reads the result of the Echo Pattern Peak Values
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDEPPVMeasurementResult(ViSession instrSession,
                                               ViInt32   arrayLength,
                                               ViInt32   *actualPoints,
                                               ViReal64  level[],
                                               ViReal64  time[],
                                               ViReal64  SFN[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];
    ViChar*  response = NULL;
    ViChar*  p2buf;
    ViChar*  p2buf2;
    ViInt32  i = 0;
    ViInt32  data = 0;

    checkErr(RsCore_LockSession(instrSession));

    snprintf (cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:DTV:RES:BFIL? EPPV");
    checkErr(RsCore_QueryViStringUnknownLength(instrSession, cmd, &response));

    data = strncmp (response, "---", 3);
    p2buf = response;
    p2buf2 = response;
    i=0;

    while(p2buf2 && (i < arrayLength))
    {
        if (!data)
        {
            level[i] = RS_VAL_NAN_VI_REAL64;
            time[i] = RS_VAL_NAN_VI_REAL64;
            SFN[i++] = RS_VAL_NAN_VI_REAL64;
        }
        else
        {
            p2buf2=strchr (p2buf, ',');
            if (((p2buf2-p2buf)==0)||(strlen(p2buf)<=1))
            {
                    level[i] = RS_VAL_NAN_VI_REAL64;
            }
            else
            {
                level[i] = RsCore_Convert_String_To_ViReal64(p2buf);
            }
            if (p2buf2)
            {
                p2buf = p2buf2+1;
            }

            p2buf2=strchr (p2buf, ',');
            if (((p2buf2-p2buf)==0)||(strlen(p2buf)<=1))
            {
                    time[i]=RS_VAL_NAN_VI_REAL64;
            }
            else
            {
                time[i] = RsCore_Convert_String_To_ViReal64(p2buf);
            }
            if (p2buf2)
            {
                p2buf = p2buf2+1;
            }

            p2buf2=strchr (p2buf, ',');
            if (((p2buf2-p2buf)==0)||(strlen(p2buf)<=1))
            {
                    SFN[i]=RS_VAL_NAN_VI_REAL64;
            }
            else
            {
                SFN[i] = RsCore_Convert_String_To_ViReal64(p2buf);
            }
            i++;
            if (p2buf2)
            {
                p2buf = p2buf2+1;
            }
        }
    };

    *actualPoints = i;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (response)
        free(response);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV FIC Sync Status
 * Purpose:  This function queries the FIC synchronization status.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDFICSyncStatus(ViSession instrSession,
                                       ViInt32   *FICSyncStatus)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_FIC_SYNC_STATUS, FICSyncStatus),
            2, "FIC Sync Status");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Spectrum Result
 * Purpose:  This function reads the measurement value of spectrum.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDSpectrumResult(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 1),
            2, "Measurement");
    switch (measurement){
        case RSETL_VAL_DTV_SPEC_SAL:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "SAttLow", RSETL_ATTR_CATV_DTV_SPEC, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_SPEC_SAUP:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "SAttUpp", RSETL_ATTR_CATV_DTV_SPEC, result),
                    3, "Result");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Overview Result
 * Purpose:  This function returns the result value.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDOverviewResult(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViReal64  *result,
                                        ViInt32   *constellationResult)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];
    ViChar   response[RS_MAX_MESSAGE_BUF_SIZE];
    ViChar   *p2buf;

    checkErr(RsCore_LockSession(instrSession));

    switch (measurement){
        case RSETL_VAL_DTV_RES_MERR:
        case RSETL_VAL_DTV_RES_MERP:
        case RSETL_VAL_DTV_RES_EVMR:
        case RSETL_VAL_DTV_RES_EVMP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DTVMeasArr[measurement]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ERROR, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RES_CFOF:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_OVER_CARR_FREQ_OFFSET, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RES_SROF:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_OVER_SRATE_OFFSET, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RES_CONS:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_CONST_VAL, constellationResult),
                    4, "Constellation Result");
        break;
        case RSETL_VAL_DTV_RES_LEV:
        case RSETL_VAL_DTV_RES_BBV:
        case RSETL_VAL_DTV_RES_PBBV:
        case RSETL_VAL_DTV_RES_TBBV:
        case RSETL_VAL_DTV_RES_BBRS:
        case RSETL_VAL_DTV_RES_PBBR:
        case RSETL_VAL_DTV_RES_TBBR:
        case RSETL_VAL_DTV_RES_PER:
        case RSETL_VAL_DTV_RES_PPER:
        case RSETL_VAL_DTV_RES_TPER:
        case RSETL_VAL_DTV_RES_PERR:
        case RSETL_VAL_DTV_RES_BROF:
        case RSETL_VAL_DTV_RES_ISR:
        case RSETL_VAL_DTV_RES_MTB:
        case RSETL_VAL_DTV_RES_BERL:
        case RSETL_VAL_DTV_RES_PBER:
        case RSETL_VAL_DTV_RES_TBER:
        case RSETL_VAL_DTV_RES_FERR:
        case RSETL_VAL_DTV_RES_MTBR:
        case RSETL_VAL_DTV_RES_BARS:
        case RSETL_VAL_DTV_RES_PBAR:
        case RSETL_VAL_DTV_RES_TBAR:
        case RSETL_VAL_DTV_RES_LTB:
        case RSETL_VAL_DTV_RES_MMTB:
        case RSETL_VAL_DTV_RES_DCN:
        case RSETL_VAL_DTV_RES_CN:
        case RSETL_VAL_DTV_RES_SNRL:
        case RSETL_VAL_DTV_RES_PNO:
        case RSETL_VAL_DTV_RES_CIFC:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DtvOverviewArr[measurement]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_OVERVIEW, result),
                    3, "Result");
        break;

        case RSETL_VAL_DTV_RES_MFECH:
            checkErr(rsetl_QueryViString(instrSession, "CALC:DTV:RES? MFEC", RS_MAX_MESSAGE_BUF_SIZE, response));

            p2buf = strtok (response, ",");
            *result = RsCore_Convert_String_To_ViReal64(p2buf);
        break;

        case RSETL_VAL_DTV_RES_MFECL:
            checkErr(rsetl_QueryViString(instrSession, "CALC:DTV:RES? MFEC", RS_MAX_MESSAGE_BUF_SIZE, response));

            p2buf = strtok (response, ",");
            p2buf = strtok (NULL, ",");
            *result = RsCore_Convert_String_To_ViReal64(p2buf);
        break;

        case RSETL_VAL_DTV_RES_TSLH:
            checkErr(rsetl_QueryViString(instrSession, "CALC:DTV:RES? TSL", RS_MAX_MESSAGE_BUF_SIZE, response));

            p2buf = strtok (response, ",");
            *result = RsCore_Convert_String_To_ViReal64(p2buf);
        break;

        case RSETL_VAL_DTV_RES_TSLL:
            checkErr(rsetl_QueryViString(instrSession, "CALC:DTV:RES? TSL", RS_MAX_MESSAGE_BUF_SIZE, response));

            p2buf = strtok (response, ",");
            p2buf = strtok (NULL, ",");
            *result = RsCore_Convert_String_To_ViReal64(p2buf);
        break;

        case RSETL_VAL_DTV_RES_FFTM:
        case RSETL_VAL_DTV_RES_GINT:
        case RSETL_VAL_DTV_RES_CRHP:
        case RSETL_VAL_DTV_RES_CRLP:
        case RSETL_VAL_DTV_RES_CID:
        case RSETL_VAL_DTV_RES_TPSR:
        case RSETL_VAL_DTV_RES_INT:
        case RSETL_VAL_DTV_RES_LIND:
        case RSETL_VAL_DTV_RES_TMOD:
        case RSETL_VAL_DTV_RES_SBP:
        case RSETL_VAL_DTV_RES_CRAT:
        case RSETL_VAL_DTV_RES_DEIN:
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, measurement), 2, "Measurement");
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Overview Level Continuous Results
 * Purpose:  This function returns the continuous level result values.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDOverviewLevelContinuousResults(ViSession instrSession,
                                                        ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 2, "Result");

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, "CALC:DTV:RES? LEVC", 1024, results, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Overview All Results
 * Purpose:  This function returns the result values.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDOverviewAllResults(ViSession instrSession,
                                            ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 2, "Results");

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, "CALC:DTV:RES? ALL", 1024, results, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Modulation Errors Result
 * Purpose:  This function returns the result value.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDModulationErrorsResult(ViSession instrSession,
                                                ViInt32   measurement,
                                                ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 22),
            2, "Measurement");

    switch (measurement){
        case RSETL_VAL_DTV_MERR:
        case RSETL_VAL_DTV_MERP:
        case RSETL_VAL_DTV_EVMR:
        case RSETL_VAL_DTV_EVMP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DTVMeasArr[measurement]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ERROR, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_IMB:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MERR_IMB, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_QERR:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MERR_QERR, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_SUP:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MERR_CSUP, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_PJIT:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MERR_PJIT, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_SNR:
        case RSETL_VAL_DTV_LEVEL:
        case RSETL_VAL_DTV_CPH:
        case RSETL_VAL_DTV_PILV:
        case RSETL_VAL_DTV_SPV:
        case RSETL_VAL_DTV_PAER:
        case RSETL_VAL_DTV_CNR:
        case RSETL_VAL_DTV_BVF:
        case RSETL_VAL_DTV_PBVF:
        case RSETL_VAL_DTV_TBVF:
        case RSETL_VAL_DTV_BVM:
        case RSETL_VAL_DTV_PBVM:
        case RSETL_VAL_DTV_TBVM:
        case RSETL_VAL_DTV_MTRM:
        case RSETL_VAL_DTV_MARM:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DtvModErrorsArr[measurement]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_MOD_ERRORS, result),
                    3, "Result");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Modulation Errors All Result
 * Purpose:  This function returns the result value.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDModulationErrorsAllResults(ViSession instrSession,
                                                    ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 2, "Results");

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, "CALC:DTV:RES? ALL", 1024, results, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Measurement Result
 * Purpose:  This function returns the result value.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDMeasurementResult(ViSession instrSession,
                                           ViInt32   measurement,
                                           ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    switch (measurement){
        case RSETL_VAL_DTV_RESULT_FFTM:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_FFT_MODE, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_GINT:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_GUARD_INTERVAL, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_CRAT:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_CODE_RATE, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_CRHP:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_CODE_RATE_HIGH_PRIORITY, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_CRLP:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_CODE_RATE_LOW_PRIORITY, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_INT:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_INTERLEAVER, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_TMOD:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_TRANSMISSION_MODE, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_SBP:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_SIDEBAND_POSITION, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_DEIN:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_TIME_DEINTERLEAVER, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_CFR:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_CONTROL_FRAME, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_CID:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_CELL_ID, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_TPSR:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_TPS_RESERVED, result),
                    3, "Result");
        break;
        case RSETL_VAL_DTV_RESULT_LIND:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_GET_DTV_LENGTH_INDICATOR, result),
                    3, "Result");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, measurement), 2, "Measurement");
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Constellation Result
 * Purpose:  This function returns the result value.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDConstellationResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 4),
            2, "Measurement");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DtvConstellationArr[measurement]);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_CONST, result),
            3, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV MER Vs Carrier Result
 * Purpose:  This function returns the result value.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDMERVsCarrierResult(ViSession instrSession,
                                            ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_MER_VS_CAR, result),
            2, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function the measurement values for the MER-PhaseNoise measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR result/Returns the result value.
ViStatus rsetl_QueryCATVDMERPhaseNoiseResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 5),
            2, "Measurement");


    checkErr(RsCore_LockSession(instrSession));

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DTVMPnoiseArr[measurement]);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_RESULT, result),
            3, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV IQ Imbalance Result
 * Purpose:  This function returns the amplitude imbalance result value.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDIQImbalanceResult(ViSession instrSession,
                                           ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_IQ_IMBALANCE, result),
            2, "Result");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Signal Statistics Result
 * Purpose:  This function reads out the results of statistical measurements
 *           of a recorded trace.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDSignalStatisticsResult(ViSession instrSession,
                                                ViInt32   traceNumber,
                                                ViInt32   resultType,
                                                ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];
    ViString statisticMeasType[] = {"Mean","Peak","CrestFactor"};

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, traceNumber, 1, 4),
            2, "Trace");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, resultType, 0, 2),
            3, "Result Type");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld,Stat%s", traceNumber, statisticMeasType[resultType]);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_STAT_RESULT, result),
            4, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Query Digital TV Signal Statistics All Results
 * Purpose:  This function reads out the results of statistical measurements
 *           of a recorded trace.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDSignalStatisticsAllResults(ViSession instrSession,
                                                    ViInt32   traceNumber,
                                                    ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, traceNumber, 1, 4),
            2, "Measurement");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 3, "Results");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":CALC:STAT:RES%ld? ALL", traceNumber);
    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, cmd, 1024, results, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Margin List
 * Purpose:  This function reads the measurement values for the digital TV
 *           measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDMarginList(ViSession instrSession,
                                    ViInt32   sequencesToQuery,
                                    ViInt32   *actualNumberOfSequences,
                                    ViReal64  interval1[],
                                    ViReal64  interval2[],
                                    ViReal64  frequency[],
                                    ViReal64  margin[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, sequencesToQuery, 1), 2, "Sequences To Query");

    checkErr(RsCore_QueryFloatArraysInterleavedToUserBuffer(instrSession, "CALC:DTV:RES:BFIL? MLIS",
        sequencesToQuery, actualNumberOfSequences, interval1, interval2, frequency, margin, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function reads the result of the transmitter identification
/// HIFN  information (TII) measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR arrayLength/Number of array points requested.
/// HIPAR numberofDetectedTransmitters/Number of detected transmitters (TX).
/// HIPAR carrierPhaseInfo/Returns the Carrier Phase Info values.
/// HIPAR mainID/Returns the Main ID values.
/// HIPAR subID/Returns the Sub ID values.
/// HIPAR time/Returns the time values.
ViStatus rsetl_QueryCATVDTransmitterIdentificationInformation(
                            ViSession instrSession,
                            ViInt32   arrayLength,
                            ViInt32*  numberofDetectedTransmitters,
                            ViInt32   carrierPhaseInfo[],
                            ViInt32   mainID[],
                            ViInt32   subID[],
                            ViReal64  time[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];
    ViChar*  response = NULL;
    ViChar*  p2buf;
    ViChar*  p2buf2;
    ViInt32  i = 0;
    ViInt32  data = 0;

    checkErr(RsCore_LockSession(instrSession));

    snprintf (cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:DTV:RES:BFIL? TIIV");

    checkErr(RsCore_QueryViStringUnknownLength(instrSession, cmd, &response));

    data = strncmp (response, "---", 3);

    p2buf = response;
    p2buf2 = response;

    p2buf2=strchr (p2buf, ',');
    if ((p2buf2 == NULL) || (strlen(p2buf) <= 1))
    {
        *numberofDetectedTransmitters = RS_VAL_NAN_VI_INT32;
    }
    else
    {
        *numberofDetectedTransmitters = RsCore_Convert_String_To_ViInt32(p2buf);
    }

    if (p2buf2)
    {
        p2buf = p2buf2+1;
    }

    while(p2buf2 && (i < arrayLength))
    {
        if (!data)
        {
            carrierPhaseInfo[i] = RS_VAL_NAN_VI_INT32;
            mainID[i] = RS_VAL_NAN_VI_INT32;
            subID[i] = RS_VAL_NAN_VI_INT32;
            time[i++] = RS_VAL_NAN_VI_REAL64;
        }
        else
        {
            p2buf2=strchr (p2buf, ',');
            if (((p2buf2-p2buf)==0)||(strlen(p2buf)<=1))
            {
                carrierPhaseInfo[i]= RS_VAL_NAN_VI_INT32;
            }
            else
            {
                carrierPhaseInfo[i] = RsCore_Convert_String_To_ViInt32(p2buf2);
            }
            if (p2buf2)
            {
                p2buf = p2buf2+1;
            }

            p2buf2=strchr (p2buf, ',');
            if (((p2buf2-p2buf)==0)||(strlen(p2buf)<=1))
            {
                    mainID[i]= RS_VAL_NAN_VI_INT32;
            }
            else
            {
                mainID[i] = RsCore_Convert_String_To_ViInt32(p2buf2);
            }
            if (p2buf2)
            {
                p2buf = p2buf2+1;
            }

            p2buf2=strchr (p2buf, ',');
            if (((p2buf2-p2buf)==0)||(strlen(p2buf)<=1))
            {
                    subID[i]= RS_VAL_NAN_VI_INT32;
            }
            else
            {
                subID[i] = RsCore_Convert_String_To_ViInt32(p2buf2);
            }

            if (p2buf2)
            {
                p2buf = p2buf2+1;
            }

            p2buf2=strchr (p2buf, ',');
            if (((p2buf2-p2buf)==0)||(strlen(p2buf)<=1))
            {
                    time[i] = RS_VAL_NAN_VI_REAL64;
            }
            else
            {
                time[i] = RsCore_Convert_String_To_ViReal64(p2buf2);
            }

            i++;
            if (p2buf2)
            {
                p2buf = p2buf2+1;
            }
        }
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (response)
        free(response);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Amplitude Phase Group Delay Result
 * Purpose:  This function reads the measurement values for the digital TV
 *           measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDAmplitudePhaseGroupDelayResult(ViSession instrSession,
                                                        ViInt32   measurement,
                                                        ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, RSETL_VAL_DTV_MEAS_RES_AMPL, RSETL_VAL_DTV_MEAS_RES_GDEL),
            2, "Measurement");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", DtvAPGDResultArr[measurement]);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_APGD_MEAS_RESULT, result),
            3, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function:Query Digital TV Ingress Diagram Equivalent Noise Bandwidth Result
 * Purpose: This function queries the equivalent noise bandwidth (NBW) of
 *          the Ingress Diagram measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDIngressDiagramEquivalentNoiseBandwidthResult(
                            ViSession instrSession,
                            ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_CATV_DTV_INGRESS_DIAGRAM_EQUIVALENT_NOISE_BANDWIDTH, result),
            2, "Result");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Layer Specific Result
 * Purpose:  This function queries the layer-specific results of the overview
 *           and modulation errors measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTLayerSpecificResult(ViSession instrSession,
                                                  ViInt32   measurement,
                                                  ViInt32   hierarchicalLayer,
                                                  ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, RSETL_VAL_DTV_RES_MERR, RSETL_VAL_DTV_RESULT_PERR),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            3, "Hierarchical Layer");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", hierarchicalLayerArr[hierarchicalLayer],ISDBTmerrArr[measurement]);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_LAYER_SPECIFIC, result),
            3, "Result");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC System Identification
 * Purpose:  This function reads the TMCC System Identification in Overview
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCSystemIdentification(
                            ViSession instrSession,
                            ViChar    systemIdentification[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_SYSTEM_IDENTIFICATION,
            RS_MAX_MESSAGE_BUF_SIZE, systemIdentification),
            2, "System Identification");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Parameter Switching Indicator
 * Purpose:  This function reads the TMCC Parameter Switching Indicator in
 *           Overview measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCParameterSwitchingIndicator(
                            ViSession instrSession,
                            ViChar    parameterSwitchingIndicator[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PARAMETER_SWITCHING_INDICATOR,
            RS_MAX_MESSAGE_BUF_SIZE, parameterSwitchingIndicator),
            2, "Parameter Switching Indicator");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Emergency Alarm Broadcasting
 * Purpose:  This function reads the TMCC Emergency Alarm Broadcasting in
 *           Overview measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCEmergencyAlarmBroadcasting(
                            ViSession instrSession,
                            ViBoolean *emergencyAlarmBroadcasting)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_EMERGENCY_ALARM_BROADCASTING, emergencyAlarmBroadcasting),
            2, "Emergency Alarm Broadcasting");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Current PartialReception
 * Purpose:  This function reads the TMCC Current Partial Reception in
 *           Overview measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCCurrentPartialReception(
                            ViSession instrSession,
                            ViBoolean *currentPartialReception)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CURRENT_PARTIAL_RECEPTION, currentPartialReception),
            2, "Current Partial Reception");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Next Partial Reception
 * Purpose:  This function reads the TMCC Next Partial Reception in Overview
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCNextPartialReception(
                            ViSession instrSession,
                            ViBoolean *nextPartialReception)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NEXT_PARTIAL_RECEPTION, nextPartialReception),
            2, "Next Partial Reception");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Phase Shift Correction
 * Purpose:  This function reads the TMCC Phase Shift Correction in Overview
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCPhaseShiftCorrection(
                            ViSession instrSession,
                            ViInt32   *phaseShiftCorrection)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PHASE_SHIFT_CORRECTION, phaseShiftCorrection),
            2, "Phase Shift Correction");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Reserved Bits
 * Purpose:  This function reads the TMCC Reserved Bits in Overview measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCReservedBits(ViSession instrSession,
                                                       ViInt32   *reservedBits)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_RESERVED_BITS, reservedBits),
            2, "Reserved Bits");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Modulation
 * Purpose:  This function reads "next or current information" for the
 *           specified layer and measurement value in the TMCC overview
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCModulation(ViSession instrSession,
                                                     ViInt32   information,
                                                     ViInt32   hierarchicalLayer,
                                                     ViInt32   *modulation)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            3, "Hierarchical Layer");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, information, RSETL_VAL_DTV_INFO_CURR, RSETL_VAL_DTV_INFO_NEXT),
            2, "Information");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", TMCCNextCurrArr[information] ,hierarchicalLayerArr[hierarchicalLayer]);

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_MODULATION, modulation),
            4, "Modulation");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Code Rate
 * Purpose:  This function reads "next or current information" for the
 *           specified layer and measurement value in the TMCC overview
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCCodeRate(ViSession instrSession,
                                                   ViInt32   information,
                                                   ViInt32   hierarchicalLayer,
                                                   ViInt32   *codeRate)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            3, "Hierarchical Layer");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, information, RSETL_VAL_DTV_INFO_CURR, RSETL_VAL_DTV_INFO_NEXT),
            2, "Information");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", TMCCNextCurrArr[information] ,hierarchicalLayerArr[hierarchicalLayer]);

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CODE_RATE, codeRate),
            4, "Code Rate");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Time Deinterleaver
 * Purpose:  This function reads "next or current information" for the
 *           specified layer and measurement value in the TMCC overview
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCTimeDeinterleaver(ViSession instrSession,
                                                            ViInt32   information,
                                                            ViInt32   hierarchicalLayer,
                                                            ViInt32   *timeDeinterleaver)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            3, "Hierarchical Layer");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, information, RSETL_VAL_DTV_INFO_CURR, RSETL_VAL_DTV_INFO_NEXT),
            2, "Information");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", TMCCNextCurrArr[information] ,hierarchicalLayerArr[hierarchicalLayer]);

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_TIME_DEINTERLEAVER, timeDeinterleaver),
            4, "Time Deinterleaver");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Overview TMCC Number Of Segments
 * Purpose:  This function reads "next or current information" for the
 *           specified layer and measurement value in the TMCC overview
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTOverviewTMCCNumberOfSegments(ViSession instrSession,
                                                           ViInt32   information,
                                                           ViInt32   hierarchicalLayer,
                                                           ViInt32   *numberOfSegments)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            3, "Hierarchical Layer");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, information, RSETL_VAL_DTV_INFO_CURR, RSETL_VAL_DTV_INFO_NEXT),
            2, "Information");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", TMCCNextCurrArr[information] ,hierarchicalLayerArr[hierarchicalLayer]);

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NUMBER_OF_SEGMENTS, numberOfSegments),
            4, "Number Of Segments");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries if the decoded physical layer pipe (PLP) is available and locked.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR state/Returns sync state.
ViStatus rsetl_QueryCATVDVBT2PLPSyncState(ViSession instrSession,
                                          ViBoolean *state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_DVB_PLP_SYNC_STATE_RESULT, state),
            2, "State");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function returns the result value for DVB-T2 measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR result/Returns the result value.
ViStatus rsetl_QueryCATVDVBT2OverviewResult(ViSession instrSession,
                                            ViInt32   measurement,
                                            ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, RSETL_VAL_DTV_RES_MRLO, RSETL_VAL_DTV_RES_TFER),
            2, "Measurement");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", dtvDVBT2Res[measurement]);

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_DVB_T2_RESULT, result),
            3, "result");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function reads the result of the Echo Pattern Peak Values
/// HIFN  measurement with further information for DVB-T2 MISO signals.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR arrayLength/Number of array points requested.
/// HIPAR actualPoints/Number of points actually returned in the result array.
/// HIPAR level/Returns the measured level values.
/// HIPAR time/Returns the measured time values.
/// HIPAR group/Returns the measured group values.
/// HIPAR SFN/Returns the measured SFN values.
ViStatus rsetl_QueryCATVDVBT2EPPVMeasurementResult(ViSession instrSession,
                                                   ViInt32   arrayLength,
                                                   ViInt32*  actualPoints,
                                                   ViReal64  level[],
                                                   ViReal64  time[],
                                                   ViReal64  group[],
                                                   ViReal64  SFN[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:DTV:RES:BFIL? T2M");
    checkErr(RsCore_QueryFloatArraysInterleavedToUserBuffer(instrSession, cmd, arrayLength, actualPoints, level, time, group, SFN, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the Bandwidth extension.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR state/Returns Bandwidth extension state.
ViStatus rsetl_QueryCATVDL1PreBandwidthExtension(ViSession instrSession,
                                                 ViBoolean *state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_L1_BANDWIDTH_EXTENSION_RESULT, state),
            2, "State");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the Guard interval.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR guardInterval/Returns Guard interval.
ViStatus rsetl_QueryCATVDL1PreGuardInterval(ViSession instrSession,
                                            ViInt32   *guardInterval)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_GUARD_INTERVAL_RESULT, guardInterval),
            2, "Guard Interval");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the Pilot pattern.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR pattern/Returns Pilot pattern.
ViStatus rsetl_QueryCATVDL1PrePilotPattern(ViSession instrSession,
                                           ViInt32   *pattern)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_PILOT_PATTERN_RESULT, pattern),
            2, "Pattern");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the Transmission system.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR transmissionSystem/Returns Transmission system.
ViStatus rsetl_QueryCATVDL1PreTransmissionSystem(ViSession instrSession,
                                                 ViInt32   *transmissionSystem)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_TRANSMISSION_SYSTEM_RESULT, transmissionSystem),
            2, "Transmission System");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the T2 version.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR bufferSize/Sets the size of buffer allocated for result.
/// HIPAR version/Returns T2 version.
ViStatus rsetl_QueryCATVDL1PreT2Version(ViSession instrSession,
                                        ViInt32   bufferSize,
                                        ViChar    version[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_L1_T2_VERSION_RESULT,
            bufferSize, version),
            3, "Version");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN unction queries the T2 frame related fields.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR frameCount/Returns number of frames per superframe.
/// HIPAR symbolsPerFrame/Returns number of data symbols per T2�frame.
ViStatus rsetl_QueryCATVDL1PreT2Frame(ViSession instrSession,
                                      ViInt32   *frameCount,
                                      ViInt32   *symbolsPerFrame)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "FrameCount", RSETL_ATTR_CATV_DTV_L1_T2_FRAME_RESULT, frameCount),
            2, "Frame Count");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "SymPerFrame", RSETL_ATTR_CATV_DTV_L1_T2_FRAME_RESULT, symbolsPerFrame),
            3, "Symbols Per Frame");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries L1-post signaling related fields carried in L1-pre signalization.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR constellation/Returns L1-post constellation.
/// HIPAR size/Returns L1-post size.
/// HIPAR extension/Returns L1-post extension state.
/// HIPAR repetition/Returns L1-post repetition.
/// HIPAR codeRate/Returns L1-post code rate.
/// HIPAR FECType/Returns L1-post FEC type.
/// HIPAR infoSize/Returns L1-post info size.
ViStatus rsetl_QueryCATVDL1PreL1Post(ViSession instrSession,
                                     ViInt32   *constellation,
                                     ViInt32   *size,
                                     ViBoolean *extension,
                                     ViBoolean *repetition,
                                     ViInt32   *codeRate,
                                     ViInt32   *FECType,
                                     ViInt32   *infoSize)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_POST_CONSTELATION_RESULT, constellation),
            2, "Constellation");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "Size", RSETL_ATTR_CATV_DTV_L1_POST_SIZE_RESULT, size),
            3, "Size");

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_L1_POST_EXTENSION_RESULT, extension),
            4, "Extension");

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "", RSETL_ATTR_CATV_DTV_L1_POST_REPETITION_RESULT, repetition),
            5, "Repetition");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_POST_CODE_RATE_RESULT, codeRate),
            6, "Code Rate");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_POST_FEC_TYPE_RESULT, FECType),
            7, "FEC Type");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "InfoSize", RSETL_ATTR_CATV_DTV_L1_POST_SIZE_RESULT, infoSize),
            8, "Info Size");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the method for reducing peak to average power ratio.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR PAPR/Returns PAPR.
ViStatus rsetl_QueryCATVDL1PrePAPR(ViSession instrSession,
                                   ViInt32   *PAPR)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_PAPR_RESULT, PAPR),
            2, "PAPR");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the stream type for the L1-pre Signalling measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR streamType/Returns stream type.
ViStatus rsetl_QueryCATVDL1PreStreamType(ViSession instrSession,
                                         ViInt32   *streamType)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_STREAM_TYPE_RESULT, streamType),
            2, "Stream Type");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the value of S1 and S2 bits (it's also transmitted in P1�symbol).
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR s1/Returns value of S1 bits.
/// HIPAR s2/Returns value of S2 bits.
ViStatus rsetl_QueryCATVDL1PreSBits(ViSession instrSession,
                                    ViInt32   *s1,
                                    ViInt32   *s2)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "S1", RSETL_ATTR_CATV_DTV_L1_S_BIT_RESULT, s1),
            2, "s1");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "S2", RSETL_ATTR_CATV_DTV_L1_S_BIT_RESULT, s2),
            3, "s2");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the ID value.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR systemID/Returns system ID.
/// HIPAR cellID/Returns cell ID.
/// HIPAR networkID/Returns network ID.
/// HIPAR TXIDAvailability/Returns TX ID Availability.
ViStatus rsetl_QueryCATVDL1PreID(ViSession instrSession,
                                 ViInt32   *systemID,
                                 ViInt32   *cellID,
                                 ViInt32   *networkID,
                                 ViInt32   *TXIDAvailability)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "System", RSETL_ATTR_CATV_DTV_L1_ID_RESULT, systemID),
            2, "System ID");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "Cell", RSETL_ATTR_CATV_DTV_L1_ID_RESULT, cellID),
            3, "Cell ID");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "Network", RSETL_ATTR_CATV_DTV_L1_ID_RESULT, networkID),
            4, "Network ID");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "TX", RSETL_ATTR_CATV_DTV_L1_ID_RESULT, TXIDAvailability),
            5, "TX ID Availability");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the Regeneration Flag.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR regenerationFlag/Returns regeneration flag.
ViStatus rsetl_QueryCATVDL1PreRegenerationFlag(ViSession instrSession,
                                               ViInt32   *regenerationFlag)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_REGENERATION_FLAG_RESULT, regenerationFlag),
            2, "Regeneration Flag");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the frequencies count.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR frequenciesCount/Returns frequencies count.
ViStatus rsetl_QueryCATVDL1PreFrequenciesCount(ViSession instrSession,
                                               ViInt32   *frequenciesCount)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_FREQUENCIES_COUNT_RESULT, frequenciesCount),
            2, "Frequencies Count");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the RF Index.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR RFIndex/Returns RF Index.
ViStatus rsetl_QueryCATVDL1PreRFIndex(ViSession instrSession,
                                      ViInt32   *RFIndex)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_RF_INDEX_RESULT, RFIndex),
            2, "RF Index");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the CRC.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR CRC/Returns CRC value.
ViStatus rsetl_QueryCATVDL1PreCRC(ViSession instrSession,
                                  ViUInt32  *CRC)
{
    ViStatus error = VI_SUCCESS;
    ViChar   response[RS_MAX_SHORT_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringShort(instrSession, "CALC:DTV:RES:L1PR? RES", response));

    sscanf (response,"%lx", CRC);

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the reserved bits.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR reservedBits/Returns reserved bits.
ViStatus rsetl_QueryCATVDL1PreReservedBits(ViSession instrSession,
                                           ViInt32   *reservedBits)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_L1_RESERVED_BITS_RESULT, reservedBits),
            2, "Reserved Bits");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the a list of L1-post signalling parameters of
/// HIFN the currently decoded physical layer pipe (PLP).
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR bufferSize/Sets the size of buffer allocated for result.
/// HIPAR decodedPLP/Returns list of L1-post signalling parameters.
ViStatus rsetl_QueryCATVDL1PostDecodedPLP(ViSession instrSession,
                                          ViInt32   bufferSize,
                                          ViChar    decodedPLP[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "DecodedPLP", RSETL_ATTR_CATV_DTV_L1_POST_SIGNALING_RESULT,
            bufferSize, decodedPLP),
            3, "Decoded PLP");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the list of L1-post signalling parameters of all
/// HIFN physical layer pipes (PLP) available in the received signal.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR bufferSize/Sets the size of buffer allocated for result.
/// HIPAR allDecodedPLP/Returns list of L1-post signalling parameters. The values are separated by commas.
ViStatus rsetl_QueryCATVDL1PostAllDecodedPLP(ViSession instrSession,
                                             ViInt32   bufferSize,
                                             ViChar    allDecodedPLP[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "AllPLP", RSETL_ATTR_CATV_DTV_L1_POST_SIGNALING_RESULT,
            bufferSize, allDecodedPLP),
            3, "All Decoded PLP");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the list of L1-post signalling parameters from
/// HIFN pane 2 and 3 of the L1-post signalling measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR bufferSize/Sets the size of buffer allocated for result.
/// HIPAR signallingParameters/Returns list of L1-post signalling parameters.
ViStatus rsetl_QueryCATVDL1PostSignallingParameters(ViSession instrSession,
                                                    ViInt32   bufferSize,
                                                    ViChar    signallingParameters[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "Common", RSETL_ATTR_CATV_DTV_L1_POST_SIGNALING_RESULT,
            bufferSize, signallingParameters),
            3, "Signalling Parameters");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries if the TV signal is available and locked.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR channel/This control selects the channel/ensemble.
/// HIPAR state/Returns synchronization state.
ViStatus rsetl_QueryCATVDATSCMHSyncState(ViSession instrSession,
                                         ViInt32   channel,
                                         ViBoolean *state)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", ATSCChannelArr[channel]);


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_SYNC_STATE_RESULT, state),
            3, "State");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the Overview measurement result of the ATSC-M/H TV standard.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR channel/This control selects the channel/ensemble.
/// HIPAR measurement/This control selects the measurement result.
/// HIPAR result/Returns the result value.
/// HIPAR target/Returns the result value.
/// HIPAR progress/Returns the result value.
ViStatus rsetl_QueryCATVDATSCMHOverviewResult(ViSession instrSession,
                                              ViInt32   channel,
                                              ViInt32   measurement,
                                              ViReal64  *result,
                                              ViReal64  *target,
                                              ViReal64  *progress)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 3),
            2, "Channel");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 3),
            3, "Measurement");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", ATSCChannelArr[channel],ATSCMeasurementArr[measurement]);


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_RESULT, result),
            4, "Result");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_TARGET, target),
            5, "Target");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_PROGRESS, progress),
            6, "Progress");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the bit rate of selected channel of the ATSC-M/H TV standard.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR channel/This control selects the channel/ensemble.
/// HIPAR bitRate/Returns the bit rate.
ViStatus rsetl_QueryCATVDATSCMHBitRate(ViSession instrSession,
                                       ViInt32   channel,
                                       ViReal64  *bitRate)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 5),
            2, "Channel");

    switch (channel){
        case RSETL_VAL_DTV_ATSC_PRI:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,Ensemble", ATSCChannelArr[channel]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_ENS_SIG_BIT_RATE_RESULT, bitRate),
                    3, "Bit Rate");
        break;
        case RSETL_VAL_DTV_ATSC_SEC:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,Ensemble", ATSCChannelArr[channel]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_ENS_SIG_BIT_RATE_RESULT, bitRate),
                    3, "Bit Rate");
        break;
        case RSETL_VAL_DTV_ATSC_TPC:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,Signaling", ATSCChannelArr[channel]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_ENS_SIG_BIT_RATE_RESULT, bitRate),
                    3, "Bit Rate");
        break;
        case RSETL_VAL_DTV_ATSC_FIC:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,Signaling", ATSCChannelArr[channel]);
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_ENS_SIG_BIT_RATE_RESULT, bitRate),
                    3, "Bit Rate");
        break;
        case RSETL_VAL_DTV_ATSC_PAYLOAD:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Payload");
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_PAY_PAR_BIT_RATE_RESULT, bitRate),
                    3, "Bit Rate");
        break;
        case RSETL_VAL_DTV_ATSC_PARADE:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Parade");
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_CATV_DTV_ATSC_PAY_PAR_BIT_RATE_RESULT, bitRate),
                    3, "Bit Rate");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This functions queries the nubmer of available M/H services.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR count/Returns number of M/H services.
ViStatus rsetl_QueryCATVDATSCMHServicesCount(ViSession instrSession,
                                             ViInt32   *count)
{
    ViStatus error = VI_SUCCESS;
    ViChar   response[RS_MAX_SHORT_MESSAGE_BUF_SIZE];
    ViInt32  data;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringShort(instrSession, "CALC:DTV:RES:ATSM:SERV:OVER?", response));

    data = strncmp (response, "N/A", 3);
    if (data == 0)
    {
        *count = RS_VAL_NAN_VI_INT32;
    }
    else
    {
        *count = RsCore_Convert_String_To_ViInt32(response);
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This functions queries the M/H service parameters listed in the M/H service Overview measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR numberOfServices/Sets the number of values allocated for each result array.
/// HIPAR serviceID/Returns the M/H service ID.
/// HIPAR serviceName/Returns the short M/H service name length (SLT).
/// HIPAR category/Returns the M/H service category (SLT).
/// HIPAR ensembleID/Returns the ensemble ID.
/// HIPAR paradeID/Returns the parade ID.
/// HIPAR returnedValues/Returns number of results returned from the instrument.
ViStatus rsetl_QueryCATVDATSCMHOverviewServices(ViSession instrSession,
                                                ViInt32   numberOfServices,
                                                ViReal64  serviceID[],
                                                ViString  *serviceName,
                                                ViInt32   category[],
                                                ViInt32   ensembleID[],
                                                ViInt32   paradeID[],
                                                ViInt32   *returnedValues)
{
    ViStatus error = VI_SUCCESS;
    ViChar   *response = NULL;
    ViChar   *p2buf;
    ViInt32  i = 0;
    ViInt32  data = 0;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringUnknownLength(instrSession, "CALC:DTV:RES:ATSM:SERV:OVER?", &response));

    data = strncmp (response, "N/A", 3);
    p2buf = strtok (response, ",");

    while ((p2buf != NULL) && (i<numberOfServices))
    {
        if (!data)
        {
            serviceID[i] = RS_VAL_NAN_VI_REAL64;
            serviceName[i] = "N/A";
            category[i] = RS_VAL_NAN_VI_INT32;
            ensembleID[i] = RS_VAL_NAN_VI_INT32;
            paradeID[i++] = RS_VAL_NAN_VI_INT32;
            p2buf = strtok (NULL, ",");
        }
        else
        {
            p2buf = strtok (NULL, ",");
            p2buf = strtok (NULL, ",");
            serviceID[i] = RsCore_Convert_String_To_ViReal64(p2buf);

            p2buf = strtok (NULL, ",");
            sprintf (serviceName[i],"%s", p2buf);

            p2buf = strtok (NULL, ",");
            category[i] = RsCore_Convert_String_To_ViInt32(p2buf);

            p2buf = strtok (NULL, ",");
            ensembleID[i] = RsCore_Convert_String_To_ViInt32(p2buf);

            p2buf = strtok (NULL, ",");
            paradeID[i++] = RsCore_Convert_String_To_ViInt32(p2buf);
        }
    }

    *returnedValues = i;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (response)
        free(response);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This functions queries the measurement results of the TPC signaling analysis.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR parade/Reserved for future use.
/// HIPAR arraySize/Sets the number of values allocated for result array.
/// HIPAR result/Returns array of Pradade data.
/// HIPAR FICVersion/Returns the FIC version.
/// HIPAR TPCVersion/Returns the TPC protocol version.
/// HIPAR returnedValues/Returns number of results returned from the instrument.
ViStatus rsetl_QueryCATVDTPCDecodedParade(ViSession instrSession,
                                          ViInt32   parade,
                                          ViInt32   arraySize,
                                          ViInt32   result[],
                                          ViInt32   *FICVersion,
                                          ViReal64  *TPCVersion,
                                          ViInt32   *returnedValues)
{
    ViStatus error = VI_SUCCESS;
    ViChar   *buffer = NULL;
    ViChar   *p2buf;
    ViInt32  i = 0;
    ViInt32  data = 0;
    ViUInt32 aux;
             parade;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringUnknownLength(instrSession, "CALC:DTV:RES:ATSM:TPC:ANAL? DPAR", &buffer));

    data = strncmp (buffer, "---", 3);

    if (!data)
    {
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        if (i < arraySize) result[i++] = RS_VAL_NAN_VI_INT32;
        *FICVersion = RS_VAL_NAN_VI_INT32;
        *TPCVersion = RS_VAL_NAN_VI_REAL64;
    }
    else
    {
        p2buf = strtok (buffer, ",");
        if (i < arraySize)
            result[i++] = RsCore_Convert_String_To_ViInt32(p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_FindStringIndex(frameModeArr, p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_FindStringIndex(codeModeArr, p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_FindStringIndex(codeModeArr, p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_FindStringIndex(blockModeArr, p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_FindStringIndex(SCCCModeArr, p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_FindStringIndex(SCCCModeArr, p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_FindStringIndex(SCCCModeArr, p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_FindStringIndex(SCCCModeArr, p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_Convert_String_To_ViInt32(p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_Convert_String_To_ViInt32(p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
            result[i++] = RsCore_Convert_String_To_ViInt32(p2buf);

        p2buf = strtok (NULL, ",");
        if (i < arraySize)
        {
            (void)sscanf(p2buf, _PERCX, &aux);
            result[i++] = aux;
        }

        p2buf = strtok (NULL, ",");
        *FICVersion = RsCore_Convert_String_To_ViInt32(p2buf);

        p2buf = strtok (NULL, ",");
        *TPCVersion = RsCore_Convert_String_To_ViReal64(p2buf);
    }

    *returnedValues = i;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (buffer)
        free(buffer);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This functions queries all measurement results of the TPC signaling analysis.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR numberOfParades/Determines the count of pardes read from instrument and number of values allocated for result array.
/// HIPAR arraySize/Sets the number of values allocated for each parade (array) in result array.
/// HIPAR result/Returns array of Pradade data.
/// HIPAR FICVersion/Returns array of the FIC version.
/// HIPAR TPCVersion/Returns array of the TPC protocol version.
/// HIPAR returnedValues/Returns number of results returned from the instrument.
/// HIPAR returnedParades/Returns number of results returned from the instrument.
ViStatus rsetl_QueryCATVDTPCAllDecodedParades(ViSession instrSession,
                                              ViInt32   numberOfParades,
                                              ViInt32   arraySize,
                                              ViInt32   result[],
                                              ViInt32   FICVersion[],
                                              ViReal64  TPCVersion[],
                                              ViInt32   *returnedValues,
                                              ViInt32   *returnedParades)
{
    ViStatus error = VI_SUCCESS;
    ViChar   *response = NULL;
    ViChar   *p2buf;
    ViUInt32 aux;
    ViInt32  n = 0;
    ViInt32  i = 0;
    ViInt32  j = 0;
    ViInt32  data = 0;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringUnknownLength(instrSession, "CALC:DTV:RES:ATSM:TPC:ANAL? APAR", &response));

    data = strncmp (response, "---", 3);
    p2buf = strtok (response, ",");
    while ((p2buf != NULL) && (j<numberOfParades))
    {
        n = 0;
        if (!data)
        {
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            if (n < arraySize){
                result[i++] = RS_VAL_NAN_VI_INT32; n++;} ;
            FICVersion[j] = RS_VAL_NAN_VI_INT32;
            TPCVersion[j] = RS_VAL_NAN_VI_REAL64;
            p2buf = strtok (NULL, ",");
        }
        else
        {
            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_Convert_String_To_ViInt32(p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_FindStringIndex(frameModeArr, p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_FindStringIndex(codeModeArr, p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_FindStringIndex(codeModeArr, p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_FindStringIndex(blockModeArr, p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_FindStringIndex(SCCCModeArr, p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_FindStringIndex(SCCCModeArr, p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_FindStringIndex(SCCCModeArr, p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_FindStringIndex(SCCCModeArr, p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_Convert_String_To_ViInt32(p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_Convert_String_To_ViInt32(p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize){
                result[i++] = RsCore_Convert_String_To_ViInt32(p2buf); n++;}

            p2buf = strtok (NULL, ",");
            if (n < arraySize)
            {
                (void)sscanf(p2buf, _PERCX, &aux);
                result[i++] = aux;
                n++;
            }

            p2buf = strtok (NULL, ",");
            FICVersion[j] = RsCore_Convert_String_To_ViInt32(p2buf);

            p2buf = strtok (NULL, ",");
            TPCVersion[j] = RsCore_Convert_String_To_ViReal64(p2buf);
        }
        j++;
    }

    *returnedValues = n;
    *returnedParades = j;
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (response)
        free(response);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This functions queries the Subframe structure.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR numberOfSubframes/Defines the number of subframe read from instriment and number
/// HIPAR numberOfSubframes/of values allocated for result array.
/// HIPAR numberOfSlots/Sets the number of values allocated for each slot in result array.
/// HIPAR result/Returns array of Pradade data.
/// HIPAR subframeUsage/Returns the usage of M/H subframe for M/H data.
/// HIPAR returnedSlots/Returns number of results returned from the instrument.
/// HIPAR returnedSubframes/Returns number of results returned from the instrument.
ViStatus rsetl_QueryCATVDTPCAllSubframesStructure(ViSession instrSession,
                                                  ViInt32   numberOfSubframes,
                                                  ViInt32   numberOfSlots,
                                                  ViInt32   result[],
                                                  ViReal64  *subframeUsage,
                                                  ViInt32   *returnedSlots,
                                                  ViInt32   *returnedSubframes)
{
    ViStatus error = VI_SUCCESS;
    ViChar   *response = NULL;
    ViChar   *p2buf;
    ViInt32  data = 0;
    ViInt32  n = 0;
    ViInt32  i = 0;
    ViInt32  j = 0;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringUnknownLength(instrSession, "CALC:DTV:RES:ATSM:TPC:ANAL? SFST", &response));

    data = strncmp (response, "---", 3);

    p2buf = strtok (response, ",");
    p2buf = strtok (NULL, ",");
    p2buf = strtok (NULL, ",");
    if (!data)
        *subframeUsage = RS_VAL_NAN_VI_REAL64;
    else
        *subframeUsage = RsCore_Convert_String_To_ViReal64(p2buf);

    do
    {
        n = 0;
        do
        {
            if (!data)
                result[i++] = RS_VAL_NAN_VI_INT32;
            else{
                p2buf = strtok (NULL, ",");
                result[i++] = RsCore_Convert_String_To_ViInt32(p2buf);
            }
            n++;
        }while ((p2buf != NULL) && (n<numberOfSlots) && (n<15));

        j++;
    }while ((p2buf != NULL) && (j<numberOfSubframes));

    *returnedSlots = n;
    *returnedSubframes = j;
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (response)
        free(response);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the list of all FIC parameters of the all ensembles contained in the decoded parade are provided.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR bufferSize/Sets the size of buffer allocated for result.
/// HIPAR FICParameters/Returns list of FIC parameters of the all ensembles contained in the decoded parade.
ViStatus rsetl_QueryCATVDFICParametersDecodedParade(ViSession instrSession,
                                                    ViInt32   bufferSize,
                                                    ViChar    FICParameters[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_ATSC_FIC_DECODED_PARADE_RESULT,
            bufferSize, FICParameters),
            3, "FIC Parameters");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the list of all FIC parameters of all ensembles in all parades.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR bufferSize/Sets the size of buffer allocated for result.
/// HIPAR FICParameters/Returns the list of all FIC parameters of all ensembles in all parades.
ViStatus rsetl_QueryCATVDFICParametersAllParades(ViSession instrSession,
                                                 ViInt32   bufferSize,
                                                 ViChar    FICParameters[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_CATV_DTV_ATSC_FIC_ALL_PARADE_RESULT,
            bufferSize, FICParameters),
            3, "FIC Parameters");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Overview Limit Result
 * Purpose:  This function returns the check limit result.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDOverviewLimitResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViInt32   limitType,
                                             ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 19),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }

    switch (measurement){
        case RSETL_VAL_DTV_MERR:
        case RSETL_VAL_DTV_MERP:
        case RSETL_VAL_DTV_EVMR:
        case RSETL_VAL_DTV_EVMP:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", DTVMeasArr[measurement], NULL);
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ERROR_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_CFOF:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_SROF:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_BBV:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BBV_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_BBRS:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BBRS_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_BROF:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_BROF_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIM:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_LEVEL_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_PER:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_PER_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_PERR:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_PERR_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_BERL:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BER_LDPC_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_BBCH:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BER_BBCH_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_MRLO:

             viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_MRLO_RESULT, result),
                     4, "Result");
        break;
        case RSETL_VAL_DTV_MPLO:
             viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_MPLO_RESULT, result),
                     4, "Result");
        break;
        case RSETL_VAL_DTV_MRPL:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_MRPL_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_MPPL:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_MPPL_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_ERPL:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_ERPL_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_EPPL:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_EPPL_RESULT, result),
                    4, "Result");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the limit of the ATSC-M/H TV standard in the overview.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR channel/This control selects the channel/ensemble.
/// HIPAR measurement/This control selects the type of the measurement.
/// HIPAR result/Returns the limit check result.
ViStatus rsetl_QueryCATVDATSCMHOverviewLimit(ViSession instrSession,
                                             ViInt32   channel,
                                             ViInt32   measurement,
                                             ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 3),
            2, "Channel");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 3),
            3, "Measurement");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", ATSCChannelArr[channel], ATSCMeasurementArr[measurement]);

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW_RESULT, result),
            4, "result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV Modulation Errors Limit Result
 * Purpose:  This function returns the check limit result.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDModulationErrorsLimitResult(ViSession instrSession,
                                                     ViInt32   measurement,
                                                     ViInt32   limitType,
                                                     ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
        break;
    }

    switch (measurement){
        case RSETL_VAL_DTV_MERR:
        case RSETL_VAL_DTV_MERP:
        case RSETL_VAL_DTV_EVMR:
        case RSETL_VAL_DTV_EVMP:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", DTVMeasArr[measurement], NULL);
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ERROR_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_IMB:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_IMB_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_QERR:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_QERR_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_SUP:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_CARR_LIM_CARR_SUPP_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_PJIT:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_PJIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_SNR:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_SNR_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_PILV:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_SPV:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_PAER:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_CNR:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_CNR_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_BVF:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BVF_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_BVM:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_LIM_BVM_RESULT, result),
                    4, "Result");
        break;

        case RSETL_VAL_DTV_MPFH:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT_RESULT, result),
                            4, "Result");
                break;
            }
        break;
        case RSETL_VAL_DTV_MPSI:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT, result),
                            4, "Result");
                break;
            }
        break;
        case RSETL_VAL_DTV_MRFH:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT_RESULT, result),
                            4, "Result");
                break;
            }
        break;
        case RSETL_VAL_DTV_MRSI:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_LIM_UPP:
                    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT, result),
                            4, "Result");
                break;
            }
        break;
        case RSETL_VAL_DTV_AMPN:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_IRR:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_PHIN:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT_RESULT, result),
                    4, "Result");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, measurement), 2, "Measurement");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Reference Oscillator
 * Purpose:  This function selects the source of the reference oscillator
 *           signal.
 *****************************************************************************/
ViStatus rsetl_ConfigureReferenceOscillator(ViSession instrSession,
                                            ViInt32   reference)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_ROSC_SOURCE, reference),
            2, "Reference");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure Output Measurement Mode
 * Purpose:  This function switches the source of the IF output between the
 *           demodulated signal and the IF signal.
 *****************************************************************************/
ViStatus rsetl_ConfigureOutputMeasurementMode(ViSession instrSession,
                                              ViInt32   measurementMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_OUTPUT_MEAS_MODE, measurementMode),
            2, "Measurement Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Power Supply
 * Purpose:  This function queries which of the available power supplies is in use.
 *****************************************************************************/
ViStatus rsetl_QueryPowerSupply(ViSession instrSession,
                                ViInt32   *powerSupply)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_SYSTEM_POWER_SUPPLY, powerSupply),
            2, "Power Supply");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Set Status Register
 * Purpose:  This function sets the Enable, NTransition, and PTransition bits
 *              of status questionable and operating registers.
 *
 *           Note:
 *
 *           (1) For detailed description of Status Reporting System see also
 *           operating manual.
 *****************************************************************************/
ViStatus rsetl_setStatusRegister(ViSession instrSession,
                                 ViInt32   registerOperation,
                                 ViInt32   selStatusReg,
                                 ViInt32   enable,
                                 ViInt32   pTransition,
                                 ViInt32   nTransition)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, registerOperation, 0, 2),
            2, "Register Oper");

    switch (registerOperation) {
        case 0:
            checkErr(RsCore_Write(instrSession, ":STAT:PRES"));
        break;
        case 1:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, selStatusReg, 0, 8),
                    3, "Questionable Register");

            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":STAT:QUES%s:ENAB %ld;PTR %ld;NTR %ld",
                selStatusRegArr[selStatusReg], enable, pTransition, nTransition);
            checkErr(RsCore_Write(instrSession, cmd));
        break;
        case 2:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, enable, 0, 65535),
                    4, "enable");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, pTransition, 0, 65535),
                    5, "pTransition");
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, nTransition, 0, 65535),
                    6, "nTransition");

            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":STAT:OPER:ENAB %ld;PTR %ld;NTR %ld",
                enable, pTransition, nTransition);
            checkErr(RsCore_Write(instrSession, cmd));
        break;
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get Status Register
 * Purpose:  This function contains the commands for the querying status
 *           reporting system.
 *
 *           Note:
 *
 *           For detailed description of Status Reporting System see also
 *           operating manual.
 *****************************************************************************/
ViStatus rsetl_getStatusRegister(ViSession instrSession,
                                 ViInt32   statusRegistersQuery,
                                 ViInt32*  registerValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, statusRegistersQuery, 0, 20),
            2, "Status Register Query");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":STAT:%s?", statusRegArr[statusRegistersQuery]);
    checkErr(RsCore_QueryViInt32(instrSession, cmd, registerValue));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Digital TV ISDB-T Limit Result
 * Purpose:  This function returns the check limit result for ISDB-T TV
 *           standard of the overview and modulation errors measurements.
 *****************************************************************************/
ViStatus rsetl_QueryCATVDISDBTLimitResult(ViSession instrSession,
                                          ViInt32   measurement,
                                          ViInt32   limitType,
                                          ViInt32   hierarchicalLayer,
                                          ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, hierarchicalLayer, RSETL_VAL_DTV_LAYER_A, RSETL_VAL_DTV_LAYER_C),
            4, "Hierarchical Layer");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, RSETL_VAL_LIM_LOW, RSETL_VAL_LIM_UPP),
            3, "Limit Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, RSETL_VAL_DTV_LIM_MERR, RSETL_VAL_DTV_LIM_BARS),
            2, "Measurement");

    switch (measurement)
    {
        case RSETL_VAL_DTV_LIM_MERR:
        case RSETL_VAL_DTV_LIM_MERP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", ISDBTmerrArr[measurement],hierarchicalLayerArr[hierarchicalLayer]);
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_RESULT, result),
                    5, "Result");
        break;
        case RSETL_VAL_DTV_LIM_MARM:
        case RSETL_VAL_DTV_LIM_MTRM:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", ISDBTmerrArr[measurement]);
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_CARRIERS_RESULT, result),
                    5, "Result");
        break;
        case RSETL_VAL_DTV_LIM_BARS:
            switch (limitType){
                case RSETL_VAL_LIM_LOW:
                    snprintf(repCap, RS_REPCAP_BUF_SIZE, "Low");
                break;
                case RSETL_VAL_LIM_UPP:
                    snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upp");
                break;
            }
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS_RESULT, result),
                    5, "Result");
        break;
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the measurement results of the Overview radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR result/Returns the measurement result.
ViStatus rsetl_QueryRadioOverviewResult(ViSession instrSession,
                                        ViInt32   measurement,
                                        ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 18),
            2, "Measurement");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", measOverviewArr[measurement]);
    switch (measurement){
        case RSETL_VAL_DTV_LIMIT_RF_LEVEL:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_OVERVIEW_LEVEL_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_CF_OFFSET:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_AM_MOD_DEPTH:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_MPX:
        case RSETL_VAL_DTV_LIMIT_DEV_DEMOD_L:
        case RSETL_VAL_DTV_LIMIT_DEV_DEMOD_R:
        case RSETL_VAL_DTV_LIMIT_DEV_MONO:
        case RSETL_VAL_DTV_LIMIT_DEV_STEREO:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_PILOT:
        case RSETL_VAL_DTV_LIMIT_PILOT_FREQ_OFFSET:
        case RSETL_VAL_DTV_LIMIT_PILOT_PHA_TO_S:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_PILOT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_RDS_DEV:
        case RSETL_VAL_DTV_LIMIT_RDS_FREQ_OFFSET:
        case RSETL_VAL_DTV_LIMIT_RDS_PHA_TO_PILOT:
        case RSETL_VAL_DTV_LIMIT_RDS_BER:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_RDS_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_DARC:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_OVERVIEW_DARC_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_CARR:
        case RSETL_VAL_DTV_LIMIT_SCA_SC_OFFSET:
        case RSETL_VAL_DTV_LIMIT_SCA_DEV_SCA:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_SCA_RESULT, result),
                    4, "Result");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries measurement results of the Audio Scope measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR positivePeak/Returns the result of positive peak value.
/// HIPAR negativePeak/Returns the negative response result value.
/// HIPAR meanPeak/Returns the mean peak result value.
/// HIPAR RMS/Returns the negative response result value.
ViStatus rsetl_QueryRadioAudioScopeMeasurementResult(ViSession instrSession,
                                                     ViReal64  *positivePeak,
                                                     ViReal64  *negativePeak,
                                                     ViReal64  *meanPeak,
                                                     ViReal64  *RMS)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "PPeak", RSETL_ATTR_RADIO_AUDIO_SCOPE_RESULT, positivePeak),
            2, "Positive Peak");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "NPeak", RSETL_ATTR_RADIO_AUDIO_SCOPE_RESULT, negativePeak),
            3, "Negative Peak");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "HPeak", RSETL_ATTR_RADIO_AUDIO_SCOPE_RESULT, meanPeak),
            4, "Mean Peak");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "RMS", RSETL_ATTR_RADIO_AUDIO_SCOPE_RESULT, RMS),
            5, "RMS");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries measurement results of the Frequency Response measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurementType/This control selects the measurement.
/// HIPAR channel/This control selects the channel.
/// HIPAR result/Returns the result value.
ViStatus rsetl_QueryRadioAudioSpectrumMeasurementResult(ViSession instrSession,
                                                        ViInt32   measurementType,
                                                        ViInt32   channel,
                                                        ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurementType, 0, 3),
            2, "Measurement Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 2),
            2, "Channel");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s", audioChannelArr[channel]);

    switch (measurementType){
        case RSETL_VAL_RADIO_SPEC_SINAD:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_SPECTRUM_RESULT_SINAD, result),
                    4, "Result");
        break;
        case RSETL_VAL_RADIO_SPEC_THD:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_SPECTRUM_RESULT_THD, result),
                    4, "Result");
        break;
        case RSETL_VAL_RADIO_SPEC_MOD_FREQ:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_SPECTRUM_RESULT_MOD_FREQ, result),
                    4, "Result");
        break;
        case RSETL_VAL_RADIO_SPEC_SC_FREQ_OFFSET:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_SPECTRUM_RESULT_SC_FREQ_OFFSET, result),
                    4, "Result");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries measurement results of the MPX Power & Peak Deviation radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR minimum/Returns the result value.
/// HIPAR current/Returns the result value.
/// HIPAR maximum/Returns the result value.
ViStatus rsetl_QueryRadioMPXPowerPeakMeasurementResult(ViSession instrSession,
                                                       ViInt32   measurement,
                                                       ViReal64  *minimum,
                                                       ViReal64  *current,
                                                       ViReal64  *maximum)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  mode;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT, &mode));

    switch (measurement)
    {
        case RSETL_VAL_RADIO_MPX_POWER:
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT, RSETL_VAL_RADIO_MPX_POWER));

        break;
        case RSETL_VAL_RADIO_PEAK_DEVIATION:
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT, RSETL_VAL_RADIO_PEAK_DEVIATION));
        break;
    }

    checkErr(RsCore_QueryTupleViReal64(instrSession, "CALC:RAD:RES:MPOW:MCM?", minimum, current, maximum, NULL));

    checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT, mode));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the temporal limit excess of the MPX Power
/// HIFN & Peak Deviation radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR tempExcess/Returns the temporal limit excess value.
ViStatus rsetl_QueryRadioMPXPowerPeakLimitExcessResult(ViSession instrSession,
                                                       ViInt32   measurement,
                                                       ViReal64  *tempExcess)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    switch (measurement){
        case RSETL_VAL_RADIO_MPX_POWER:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "MPower", RSETL_ATTR_RADIO_POWER_PEAK_LIMIT_RESULT, tempExcess),
                    3, "Temp Excess");
        break;
        case RSETL_VAL_RADIO_PEAK_DEVIATION:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, "PDeviation", RSETL_ATTR_RADIO_POWER_PEAK_LIMIT_RESULT, tempExcess),
                    3, "Temp Excess");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Query the measurement results of the MPX deviation violation radio
/// HIFN  measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR ratio/Query the measurement results of the MPX deviation violation radio
/// HIPAR ratio/measurement.
/// HIPAR samplesViolating/Query the measurement results of the MPX deviation violation radio
/// HIPAR samplesViolating/measurement.
/// HIPAR samplesTotal/Query the measurement results of the MPX deviation violation radio
/// HIPAR samplesTotal/measurement.
ViStatus rsetl_QueryRadioMPXDeviationViolationResult(ViSession instrSession,
                                                     ViReal64  *ratio,
                                                     ViInt32   *samplesViolating,
                                                     ViInt32   *samplesTotal)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

       viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_RATIO_RESULT, ratio),
               2, "Ratio");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_VIOLATING_RESULT, samplesViolating),
            3, "Samples Violating");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_TOTAL_RESULT, samplesTotal),
            4, "Samples Total");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN  Queries the actual number of raw samples taken into account for the
/// HIFN  current deviation distribution and cumulated deviation distribution
/// HIFN  results. The number is identical to the total samples in the deviation
/// HIFN  violation measurement
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR rawSamples/Queries the actual number of raw samples taken into account for the
/// HIPAR rawSamples/current deviation distribution and cumulated deviation distribution
/// HIPAR rawSamples/results. The number is identical to the total samples in the deviation
/// HIPAR rawSamples/violation measurement
ViStatus rsetl_QueryRadioMPXDeviationRawSamplesResult(ViSession instrSession,
                                                      ViInt32   *rawSamples)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

       viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_MPX_DEVIATION_RAW_VIOLATION_SAMPLES_RESULT, rawSamples),
               2, "Raw Samples");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries measurement results of the Multipath Detection radio measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR freqResponseGradient/Returns the result value.
/// HIPAR frequencyResponse/Returns the result value.
ViStatus rsetl_QueryRadioMultipathDetectionMeasurementResult(ViSession instrSession,
                                                             ViReal64  *freqResponseGradient,
                                                             ViReal64  *frequencyResponse)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "Grad", RSETL_ATTR_RADIO_MULTIPATH_DETECTION_RESULT, freqResponseGradient),
            2, "Freq Response Gradient");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "Resp", RSETL_ATTR_RADIO_MULTIPATH_DETECTION_RESULT, frequencyResponse),
            3, "Frequency Response");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Queries the occupied bandwidth of an FM radio signal.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR obwResult/Queries the occupied bandwidth of an FM radio signal.
ViStatus rsetl_QueryRadioOBWResult(ViSession instrSession,
                                   ViReal64* obwResult)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

       viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_RADIO_OBW_RESULT, obwResult),
               2, "Obw Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries Service related informations.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR syncStatus/Returns Sync Status code.
ViStatus rsetl_QueryRadioRDSSyncStatus(ViSession instrSession,
                                       ViInt32   *syncStatus)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_RDS_RESULT_SYNC, syncStatus),
            2, "Sync Status");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries Service related informations.
/// HIFN You may use multiple lines for documentation.
/// HIRET Document return value here.
/// HIRET You may use multiple lines for documentation.
/// HIPAR instrSession/Document parameter here.
/// HIPAR bufferSize/Sets the size of buffer allocated for Name and Country.
/// HIPAR PID/Returns Program identification.
/// HIPAR name/Returns the Program service name.
/// HIPAR ECC/Returns the Extended country code.
/// HIPAR country/Returns the textual translation of the the Country Code.
ViStatus rsetl_QueryRadioRDSService(ViSession instrSession,
                                    ViInt32   bufferSize,
                                    ViInt32   *PID,
                                    ViChar    name[],
                                    ViInt32   *ECC,
                                    ViChar    country[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_RDS_RESULT_PID, PID),
            3, "PID");

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_RADIO_RDS_RESULT_NAME,
            bufferSize, name),
            4, "Name");

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_RDS_RESULT_ECC, ECC),
            5, "ECC");

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_RADIO_RDS_RESULT_COUNTRY,
            bufferSize, country),
            6, "Country");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries Service related informations.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR bufferSize/Sets the size of buffer allocated for PTy(s).
/// HIPAR LAFlag/For future use.
/// HIPAR TPFlag/Returns state of Traffic program Flag.
/// HIPAR TAFlag/Returns state of Traffic announcement Flag.
/// HIPAR MSFlag/Returns state of Music/speech Flag.
/// HIPAR PTy_s/Returns program type with textual translation of the transmitted value.
ViStatus rsetl_QueryRadioRDSServiceDetails(ViSession instrSession,
                                           ViInt32   bufferSize,
                                           ViBoolean *LAFlag,
                                           ViBoolean *TPFlag,
                                           ViBoolean *TAFlag,
                                           ViBoolean *MSFlag,
                                           ViChar    PTy_s[])
{
    ViStatus error = VI_SUCCESS;
             LAFlag;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "TP", RSETL_ATTR_RADIO_RDS_RESULT_FLAG, TPFlag),
            4, "TPFlag");

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "TA", RSETL_ATTR_RADIO_RDS_RESULT_FLAG, TAFlag),
            5, "TAFlag");

    viCheckParm(rsetl_GetAttributeViBoolean(instrSession, "MS", RSETL_ATTR_RADIO_RDS_RESULT_FLAG, MSFlag),
            6, "MSFlag");

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_RADIO_RDS_RESULT_PTYPE,
            bufferSize, PTy_s),
            7, "PTy_s");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries Decoder information.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR stereo/Returns state of d0 bit (Stereo/Mono).
/// HIPAR artificialHead/Returns state of d1 bit (Artificial Head).
/// HIPAR compressed/Returns state of d2 bit (Compressed).
/// HIPAR dynamicallySwitchedPTY/Returns state of d3 bit (Dynamically switched PTY)..
ViStatus rsetl_QueryRadioRDSDecoderInformation(ViSession instrSession,
                                               ViBoolean *stereo,
                                               ViBoolean *artificialHead,
                                               ViBoolean *compressed,
                                               ViBoolean *dynamicallySwitchedPTY)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  val = 0;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_RDS_RESULT_DID, &val));

    *stereo = (val & 1)?VI_TRUE:VI_FALSE;
    *artificialHead = (val & 2)?VI_TRUE:VI_FALSE;
    *compressed = (val & 4)?VI_TRUE:VI_FALSE;
    *dynamicallySwitchedPTY = (val & 8)?VI_TRUE:VI_FALSE;

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries date and time.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR bufferSize/Sets the size of buffer allocated for PTy(s).
/// HIPAR date/Returns the transmitted date.
/// HIPAR localTime/Returns the transmitted local time.
/// HIPAR UTC/Returns the transmitted time in UTC.
ViStatus rsetl_QueryRadioRDSDateTime(ViSession instrSession,
                                     ViInt32   bufferSize,
                                     ViChar    date[],
                                     ViChar    localTime[],
                                     ViChar    UTC[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "Date", RSETL_ATTR_RADIO_RDS_RESULT_DATE_TIME,
            bufferSize, date),
            3, "Date");

    viCheckParm(rsetl_GetAttributeViString(instrSession, "LTime", RSETL_ATTR_RADIO_RDS_RESULT_DATE_TIME,
            bufferSize, localTime),
            3, "Local Time");

    viCheckParm(rsetl_GetAttributeViString(instrSession, "UTime", RSETL_ATTR_RADIO_RDS_RESULT_DATE_TIME,
            bufferSize, UTC),
            3, "UTC");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries measurement results of the Frequency Response measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR responseType/This control selects the respone type.
/// HIPAR channel/This control selects the channel.
/// HIPAR positive/Returns the positive response result value.
/// HIPAR negative/Returns the negative response result value.
ViStatus rsetl_QueryRadioFrequencyResponseMeasurementResult(ViSession instrSession,
                                                            ViInt32   responseType,
                                                            ViInt32   channel,
                                                            ViReal64  *positive,
                                                            ViReal64  *negative)
{
    ViStatus error = VI_SUCCESS;
    ViChar   buffer_positive[RS_MAX_MESSAGE_BUF_SIZE] = "";
    ViChar   buffer_negative[RS_MAX_MESSAGE_BUF_SIZE] = "";

    checkErr(RsCore_LockSession(instrSession));
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, responseType, 0, 2),
            2, "Response Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 2),
            3, "Channel");

    sprintf (buffer_positive, "%s,Positive", audioChannelArr[channel]);
    sprintf (buffer_negative, "%s,Negative", audioChannelArr[channel]);


    checkErr(RsCore_LockSession(instrSession));

    switch (responseType){
        case RSETL_VAL_RADIO_RESPONSE_FREQ:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_positive, RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_FREQUENCY, positive),
                    4, "Positive");

            viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_negative, RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_FREQUENCY, negative),
                    5, "Negative");

        break;
        case RSETL_VAL_RADIO_RESPONSE_AMP:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_positive, RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_AMPLIITUDE, positive),
                    4, "Positive");

            viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_negative, RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_AMPLIITUDE, negative),
                    5, "Negative");
        break;
        case RSETL_VAL_RADIO_RESPONSE_PHASE:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_positive, RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_PHASE, positive),
                    4, "Positive");

            viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_negative, RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_PHASE, negative),
                    5, "Negative");
        break;
    }

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries measurement results of the Crosstalk measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR channel/This control selects the channel.
/// HIPAR crosstalk/Returns the result value.
/// HIPAR frequency/Returns the result value.
ViStatus rsetl_QueryRadioCrosstalkMeasurementResult(ViSession instrSession,
                                                    ViInt32   channel,
                                                    ViReal64  *crosstalk,
                                                    ViReal64  *frequency)
{
    ViStatus error = VI_SUCCESS;
    ViChar   buffer_crosstalk[RS_MAX_MESSAGE_BUF_SIZE] = "";
    ViChar   buffer_frequency[RS_MAX_MESSAGE_BUF_SIZE] = "";

    checkErr(RsCore_LockSession(instrSession));
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 2),
            2, "Channel");

    sprintf (buffer_crosstalk, "%s,Crosstalk", audioChannelArr[channel]);
    sprintf (buffer_frequency, "%s,Frequency", audioChannelArr[channel]);


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_crosstalk, RSETL_ATTR_RADIO_CROSSTALK_RESULT, crosstalk),
            3, "Crosstalk");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_frequency, RSETL_ATTR_RADIO_CROSSTALK_RESULT, frequency),
            4, "Frequency");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the measurement results of the S/N measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR channel/This control selects the channel.
/// HIPAR result/Returns the result value.
ViStatus rsetl_QueryRadioSNMeasurementResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViInt32   channel,
                                             ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 7),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 2),
            3, "Channel");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", audioChannelArr[channel], audioMeasArr[measurement]);


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_SN_RESULT, result),
            3, "Result");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries measurement results of the THD measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR channel/This control selects the channel.
/// HIPAR audioFrequency/Returns the result value.
/// HIPAR deviation/Returns the result value.
/// HIPAR THD/Returns the result value.
ViStatus rsetl_QueryRadioTHDMeasurementResult(ViSession instrSession,
                                              ViInt32   channel,
                                              ViReal64  *audioFrequency,
                                              ViReal64  *deviation,
                                              ViReal64  *THD)
{
    ViStatus error = VI_SUCCESS;
    ViChar   buffer_frequency[RS_MAX_MESSAGE_BUF_SIZE] = "";
    ViChar   buffer_deviation[RS_MAX_MESSAGE_BUF_SIZE] = "";
    ViChar   buffer_THD[RS_MAX_MESSAGE_BUF_SIZE] = "";

    checkErr(RsCore_LockSession(instrSession));
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 2),
            2, "Channel");

    sprintf (buffer_frequency, "%s,AudioFreq", audioChannelArr[channel]);
    sprintf (buffer_deviation, "%s,Deviation", audioChannelArr[channel]);
    sprintf (buffer_THD, "%s,THD", audioChannelArr[channel]);


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_frequency, RSETL_ATTR_RADIO_THD_RESULT, audioFrequency),
            3, "Audio Frequency");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_deviation, RSETL_ATTR_RADIO_THD_RESULT, deviation),
            4, "Deviation");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, buffer_THD, RSETL_ATTR_RADIO_THD_RESULT, THD),
            5, "THD");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the measurement values of the bar graph of the THD measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR resultsLeftChannel/Returns the array of result values for left channel.
/// HIPAR resultsRightChannel/Returns the array of result values for right channel.
ViStatus rsetl_QueryRadioTHDMeasurementAllResults(ViSession instrSession,
                                                  ViReal64  resultsLeftChannel[],
                                                  ViReal64  resultsRightChannel[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryFloatArraysInterleavedToUserBuffer(instrSession,
        "CALC:RAD:RES:THD? ATHD", 10, NULL, resultsLeftChannel, resultsRightChannel, NULL, NULL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the measurement results of the DFD measurement of a FM transmitter.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR channel/This control selects the channel.
/// HIPAR result/Returns the result value.
ViStatus rsetl_QueryRadioDFDMeasurementResult(ViSession instrSession,
                                              ViInt32   measurement,
                                              ViInt32   channel,
                                              ViReal64  *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 5),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 2),
            3, "Channel");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "%s,%s", audioChannelArr[channel], audioDFDArr[measurement]);


    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_RADIO_DFD_RESULT, result),
            4, "Result");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function queries the measurement values of the bar graph of the DFD measurement.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR resultsLeftChannel/Returns the array of result values for left channel.
/// HIPAR resultsRightChannel/Returns the array of result values for right channel.
ViStatus rsetl_QueryRadioDFDMeasurementAllResults(ViSession instrSession,
                                                  ViReal64  resultsLeftChannel[],
                                                  ViReal64  resultsRightChannel[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryFloatArraysInterleavedToUserBuffer(instrSession, "CALC:RAD:RES:DFD? ADFD",
        6, NULL, resultsLeftChannel, resultsRightChannel, NULL, NULL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function returns the check limit result.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR limitType/This control selects the type of the limit.
/// HIPAR result/Returns the result value.
ViStatus rsetl_QueryRadioOverviewLimitResult(ViSession instrSession,
                                             ViInt32   measurement,
                                             ViInt32   limitType,
                                             ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 18),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            3, "Limit Type");

    switch (limitType){
        case RSETL_VAL_LIM_LOW:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Lower");
        break;
        case RSETL_VAL_LIM_UPP:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Upper");
        break;
    }
    switch (measurement){
        case RSETL_VAL_DTV_LIMIT_RF_LEVEL:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_CF_OFFSET:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_AM_MOD_DEPTH:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_MPX:
        case RSETL_VAL_DTV_LIMIT_DEV_DEMOD_L:
        case RSETL_VAL_DTV_LIMIT_DEV_DEMOD_R:
        case RSETL_VAL_DTV_LIMIT_DEV_MONO:
        case RSETL_VAL_DTV_LIMIT_DEV_STEREO:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", measOverviewArr[measurement], NULL);
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_PILOT:
        case RSETL_VAL_DTV_LIMIT_PILOT_FREQ_OFFSET:
        case RSETL_VAL_DTV_LIMIT_PILOT_PHA_TO_S:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", measOverviewArr[measurement], NULL);
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_RDS_DEV:
        case RSETL_VAL_DTV_LIMIT_RDS_FREQ_OFFSET:
        case RSETL_VAL_DTV_LIMIT_RDS_PHA_TO_PILOT:
        case RSETL_VAL_DTV_LIMIT_RDS_BER:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", measOverviewArr[measurement], NULL);
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_DARC:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_DTV_LIMIT_DEV_CARR:
        case RSETL_VAL_DTV_LIMIT_SCA_SC_OFFSET:
        case RSETL_VAL_DTV_LIMIT_SCA_DEV_SCA:
            RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", measOverviewArr[measurement], NULL);
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT_RESULT, result),
                    4, "Result");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function returns the check limit result.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR limitType/This control selects the type of the limit.
/// HIPAR result/Returns the result value.
ViStatus rsetl_QueryRadioModulationMeasurementLimitResult(ViSession instrSession,
                                                          ViInt32   measurement,
                                                          ViInt32   limitType,
                                                          ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 3),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 1, 1),
            3, "Limit Type");
    switch (measurement){
        case RSETL_VAL_RADIO_LIMIT_MPX_POW:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "MPower", RSETL_ATTR_RADIO_MPX_POW_PEAK_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_RADIO_LIMIT_MPX_PEAK_DEV:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "PDeviation", RSETL_ATTR_RADIO_MPX_POW_PEAK_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_RADIO_LIMIT_MP_RESPONSE:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "Resp", RSETL_ATTR_RADIO_MP_DETECTION_LIMIT_RESULT, result),
                    4, "Result");
        break;
        case RSETL_VAL_RADIO_LIMIT_MP_GRADIENT:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, "Grad", RSETL_ATTR_RADIO_MP_DETECTION_LIMIT_RESULT, result),
                    4, "Result");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function returns the check limit result.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR measurement/This control selects the measurement.
/// HIPAR channel/This control selects the channel.
/// HIPAR limitType/This control selects the type of the limit.
/// HIPAR result/Returns the result value.
ViStatus rsetl_QueryRadioAurdioMeasurementLimitResult(ViSession instrSession,
                                                      ViInt32   measurement,
                                                      ViInt32   channel,
                                                      ViInt32   limitType,
                                                      ViInt32   *result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 11),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 1, 2),
            3, "Channel");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limitType, 0, 1),
            4, "Limit Type");

    switch (channel){
        case RSETL_VAL_RADIO_CH_L:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Left");
        break;
        case RSETL_VAL_RADIO_CH_R:
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "Right");
        break;
    }

    RsCore_StrcatMaxLen(repCap, RS_REPCAP_BUF_SIZE, ",", audioMeasArr[measurement], NULL);

    switch (measurement){
        case RSETL_VAL_RADIO_LIMIT_SN_R15:
        case RSETL_VAL_RADIO_LIMIT_SN_Q15:
        case RSETL_VAL_RADIO_LIMIT_SN_QI15:
        case RSETL_VAL_RADIO_LIMIT_SN_MR1H:
        case RSETL_VAL_RADIO_LIMIT_SN_AP1H:
        case RSETL_VAL_RADIO_LIMIT_SN_P20:
        case RSETL_VAL_RADIO_LIMIT_SN_AQ20:
        case RSETL_VAL_RADIO_LIMIT_SN_AQI2:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_AUDIO_SN_LIMIT_RESULT, result),
                    5, "Result");
        break;
        case RSETL_VAL_RADIO_LIMIT_DFD_D2D:
        case RSETL_VAL_RADIO_LIMIT_DFD_D2DS:
        case RSETL_VAL_RADIO_LIMIT_DFD_D3:
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT_RESULT, result),
                    5, "Result");
        break;
        case RSETL_VAL_RADIO_LIMIT_THD:
            switch (channel){
                case RSETL_VAL_RADIO_CH_L:
                    snprintf(repCap, RS_REPCAP_BUF_SIZE, "Left");
                break;
                case RSETL_VAL_RADIO_CH_R:
                    snprintf(repCap, RS_REPCAP_BUF_SIZE, "Right");
                break;
            }
            viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_RADIO_AUDIO_THD_LIMIT_RESULT, result),
                    5, "Result");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Queries whether the OBW radio measurement value passes or fails its
/// HIFN  set limits.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR result/Queries whether the OBW radio measurement value passes or fails its
/// HIPAR result/set limits.
ViStatus rsetl_QueryRadioOBWUpperLimitResult(ViSession instrSession,
                                             ViInt32*  result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

       viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_RADIO_OBW_UPPER_LIMIT_RESULT, result),
               2, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Start Stop
 * Purpose:  This function configures the frequency range of the spectrum
 *           analyzer using start frequency and stop frequency. If start
 *           frequency is equal to the stop frequency, then the spectrum
 *           analyzer is in time-domain mode.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencyStartStop(ViSession instrSession,
                                              ViReal64  startFrequency,
                                              ViReal64  stopFrequency)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_START, startFrequency),
            2, "Start Frequency");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_STOP, stopFrequency),
            3, "Stop Frequency");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Center
 * Purpose:  This function configures the center frequency
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencyCenter(ViSession instrSession,
                                           ViReal64  centerFrequency)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_CENTER, centerFrequency),
            2, "Center Frequency");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Center Span
 * Purpose:  This function configures the frequency range of the spectrum
 *           analyzer using the center frequency and the frequency span.  If
 *           span corresponds to zero hertz, then the spectrum analyzer is in
 *           time-domain.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencyCenterSpan(ViSession instrSession,
                                               ViReal64  centerFrequency,
                                               ViReal64  span)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "FREQ:CENT %.12lf;:FREQ:SPAN %.12lf", centerFrequency, span);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Step Size
 * Purpose:  This function sets the step width of the center frequency.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencyStepSize(ViSession instrSession,
                                             ViReal64  stepSize)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_FREQUENCY_CENTER_LINK, RSETL_VAL_CENT_FREQ_LINK_OFF));
    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_CENTER_STEP, stepSize),
            2, "Step Size");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Step Size Coupling
 * Purpose:  This function couples the step size of the center frequency to
 *           the span (ON) or sets the value of the center frequency entered
 *           via [SENSe<1|2>:]FREQuency:CENTer:STEP (OFF).
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencyStepSizeCoupling(ViSession instrSession,
                                                     ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FREQUENCY_STEP_AUTO, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Coupling Factor
 * Purpose:  This function couples the step width of the center frequency to
 *           span (span >0) or to the resolution bandwidth (span = 0) or
 *           cancels the couplings and sets the coupling factor.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencyCouplingFactor(ViSession instrSession,
                                                   ViInt32   coupling,
                                                   ViInt32   couplingFactor)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_FREQUENCY_CENTER_LINK, coupling),
            2, "Coupling");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_FREQUENCY_CENTER_LINK_FACTOR, couplingFactor),
            3, "Coupling Factor");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Span Full
 * Purpose:  This function sets the frequency span in the analyzer mode to its
 *           maximum.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencySpanFull(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FREQUENCY_SPAN_FULL, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Mode
 * Purpose:  This function switches between frequency domain (SWEep) and
 *           time domain (CW | FIXed) in the spectrum analyzer mode.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencyMode(ViSession instrSession,
                                         ViInt32   frequencyMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_FREQUENCY_MODE, frequencyMode),
            2, "Frequency Mode");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Frequency Offset
 * Purpose:  This function configures the frequency offset attribute of the
 *           spectrum analyzer. This function affects the setting of the
 *           spectrum analyzer's absolute frequencies, such as start, stop,
 *           center, and marker. It does not affect values, which are the
 *           difference of frequencies, such as span and delta marker.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFrequencyOffset(ViSession instrSession,
                                           ViReal64  frequencyOffset)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_FREQUENCY_OFFSET, frequencyOffset),
            2, "Frequency Offset");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Sweep Coupling Auto
 * Purpose:  This function activates auto coupling of selected coupling
 *           method.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSweepCouplingAuto(ViSession instrSession,
                                             ViInt32   sweepCoupling)
{
    ViStatus error = VI_SUCCESS;
    ViAttr   attribute = 0;

    checkErr(RsCore_LockSession(instrSession));

    switch (sweepCoupling)
    {
        case  RSETL_VAL_COUPLING_RBW:
            attribute = RSETL_ATTR_RESOLUTION_BANDWIDTH_AUTO;
            break;

        case RSETL_VAL_COUPLING_VBW:
            attribute = RSETL_ATTR_VIDEO_BANDWIDTH_AUTO;
            break;

        case RSETL_VAL_COUPLING_SWEEP_TIME:
            attribute = RSETL_ATTR_SWEEP_TIME_AUTO;
            break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, sweepCoupling), 2, "Sweep Coupling");
    }

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", attribute, VI_TRUE),
            1, "Dummy");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Sweep Coupling
 * Purpose:  This function configures the coupling values of the spectrum
 *           analyzer.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSweepCoupling(ViSession instrSession,
                                         ViInt32   sweepCoupling,
                                         ViReal64  couplingValue)
{
    ViStatus error = VI_SUCCESS;
    ViAttr   attribute = 0;

    checkErr(RsCore_LockSession(instrSession));

    switch (sweepCoupling)
    {
        case RSETL_VAL_COUPLING_RBW:
            attribute = RSETL_ATTR_RESOLUTION_BANDWIDTH;
            break;

        case RSETL_VAL_COUPLING_VBW:
            attribute = RSETL_ATTR_VIDEO_BANDWIDTH;
            break;

        case RSETL_VAL_COUPLING_SWEEP_TIME:
            attribute = RSETL_ATTR_SWEEP_TIME;
            break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, sweepCoupling), 2, "Sweep Coupling");
    }

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", attribute, couplingValue),
            3, "Coupling Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Sweep Coupling Advanced
 * Purpose:  This function configures advanced parameters of coupling and
 *           sweeping.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSweepCouplingAdvanced(ViSession instrSession,
                                                 ViInt32   ratioSelection,
                                                 ViReal64  value)
{
    ViStatus error = VI_SUCCESS;
    ViAttr   attribute = 0;

    checkErr(RsCore_LockSession(instrSession));

    switch (ratioSelection)
    {
        case RSETL_VAL_COUPLING_RATIO_RBW:
            attribute = RSETL_ATTR_RESOLUTION_BANDWIDTH_RATIO;
            break;
        case RSETL_VAL_COUPLING_RATIO_VBW:
            attribute = RSETL_ATTR_VIDEO_BANDWIDTH_RATIO;
            break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, ratioSelection), 2, "Ratio Selection");
    }

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", attribute, value),
            3, "Value");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Filter Type
 * Purpose:  This function sets the filter type for the resolution bandwidth.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANFilterType(ViSession instrSession,
                                      ViInt32   filterType)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_RESOLUTION_BANDWIDTH_FILTER_TYPE, filterType),
            2, "Filter Type");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN VBW Mode
 * Purpose:  This function selects the position of the video filter in the
 *           signal path, provided that the resolution bandwidth is <=100 kHz.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANVBWMode(ViSession instrSession,
                                   ViInt32   videoFilterType)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_VIDEO_BANDWIDTH_TYPE, videoFilterType),
            2, "Video Filter Type");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Averaging
 * Purpose:  This function switches on or off the average calculation for the
 *           selected trace in the selected measurement window.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANAveraging(ViSession instrSession,
                                     ViInt32   trace,
                                     ViBoolean state)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_AVG_STATE, state),
            3, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Averaging Type
 * Purpose:  This function selects the type of average function. If Video is
 *           selected, the logarithmic power is averaged and, if Linear is
 *           selected, the power values are averaged before they are converted
 *           to logarithmic values.
 *           The type of average calculation is equally set for all traces in
 *           one measurement window.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANAveragingType(ViSession instrSession,
                                         ViInt32   averagingType)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_AVG_TYPE, averagingType),
            2, "Averaging Type");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Averaging Count
 * Purpose:  This function defines the number of measurements which contribute
 *           to the average value.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANAveragingCount(ViSession instrSession,
                                          ViInt32   averagingCount)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_AVG_COUNT, averagingCount),
            2, "Averaging Count");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Averaging Auto Count
 * Purpose:  This function selects a suitable number of counts for the
 *           selected measurement type.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANAveragingAutoCount(ViSession instrSession,
                                              ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_AVG_COUNT_AUTO, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Acquisition
 * Purpose:  This function configures the acquisition attributes of the
 *           spectrum analyzer.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANAcquisition(ViSession instrSession,
                                       ViBoolean sweepModeContinuous,
                                       ViInt32   numberOfSweeps)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_SWEEP_MODE_CONTINUOUS, sweepModeContinuous),
            2, "Sweep Mode Continuous");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_NUMBER_OF_SWEEPS, numberOfSweeps),
            3, "Number Of Sweeps");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Vertical Scale
 * Purpose:  This function configures the vertical scale of analyzer.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANVerticalScale(ViSession instrSession,
                                         ViInt32   verticalScale)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_VERTICAL_SCALE, verticalScale),
            2, "Vertical Scale");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Sweep Points
 * Purpose:  This function defines the number of measurement points for one
 *           sweep run.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSweepPoints(ViSession instrSession,
                                       ViInt32   sweepPoints)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_SWEEP_POINTS, sweepPoints),
            2, "Sweep Points");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Attenuation
 * Purpose:  This function configures the input attenuation.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANAttenuation(ViSession instrSession,
                                       ViBoolean attenuationAuto,
                                       ViReal64  attenuation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_ATTENUATION_AUTO, attenuationAuto),
            2, "Attenuation Auto");
    if (attenuationAuto == VI_FALSE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ATTENUATION, attenuation),
                3, "Attenuation");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Reference Level
 * Purpose:  This function configures the reference level
 *****************************************************************************/
ViStatus rsetl_ConfigureSANReferenceLevel(ViSession instrSession,
                                          ViReal64  referenceLevel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_REFERENCE_LEVEL, referenceLevel),
            2, "Reference Level");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Level
 * Purpose:  This function configures the vertical attributes of the spectrum
 *           analyzer.  This corresponds to attributes like amplitude units,
 *           input attenuation, input impedance, reference level, and reference
 *           level offset.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANLevel(ViSession instrSession,
                                 ViInt32   amplitudeUnits,
                                 ViReal64  inputImpedance,
                                 ViReal64  referenceLevel,
                                 ViReal64  referenceLevelOffset,
                                 ViBoolean attenuationAuto,
                                 ViReal64  attenuation)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_AMPLITUDE_UNITS, amplitudeUnits),
            2, "Amplitude Units");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_INPUT_IMPEDANCE, inputImpedance),
            3, "Input Impedance");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_REFERENCE_LEVEL_OFFSET, referenceLevelOffset),
            5, "Reference Level Offset");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_ATTENUATION_AUTO, attenuationAuto),
            6, "Attenuation Auto");
    if (attenuationAuto == VI_FALSE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_ATTENUATION, attenuation),
                7, "Attenuation");
    }

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_REFERENCE_LEVEL, referenceLevel),
            4, "Reference Level");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN IQ State
 * Purpose:  This function toggles the input between RF and I/Q. With ON, the
 *           input is switched to I/Q, with OFF to RF.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANIQState(ViSession instrSession,
                                   ViBoolean IQState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_INPUT_IQ_STATE, IQState),
            2, "IQ State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Unit
 * Purpose:  This function configures the unit for power.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANUnits(ViSession instrSession,
                                 ViInt32   units)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_UNIT_POWER, units),
            2, "Units");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trace
 * Purpose:  This function configures the trace to acquire.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTrace(ViSession instrSession,
                                 ViInt32   trace,
                                 ViInt32   traceType)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);
    switch (traceType){
        case RSETL_TRAC_MOD_BLANK:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_TRACE_STATE, VI_FALSE));
        break;
        default:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_TRACE_STATE, VI_TRUE));
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_TRACE_TYPE, traceType),
                    3, "Trace Type");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trace Detector
 * Purpose:  This function configures the trace detector.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTraceDetector(ViSession instrSession,
                                         ViInt32   trace,
                                         ViBoolean detectorTypeAuto,
                                         ViInt32   detectorType)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_DETECTOR_TYPE_AUTO, detectorTypeAuto),
            3, "Detector Type Auto");
    if (detectorTypeAuto == VI_FALSE)
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_DETECTOR_TYPE, detectorType),
                4, "Detector Type");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trace Reset Behavior
 * Purpose:  This function specifies whether or not the traces with peak or
 *           minimum value detection are reset after specific parameter
 *           changes.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTraceResetBehavior(ViSession instrSession,
                                              ViInt32   trace,
                                              ViBoolean resetatChange)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld", trace);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_TRACE_RESET_BEHAVIOR, resetatChange),
            3, "Reset At Change");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Store Trace to File
 * Purpose:  This function stores the selected trace (1 to 4) in the
 *           measurement window indicated by window in a file with ASCII
 *           format.
 *****************************************************************************/
ViStatus rsetl_SANStoreTraceToFile(ViSession instrSession,
                                   ViInt32   trace,
                                   ViString  fileName)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, fileName), 3, "File Name");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "MMEM:STOR:TRAC %ld,'%s'", trace, fileName);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Trace IQ Set
 * Purpose:  This function defines the settings of the analyzer hardware for
 *           the measurement of I/Q data. This allows setting the bandwidth of
 *           the analog filters in front of the A/D converter as well as
 *           setting the sample rate, trigger conditions and the record length.
 *
 *           Notes:
 *
 *           (1) Function Trace I/Q State (confTraceIQState) has to be
 *           switched ON before using this function.
 *****************************************************************************/
ViStatus rsetl_SANTraceIQSet(ViSession instrSession,
                             ViReal64  samplingRate,
                             ViInt32   triggerMode,
                             ViInt32   triggerSlope,
                             ViInt32   pretriggerSamples,
                             ViInt32   noOfSamples)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViReal64Range(instrSession, samplingRate, 10.0e3, 65.83e6), 2, "Sampling Rate");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, triggerSlope, 0, 1),
            4, "Trigger Slope");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, pretriggerSamples, -16253439, 523775), 5, "Pretrigger Samples");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, noOfSamples, 1, 523776),
            6, "No Of Samples");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":TRAC:IQ:SET NORM,0,%.12f,%s,%s,%ld,%ld", samplingRate, rsetl_rngTriggerSource.entries[triggerMode].cmdString,
            rsetl_rngPolarity.entries[triggerSlope].cmdString, pretriggerSamples, noOfSamples);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trace IQ Sample Rate
 * Purpose:  This function sets the sampling rate for the I/Q data acquisition.
 *           Thus the sample rate can be modified without affecting the other
 *           settings.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTraceIQSampleRate(ViSession instrSession,
                                             ViReal64  samplingRate)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_IQ_SAMPLE_RATE, samplingRate),
            2, "Sampling Rate");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trace IQ Data Acquisition
 * Purpose:  This function configures the trace IQ data acquisition.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTraceIQDataAcquisition(ViSession instrSession,
                                                  ViBoolean traceState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_IQ_DATA_STATE, traceState),
            2, "Trace State");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trace IQ Data Averaging
 * Purpose:  This function configures the trace IQ data averaging.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTraceIQDataAveraging(ViSession instrSession,
                                                ViBoolean averagingState,
                                                ViInt32   averagingCount)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_IQ_DATA_AVER_STATE, averagingState),
            2, "Averaging State");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_IQ_DATA_AVER_COUNT, averagingCount),
            3, "Averaging Count");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trace IQ Data Synchronization
 * Purpose:  This function activates the synchronization of I/Q data
 *           acquisition and trigger point. Prerequisites are that the I/Q
 *           data acquisition is activated using the TRACe<1|2>:IQ[:STATe]
 *           command and the sampling rate is set to 32 MHz. The synchronization
 *           ensures that the data acquisition starts always with the same
 *           phase shift to the trigger point. The constant phase shift is
 *           necessary for correct I/Q data averaging.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTraceIQDataSynchronization(ViSession instrSession,
                                                      ViBoolean synchronization)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_IQ_DATA_SYNC, synchronization),
            2, "Synchronization");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Copy Trace
 * Purpose:  This function copies one trace array to another trace array.  Any
 *           data in the destination trace is over written.
 *****************************************************************************/
ViStatus rsetl_SANCopyTrace(ViSession instrSession,
                            ViInt32   destinationTrace,
                            ViInt32   sourceTrace)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, destinationTrace, 1, 4),
            2, "Destination Trace");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, sourceTrace, 1, 4),
            3, "Source Trace");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "TRAC:COPY TRACE%ld,TRACE%ld", destinationTrace, sourceTrace);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Subtract Traces
 * Purpose:  This function configures subtraction of traces.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSubtractTraces(ViSession instrSession,
                                          ViReal64  position,
                                          ViBoolean traceMathState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRACE_MATH_POSITION, position),
            2, "Position");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_TRACE_MATH_STATE, traceMathState),
            3, "Trace Math State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SANSubtract Traces
 * Purpose:  This function subtracts the array elements of trace defined in
 *           argument Trace 2 from TRACE1 of the instrument and stores the
 *           result in the TRACE1.
 *****************************************************************************/
ViStatus rsetl_SANSubtractTraces(ViSession instrSession,
                                 ViInt32   trace2)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace2, 2, 4),
            2, "Trace 2");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:MATH (TRACE1-TRACE%ld)", trace2);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker
 * Purpose:  This function enables the active marker on the specified trace.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarker(ViSession instrSession,
                                  ViInt32   marker,
                                  ViBoolean markerEnabled,
                                  ViInt32   trace)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MARKER_ENABLED, markerEnabled),
            3, "Marker Enabled");
    if (markerEnabled == VI_TRUE)
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_MARKER_TRACE, trace),
                4, "Trace");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Signal Track
 * Purpose:  This function turns configures signal-tracking.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSignalTrack(ViSession instrSession,
                                       ViBoolean signalTrackEnabled,
                                       ViReal64  signalTrackBandwidth,
                                       ViReal64  signalTrackThreshold,
                                       ViInt32   trace)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_SIGNAL_TRACK_ENABLED, signalTrackEnabled),
            2, "Signal Track Enabled");
    if (signalTrackEnabled == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_SIGNAL_TRACK_BWID, signalTrackBandwidth),
                3, "Signal Track Bandwidth");

        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_SIGNAL_TRACK_THRESHOLD, signalTrackThreshold),
                4, "Signal Track Threshold");

        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_SIGNAL_TRACK_TRACE, trace),
                5, "Trace");
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Disable All Markers
 * Purpose:  This function turns off all the markers in selected measurement
 *           window.
 *****************************************************************************/
ViStatus rsetl_SANDisableAllMarkers(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MARKER_AOFF, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Marker Search
 * Purpose:  This function specifies the type of marker search and performs
 *           the search.
 *****************************************************************************/
ViStatus rsetl_SANMarkerSearch(ViSession instrSession,
                               ViInt32   marker,
                               ViInt32   markerSearch)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            3, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    switch (markerSearch)
    {
            case RSETL_VAL_MARKER_SEARCH_HIGHEST:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_PEAK, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_PEAK_NEXT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_LEFT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_PEAK_LEFT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_RIGHT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_PEAK_RIGHT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_MINIMUM:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_MIN, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_MIN_NEXT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_LEFT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_MIN_LEFT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_RIGHT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_SEARCH_MIN_RIGHT, NULL));
            break;

            default:
                viCheckParm(RsCore_InvalidViInt32Value(instrSession, markerSearch), 3, "Parameter to set");
            break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Marker Peak Auto
 * Purpose:  This function configures an automatic peak search action
 *           for Marker 1 at the end of each particular sweep. This function
 *           may be used during adjustments of a device under test to keep
 *           track of the actual peak marker position and level.
 *****************************************************************************/
ViStatus rsetl_SANMarkerPeakAuto(ViSession instrSession,
                                 ViInt32   markerSearch,
                                 ViBoolean autoPeak)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    switch (markerSearch){
        case RSETL_VAL_MARKER_SEARCH_HIGHEST:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_SEARCH_PEAK_AUTO, autoPeak),
                    3, "Auto Peak");
        break;
        case RSETL_VAL_MARKER_SEARCH_MINIMUM:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_SEARCH_MIN_AUTO, autoPeak),
                    3, "Auto Peak");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, markerSearch), 2, "Marker Search");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Move Marker
 * Purpose:  This function moves the active marker to the specified horizontal
 *           position.
 *****************************************************************************/
ViStatus rsetl_SANMoveMarker(ViSession instrSession,
                             ViInt32   marker,
                             ViReal64  markerPosition)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_POSITION, markerPosition),
            3, "Marker Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Set SAN From Marker
 * Purpose:  This function makes the selected marker frequency to be the
 *           center frequency or step width of center frequency. It can also
 *           make the active marker amplitude to be the reference level.
 *****************************************************************************/
ViStatus rsetl_SetSANFromMarker(ViSession instrSession,
                                ViInt32   marker,
                                ViInt32   instrumentSetting)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    switch(instrumentSetting)
    {
        case RSETL_VAL_INSTRUMENT_SETTING_FREQUENCY_CENTER:
            checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_TO_CENTER, NULL));
        break;
        case RSETL_VAL_INSTRUMENT_SETTING_FREQUENCY_STEP:
            checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_TO_STEP, NULL));
        break;
        case RSETL_VAL_INSTRUMENT_SETTING_REFERENCE_LEVEL:
            checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MARKER_TO_REFERENCE, NULL));
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, instrumentSetting), 3, "Parameter to set");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Zoom
 * Purpose:  This function defines the range to be zoomed around marker 1 in
 *           the selected measurement window. Marker 1 is activated first, if
 *           necessary.
 *           The subsequent frequency sweep is stopped at the marker position
 *           and the frequency of the signal is counted. This frequency becomes
 *           the new center frequency, and the zoomed span is set. In order to
 *           recognize the end of the operation the synchronization to the
 *           sweep end should be activated. This is only possible in single
 *           sweep mode.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerZoom(ViSession instrSession,
                                      ViReal64  markerZoom,
                                      ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = -1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 4, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_ZOOM, markerZoom),
            2, "Marker Zoom");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout >= 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Marker
 * Purpose:  This function returns the horizontal position and the marker
 *           amplitude level of the selected marker.
 *****************************************************************************/
ViStatus rsetl_QuerySANMarker(ViSession instrSession,
                              ViInt32   marker,
                              ViReal64* markerPosition,
                              ViReal64* markerAmplitude)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_POSITION, markerPosition),
            3, "Marker Position");

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_AMPLITUDE, markerAmplitude),
            4, "Marker Amplitude");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Percent Marker
 * Purpose:  This function positions the selected marker in the selected
 *           window to the given probability.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANPercentMarker(ViSession instrSession,
                                         ViInt32   marker,
                                         ViReal64  positionValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_PROBABILITY, positionValue),
            3, "Position Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Search Threshold
 * Purpose:  This function configures marker threshold values. The marker
 *           threshold specifies a lower bound for ALL marker search functions.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerSearchThreshold(ViSession instrSession,
                                                 ViBoolean thresholdState,
                                                 ViReal64  markerThreshold)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_THRESHOLD_STATE, thresholdState),
            2, "Threshold State");

    if (thresholdState == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_THRESHOLD, markerThreshold),
                3, "Marker Threshold");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Search Peak Excursion
 * Purpose:  This function configures the marker peak excursion The marker
 *           peak excursion specifies the minimum amplitude variation that can
 *           be recognized as a peak or minimum by the marker.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerSearchPeakExcursion(ViSession instrSession,
                                                     ViReal64  peakExcursion)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_PEAK_EXCURSION, peakExcursion),
            2, "Peak Excursion");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Search Local Oscillator
 * Purpose:  This function configures state of local oscillator supression.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerSearchLocalOscillator(ViSession instrSession,
                                                       ViBoolean localOscillatorSupression)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_LOEX, localOscillatorSupression),
            2, "Local Oscillator Supression");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Search Limits
 * Purpose:  This function configures marker search limits.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerSearchLimits(ViSession instrSession,
                                              ViBoolean searchLimits,
                                              ViReal64  searchLimitLeft,
                                              ViReal64  searchLimitRight)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_SEARCH_LIMITS_STATE, searchLimits),
            2, "Serach Limit");
    if (searchLimits == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_SEARCH_LIMITS_LEFT, searchLimitLeft),
                3, "Search Limit Left");

        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_SEARCH_LIMITS_RIGHT, searchLimitRight),
                4, "Search Limit Right");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Demodulation
 * Purpose:  This function configures marker demodulation parameters.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerDemodulation(ViSession instrSession,
                                              ViInt32   marker,
                                              ViBoolean state,
                                              ViInt32   demodulationType,
                                              ViReal64  markerStopTime,
                                              ViBoolean continuousDemodulation)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MARKER_DEMOD_STATE, state),
            3, "State");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_MARKER_DEMOD_TYPE, demodulationType),
            4, "Demodulation Type");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_DEMOD_HOLDOFF, markerStopTime),
            5, "Marker Stop Time");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_DEMOD_CONT, continuousDemodulation),
            6, "Continuous Demodulation");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Peak List
 * Purpose:  This function searches the selected trace for the indicated
 *           number of maxima. The number of maxima found depends on the
 *           waveform and value set for the Peak Excursion parameter, however,
 *           a maximum number of 50 maxima are determined. Only the signals
 *           which exceed their surrounding values at least by the value
 *           indicated by the peak excursion parameter will be recognized as
 *           maxima. Therefore, the number of maxima found is not automatically
 *           the same as the number of maxima desired..
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerPeakList(ViSession instrSession,
                                          ViInt32   marker,
                                          ViInt32   peakListCount,
                                          ViInt32   peakListSort)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_MARKER_PEAK_LIST_COUNT, peakListCount),
            3, "Peak List Count");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_MARKER_PEAK_LIST_SORT, peakListSort),
            4, "Peak List Sort");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Marker Peak List Found
 * Purpose:  This function reads out the number of maxima found during the
 *           search. If no search for maxima has been performed, 0 is returned.
 *****************************************************************************/
ViStatus rsetl_QuerySANMarkerPeakListFound(ViSession instrSession,
                                           ViInt32   marker,
                                           ViInt32*  peakListFound)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_ATTR_MARKER_PEAK_LIST_FOUND, peakListFound),
            3, "Peak List Found");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Marker Peak List
 * Purpose:  This function reads out the list of X or Y values of the maxima
 *           found.
 *****************************************************************************/
ViStatus rsetl_QuerySANMarkerPeakList(ViSession instrSession,
                                      ViInt32   marker,
                                      ViInt32   arraySize,
                                      ViInt32   peakListSelection,
                                      ViReal64  peakList[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");
    switch (peakListSelection){
        case RSETL_VAL_MARKER_SORT_X:
            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:MARK%ld:FUNC:FPE:X?", marker);
        break;
        case RSETL_VAL_MARKER_SORT_Y:
            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:MARK%ld:FUNC:FPE:Y?", marker);
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, peakListSelection), 4, "Peak List Selection");
        break;
    }
    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, cmd, arraySize, peakList, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Delta Marker
 * Purpose:  This function enables the active marker on the specified trace.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDeltaMarker(ViSession instrSession,
                                       ViInt32   deltaMarker,
                                       ViBoolean state,
                                       ViInt32   trace)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarker, 1, 4),
            2, "Delta Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarker);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_STATE, state),
            3, "State");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_TRACE, trace),
            4, "Trace");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Delta Marker Position
 * Purpose:  This function configures the delta marker position.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDeltaMarkerPosition(ViSession instrSession,
                                               ViInt32   deltaMarker,
                                               ViInt32   mode,
                                               ViReal64  position)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarker, 1, 4),
            2, "Delta Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarker);
    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MODE, mode),
            3, "Mode");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_POSITION, position),
            4, "Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Disable All Delta Markers
 * Purpose:  This function turns off all the delta markers in selected
 *           measurement window.
 *****************************************************************************/
ViStatus rsetl_SANDisableAllDeltaMarkers(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_REFERENCE_MARKER_AOFF, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Delta Marker Search
 * Purpose:  This function specifies the type of delta marker search and
 *           performs the search.
 *****************************************************************************/
ViStatus rsetl_SANDeltaMarkerSearch(ViSession instrSession,
                                    ViInt32   deltaMarker,
                                    ViInt32   markerSearch)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarker, 1, 4),
            2, "Delta Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarker);
    switch (markerSearch)
    {
            case RSETL_VAL_MARKER_SEARCH_HIGHEST:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_PEAK, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT, NULL));
            break;

            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_LEFT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_LEFT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_PEAK_RIGHT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_RIGHT, NULL));
                         break;

            case RSETL_VAL_MARKER_SEARCH_MINIMUM:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MIN, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_LEFT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_LEFT, NULL));
            break;
            case RSETL_VAL_MARKER_SEARCH_NEXT_MINIMUM_RIGHT:
                checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_RIGHT, NULL));
            break;

            default:
                viCheckParm(RsCore_InvalidViInt32Value(instrSession, markerSearch), 3, "Parameter to set");
            break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Delta Marker
 * Purpose:  This function returns the horizontal position and the marker
 *           amplitude level of the selected delta marker.
 *****************************************************************************/
ViStatus rsetl_QuerySANDeltaMarker(ViSession instrSession,
                                   ViInt32   deltaMarker,
                                   ViInt32   mode,
                                   ViReal64* position,
                                   ViReal64* amplitude)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, deltaMarker, 1, 4),
            2, "Delta Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DM%ld", deltaMarker);
    switch (mode){
        case RSETL_VAL_ABS:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_POSITION, position),
                    4, "Position");
        break;
        case RSETL_VAL_REL:
            viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_REL_POSITION, position),
                    4, "Position");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, mode), 3, "Mode");
    }

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_REFERENCE_MARKER_AMPLITUDE, amplitude),
            5, "Amplitude");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Reference Fixed
 * Purpose:  This function configures marker reference fixed state.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANReferenceFixed(ViSession instrSession,
                                          ViBoolean fixedReference)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_REF_STATE, fixedReference),
            2, "Fixed Reference");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Reference Fixed Point
 * Purpose:  This function configures marker reference fixed position.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANReferenceFixedPoint(ViSession instrSession,
                                               ViReal64  refPointLevel,
                                               ViReal64  refPointLevelOffset,
                                               ViReal64  refPointFrequencyTime)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_REF_LEVEL, refPointLevel),
            2, "Reference Point Level");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_REF_LEVEL_OFFSET, refPointLevelOffset),
            3, "Reference Point Level Offset");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_REF_FREQ, refPointFrequencyTime),
            4, "Reference Point Frequency");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Reference Fixed Peak Search
 * Purpose:  This function sets the reference point level for all delta
 *           markers in the selected measurement window for a measurement with
 *           fixed reference point (CALC:DELT:FUNC:FIX:STAT ON) to the peak of
 *           the selected trace.
 *****************************************************************************/
ViStatus rsetl_SANReferenceFixedPeakSearch(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MARKER_REF_PEAK, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Speaker Volume
 * Purpose:  This function sets the volume of the built-in loudspeaker for
 *           demodulated signals.
 *****************************************************************************/
ViStatus rsetl_SANSpeakerVolume(ViSession instrSession,
                                ViReal64  speakerVolume)
{
    ViStatus error = VI_SUCCESS;
    ViReal64 tmp_value;

    checkErr(RsCore_LockSession(instrSession));

    tmp_value= speakerVolume/100.0;
    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_SYST_SPEAKER, tmp_value),
            2, "Speaker Volume");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Extern Gain Correction
 * Purpose:  This function configures the extern preamplifier gain value.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANExternGainCorrection(ViSession instrSession,
                                                ViReal64  gain)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_EXTERN_PREAMP_GAIN, gain),
            2, "Gain");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trigger Source
 * Purpose:  This function specifies the trigger source that causes the
 *           spectrum analyzer to leave the Wait-for-Trigger state.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTriggerSource(ViSession instrSession,
                                         ViInt32   triggerSource)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_SOURCE, triggerSource),
            2, "Trigger Source");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Trigger
 * Purpose:  This function specifies the delay and polarity for triggering.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTrigger(ViSession instrSession,
                                   ViReal64  triggerDelay,
                                   ViInt32   triggerPolarity)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_DELAY, triggerDelay),
            2, "Trigger Delay");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_SLOPE, triggerPolarity),
            3, "Trigger Polarity");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Video Trigger
 * Purpose:  This function specifies the video level for triggering.  This is
 *           applicable when the trigger source is set to video.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANVideoTrigger(ViSession instrSession,
                                        ViReal64  videoTriggerLevel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_VIDEO_TRIGGER_LEVEL, videoTriggerLevel),
            2, "Video Trigger Level");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN IF Power Trigger
 * Purpose:  This function specifies sets the level of the IF power trigger
 *           source. This is applicable when the trigger source is set to IF
 *           Power.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANIFPowerTrigger(ViSession instrSession,
                                          ViReal64  triggerLevel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_IFP_LEVEL, triggerLevel),
            2, "Trigger Level");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN IF Power Trigger Parameters
 * Purpose:  This function sets the IF power trigger parameters. This is
 *           applicable when the trigger source is set to IF Power.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANIFPowerTriggerParameters(ViSession instrSession,
                                                    ViReal64  triggerLevel,
                                                    ViReal64  holdoff,
                                                    ViReal64  hysteresis)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_IFP_LEVEL, triggerLevel),
            2, "Trigger Level");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_IFP_OFFSET, holdoff),
            3, "Holdoff");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRIGGER_IFP_HYSTERESIS, hysteresis),
            4, "Hysteresis");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN TV Trigger
 * Purpose:  This function configures the TV Trigger parameters.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTVTrigger(ViSession instrSession,
                                     ViInt32   lineSystem,
                                     ViInt32   synchronization,
                                     ViInt32   horizontalSyncLine,
                                     ViInt32   polarity)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_SOURCE, RSETL_VAL_TRG_TV));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_TV_LINE_SYSTEM, lineSystem),
            2, "Line System");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_TV_VERTICAL_SYNC, synchronization),
            3, "Synchronization");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_TV_HORIZONTAL_SYNC_LINE_NUMBER, horizontalSyncLine),
            4, "Horizontal Sync Line");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_TV_VIDEO_SYNC_SIGNAL_POLARITY, polarity),
            5, "Polarity");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN TV Trigger Free Run State
 * Purpose:  This function configures the TV Trigger Free Run Mode.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTVTriggerFreeRunState(ViSession instrSession,
                                                 ViBoolean TVFreeRunState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRIGGER_SOURCE, RSETL_VAL_TRG_TV));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_TRIGGER_TV_FREE_RUN_TRIG_MODE, TVFreeRunState),
            2, "TV Free Run State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN External Gate
 * Purpose:  This function configures the external gate parameters.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANExternalGate(ViSession instrSession,
                                        ViBoolean gating,
                                        ViInt32   gateSource,
                                        ViInt32   mode,
                                        ViInt32   polarity,
                                        ViReal64  delay,
                                        ViReal64  length)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    if (gating == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_EXTERNAL_GATE_SIGNAL_SOURCE, gateSource),
                3, "Gate Source");

        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_EXTERNAL_GATE_TRIGGER_TYPE, mode),
                4, "Mode");

        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_EXTERNAL_GATE_POLARITY, polarity),
                5, "Polarity");

        viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_EXTERNAL_GATE_HOLD, delay),
                6, "Delay");

        if (mode==RSETL_VAL_EGAT_TRIG_EDGE)
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_EXTERNAL_GATE_LENGTH, length),
                    7, "Length");
    }
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_EXTERNAL_GATE, gating),
            2, "Gating");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Preamplifier State
 * Purpose:  This function switches on the preamplifier for the instrument.
 *           The switchable gain is fixed to 20 dB.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANPreamplifierState(ViSession instrSession,
                                             ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_AMPL_PREAMPLIFIER, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Create SAN Limit Line
 * Purpose:  This function creates new limit or selects existing one and
 *           configures basic parameters.
 *****************************************************************************/
ViStatus rsetl_CreateSANLimitLine(ViSession instrSession,
                                  ViInt32   limit,
                                  ViString  name,
                                  ViInt32   domain,
                                  ViString  comment,
                                  ViInt32   assigntoTrace,
                                  ViBoolean deleteExistingLimitLine)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];
    ViChar   error_message[RS_MAX_MESSAGE_BUF_SIZE] = "";

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");
    viCheckParm(RsCore_InvalidStringLength(instrSession, name, 0, 8), 3, "Name (string length)");
    viCheckParm(RsCore_InvalidStringLength(instrSession, comment, 0, 40), 5, "Comment (string length)");
    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, deleteExistingLimitLine), 7, "Delete Existing Line");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);

    if (deleteExistingLimitLine == VI_TRUE)
    {
        error = rsetl_SetAttributeViString(instrSession, repCap, RSETL_LIMIT_DELETE,"");

        do
        {
            (void) rsetl_error_query(instrSession, &error, error_message);
        } while (error != 0);
    }
    viCheckParm(rsetl_SetAttributeViString(instrSession, repCap, RSETL_LIMIT_NAME, name),
            3, "Name");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_CONTROL_DOMAIN, domain),
            4, "Domain");

    viCheckParm(rsetl_SetAttributeViString(instrSession, repCap, RSETL_LIMIT_COMMENT, comment),
            5, "Comment");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);
    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_ASSIGN_TRACE, assigntoTrace),
            6, "Assign to Trace");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Limit Line
 * Purpose:  This function configures specified limit line.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANLimitLine(ViSession instrSession,
                                     ViInt32   limit,
                                     ViInt32   type,
                                     ViInt32   units,
                                     ViInt32   xAxisInterpolation,
                                     ViInt32   yAxisInterpolation,
                                     ViInt32   xAxisScaling,
                                     ViReal64  margin,
                                     ViReal64  threshold)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];
    ViInt32  scaling;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, type, RSETL_VAL_LIMIT_UPPER, RSETL_VAL_LIMIT_LOWER),
            3, "Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, units, RSETL_VAL_UNIT_DBM, RSETL_VAL_UNIT_UNITLESS),
            4, "Units");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);

    scaling = (units == RSETL_VAL_UNIT_DB ) ? RSETL_VAL_REL : RSETL_VAL_ABS;

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_UNITS, units),
            4, "Units");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_CONTROL_SPACING, xAxisInterpolation),
            5, "X Axis Interpolation");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_CONTROL_SCALING, xAxisScaling),
            7, "X Axis Scaling");

    switch (type)
    {
        case RSETL_VAL_LIMIT_LOWER:
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_LOWER_SPACING, yAxisInterpolation),
                    6, "Y Axis Interpolation");

            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_LIMIT_LOWER_MARGIN, margin),
                    8, "Marging");
            if (scaling == RSETL_VAL_REL)
            {
                viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_LIMIT_LOWER_THRESHOLD, threshold),
                        9, "Threshold");
            }
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_LOWER_SCALING, scaling));
            break;

        case RSETL_VAL_LIMIT_UPPER:
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_UPPER_SPACING, yAxisInterpolation),
                    6, "Y Axis Interpolation");

            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_LIMIT_UPPER_MARGIN, margin),
                    8, "Marging");
            if (scaling == RSETL_VAL_REL)
            {
                viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_LIMIT_UPPER_THRESHOLD, threshold),
                        9, "Threshold");
            }
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_UPPER_SCALING, scaling));
            break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Define SAN Limit Line
 * Purpose:  This function defines specified limit line.
 *****************************************************************************/
ViStatus rsetl_DefineSANLimitLine(ViSession instrSession,
                                  ViInt32   limit,
                                  ViInt32   type,
                                  ViInt32   count,
                                  ViReal64  xAxis[],
                                  ViReal64  amplitude[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, type, RSETL_VAL_LIMIT_UPPER, RSETL_VAL_LIMIT_LOWER),
            3, "Type");
    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, count, 1), 4, "Count");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, xAxis), 5, "X Axis");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, amplitude), 6, "Amplitude");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:LIM%ld:CONT ", limit);
    checkErr(RsCore_WriteAsciiViReal64Array(instrSession, cmd, xAxis, count));
    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:LIM%ld:%s ", limit, limTypeArr[type]);
    checkErr(RsCore_WriteAsciiViReal64Array(instrSession, cmd, amplitude, count));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Select SAN Limit Line
 * Purpose:  This function selects the limit line.
 *****************************************************************************/
ViStatus rsetl_SelectSANLimitLine(ViSession instrSession,
                                  ViInt32   limit,
                                  ViString  name,
                                  ViBoolean limitEnabled)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");
    viCheckParm(RsCore_InvalidStringLength(instrSession, name, 0, 8), 3, "Name (string length)");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);
    viCheckParm(rsetl_SetAttributeViString(instrSession, repCap, RSETL_LIMIT_NAME, name),
            3, "Name");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_LIMIT_STATE, limitEnabled),
            4, "Limit Enabled");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Enable SAN Limit Check
 * Purpose:  This function switches on or off the limit check and/or limit
 *           line for the selected limit line.
 *****************************************************************************/
ViStatus rsetl_EnableSANLimitCheck(ViSession instrSession,
                                   ViInt32   limit,
                                   ViInt32   type,
                                   ViBoolean limitEnabled,
                                   ViBoolean checkEnabled)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];
    ViInt32  attribute = 0;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");

    switch (type)
    {
        case RSETL_VAL_LIMIT_LOWER:
            attribute = RSETL_LIMIT_LOWER_STATE;
            break;
        case RSETL_VAL_LIMIT_UPPER:
            attribute = RSETL_LIMIT_UPPER_STATE;
            break;

        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, type), 3, "Type");
    }

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_LIMIT_STATE, limitEnabled),
            4, "Limit Enabled");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, (ViUInt32) attribute, checkEnabled), 5, "Check Enabled");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Move SAN Limit Line
 * Purpose:  This function moves specified limit line.
 *****************************************************************************/
ViStatus rsetl_MoveSANLimitLine(ViSession instrSession,
                                ViInt32   limit,
                                ViInt32   type,
                                ViInt32   method,
                                ViReal64  value)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];
    ViInt32  attributes[4][2] = {{0,0},
             {RSETL_LIMIT_LOWER_OFFSET,RSETL_LIMIT_LOWER_SHIFT},
             {RSETL_LIMIT_UPPER_OFFSET,RSETL_LIMIT_UPPER_SHIFT},
             {RSETL_LIMIT_CONTROL_OFFSET,RSETL_LIMIT_CONTROL_SHIFT}};

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, type, RSETL_VAL_LIMIT_UPPER, RSETL_VAL_LIMIT_CONTROL),
            3, "Type");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, method, RSETL_VAL_LIMIT_MOVE_OFFSET, RSETL_VAL_LIMIT_MOVE_SHIFT),
            4, "Method");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, (ViUInt32)attributes[type][method], value), 5, "Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Copy SAN Limit Line
 * Purpose:  This function copies specified limit line into another one.
 *****************************************************************************/
ViStatus rsetl_CopySANLimitLine(ViSession instrSession,
                                ViInt32   limit,
                                ViInt32   copyTo)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_COPY, copyTo),
            3, "Copy To");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Delete SAN Limit Line
 * Purpose:  This function removes specified limit line.
 *****************************************************************************/
ViStatus rsetl_DeleteSANLimitLine(ViSession instrSession,
                                  ViInt32   limit)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);

    checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_LIMIT_DELETE, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Clear SAN Limit Line Results
 * Purpose:  This function deletes the result of the current limit check.
 *****************************************************************************/
ViStatus rsetl_ClearSANLimitLineResults(ViSession instrSession,
                                        ViInt32   limit)
{
    ViStatus error = VI_SUCCESS;
    ViChar   lim_line_no[RS_MAX_MESSAGE_BUF_SIZE] = "";

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit Line Number");

    sprintf(lim_line_no,"L%ld",limit);

    checkErr(rsetl_SetAttributeViString(instrSession, lim_line_no, RSETL_LIMIT_CLEAR, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Line State
 * Purpose:  This function configures state of specified display line.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayLineState(ViSession instrSession,
                                            ViInt32   line,
                                            ViInt32   type,
                                            ViBoolean state)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    switch (type){
        case RSETL_VAL_LINE_THR:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_THRLINE_STATE, state),
                    4, "State");
        break;
        case RSETL_VAL_LINE_DISPLAY:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, line, 1, 2),
                    2, "Line");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", line);
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_DLINE_STATE, state),
                    4, "State");
        break;
        case RSETL_VAL_LINE_FREQ:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, line, 1, 2),
                    2, "Line");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", line);
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_FLINE_STATE, state),
                    4, "State");
        break;
        case RSETL_VAL_LINE_TIME:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, line, 1, 2),
                    2, "Line");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", line);
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_TLINE_STATE, state),
                    4, "State");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, type), 3, "Type");
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Line Position
 * Purpose:  This function configures position of specified display line.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayLinePosition(ViSession instrSession,
                                               ViInt32   line,
                                               ViInt32   type,
                                               ViReal64  position)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    switch (type){
        case RSETL_VAL_LINE_THR:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_THRLINE_POSITION, position),
                    4, "Position");
        break;
        case RSETL_VAL_LINE_DISPLAY:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, line, 1, 2),
                    2, "Line");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", line);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_DLINE_POSITION, position),
                    4, "Position");
        break;
        case RSETL_VAL_LINE_FREQ:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, line, 1, 2),
                    2, "Line");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", line);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_FLINE_POSITION, position),
                    4, "Position");
        break;
        case RSETL_VAL_LINE_TIME:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, line, 1, 2),
                    2, "Line");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", line);
             viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_TLINE_POSITION, position),
                     4, "Position");
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, type), 3, "Type");
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Control
 * Purpose:  This function controls the apperance of display elements.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayControl(ViSession instrSession,
                                          ViBoolean frequency,
                                          ViBoolean time)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_FREQ_STATE, frequency),
            2, "Frequency");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_TIME_STATE, time),
            3, "Time");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Logo
 * Purpose:  This function switches the company logo on the screen on or off.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayLogo(ViSession instrSession,
                                       ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_LOGO, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Comment
 * Purpose:  This function defines a comment (max. 20 characters) which can
 *           be displayed on the screen and the comment state.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayComment(ViSession instrSession,
                                          ViBoolean state,
                                          ViString  comment)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_COMMENT_STATE, state),
            2, "State");

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_DISP_COMMENT, comment),
            3, "Comment");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Power Save
 * Purpose:  This function configures power-save mode of the display. With the
 *           power-save mode activated the display including backlight is
 *           completely switched off after the elapse of the response time (see
 *           command DISPlay:PSAVe:HOLDoff).
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayPowerSave(ViSession instrSession,
                                            ViBoolean state,
                                            ViInt32   holdoff)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_PWR_SAVE_STATE, state),
            2, "State");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISP_PWR_SAVE_HOLDOFF, holdoff),
            3, "Hold Off");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Window Size
 * Purpose:  This function switches the measurement window for channel and
 *           adjacent-channel power measurements to full screen or half screen.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayWindowSize(ViSession instrSession,
                                             ViInt32   windowSize)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISP_WINDOW_SIZE, windowSize),
            2, "Window Size");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Log Range
 * Purpose:  This function defines the display range of the Y axis (level
 *           axis) in the selected measurement window with logarithmic scaling
 *           (DISP:TRAC:Y:SPAC LOG).
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayLogRange(ViSession instrSession,
                                           ViReal64  range)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_LOG_RANGE, range),
            2, "Range");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Amplitude Grid Mode
 * Purpose:  This function defines the scale type of the Y axis (absolute or
 *           relative) in the selected measurement window.
 *           When SYSTem:DISPlay is set to OFF, this command has no immediate
 *           effect on the screen.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayAmplitudeGridMode(ViSession instrSession,
                                                    ViInt32   yAxisGridMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_DISP_AMPLITUDE_GRID_MODE, yAxisGridMode),
            2, "Y Axis Grid Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Reference Value
 * Purpose:  If the external generator control option (FSP-B10) is mounted and
 *           the normalization in the NETWORK mode is activated, this value
 *           defines the power value assigned to the reference position in the
 *           selected measurement window. This value corresponds to the
 *           parameter REFERENCE VALUE in manual operation.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayReferenceValue(ViSession instrSession,
                                                 ViReal64  referenceValue)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_REF_VALUE, referenceValue),
            2, "Reference Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Coupled Reference Level
 * Purpose:  If the external defines wether the reference value for the Y
 *           axis is coupled to the reference level (default) or not
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayCoupledReferenceLevel(ViSession instrSession,
                                                        ViBoolean coupledReferenceLevel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_COUP_REF_LEV, coupledReferenceLevel),
            2, "Coupled Reference Level");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Reference Position
 * Purpose:  This function defines the position of the reference value.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayReferencePosition(ViSession instrSession,
                                                    ViReal64  referencePosition)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_DISP_REF_POSITION, referencePosition),
            2, "Reference Value Position");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Single Sweep
 * Purpose:  This function configures the behaviour of the display during a
 *           single sweep.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplaySingleSweep(ViSession instrSession,
                                              ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_SINGLE_SWEEP, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Update
 * Purpose:  This function switches on or off the update of all display
 *           elements during remote control.
 *
 *           Note:
 *
 *           The best performance is obtained when the display output is
 *           switched off during remote control.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayUpdate(ViSession instrSession,
                                         ViBoolean displayInRemote)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_UPDATE, displayInRemote),
            2, "Display In Remote");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Soft Frontpanel
 * Purpose:  This function activates or deactivates the display of the front
 *           panel keys on the screen. With the display activated, the
 *           instrument can be operated on the screen using the mouse by
 *           pressing the corresponding buttons. This may be useful if the
 *           instrument is operated in a detached station by means of a remote
 *           program such as PCANYWHERE.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplaySoftFrontpanel(ViSession instrSession,
                                                 ViBoolean softFrontpanel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_DISP_FP_KEYS, softFrontpanel),
            2, "Soft Front panel");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Display Color Default
 * Purpose:  This function resets the screen colors of all display items to
 *           their default settings.
 *****************************************************************************/
ViStatus rsetl_SANDisplayColorDefault(ViSession instrSession,
                                      ViInt32   defaultSetting)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, defaultSetting, 1, 2),
            2, "Default Settings");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DEF%ld", defaultSetting);

    checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_DISP_COL_PRESET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Color
 * Purpose:  This function defines the color table of the instrument.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayColor(ViSession instrSession,
                                        ViInt32   colorMap,
                                        ViReal64  tint,
                                        ViReal64  saturation,
                                        ViReal64  brightness)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorMap, 1, 26),
            2, "Color Map");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, tint, 0.0, 100.0), 3, "TINT");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, saturation, 0.0, 100.0), 4, "SATURATION");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, brightness, 0.0, 100.0), 5, "BRIGHTNESS");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "DISP:CMAP%ld:HSL %.12f,%.12f,%.12f", colorMap, tint/100.0, saturation/100.0, brightness/100.0);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Color by Predefined
 * Purpose:  This function defines the color table of the instrument using
 *           predefined colors.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayColorByPredefined(ViSession instrSession,
                                                    ViInt32   colorMap,
                                                    ViInt32   predefinedColors)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorMap, 1, 26),
            2, "Color Map");
    snprintf(repCap, RS_REPCAP_BUF_SIZE, "CM%ld", colorMap);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_DISP_COL_PREDEFINED, predefinedColors),
            3, "Predefined Colors");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Select SAN Transducer Factor
 * Purpose:  This function generates a transducer factor <name> using
 *           normalized trace data.
 *****************************************************************************/
ViStatus rsetl_SelectSANTransducerFactor(ViSession instrSession,
                                         ViBoolean transducerState,
                                         ViString  transducerName)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_TFAC_SEL_NAME, transducerName),
            3, "Transducer Name");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_TFAC_STATE, transducerState),
            2, "Transducer State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Transducer Factor
 * Purpose:  This function configures the transducer factor. The transducer
 *           is stored on harddisk any may be activated by function
 *           SelectTransducerFactor.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTransducerFactor(ViSession instrSession,
                                            ViString  name,
                                            ViInt32   unit,
                                            ViInt32   interpolation,
                                            ViString  comment,
                                            ViInt32   noOfTestPoints,
                                            ViReal64  frequencyData[],
                                            ViReal64  levelData[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_TFAC_SEL_NAME, name),
            2, "Name");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TFAC_UNIT, unit),
            3, "Unit");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TFAC_SCALING, interpolation),
            4, "Interpolation");

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_TFAC_COMMENT, comment),
            5, "Comment");

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, noOfTestPoints, 0), 6, "No Of Test Points");

    checkErr(RsCore_WriteAsciiViReal64ArraysInterleaved(instrSession, "SENS:CORR:TRAN:DATA ",
        noOfTestPoints, frequencyData, levelData, NULL, NULL, NULL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Transducer Factor Ref Level Adj
 * Purpose:  This function allows automatic reference level offset adaption
 *           to restore the original dynamic range by also shifting the reference
 *           level by the maximum value of the transducer factor.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTransducerFactorRefLevAdj(ViSession instrSession,
                                                     ViBoolean refLevAdj)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_TFAC_ADJ_STATE, refLevAdj),
            2, "Ref Lev Adj");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Display Transducer State
 * Purpose:  This function switches on the display of the active transducer
 *           factor or set.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANDisplayTransducerState(ViSession instrSession,
                                                  ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_TFAC_DISPLAY, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Delete SAN Transducer Factor
 * Purpose:  This function deletes the selected transducer factor.
 *****************************************************************************/
ViStatus rsetl_DeleteSANTransducerFactor(ViSession instrSession,
                                         ViString  transducerName)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_TFAC_SEL_NAME, transducerName),
            3, "Transducer Name");
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_TFAC_DELETE, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Hardcopy Device
 * Purpose:  This function selects the printer output medium and the data
 *           format of the printout.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANHardcopyDevice(ViSession instrSession,
                                          ViInt32   device,
                                          ViInt32   destination,
                                          ViInt32   pageOrientation)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, device, 1, 2),
            2, "Device");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, destination, 0, 4),
            3, "Destination");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DE%ld", device);
    switch(destination){
        case  RSETL_VAL_HCOPY_DEST_BMP:
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_DESTINATION, RSETL_VAL_HCOPY_DEVICE_MEM));
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM, RSETL_VAL_HCOPY_DEVICE_LANG_BMP));
        break;
        case  RSETL_VAL_HCOPY_DEST_WMF:
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_DESTINATION, RSETL_VAL_HCOPY_DEVICE_MEM));
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM, RSETL_VAL_HCOPY_DEVICE_LANG_WMF));
        break;
        case  RSETL_VAL_HCOPY_DEST_EMF:
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_DESTINATION, RSETL_VAL_HCOPY_DEVICE_MEM));
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM, RSETL_VAL_HCOPY_DEVICE_LANG_EWMF));
        break;
        case  RSETL_VAL_HCOPY_DEST_CLP:
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_DESTINATION, RSETL_VAL_HCOPY_DEVICE_CLP));
        break;
        case  RSETL_VAL_HCOPY_DEST_PRN:
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_DESTINATION, RSETL_VAL_HCOPY_DEVICE_PRN));
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM, RSETL_VAL_HCOPY_DEVICE_LANG_GDI));
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_ORIENTATION, pageOrientation),
                    4, "Page Orientation");
        break;
        case  RSETL_VAL_HCOPY_DEST_JPG:
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_DESTINATION, RSETL_VAL_HCOPY_DEVICE_MEM));
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM, RSETL_VAL_HCOPY_DEVICE_LANG_JPG));
        break;

        case  RSETL_VAL_HCOPY_DEST_PNG:
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_DESTINATION, RSETL_VAL_HCOPY_DEVICE_MEM));
            checkErr(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM, RSETL_VAL_HCOPY_DEVICE_LANG_PNG));
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Hardcopy Abort
 * Purpose:  This function aborts a running hardcopy output.
 *****************************************************************************/
ViStatus rsetl_SANHardcopyAbort(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_HCOPY_ABORT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Hardcopy Print
 * Purpose:  This function starts a hardcopy output of the selected items.
 *****************************************************************************/
ViStatus rsetl_SANHardcopyPrint(ViSession instrSession,
                                ViInt32   device,
                                ViInt32   items)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, device, 1, 2),
            2, "Device");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, items, 0, 1),
            3, "Items");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DE%ld", device);
    switch (items){
        case RSETL_VAL_HCOP_ALL:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_HCOPY_PRINT_SCREEN, NULL));
        break;
        case RSETL_VAL_HCOP_TRACE:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_HCOPY_PRINT_TRACE, VI_TRUE));
        break;
    }
    checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_HCOPY_PRINT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Hardcopy Print Next
 * Purpose:  This function starts a hardcopy output. If the output is printed
 *           to a file (see HCOPy:DESTination<1|2>), the file name used in
 *           the last saving process is automatically counted up to the next
 *           unused name.
 *****************************************************************************/
ViStatus rsetl_SANHardcopyPrintNext(ViSession instrSession,
                                    ViInt32   device)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, device, 1, 2),
            2, "Device");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DE%ld", device);

    checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_HCOPY_PRINT_NEXT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Hardcopy Set File Name
 * Purpose:  This function defines a destination file for the hadcopy output.
 *****************************************************************************/
ViStatus rsetl_SANHardcopySetFileName(ViSession instrSession,
                                      ViString  name)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_HCOPY_FILE_NAME, name));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Hardcopy Get Printer List
 * Purpose:  This function queries the list of printers under Windows NT.
 *****************************************************************************/
ViStatus rsetl_SANHardcopyGetPrinterList(ViSession instrSession,
                                         ViInt32   bufferSize,
                                         ViChar    printerList[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   response[RS_MAX_MESSAGE_BUF_SIZE];
    size_t   count;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, bufferSize, 1), 2, "Buffer Size");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, printerList), 3, "Printer List");

    count=0;
    checkErr(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_HCOPY_PRINTER_FIRST,
                RS_MAX_MESSAGE_BUF_SIZE, response));

    strcpy(printerList, "");
    while (sscanf (response, "'%[^']'", response) == 1)
    {
        if (strlen(printerList) == 0)
            RsCore_StrcatMaxLen(printerList, bufferSize, response, NULL, NULL);
        else
            RsCore_StrcatMaxLen(printerList, bufferSize, ",", response, NULL);

        checkErr(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_HCOPY_PRINTER_NEXT,
                RS_MAX_MESSAGE_BUF_SIZE, response));
    }

    if (count>(size_t) bufferSize)
        error = (ViStatus) count;

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Hardcopy Set Printer
 * Purpose:  This function selects one of the printers installed under Windows
 *           NT. Prior to use this function get list of available printers
 *           using function Hardcopy Get Printer List.
 *****************************************************************************/
ViStatus rsetl_SANHardcopySetPrinter(ViSession instrSession,
                                     ViInt32   device,
                                     ViString  printerName)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, device, 1, 2),
            2, "Device");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DE%ld", device);
    viCheckParm(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_HCOPY_PRINTER, printerName),
            3, "Printer Name");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Hardcopy Comment
 * Purpose:  This function defines the comment text for measurement window.
 *****************************************************************************/
ViStatus rsetl_SANHardcopyComment(ViSession instrSession,
                                  ViString  comment)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_HCOPY_COMM_SCR, comment));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Hardcopy Color
 * Purpose:  This function resets the colors for a hardcopy to the selected
 *           default settings. DEFault1(SCREEN COLORS, but background white),
 *           DEFault2 (OPTIMIZED COLOR SET) and DEFault3 (USER DEFINED). The
 *           numeric suffix in CMAP is not significant.
 *****************************************************************************/
ViStatus rsetl_SANHardcopyColor(ViSession instrSession,
                                ViBoolean color,
                                ViInt32   defaultSetting)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "DEF%ld", defaultSetting);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_HCOPY_COLOR, color),
            2, "Color");

    if (color == VI_TRUE)
        viCheckParm(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_HCOPY_COLOR_DEF, NULL),
                3, "Default Setting");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Hardcopy Color
 * Purpose:  This function defines the color table in USER DEFINED COLORS
 *           mode.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANHardcopyColor(ViSession instrSession,
                                         ViInt32   colorMap,
                                         ViReal64  tint,
                                         ViReal64  saturation,
                                         ViReal64  brightness)
{
   ViStatus error = VI_SUCCESS;
   ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorMap, 1, 26),
            2, "Color Map");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, tint, 0.0, 100.0), 3, "TINT");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, saturation, 0.0, 100.0), 4, "SATURATION");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, brightness, 0.0, 100.0), 5, "BRIGHTNESS");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "HCOP:CMAP%ld:HSL %.12f,%.12f,%.12f", colorMap, tint/100.0, saturation/100.0, brightness/100.0);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Hardcopy Color by Predefined
 * Purpose:  This function defines the color table in USER DEFINED COLORS
 *           using predefined color values.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANHardcopyColorByPredefined(ViSession instrSession,
                                                     ViInt32   colorMap,
                                                     ViInt32   predefinedColors)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, colorMap, 1, 26),
            2, "Color Map");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "CM%ld", colorMap);

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, repCap, RSETL_ATTR_HCOPY_COLOR_PREDEFINED, predefinedColors),
            3, "Predefined Colors");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: File Decimal Separator
 * Purpose:  This function configures the decimal separator (decimal point or
 *           comma) for floating-point numerals contained in the file.
 *****************************************************************************/
ViStatus rsetl_FileDecimalSeparator(ViSession instrSession,
                                    ViInt32   decimalSeparator)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_FILE_DEC_SEPARATOR, decimalSeparator),
            2, "Decimal Separator");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: File Manager Operations
 * Purpose:  The MMEMory (mass memory) subsystem function provides commands
 *           which allow for access to the storage media of the instrument and
 *           for storing and loading various instrument settings.
 *           The File to be Printed/Plotted command stores the HCOPy outputs
 *           in a file. The various drives can be addressed via the mass
 *           storage unit specifier <msus> using the conventional DOS syntax.
 *           The internal hard disk is addressed by "C:", the floppy-disk drive
 *           installed by "A:". The file names <file_name> are indicated as
 *           string parameters with the commands being enclosed in quotation
 *           marks. They correspond to the DOS conventions.
 *           DOS file names consist of max. 8 ASCII characters and an
 *           extension of up to three characters separated from the file name
 *           by a colon "." Both, the colon and the extension are optional. The
 *           colon is not part of the file name. DOS file names do not differ
 *           between uppercase and lowercase notation. All letters and digits
 *           are permitted as well as the special characters "_", "^", "$",
 *           "~", "!", "#", "%", "&", "-", "{","}", "(", ")", "@" and "' ".
 *           Reserved file names are CLOCK$, CON, AUX, COM1 to COM4, LPT1 to
 *           LPT3, NUL and PRN. The two characters "*" and "?" have the
 *           function of so-called "wildcards", i.e., they are variables for
 *           selection of several files. The question mark "?" replaces
 *           exactly one character which may be any, the asterisk means any of
 *           the remaining characters in the file name. "*.*" thus means all
 *           files in a directory.
 *****************************************************************************/
ViStatus rsetl_FileManagerOperations(ViSession instrSession,
                                     ViInt32   operation,
                                     ViString  source,
                                     ViString  destination)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, operation, 0, 7),
            2, "Operation");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, source), 3, "Source");

    switch(operation){
        case RSETL_VAL_FILE_NEW:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_MANAGER_MAKE_DIR, source));
        break;
        case RSETL_VAL_FILE_COPY:
            viCheckParm(RsCore_InvalidNullPointer(instrSession, destination), 4, "Destination");
            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":MMEM:COPY '%s','%s'", source, destination);
            checkErr(RsCore_Write(instrSession, cmd));
        break;
        case RSETL_VAL_FILE_RENAME:
            viCheckParm(RsCore_InvalidNullPointer(instrSession, destination), 4, "Destination");
            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":MMEM:MOVE '%s','%s'", source, destination);
            checkErr(RsCore_Write(instrSession, cmd));
        break;
        case RSETL_VAL_FILE_DELETE:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_MANAGER_DELETE, source));
        break;
        case RSETL_VAL_FILE_RDIR:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_MANAGER_DELETE_DIR, source));
        break;
        case RSETL_VAL_FILE_CDIR:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_MANAGER_EDIT_PATH, source));
        break;
        case RSETL_VAL_FILE_CDISC:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_MANAGER_EDIT_PATH_DEVICE, source));
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: File Directory
 * Purpose:  This function reads the indicated directory. According to DOS
             convention, wild card characters can be entered in order to
             query eg. a list of all file of a certain type.
 *****************************************************************************/
ViStatus rsetl_FileDirectory(ViSession instrSession,
                             ViString  directory,
                             ViInt32   bufferSize,
                             ViChar    output[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, directory), 2, "Directory");
    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "*CLS;:MMEM:CAT? '%s'", directory);
    checkErr(RsCore_QueryViStringUnknownLengthToUserBuffer(instrSession, cmd, bufferSize , output, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get Current Directory
 * Purpose:  This function returns the default directory for mass memory
 *           storage (current directory).
 *****************************************************************************/
ViStatus rsetl_GetCurrentDirectory(ViSession instrSession,
                                   ViChar    currentDirectory[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_FILE_MANAGER_EDIT_PATH,
            RS_MAX_MESSAGE_BUF_SIZE, currentDirectory),
            2, "CurrentDirectory");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Read To File From Instrument
 * Purpose:  This function is used to read data from the instrument and write
 *           it to a user specified file on the host computer.
 *****************************************************************************/
ViStatus rsetl_ReadToFileFromInstrument(ViSession instrSession,
                                        ViString  source,
                                        ViString  destination)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "MMEM:DATA? '%s'", source);
    checkErr(RsCore_QueryBinaryDataBlockToFile(instrSession, cmd, destination, RS_VAL_TRUNCATE));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Write From File To Instrument
 * Purpose:  This function is used to read data from the host computer and
 *           write it to a user specified file in the instrument.
 *****************************************************************************/
ViStatus rsetl_WriteFromFileToInstrument(ViSession instrSession,
                                         ViString  source,
                                         ViString  destination)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "MMEM:DATA '%s',", destination);
    checkErr(RsCore_WriteBinaryDataFromFile(instrSession, cmd, source));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Data Set File Operations
 * Purpose:  This function allows to provide data set operation for
 *           Save/Recall items of memory subsystem.
 *****************************************************************************/
ViStatus rsetl_DataSetFileOperations(ViSession instrSession,
                                     ViInt32   operation,
                                     ViString  path)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, operation, 0, 7),
            2, "Operation");

    switch(operation){
        case RSETL_VAL_MEM_SAVE:
            viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_SAVE, path),
                    2, "Path");
        break;
        case RSETL_VAL_MEM_RECALL:
            viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_RECALL, path),
                    2, "Path");
        break;
        case RSETL_VAL_MEM_DELETE:
            viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_DATA_CLEAR, path),
                    2, "Path");
        break;
        case RSETL_VAL_MEM_STARTUP:
            viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_STARTUP_RECALL, path),
                    2, "Path");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Data Set File Clear All
 * Purpose:  This function deletes all device settings in the selected
 *           directory.
 *****************************************************************************/
ViStatus rsetl_DataSetFileClearAll(ViSession instrSession,
                                   ViString  directory)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_MANAGER_EDIT_PATH, directory),
            2, "Directory");
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_DATA_CLEAR_ALL, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Data Set File Select Items
 * Purpose:  This function add/remove settings to/from the list of partial
 *           datasets of a device setting to be stored/loaded.
 *****************************************************************************/
ViStatus rsetl_DataSetFileSelectItems(ViSession instrSession,
                                      ViInt32   itemSelector,
                                      ViBoolean itemState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, itemSelector, 0, 7),
            2, "Item Selector");

    switch(itemSelector){
        case RSETL_VAL_FILE_ITEMS_NONE:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_NONE, NULL));
        break;
        case RSETL_VAL_FILE_ITEMS_DEFAULT:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_DEFAULT, NULL));
        break;
        case RSETL_VAL_FILE_ITEMS_ALL:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_ALL, NULL));
        break;
        case RSETL_VAL_FILE_ITEMS_HWSETTINGS:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_HWSETTINGS, itemState),
                    3, "Item State");
        break;
        case RSETL_VAL_FILE_ITEMS_ALLTRACES:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAC, itemState),
                    3, "Item State");
        break;
        case RSETL_VAL_FILE_ITEMS_ALLLINES:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_LINE, itemState),
                    3, "Item State");
        break;
        case RSETL_VAL_FILE_ITEMS_SOUR_CAL_DATA:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_SOURCE_CAL_DATA, itemState),
                    3, "Item State");
        break;
        case RSETL_VAL_FILE_ITEMS_ALLTRAN:
            viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAN, itemState),
                    3, "Item State");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Calibration
 * Purpose:  This function initiates the acquisition of system error
 *           correction data. A "0" is returned if the acquisition was
 *           successful.
 *****************************************************************************/
ViStatus rsetl_SANCalibration(ViSession instrSession,
                              ViBoolean sync,
                              ViUInt32  timeout,
                              ViInt32*  result)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, sync), 2, "Sync");
    if (sync == VI_TRUE)
    {
        viCheckParm(RsCore_InvalidViInt32Range(instrSession, timeout, 0, 600000),
                3, "Timeout");
        checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
        checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
        viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_CALIBRATION_CHECK, result),
                4, "Result");
    }
    else
    {
        checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CALIBRATION, NULL));
    }

//  checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout >= 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Calibration Abort
 * Purpose:  This function aborts the acquisition of correction data and
 *           restores the last complete correction data set.
 *****************************************************************************/
ViStatus rsetl_SANCalibrationAbort(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_CALIBRATION_ABORT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Calibration Result
 * Purpose:  This function reads the results of the correction data
 *           acquisition. The lines of the result table (see manual section
 *           "Recording the correction data of FSQ - CAL key") are output as
 *           string data separated by commas:
 *           "Total Calibration Status: PASSED","Date (dd/mm/yyyy):
 *           12/07/1999", "Time: 16:24:54","Runtime:00.06"
 *****************************************************************************/
ViStatus rsetl_SANCalibrationResult(ViSession instrSession,
                                    ViInt32   arraySize,
                                    ViChar    result[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    //viCheckParm(rsetl_GetAttributeViString(instrSession, "",
    //        RSETL_ATTR_CALIBRATION_RESULT_QUERY, arraySize, result), 2, "Result");
    checkErr(RsCore_QueryViStringUnknownLengthToUserBuffer(instrSession, "CAL:RES?", arraySize, result, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Calibration State
 * Purpose:  This function determines whether the current calibration data are
 *           taken into account by the instrument (ON) or not (OFF).
 *****************************************************************************/
ViStatus rsetl_SANCalibrationState(ViSession instrSession,
                                   ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_CALIBRATION_STATE, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN User Ports State
 * Purpose:  This function toggles the control lines of the user ports between
 *           INPut and OUTPut. With ON, the user port is switched to INPut,
 *           with OFF to OUTPut.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANUserPortsState(ViSession instrSession,
                                          ViBoolean userPortsState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_INP_UPORT_STATE, userPortsState),
            3, "User Ports State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Output Control Lines
 * Purpose:  This function sets the control lines of the user ports.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANOutputControlLines(ViSession instrSession,
                                              ViString  controlLines)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_OUT_UPORT_VALUE, controlLines),
            3, "Control Lines");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get SAN User Ports Control Lines
 * Purpose:  This function queries the control lines of the user ports.
 *****************************************************************************/
ViStatus rsetl_GetSANUserPortsControlLine(ViSession instrSession,
                                          ViInt32   lines,
                                          ViChar    controlLines[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, lines, 0, 1),
            2, "Lines");

    switch (lines){

        case RSETL_VAL_USER_PORT_INP:
            viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_INP_UPORT_VALUE,
                    8, controlLines),
                    3, "Control Lines");
        break;
        case RSETL_VAL_USER_PORT_OUT:
            viCheckParm(rsetl_GetAttributeViString(instrSession, "", RSETL_ATTR_OUT_UPORT_VALUE,
                    8, controlLines),
                    3, "Control Lines");
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Service Input
 * Purpose:  This function toggles between the RF input on the front panel
 *           and the internal 65.83 MHz reference signal.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANServiceInput(ViSession instrSession,
                                        ViInt32   input)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_SERVICE_INPUT_SOURCE, input),
            2, "Input");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/*****************************************************************************
 * Function: Configure SAN Service Comb Frequency
 * Purpose:  This function sets the comb generator frequency. This function
 *           only takes effect, if the internal reference signal is selected
 *           for calibration (DIAGnostic<1|2>:SERVice:INPut[:SELect]).
 *****************************************************************************/
ViStatus rsetl_ConfigureSANServiceCombFrequency(ViSession instrSession,
                                                ViInt32   frequency)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_SERVICE_INPUT_COMB_FREQUENCY, frequency),
            2, "Frequency");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/*****************************************************************************
 * Function: Configure SAN Service Noise Source
 * Purpose:  This function switches the 28-V supply of the noise source at
 *           the rear panel on or off.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANServiceNoiseSource(ViSession instrSession,
                                              ViBoolean noiseSource)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_SERVICE_NOISE_SOURCE, noiseSource),
            2, "Noise Source");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/*****************************************************************************
 * Function: Configure SAN Service HW Info
 * Purpose:  This function queries the contents of the module info table.
 *           Table lines are output as string data and are separated by commas.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANServiceHWInfo(ViSession instrSession,
                                         ViInt32   bufferSize,
                                         ViChar    HWInfo[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringUnknownLengthToUserBuffer(instrSession, "DIAG:SERV:HWIN?", bufferSize, HWInfo, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/*****************************************************************************
 * Function: Read SAN Y Trace
 * Purpose:  This function initiates a signal acquisition based on the present
 *           instrument configuration.  It then waits for the acquisition to
 *           complete, and returns the trace as an array of amplitude values.
 *           The amplitude array returns data that represent the amplitude of
 *           the signals of the sweep from the start frequency to the stop
 *           frequency (in frequency domain, in time domain the amplitude array
 *           is ordered from beginning of sweep to end).  The Amplitude Units
 *           attribute determines the units of the points in the amplitude
 *           array.  This function resets the sweep count.
 *****************************************************************************/
ViStatus rsetl_ReadSANYTrace(ViSession instrSession,
                             ViInt32   trace,
                             ViUInt32  maximumTime,
                             ViInt32   arrayLength,
                             ViInt32*  actualPoints,
                             ViReal64  amplitude[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");
    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, maximumTime, 0, 4294967295), 3, "Maximum Time");

    checkErr(rsetl_SANInitiate(instrSession, maximumTime));

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":TRAC? TRACE%ld", trace);
    checkErr(rsetl_dataReadTrace(instrSession, cmd, arrayLength,
                    amplitude, actualPoints));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Fetch SAN Y Trace
 * Purpose:  This function returns the trace the spectrum analyzer acquires.
 *           The trace is from a previously initiated acquisition.  You use the
 *           rsetl_Initiate function to start an acquisition.  You use the
 *           rsetl_AcquisitionStatus function to determine when the acquisition
 *           is complete.
 *****************************************************************************/
ViStatus rsetl_FetchSANYTrace(ViSession instrSession,
                              ViInt32   trace,
                              ViInt32   arrayLength,
                              ViInt32*  actualPoints,
                              ViReal64  amplitude[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":TRAC? TRACE%ld", trace);

    checkErr(rsetl_dataReadTrace(instrSession, cmd, arrayLength, amplitude, actualPoints));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Read SAN Trace IQ Data
 * Purpose:  This function will start a measurement and read I/Q trace data
 *           results. The result values are scaled linear in unit Volt and
 *           correspond to the voltage at the RF input of the instrument.
 *****************************************************************************/
ViStatus rsetl_ReadSANTraceIQData(ViSession instrSession,
                                  ViUInt32  timeout,
                                  ViInt32   bufferSize,
                                  ViInt32*  noofPoints,
                                  ViReal64  realPartsI[],
                                  ViReal64  imaginaryPartsQ[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE] = "";

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":FORM REAL,32;*CLS;:TRAC:IQ:DATA?");
    checkErr(rsetl_dataReadInterleaved(instrSession, cmd, timeout, bufferSize, realPartsI, imaginaryPartsQ, noofPoints));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Fetch SAN Trace IQ Data
 * Purpose:  This function permits the readout of previously acquired (and
 *           frequency response corrected) I/Q data from the memory, with
 *           indication of the offset related to the start of measurement and
 *           with indication of the number of measurement values. Therefore a
 *           previously acquired data set can be read out in smaller portions.
 *           The result values are scaled linear in unit Volt and correspond to
 *           the voltage at the RF input of the instrument.
 *****************************************************************************/
ViStatus rsetl_FetchSANTraceIQData(ViSession instrSession,
                                   ViInt32   offsetSamples,
                                   ViInt32   noofSamples,
                                   ViInt32   bufferSize,
                                   ViInt32*  noofPoints,
                                   ViReal64  realPartsI[],
                                   ViReal64  imaginaryPartsQ[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, ":FORM REAL,32;*CLS;:TRAC:IQ:DATA:MEM? %ld,%ld", offsetSamples, noofSamples);
    checkErr(rsetl_dataReadInterleaved(instrSession, cmd, 0, bufferSize, realPartsI, imaginaryPartsQ, noofPoints));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get SAN Limit Check Result
 * Purpose:  This function queries the result of the limit check of the limit
 *           line indicated in the selected measurement window. It should be
 *           noted that a complete sweep must have been performed for obtaining
 *           a valid result. A synchronization with  *OPC, *OPC? or *WAI should
 *           therefore be provided.
 *****************************************************************************/
ViStatus rsetl_GetSANLimitCheckResult(ViSession instrSession,
                                      ViInt32   limit,
                                      ViInt32*  state)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, limit, 1, 8),
            2, "Limit");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "L%ld", limit);

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, repCap, RSETL_LIMIT_CHECK_RESULT, state),
            3, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Initiate
 * Purpose:  This function initiates an acquisition. After calling this
 *           function, the spectrum analyzer leaves the idle state and waits
 *           for a trigger.
 *
 *           This function does not check the instrument status. Typically,
 *           the end-user calls this function only in a sequence of calls to
 *           other low-level driver functions. The sequence performs one
 *           operation. The end-user uses the low-level functions to optimize
 *           one or more aspects of interaction with the instrument.
 *****************************************************************************/
ViStatus rsetl_SANInitiate(ViSession instrSession,
                           ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 3, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    checkErr(rsetl_SetAttributeViString(instrSession, NULL, RSETL_ATTR_INIT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout > 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Abort
 * Purpose:  This function aborts a previously initiated measurement and
 *           returns the spectrum analyzer to the idle state.
 *****************************************************************************/
ViStatus rsetl_SANAbort(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_ABORT, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Continue
 * Purpose:  This function continues a stopped measurement at the current
 *           position in single sweep mode. The function is useful especially
 *           for trace functions MAXHold, MINHold and AVERage if the previous
 *           results are not to be cleared with Sweep Count > 0 or Average
 *           Count > 0 on restarting the measurement (INIT:IMMediate resets the
 *           previous results on restarting the measurement).
 *           The single-sweep mode is automatically switched on.
 *           Synchronization to the end of the indicated number of measurements
 *           can then be performed with the command *OPC, *OPC? or *WAI. In the
 *           continuous-sweep mode, synchronization to the sweep end is not
 *           possible since the overall measurement never ends.
 *****************************************************************************/
ViStatus rsetl_SANContinue(ViSession instrSession,
                           ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_INIT_CONMEAS, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout > 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Send Software Trigger
 * Purpose:  This function sends a command to trigger the SpecAn.  Call this
 *           function if the trigger source is set to software trigger.
 *****************************************************************************/
ViStatus rsetl_SANSendSoftwareTrigger(ViSession instrSession,
                                      ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_INIT_SW_TRIGGER, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout > 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get SAN Sweep Number
 * Purpose:  This function returns the current number of started sweeps. A
 *           sweep count value should be set and the device should be in single
 *           sweep mode.
 *****************************************************************************/
ViStatus rsetl_GetSANSweepNumber(ViSession instrSession,
                                 ViInt32*  numberOfSweeps)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RSETL_ATTR_SWEEP_COUNT_CURRENT, numberOfSweeps),
            2, "Number Of Sweeps");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Tracking Generator State
 * Purpose:  This function sets the tracking generator operating modes.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTrackingGeneratorState(ViSession instrSession,
                                                  ViBoolean trackingGenerator)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_TRACK_GEN_STATE, trackingGenerator),
            2, "Tracking Generator");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Tracking Corr State
 * Purpose:  This function activates/deactivates normalization of the
 *           measurement results. The function is available only after
 *           acquisition of a reference trace for the selected type of
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTrackingGeneratorCorrState(ViSession instrSession,
                                                      ViBoolean corrState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_TRACK_GEN_CORR_STATE, corrState),
            2, "Corr State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Tracking Correction
 * Purpose:  This function calls the tracking generator calibrations.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTrackingGeneratorCorr(ViSession instrSession,
                                                 ViInt32   sourceCalibration,
                                                 ViInt32   timeoutms)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeoutms, 0, 4294967295), 3, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeoutms));

    switch (sourceCalibration)
    {
        case RSETL_VAL_TRACK_GEN_CAL_TRANS:
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRACK_GEN_MEAS_TYPE, RSETL_VAL_TRACK_GEN_MEAS_TYPE_TRAN));
            checkErr(rsetl_CheckStatus(instrSession));
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRACK_GEN_CAL_RESULT_TYPE, RSETL_VAL_TRACK_GEN_CAL_RES_TYPE_THR));
        break;
        case RSETL_VAL_TRACK_GEN_CAL_OPEN:
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRACK_GEN_MEAS_TYPE, RSETL_VAL_TRACK_GEN_MEAS_TYPE_REFL));
            checkErr(rsetl_CheckStatus(instrSession));
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRACK_GEN_CAL_RESULT_TYPE, RSETL_VAL_TRACK_GEN_CAL_RES_TYPE_OPEN));
        break;
        case RSETL_VAL_TRACK_GEN_CAL_SHORT:
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRACK_GEN_MEAS_TYPE, RSETL_VAL_TRACK_GEN_MEAS_TYPE_REFL));
            checkErr(rsetl_CheckStatus(instrSession));
            checkErr(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_TRACK_GEN_CAL_RESULT_TYPE, RSETL_VAL_TRACK_GEN_CAL_RES_TYPE_THR));
        break;
        case RSETL_VAL_TRACK_GEN_RECALL:
            checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_TRACK_GEN_RECALL_SETTINGS, NULL));
        break;
        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, sourceCalibration), 2, "Source Calibration");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout > 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Tracking Output Level
 * Purpose:  This function defines the output level of the tracking generator.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTrackingGeneratorOutputLevel(ViSession instrSession,
                                                        ViReal64  outputLevel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL, outputLevel),
            2, "Output Level");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Tracking Output Level Offset
 * Purpose:  This function calls the tracking generator calibrations.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTrackingGeneratorOutputLevelOffset(
                            ViSession instrSession,
                            ViReal64  outputLevelOffset)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL_OFFSET, outputLevelOffset),
            2, "Output Level Offset");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Noise Measurement
 * Purpose:  This function switches the noise measurement on or off for all
 *           markers of the indicated measurement window. The noise power
 *           density is measured at the position of the markers.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerNoiseMeasurement(ViSession instrSession,
                                                  ViInt32   marker,
                                                  ViBoolean state)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MARKER_NOISE_STATE, state),
            3, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Marker Noise Measurement Result
 * Purpose:  This function queries the result of the noise measurement.
 *           A complete sweep with synchronization to the sweep end must be
 *           performed between switching on the function and querying the
 *           measured value in order to obtain a valid query result. This is
 *           only possible in single sweep mode.
 *****************************************************************************/
ViStatus rsetl_QuerySANMarkerNoiseMeasurementResult(ViSession instrSession,
                                                    ViInt32   marker,
                                                    ViReal64* result)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
            2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_NOISE_RESULT, result),
            3, "Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Phase Noise Measurement
 * Purpose:  This function configures phase noise marker measurement. To setup
 *           reference point use function rsetl_ConfigureSANReferenceFixedPoint.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerPhaseNoiseMeasurement(ViSession instrSession,
                                                       ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_REFERENCE_MARKER_PNO_STATE, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Phase Noise Peak Search
 * Purpose:  This function defines a new reference point level for delta
 *           marker 2.
 *****************************************************************************/
ViStatus rsetl_SANPhaseNoisePeakSearch(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MARKER_REF_PEAK, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Phase Noise Result
 * Purpose:  This function queries the result of the phase-noise measurement
 *           in the selected measurement window. The measurement will be
 *           switched on, if necessary.
 *****************************************************************************/
ViStatus rsetl_QuerySANPhaseNoiseResult(ViSession instrSession,
                                        ViReal64* phaseNoiseResult)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_REFERENCE_MARKER_PNO_RESULT, phaseNoiseResult),
            2, "Phase Noise Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Marker Frequency Counter
 * Purpose:  This function sets the marker frequency counter resolution and
 *           turns the marker frequency counter on/off.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMarkerFrequencyCounter(ViSession instrSession,
                                                  ViInt32   marker,
                                                  ViBoolean markerFrequencyCounter,
                                                  ViReal64  frequencyCounterResolution)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

     viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
             2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MARKER_FREQUENCY_COUNTER_ENABLED, markerFrequencyCounter),
            3, "Marker Frequency Counter");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_FREQUENCY_COUNTER_RESOLUTION, frequencyCounterResolution),
            4, "Freqeuncy Counter Resolution");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Marker Frequency Counter Result
 * Purpose:  This function queries the result of the frequency counter for the
 *           indicated marker in the selected measurement window. Before the
 *           command, the frequency counter should be switched on and a
 *           complete measurement performed to obtain a valid count result.
 *           Therefore, a single sweep with synchronization must be performed
 *           between switching on the frequency counter and querying the count
 *           result.
 *****************************************************************************/
ViStatus rsetl_QuerySANMarkerFrequencyCounterResult(ViSession instrSession,
                                                    ViInt32   marker,
                                                    ViReal64* counterFrequency)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

     viCheckParm(RsCore_InvalidViInt32Range(instrSession, marker, 1, 4),
             2, "Marker");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "M%ld", marker);
    viCheckParm(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MARKER_COUNT, counterFrequency),
            3, "Counter Freqeuncy");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN N dB Points
 * Purpose:  This function configures the N dB function.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANNdBPoints(ViSession instrSession,
                                     ViBoolean ndBState,
                                     ViReal64  ndBLevel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MARKER_NDB_STATE, ndBState),
            2, "N dB State");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_NDB_VAL, ndBLevel),
            3, "N dB Level");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN N dB Result
 * Purpose:  This function queries the frequency spacing (bandwidth) of the
 *           N-dB-down markers in the selected measurement window.
 *           A complete sweep with synchronization to sweep end must be
 *           performed between switching on the function and querying the
 *           measured value in order to obtain a valid query result. This is
 *           only possible in single sweep mode.
 *****************************************************************************/
ViStatus rsetl_QuerySANNdBResult(ViSession instrSession,
                                 ViReal64* ndBResult)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MARKER_NDB_RESULT, ndBResult),
            2, "N dB Result");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN N dB Frequencies
 * Purpose:  This function queries the two frequencies of the N-dB-down marker
 *           in the selected measurement window. The two frequency values are
 *           output in ascending order.
 *****************************************************************************/
ViStatus rsetl_QuerySANNdBFrequencies(ViSession instrSession,
                                      ViReal64* ndBFrequencyLower,
                                      ViReal64* ndBFrequencyHigher)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, ndBFrequencyLower), 2, "N dB Frequency Lower");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, ndBFrequencyHigher), 3, "N dB Frequency Higher");

    checkErr(RsCore_QueryTupleViReal64(instrSession, "CALC:MARK:FUNC:NDBD:FREQ?", ndBFrequencyLower, ndBFrequencyHigher, NULL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN N dB Times
 * Purpose:  This function queries the two times of the N-dB-down marker in
 *           the selected measurement window.
 *****************************************************************************/
ViStatus rsetl_QuerySANNdBTimes(ViSession instrSession,
                                ViReal64  *ndBTimeLower,
                                ViReal64  *ndBTimeHigher)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, ndBTimeLower), 2, "N dB Time Lower");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, ndBTimeHigher), 3, "N dB Time Higher");

    checkErr(RsCore_QueryTupleViReal64(instrSession, "CALC:MARK:FUNC:NDBD:TIME?", ndBTimeLower, ndBTimeHigher, NULL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN List Power Sequence
 * Purpose:  This function configures the list of settings (max. 100 entries
 *           for an individual frequency point) for the multiple power
 *           measurement and starts a measurement sequence. To reduce the
 *           setting time, all indicated parameters are set up simultaneously
 *           at each test point.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANListPowerSequence(ViSession instrSession,
                                             ViInt32   noofListItems,
                                             ViReal64  analyzerFrequency[],
                                             ViReal64  referenceLevel[],
                                             ViReal64  rfInputAttenuation[],
                                             ViReal64  rfInputElectronicAttn[],
                                             ViInt32   filterType[],
                                             ViReal64  resolutionBandwidth[],
                                             ViReal64  videoBandwidth[],
                                             ViReal64  measTime[],
                                             ViReal64  triggerLevel[])
{
    ViStatus error = VI_SUCCESS;
    ViChar*  writeBuffer = NULL;
    ViChar*  p2buf;
    ViInt32  i = 0;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, noofListItems, 1, 100),
            2, "No Of List Items");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, analyzerFrequency), 3, "Analyzer Frequency");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, referenceLevel), 4, "Reference Level");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, rfInputAttenuation), 5, "RF Input Attenuation");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, rfInputElectronicAttn), 6, "RF Input Electronic Attn");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, filterType), 7, "Filter Type");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, resolutionBandwidth), 8, "Resolutin Bandwidth");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, videoBandwidth), 9, "Video Bandwidth");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, measTime), 10, "Meas Time");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, triggerLevel), 11, "Trigger Level");

    /*
     * Alloc buffer. Size is calclulated as:
     * size of header + size required for one entry * number of entries
     */
    viCheckAlloc(writeBuffer = (ViChar*)malloc((size_t)(20 + 240 * noofListItems)));
    p2buf = writeBuffer;

    p2buf += sprintf (p2buf, ":SENS:LIST:POW:SEQ ");

    for (i = 0; i < noofListItems; i++)
    {
        // Electronic attenuator is not in the signal path.
        if (rfInputElectronicAttn[i] < 0)
        {
            p2buf += sprintf (p2buf, "%.12f,%.12f,%.12f,OFF,%s,%.12f,%.12f,%.12f,%.12f,",
                                analyzerFrequency[i],
                                referenceLevel[i],
                                rfInputAttenuation[i],
                                listFilterTypeArr[filterType[i]],// RFInputEAttn[i],
                                resolutionBandwidth[i],
                                videoBandwidth[i],
                                measTime[i],
                                triggerLevel[i]);
        }
        else
        {
            p2buf += sprintf (p2buf, "%.12f,%.12f,%.12f,%.12f,%s,%.12f,%.12f,%.12f,%.12f,",
                                analyzerFrequency[i],
                                referenceLevel[i],
                                rfInputAttenuation[i],
                                rfInputElectronicAttn[i],
                                listFilterTypeArr[filterType[i]],
                                resolutionBandwidth[i],
                                videoBandwidth[i],
                                measTime[i],
                                triggerLevel[i]);
        }
    }

    *--p2buf = '\0'; // Remove remaining comma

    checkErr(RsCore_Write(instrSession, writeBuffer));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (writeBuffer)
        free (writeBuffer);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN List Power Set
 * Purpose:  This function defines the constant settings for the list during
 *           multiple power measurement. Parameters Peak Meas, RMS Meas and AVG
 *           Meas define, which measurements are to be performed at the same
 *           time at the frequency point. Correspondingly, one, two or three
 *           results per frequency point are returned for the function Get List
 *           Power Sequence (actListPwrSeq). If all three parameters are set to
 *           OFF, the command generates an execution error.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANListPowerSet(ViSession instrSession,
                                        ViBoolean peakMeas,
                                        ViBoolean RMSMeas,
                                        ViBoolean AVGMeas,
                                        ViInt32   triggerMode,
                                        ViInt32   triggerSlope,
                                        ViReal64  triggerOffset,
                                        ViReal64  gateLength)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, peakMeas), 2, "Peak Meas");
    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, RMSMeas), 3, "RMS Meas");
    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, AVGMeas), 4, "AVG Meas");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, triggerMode, 0, 3),
            5, "Trigger Mode");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, triggerSlope, 0, 1),
            6, "Trigger Slope");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, triggerOffset, 0.0, 100.0), 7, "Trigger Offset");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, triggerOffset, 0.0, 100.0), 8, "Gate Length");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "SENS:LIST:POW:SET %s,%s,%s,%s,%s,%.12f,%.12f", switchArr[peakMeas], switchArr[RMSMeas], switchArr[AVGMeas],
            rsetl_rngTriggerSource.entries[triggerMode].cmdString, rsetl_rngPolarity.entries[triggerSlope].cmdString,
            triggerOffset, gateLength);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN List Power Measurement Off
 * Purpose:  This function deactivates the list measurement.
 *****************************************************************************/
ViStatus rsetl_SANListPowerMeasurementOff(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_LIST_POW_STATE_OFF, ""));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN List Power Sequence
 * Purpose:  This function returns the list of settings (max. 100 entries for
 *           an individual frequency point) for the multiple power measurement,
 *           starts a measurement sequence and returns the measured data. To
 *           reduce the setting time, all indicated parameters are set up
 *           simultaneously at each test point.
 *****************************************************************************/
ViStatus rsetl_QuerySANListPowerSequence(ViSession instrSession,
                                         ViInt32   noofListItems,
                                         ViReal64  analyzerFrequency[],
                                         ViReal64  referenceLevel[],
                                         ViReal64  RFInputAttenuation[],
                                         ViReal64  RFInputElectronicAttn[],
                                         ViInt32   filterType[],
                                         ViReal64  resolutionBandwidth[],
                                         ViReal64  videoBandwidth[],
                                         ViReal64  measTime[],
                                         ViReal64  triggerLevel[],
                                         ViReal64  listPowerResults[])
{
    ViStatus error = VI_SUCCESS;
    ViChar*  writeBuffer = NULL;
    ViChar*  p2buf;
    ViInt32  i = 0;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, noofListItems, 1, 100),
            2, "No Of List Items");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, analyzerFrequency), 3, "Analyzer Frequency");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, referenceLevel), 4, "Reference Level");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, RFInputAttenuation), 5, "RF Input Attenuation");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, RFInputElectronicAttn), 6, "RF Input Electronic Attn");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, filterType), 7, "Filter Type");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, resolutionBandwidth), 8, "Resolutin Bandwidth");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, videoBandwidth), 9, "Video Bandwidth");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, measTime), 10, "Meas Time");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, triggerLevel), 11, "Trigger Level");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, listPowerResults), 12, "List Power Results");

    viCheckAlloc(writeBuffer = (ViChar*)malloc((size_t)(20 + 240 * noofListItems)));
    p2buf = writeBuffer;
    p2buf += sprintf (p2buf, "*CLS;:SENS:LIST:POW:SEQ? ");

    for (i=0; i<noofListItems; i++)
        {
        // Electronic attenuator is not in the signal path.
        if (RFInputElectronicAttn[i] < 0)
            p2buf += sprintf (p2buf, "%.12f,%.12f,%.12f,OFF,%s,%.12f,%.12f,%.12f,%.12f,",
                                analyzerFrequency[i], referenceLevel[i], RFInputAttenuation[i],
                                /* RFInputEAttn[i], */ listFilterTypeArr[filterType[i]], resolutionBandwidth[i],
                                videoBandwidth[i], measTime[i], triggerLevel[i]);
        else
            p2buf += sprintf (p2buf, "%.12f,%.12f,%.12f,%.12f,%s,%.12f,%.12f,%.12f,%.12f,",
                                analyzerFrequency[i], referenceLevel[i], RFInputAttenuation[i],
                                RFInputElectronicAttn[i], listFilterTypeArr[filterType[i]], resolutionBandwidth[i],
                                videoBandwidth[i], measTime[i], triggerLevel[i]);
        }

    *--p2buf = '\0'; // Remove remaining comma

    checkErr(RsCore_QueryFloatArrayToUserBufferWithOpc(instrSession, writeBuffer, 0, noofListItems, listPowerResults, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (writeBuffer) free (writeBuffer);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN List Power Result
 * Purpose:  This function queries the result of a previous list measurement
 *           as configured and initiated with List Power Sequence. This
 *           function may be used to obtain measurement results in an
 *           asynchronous way, using the service request mechanism for
 *           synchronization with the end of the measurement. If no measurement
 *           results are available, the function will return a query error.
 *****************************************************************************/
ViStatus rsetl_QuerySANListPowerResult(ViSession instrSession,
                                       ViInt32   noofResults,
                                       ViReal64  listPowerResults[],
                                       ViInt32*  returnedValues)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, noofResults, 1), 3, "No Of Results");

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, "SENS:LIST:POW:RES?", noofResults, listPowerResults, returnedValues));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Time Domain Power Measurement State
 * Purpose:  This function switches on or off the previously selected time
 *           domain power measurements. Thus one or several measurements can be
 *           first selected and then switched on and off together with this
 *           attribute.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTimeDomainPowerMeasurementState(ViSession instrSession,
                                                           ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_TDOM_STATE, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Time Domain Power Measurement
 * Purpose:  This function configures parameters of time domain power
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTimeDomainPowerMeasurement(ViSession instrSession,
                                                      ViBoolean peak,
                                                      ViBoolean RMS,
                                                      ViBoolean mean,
                                                      ViBoolean standardDeviation,
                                                      ViBoolean average,
                                                      ViBoolean maxHold,
                                                      ViInt32   power)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_TDOM_PEAK, peak),
            2, "Peak");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_TDOM_RMS, RMS),
            3, "RMS");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_TDOM_MEAN, mean),
            4, "Mean");
    if (mean == VI_TRUE)
        viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_TDOM_SDEV, standardDeviation),
                5, "Standard Deviation");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_TDOM_AVG, average),
            6, "Average");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_TDOM_MAX_HOLD, maxHold),
            7, "Max Hold");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_TDOM_MODE, power),
            8, "Power");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Time Domain Power Measurement All Off
 * Purpose:  This function switches off all time domain measurements.
 *****************************************************************************/
ViStatus rsetl_SANTimeDomainPowerMeasurementAllOff(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_TDOM_AOFF, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Time Domain Power Measurement Set Reference
 * Purpose:  With this function the currently measured average value and RMS
 *           value are declared as reference values for relative measurements
 *           in the indicated measurement window.
 *           If the function of Averaging or Peak Hold is switched on, the
 *           current value is the accumulated measurement value at the time
 *           considered.
 *****************************************************************************/
ViStatus rsetl_SANTimeDomainPowerMeasurementSetReference(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_TDOM_SET_REFERENCE, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Time Domain Power Result
 * Purpose:  This function queries selected time domain power measurement
 *           result in the indicated measurement window.
 *****************************************************************************/
ViStatus rsetl_QuerySANTDomPowerResult(ViSession instrSession,
                                       ViInt32   measurement,
                                       ViInt32   resultType,
                                       ViReal64* result)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 3),
            2, "Measurement");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, resultType, 0, 2),
            3, "Result Type");

    switch (measurement){
        case RSETL_VAL_TDOM_PEAK:
            switch (resultType){
                case RSETL_VAL_TDOM_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_PEAK_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_TDOM_AVG_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_AVG_PEAK_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_TDOM_MAX_HOLD_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RESULT, result),
                            4, "Result");
                break;
            }
        break;
        case RSETL_VAL_TDOM_RMS:
            switch (resultType){
                case RSETL_VAL_TDOM_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_RMS_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_TDOM_AVG_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_AVG_RMS_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_TDOM_MAX_HOLD_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RMS_RESULT, result),
                            4, "Result");
                break;
            }
        break;
        case RSETL_VAL_TDOM_MEAN:
            switch (resultType){
                case RSETL_VAL_TDOM_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_MEAN_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_TDOM_AVG_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_AVG_MEAN_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_TDOM_MAX_HOLD_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_MEAN_RESULT, result),
                            4, "Result");
                break;
            }
        break;
        case RSETL_VAL_TDOM_SDEV:
            switch (resultType){
                case RSETL_VAL_TDOM_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_SDEV_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_TDOM_AVG_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_AVG_SDEV_RESULT, result),
                            4, "Result");
                break;
                case RSETL_VAL_TDOM_MAX_HOLD_RESULT:
                    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_SDEV_RESULT, result),
                            4, "Result");
                break;
            }
        break;
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query Time Domain Power Pulse Sequence Result
 * Purpose:  This function is used to determine the power of a sequence of signal
 *           pulses having the same interval, as are typical for the slots of a GSM
 *           signal, for example. The number of pulses to be measured as well
 *           as the measurement time and the period can be set. To define the
 *           position of the first pulse in the trace, a suitable offset can
 *           be entered.
 *****************************************************************************/
ViStatus rsetl_QuerySANTDomPowerPulseSequenceResult(ViSession instrSession,
                                                    ViReal64  timeOffsetOfFirstPulse,
                                                    ViReal64  measurementTime,
                                                    ViReal64  period,
                                                    ViInt32   numberOfPulses,
                                                    ViReal64  results[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, numberOfPulses, 1), 5, "Number Of Pulses");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 6, "Results");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:MARK:FUNC:MSUM? %.12f,%.12f,%.12f,%ld", timeOffsetOfFirstPulse, measurementTime, period, numberOfPulses);
    checkErr(RsCore_QueryFloatArrayToUserBufferWithOpc(instrSession, cmd, ((ViInt32)measurementTime + 10000), numberOfPulses, results, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Select SAN Power Measurement
 * Purpose:  This function configures the power measurement.
 *****************************************************************************/
ViStatus rsetl_SelectSANPowerMeasurement(ViSession instrSession,
                                         ViBoolean state,
                                         ViInt32   powerMeasurement)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViBooleanRange(instrSession, state), 2, "State");

    if (state == VI_TRUE)
    {
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_SELECT, powerMeasurement),
                3, "Power Measurement");
    }
    else
    {
        checkErr(rsetl_SetAttributeViString(instrSession, repCap, RSETL_ATTR_MEAS_POW_OFF, NULL));
    }
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Power Measurement
 * Purpose:  This function configures the adjacent power channels measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANPowerMeasurement(ViSession instrSession,
                                            ViInt32   noOfAdjChannels,
                                            ViInt32   channelMode,
                                            ViInt32   powerMode,
                                            ViBoolean resultMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_ADJ_NUM, noOfAdjChannels),
            2, "No Of Adj Channels");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_ADJ_MODE, channelMode),
            3, "Channel Mode");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_MODE, powerMode),
            4, "Power Mode");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_POW_RESULT_MODE, resultMode),
            5, "Result Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Power Channel Spacing
 * Purpose:  This function configures the adjacent power channel spacing.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANPowerChannelSpacing(ViSession instrSession,
                                               ViInt32   channel,
                                               ViInt32   channelNumber,
                                               ViReal64  spacing)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 2),
            2, "Channel");

    switch (channel){
        case RSETL_VAL_ACP_TX:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, channelNumber, 1, 1),
                    3, "Channel Number");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "CH%ld", channelNumber);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MEAS_POW_CHANNEL_SPACING, spacing),
                    4, "Spacing");
        break;
        case RSETL_VAL_ACP_ADJ:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_SPACING, spacing),
                    4, "Spacing");
        break;
        case RSETL_VAL_ACP_ALT:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, channelNumber, 1, 11),
                    3, "Channel Number");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "CH%ld", channelNumber);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MEAS_POW_ALT_CHANNEL_SPACING, spacing),
                    4, "Spacing");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Power Channel Bandwidth
 * Purpose:  This function configures the adjacent power channel bandwidth.
 *
 *           Note:
 *           (1) This function is only available in the frequency domain (span
 *           > 0).
 *****************************************************************************/
ViStatus rsetl_ConfigureSANPowerChannelBandwidth(ViSession instrSession,
                                                 ViInt32   channel,
                                                 ViInt32   channelNumber,
                                                 ViReal64  bandwidth)
{
    ViStatus error = VI_SUCCESS;
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channel, 0, 2),
            2, "Channel");

    switch (channel){
        case RSETL_VAL_ACP_TX:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, channelNumber, 1, 11),
                    3, "Channel Number");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "CH%ld", channelNumber);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MEAS_POW_CHANNEL_BANDWIDTH, bandwidth),
                    4, "Bandwidth");
        break;
        case RSETL_VAL_ACP_ADJ:
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_BANDWIDTH, bandwidth),
                    4, "Bandwidth");
        break;
        case RSETL_VAL_ACP_ALT:
            viCheckParm(RsCore_InvalidViInt32Range(instrSession, channelNumber, 1, 11),
                    3, "Channel Number");
            snprintf(repCap, RS_REPCAP_BUF_SIZE, "CH%ld", channelNumber);
            viCheckParm(rsetl_SetAttributeViReal64(instrSession, repCap, RSETL_ATTR_MEAS_POW_ALT_CHANNEL_BANDWIDTH, bandwidth),
                    4, "Bandwidth");
        break;
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Channel Power Trace
 * Purpose:  This function assigns the channel/adjacent channel power
 *           measurement of the indicated trace in the selected measurement
 *           window. The corresponding trace should be active, ie its states
 *           should differ from blank.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANChannelPowerTrace(ViSession instrSession,
                                             ViInt32   traceNumber)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_TRACE, traceNumber),
            2, "Trace Number");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Channel Power Standard
 * Purpose:  This function configures the standard for channel power
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANChannelPowerStandard(ViSession instrSession,
                                                ViInt32   ACPStandard)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_STANDARD, ACPStandard),
            2, "ACP Standard");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Power Adjust Reference Level
 * Purpose:  This sets the reference value for the relative measurement to the
 *           currently measured channel power.
 *****************************************************************************/
ViStatus rsetl_SANPowerAdjustReferenceLevel(ViSession instrSession,
                                            ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = -1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_POW_REF_VALUE, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout >= 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Power Preset Measurement
 * Purpose:  This function adjusts the frequency span, the measurement
 *           bandwidths and the detector as required for the number of
 *           channels, the channel bandwidths and the channel spacings selected
 *           in the active power measurement. If necessary, adjacent-channel
 *           power measurement is switched on prior to the adjustment.
 *****************************************************************************/
ViStatus rsetl_SANPowerPresetMeasurement(ViSession instrSession,
                                         ViInt32   channelPowerType,
                                         ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = -1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");
    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_ADJ_PRESET, channelPowerType),
            3, "Channel Power Type");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout >= 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Power Results
 * Purpose:  This function returns the power measurement results.
 *****************************************************************************/
ViStatus rsetl_QuerySANPowerResults(ViSession instrSession,
                                    ViInt32   powerMeasurement,
                                    ViInt32   arraySize,
                                    ViReal64  results[],
                                    ViInt32*  returnedValues)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, powerMeasurement, 0, 5),
            2, "Power Measurement");
    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, arraySize, 0), 3, "Array Size");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, results), 4, "Results");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:MARK:FUNC:POW:RES? %s", rsetl_rngMeasPowerSelect.entries[powerMeasurement].cmdString);
    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, cmd, arraySize, results, returnedValues));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN ACP Fast ACP State
 * Purpose:  This function switches on or off the high-speed channel/adjacent
 *           channel power measurement.
 *           The measurement itself is performed in the time domain on the
 *           center frequencies of the individual channels. The function
 *           automatically switches to the time domain and back. Depending on
 *           the selected mobile radio standard, weighting filters with
 *           sqrt(cos) characteristic or very steep-sided channel filters are
 *           used for band limitation.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANACPFastACPState(ViSession instrSession,
                                           ViBoolean fastACPState)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_ACP_HSP, fastACPState),
            3, "Fast ACP State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN ACP Channel Power Auto Adjust
 * Purpose:  This function adapts the reference level to the measured channel
 *           power and - if required - switches on previously the adjacent
 *           channel power measurement. This ensures that the signal path of
 *           the instrument is not overloaded. Since the measurement bandwidth
 *           is significantly smaller than the signal bandwidth in channel
 *           power measurements, the signal path can be overloaded although the
 *           trace is still significantly below the reference level. If the
 *           measured channel power equals the reference level, the signal path
 *           is not overloaded.
 *****************************************************************************/
ViStatus rsetl_SANACPChannelPowerAutoAdjust(ViSession instrSession,
                                            ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = -1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_ACP_PRESET_REF_LEVEL, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout >= 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN ACP Limit State
 * Purpose:  This function switches on and off the limit check for adjacent
 *           channel power measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANACPLimitState(ViSession instrSession,
                                         ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_ACP_LIMIT_STATE, state),
            2, "State");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN ACP Adjacent Channel Limit
 * Purpose:  This function defines the limit value of the adjacent channel.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANACPAdjacentChannelLimit(ViSession instrSession,
                                                   ViInt32   limitCheck,
                                                   ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    switch (limitCheck)
    {
        case RSETL_VAL_ACP_LIMIT_CHECK_OFF:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_ACP_LIMIT_ABS_STATE, VI_FALSE));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_ACP_LIMIT_REL_STATE, VI_FALSE));
        break;

        case RSETL_VAL_ACP_LIMIT_CHECK_ABS:
            viCheckParm(RsCore_InvalidViReal64Range(instrSession, limitValue, 0.0, 100.0), 3, "Limit Value");

            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:LIM:ACP:ACH:ABS %.12lf,0.0", limitValue);
            checkErr(RsCore_Write(instrSession, cmd));
            checkErr(rsetl_CheckStatus(instrSession));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_ACP_LIMIT_ABS_STATE, VI_TRUE));

        break;

        case RSETL_VAL_ACP_LIMIT_CHECK_REL:
            viCheckParm(RsCore_InvalidViReal64Range(instrSession, limitValue, -200.0, 200.0), 3, "Limit Value");

            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:LIM:ACP:ACH %.12lf,0.0", limitValue);
            checkErr(RsCore_Write(instrSession, cmd));
            checkErr(rsetl_CheckStatus(instrSession));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_ACP_LIMIT_REL_STATE, VI_TRUE));

        break;

        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, limitCheck), 2, "Limit Check");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN ACP Alternate Channel Limit
 * Purpose:  This function defines the limit value of the alternate adjacent
 *           channel.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANACPAlternateChannelLimit(ViSession instrSession,
                                                    ViInt32   channelNumber,
                                                    ViInt32   limitCheck,
                                                    ViReal64  limitValue)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channelNumber, 1, 11),
            2, "Channel Number");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "CH%ld", channelNumber);

    switch (limitCheck)
    {
        case RSETL_VAL_ACP_LIMIT_CHECK_OFF:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MEAS_ACP_ALT_LIMIT_ABS_STATE, VI_FALSE));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MEAS_ACP_ALT_LIMIT_REL_STATE, VI_FALSE));
        break;

        case RSETL_VAL_ACP_LIMIT_CHECK_ABS:
            viCheckParm(RsCore_InvalidViReal64Range(instrSession, limitValue, 0.0, 100.0), 4, "Limit Value");

            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:LIM:ACP:ALT%ld:ABS %.12lf,0.0", channelNumber, limitValue);
            checkErr(RsCore_Write(instrSession, cmd));
            checkErr(rsetl_CheckStatus(instrSession));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MEAS_ACP_ALT_LIMIT_ABS_STATE, VI_TRUE));

        break;

        case RSETL_VAL_ACP_LIMIT_CHECK_REL:
            viCheckParm(RsCore_InvalidViReal64Range(instrSession, limitValue, -200.0, 200.0), 4, "Limit Value");

            snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:LIM:ACP:ALT%ld %.12lf,0.0", channelNumber, limitValue);
            checkErr(RsCore_Write(instrSession, cmd));
            checkErr(rsetl_CheckStatus(instrSession));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, repCap, RSETL_ATTR_MEAS_ACP_ALT_LIMIT_REL_STATE, VI_TRUE));

        break;

        default:
            viCheckParm(RsCore_InvalidViInt32Value(instrSession, limitCheck), 3, "Limit Check");
    }

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN ACP Adjacent Channel Limit Check Results
 * Purpose:  This function returns the adjacent channel limit results.
 *****************************************************************************/
ViStatus rsetl_QuerySANACPAdjacentChannelLimitCheckResults(ViSession instrSession,
                                                           ViInt32*  lowerResult,
                                                           ViInt32*  upperResult)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, lowerResult), 2, "Lower Result");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, upperResult), 3, "Upper Result");

    checkErr(RsCore_QueryTupleViInt32(instrSession, "CALC:LIM:ACP:ACH:RES?", lowerResult, upperResult, NULL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN ACP Alternate Channel Limit Check Results
 * Purpose:  This function returns the alternate channel limit results.
 *****************************************************************************/
ViStatus rsetl_QuerySANACPAlternateChannelLimitCheckResults(ViSession instrSession,
                                                            ViInt32   channelNumber,
                                                            ViInt32*  lowerResult,
                                                            ViInt32*  upperResult)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, channelNumber, 1, 11),
            2, "Channel Number");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, lowerResult), 3, "Lower Result");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, upperResult), 4, "Upper Result");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:LIM:ACP:ALT%ld:RES?", channelNumber);
    checkErr(RsCore_QueryTupleViInt32(instrSession, cmd, lowerResult, upperResult, NULL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Multicarrier ACP Power
 * Purpose:  This function configures the adjacent power channels measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANMulticarrierACPPower(ViSession instrSession,
                                                ViInt32   noOfAdjChannels,
                                                ViInt32   noOfTXChannels,
                                                ViInt32   channelMode,
                                                ViInt32   powerMode,
                                                ViBoolean resultMode)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_ADJ_NUM, noOfAdjChannels),
            2, "No Of Adj Channels");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_CARR_SIG_NUM, noOfTXChannels),
            3, "No Of TX Channels");
    if (noOfAdjChannels>0)
        viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_ADJ_MODE, channelMode),
                4, "Channel Mode");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_MODE, powerMode),
            5, "Power Mode");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_POW_RESULT_MODE, resultMode),
            6, "Result Mode");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN ACP Reference Channel Auto
 * Purpose:  Activates the automatic selection of a transmission channel to be
 *           used as a reference channel in relative adjacent-channel power
 *           measurements. The transmission channel with the highest power, the
 *           transmission channel with the lowest power, or the transmission
 *           channel nearest to the adjacent channels can be defined as a
 *           reference channel.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANACPReferenceChannelAuto(ViSession instrSession,
                                                   ViInt32   reference)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_REF_CHAN_SEL_AUTO, reference),
            2, "Reference");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN ACP Reference Channel Man
 * Purpose:  This function selects a transmission channel to be used as a
 *           reference channel in relative adjacent-channel power measurements.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANACPReferenceChannelMan(ViSession instrSession,
                                                  ViInt32   channel)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_POW_ADJ_REF_TXCHANNEL, channel),
            2, "Channel");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Occupied Bandwidth
 * Purpose:  This function defines the percentage of the power with respect to
 *           the total power. This value is the basis for the occupied
 *           bandwidth measurement (command: POWer:ACHannel:PRESet OBW).
 *****************************************************************************/
ViStatus rsetl_ConfigureSANOccupiedBandwidth(ViSession instrSession,
                                             ViReal64  powerBandwidth,
                                             ViReal64  channelBandwidth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_POW_BANDWIDTH, powerBandwidth),
            2, "Power Bandwidth");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_POW_CHANNEL_BANDWIDTH, channelBandwidth),
            3, "Channel Bandwidth");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Signal Statistic Measurement
 * Purpose:  This function configures parameters of signal statistic
 *           measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSignalStatisticMeasurement(ViSession instrSession,
                                                      ViInt32   measurement,
                                                      ViInt32   numberofSamples,
                                                      ViReal64  resolutionBandwidth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, measurement, 0, 2),
            2, "Measurement");

    switch (measurement){
        case RSETL_VAL_SSTAT_OFF:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_STAT_APD_STATE, VI_FALSE));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_STAT_CCDF_STATE, VI_FALSE));
        break;
        case RSETL_VAL_SSTAT_APD:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_STAT_CCDF_STATE, VI_FALSE));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_STAT_APD_STATE, VI_TRUE));
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_STAT_SAMPLES, numberofSamples),
                    4, "Number Of Samples");
        break;
        case RSETL_VAL_SSTAT_CCDF:
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_STAT_APD_STATE, VI_FALSE));
            checkErr(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_STAT_CCDF_STATE, VI_TRUE));
            viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_STAT_SAMPLES, numberofSamples),
                    3, "Number Of Samples");
        break;
    }
    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_RESOLUTION_BANDWIDTH, resolutionBandwidth),
            4, "Resolution Bandwidth");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Signal Statistic Measurement X Axis
 * Purpose:  This function configures parameters of signal statistic
 *           measurement X-Axis scaling.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSignalStatisticMeasurementXAxis(ViSession instrSession,
                                                           ViReal64  xAxisRefLevel,
                                                           ViReal64  xAxisRange)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_STAT_X_REF, xAxisRefLevel),
            2, "X Axis Ref Level");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_STAT_X_RANGE, xAxisRange),
            3, "X Axis Range");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Signal Statistic Measurement Y Axis
 * Purpose:  This function configures parameters of signal statistic
 *           measurement Y Axis scaling.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSignalStatisticMeasurementYAxis(ViSession instrSession,
                                                           ViReal64  yAxisMaxValue,
                                                           ViReal64  yAxisMinValue)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_STAT_Y_MAX, yAxisMaxValue),
            2, "Y Axis Max Value");

    viCheckParm(rsetl_SetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_STAT_Y_MIN, yAxisMinValue),
            3, "Y Axis Min Value");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Signal Statistic Sweep
 * Purpose:  This function configures the acquisition attributes of signal
 *           statistic.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANSignalStatisticSweep(ViSession instrSession,
                                                ViBoolean sweepModeContinuous)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_SWEEP_MODE_CONTINUOUS, sweepModeContinuous),
            2, "Sweep Mode Continuous");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Signal Statistic Measurement Adjust Settings
 * Purpose:  This function optimizes the level setting of the instrument
 *           depending on the measured peak power, in order to obtain maximum
 *           instrument sensitivity.
 *****************************************************************************/
ViStatus rsetl_SANSignalStatisticMeasurementAdjustSettings(ViSession instrSession,
                                                           ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout = -1;

    checkErr(RsCore_LockSession(instrSession));

     viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");

    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_STAT_ADJ, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout >= 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Signal Statistic Measurement Preset Scaling
 * Purpose:  This function resets the scaling of the X and Y axes in a
 *           statistical measurement.
 *****************************************************************************/
ViStatus rsetl_SANSignalStatisticMeasurementPresetScaling(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_STAT_PRESET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Signal Statistic Result
 * Purpose:  This function reads out the results of statistical measurements
 *           of a recorded trace.
 *****************************************************************************/
ViStatus rsetl_QuerySANSignalStatisticResult(ViSession instrSession,
                                             ViInt32   trace,
                                             ViInt32   resultType,
                                             ViReal64* result)
{
    ViStatus error = VI_SUCCESS;
    ViString statisticMeasType[] = {"Mean","Peak","CrestFactor"};
    ViChar   repCap[RS_REPCAP_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, trace, 1, 4),
            2, "Trace");

    snprintf(repCap, RS_REPCAP_BUF_SIZE, "TR%ld,Stat%s", trace, statisticMeasType[resultType]);

    checkErr(rsetl_GetAttributeViReal64(instrSession, repCap, RSETL_ATTR_STAT_RESULT, result));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Signal Statistic All Results
 * Purpose:  This function reads out all three results of statistical measurements
 *           of a recorded trace.
 *****************************************************************************/
ViStatus rsetl_QuerySANSignalStatisticAllResults(ViSession instrSession,
                                                 ViInt32   trace,
                                                 ViReal64  result[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, trace, 1), 2, "Trace");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "CALC:STAT:RES%ld? ALL", trace);
    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, cmd, 8, result, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Modulation Depth Measurement
 * Purpose:  This function switches on the measurement of the AM modulation
 *           depth. An AM-modulated carrier is required on the screen for
 *           correct operation. If necessary, marker 1 is previously activated
 *           and set to the largest signal available.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANModDepthMeasurement(ViSession instrSession,
                                               ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_MDEPTH_STATE, state),
            2, "State");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Modulation Depth
 * Purpose:  This function queries the AM modulation depth.
 *****************************************************************************/
ViStatus rsetl_QuerySANModulationDepth(ViSession instrSession,
                                       ViReal64* modulationDepth)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_MDEPTH_RESULT, modulationDepth),
            2, "Modulation Depth");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Modulation Depth Signal Search
 * Purpose:  This function starts the search of the signals required for
 *           the modulation depth measurement.
 *****************************************************************************/
ViStatus rsetl_SANModulationDepthSignalSearch(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_MDEPTH_SEARCH, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN TOI Measurement
 * Purpose:  This function initiates the measurement of the third-order
 *           intercept point.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANTOIMeasurement(ViSession instrSession,
                                          ViBoolean state)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_TOI_STATE, state),
            2, "State");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN TOI
 * Purpose:  This function queries the third-order intercept point measurement
 *           in the indicated measurement window.
 *****************************************************************************/
ViStatus rsetl_QuerySANTOI(ViSession instrSession,
                           ViReal64* TOIMeasurement)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MEAS_TOI_RESULT, TOIMeasurement),
            2, "TOI Measurement");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN TOI Signal Search
 * Purpose:  This function starts the search of the signals required for the
 *           third order intercept measurement.
 *****************************************************************************/
ViStatus rsetl_SANTOISignalSearch(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_TOI_SEARCH, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Configure SAN Harmonic Distortion Measurement
 * Purpose:  This function configures harmonic distortion measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANHDistMeasurement(ViSession instrSession,
                                            ViBoolean state,
                                            ViInt32   noofHarmonics,
                                            ViBoolean harmonicRBWAuto)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_HDIST_STATE, state),
            2, "State");

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MEAS_HDIST_NOOFHARM, noofHarmonics),
            3, "No Of Harmonic");

    viCheckParm(rsetl_SetAttributeViBoolean(instrSession, "", RSETL_ATTR_MEAS_HDIST_RBWAUTO, harmonicRBWAuto),
            4, "Harmonic RBW Auto");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Adjust Harmonic Distortion Settings
 * Purpose:  This function optimizes the device settings depending on the mode
 *           in which the harmonic measurement was started:
 *           If the harmonic measurement was started in the frequency domain
 *           (span > 0), the frequency and the
 *           level of the first harmonic are calculated, from which the
 *           measurement list is set up.
 *           If the measurement was started in the time domain (span = 0), the
 *           frequency of the first harmonic is
 *           not changed. The level, however, is not calculated.
 *           The function is independent of the marker selection.
 *****************************************************************************/
ViStatus rsetl_SANAdjustHDistSettings(ViSession instrSession,
                                      ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;
    ViInt32  old_timeout=-1;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 2, "Timeout");
    checkErr(rsetl_GetOPCTimeout(instrSession, &old_timeout));
    checkErr(rsetl_SetOPCTimeout(instrSession, timeout));
    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_MEAS_HDIST_PRESET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    if (old_timeout > 0)
        rsetl_SetOPCTimeout(instrSession, old_timeout);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Harmonic Distortion
 * Purpose:  This function queries the results of the total harmonic
 *           distortion (THD).
 *****************************************************************************/
ViStatus rsetl_QuerySANHDist(ViSession instrSession,
                             ViReal64* harmonicDistortionInPercent,
                             ViReal64* harmonicDistortionInDB)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, harmonicDistortionInPercent), 2, "Harmonic Distortion in percent");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, harmonicDistortionInDB), 3, "Harmonic Distortion in dB");

    checkErr(RsCore_QueryTupleViReal64(instrSession, ":CALC:MARK:FUNC:HARM:DIST? TOT",
        harmonicDistortionInPercent, harmonicDistortionInDB, NULL, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query SAN Harmonic Distortion Harmonics List
 * Purpose:  This function reads out the list of harmonics. The first value is
 *           the absolute power of the first harmonic in the unit set via UNIT.
 *           The other values are relative to the carrier signal and are output
 *           in dB.
 *****************************************************************************/
ViStatus rsetl_QuerySANHDistHarmonicsList(ViSession instrSession,
                                          ViInt32   arraySize,
                                          ViReal64  harmonicsList[],
                                          ViInt32*  returnedValues)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, harmonicsList), 2, "Harmonic List");

    checkErr(RsCore_QueryFloatArrayToUserBuffer(instrSession, "CALC:MARK:FUNC:HARM:LIST?", arraySize, harmonicsList, returnedValues));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: SAN Burst Power Sequence
 * Purpose:  This function configures the instrument setup for multiple burst
 *           power measurement and starts a measurement sequence. To reduce the
 *           setting time, the setup is performed simultaneously for all
 *           selected parameters.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANBurstPowerSequence(ViSession instrSession,
                                              ViReal64  analyzerFrequencyHz,
                                              ViReal64  resolutionBandwidthHz,
                                              ViReal64  measTimes,
                                              ViInt32   triggerSource,
                                              ViReal64  triggerLevel,
                                              ViReal64  triggerOffsets,
                                              ViInt32   typeOfMeas,
                                              ViInt32   noOfMeasurements)
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViReal64RangeMin(instrSession, analyzerFrequencyHz, 0), 2, "Analyzer Frequency [Hz]");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, resolutionBandwidthHz, 10.0, 10.0e+6), 3, "Resolution Bandwidth [Hz]");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, measTimes, 1.0e-6, 30.0), 4, "Meas Time [s]");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, triggerLevel, 0.0, 100.0), 6, "Trigger Level");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, triggerOffsets, 125.0e-9, 100.0), 7, "Trigger Offset [s]");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, typeOfMeas, 0, 1),
            8, "Type Of Meas");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, noOfMeasurements, 1, 32001),
            9, "No Of Measurements");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "SENS:MPOW:SEQ %.12lf,%.12lf,%.12lf,%s,%.12lf,%.12lf,%s,%ld;*WAI",
        analyzerFrequencyHz,
        resolutionBandwidthHz,
        measTimes,
        rsetl_rngTriggerSource.entries[triggerSource].cmdString,
        triggerLevel,
        triggerOffsets,
        measTypeArr[typeOfMeas],
        noOfMeasurements);
    checkErr(RsCore_Write(instrSession, cmd));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Burst Power Filter Type
 * Purpose:  This function configures the filter type for the measurement.
 *****************************************************************************/
ViStatus rsetl_ConfigureSANBurstPowerFilterType(ViSession instrSession,
                                                ViInt32   filterType)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RSETL_ATTR_MPOW_FTYPE, filterType),
            2, "Filter Type");
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get SAN Burst Power Sequence
 * Purpose:  This function configures the instrument setup for multiple burst
 *           power measurement, starts a measurement sequence and reads the
 *           results. To reduce the setting time, the setup is performed
 *           simultaneously for all selected parameters.
 *****************************************************************************/
ViStatus rsetl_GetSANBurstPowerSequence(ViSession instrSession,
                                        ViReal64  analyzerFrequencyHz,
                                        ViReal64  resolutionBandwidthHz,
                                        ViReal64  measTimes,
                                        ViInt32   triggerSource,
                                        ViReal64  triggerLevel,
                                        ViReal64  triggerOffsets,
                                        ViInt32   typeOfMeas,
                                        ViInt32   noOfMeasurements,
                                        ViUInt32  timeout,
                                        ViReal64  burstPowerResults[])
{
    ViStatus error = VI_SUCCESS;
    ViChar   cmd[RS_MAX_MESSAGE_BUF_SIZE];

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViReal64RangeMin(instrSession, analyzerFrequencyHz, 0), 2, "Analyzer Frequency [Hz]");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, resolutionBandwidthHz, 10.0, 10.0e+6), 3, "Resolution Bandwidth [Hz]");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, measTimes, 1.0e-6, 30.0), 4, "Meas Time [s]");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, triggerLevel, 0.0, 100.0), 6, "Trigger Level");
    viCheckParm(RsCore_InvalidViReal64Range(instrSession, triggerOffsets, 125.0e-9, 100.0), 7, "Trigger Offset [s]");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, typeOfMeas, 0, 1),
            8, "Type Of Meas");
    viCheckParm(RsCore_InvalidViInt32Range(instrSession, noOfMeasurements, 1, 32001),
            9, "No Of Measurements");
    viCheckParm(RsCore_InvalidViUInt32Range(instrSession, timeout, 0, 4294967295), 10, "Timeout");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, burstPowerResults), 11, "Burst Power Results");

    snprintf(cmd, RS_MAX_MESSAGE_BUF_SIZE, "*CLS;:SENS:MPOW:SEQ? %.12lf,%.12lf,%.12lf,%s,%.12lf,%.12lf,%s,%ld",
        analyzerFrequencyHz,
        resolutionBandwidthHz,
        measTimes,
        rsetl_rngTriggerSource.entries[triggerSource].cmdString,
        triggerLevel,
        triggerOffsets,
        measTypeArr[typeOfMeas],
        noOfMeasurements);
    checkErr(RsCore_QueryFloatArrayToUserBufferWithOpc(instrSession, cmd, timeout, noOfMeasurements, burstPowerResults, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get SAN Burst Power Results
 * Purpose:  This function queries the results of a multiple burst power
 *           measurement as configured and initiated with Get Burst Power
 *           Result (actBurstPwrResult). The unit used for the return values is
 *           always dBm. This function may be used to obtain measurement
 *           results in an asynchronous way using the service request mechanism
 *           for synchronization with the end of the measurement. If no
 *           measurement results are available, the function will return a
 *           query error.
 *****************************************************************************/
ViStatus rsetl_GetSANBurstPowerResults(ViSession instrSession,
                                       ViInt32   noOfResults,
                                       ViReal64  burstPowerResults[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, noOfResults, 1), 2, "No Of Results");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, burstPowerResults), 3, "burstPowerResults");

    checkErr(RsCore_QueryFloatArrayToUserBufferWithOpc(instrSession, "SENS:MPOW:RES?", 0, noOfResults, burstPowerResults, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get SAN Burst Power Result Min
 * Purpose:  This function queries the minimum power value in a multiple burst
 *           power measurement as configured and initiated with Burst Power
 *           Sequence (confBurstPwrSeq). The unit used for the return values is
 *           always dBm. If no measurement result is available, the function
 *           will return a query error.
 *****************************************************************************/
ViStatus rsetl_GetSANBurstPwrResultMin(ViSession instrSession,
                                       ViReal64* powerResultMin)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViReal64(instrSession, "", RSETL_ATTR_MPOW_MIN, powerResultMin),
            2, "Power Result Min");

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: rsetl_SetAttribute<type> Functions
 * Purpose:  These functions enable the instrument driver user to set
 *           attribute values directly.  There are typesafe versions for
 *           ViInt32, ViReal64, ViString, ViBoolean, and ViSession datatypes.
 *****************************************************************************/

/* ViInt32 */
ViStatus rsetl_SetAttributeViInt32(ViSession instrSession,
                                   ViString  repeatedCapabilityName,
                                   ViUInt32  attributeId,
                                   ViInt32   value)
{
    ViStatus error = VI_SUCCESS;

    (void)RsCore_LockSession(instrSession);

    error = RsCore_SetAttributeViInt32(instrSession, repeatedCapabilityName, attributeId, RS_VAL_DIRECT_USER_CALL, value);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/* ViReal64 */
ViStatus rsetl_SetAttributeViReal64(ViSession instrSession,
                                    ViString  repeatedCapabilityName,
                                    ViUInt32  attributeId,
                                    ViReal64  value)
{
    ViStatus error = VI_SUCCESS;

    (void)RsCore_LockSession(instrSession);

    error = RsCore_SetAttributeViReal64(instrSession, repeatedCapabilityName, attributeId, RS_VAL_DIRECT_USER_CALL, value);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/* ViString */
ViStatus rsetl_SetAttributeViString(ViSession instrSession,
                                    ViString  repeatedCapabilityName,
                                    ViUInt32  attributeId,
                                    ViString  value)
{
    ViStatus error = VI_SUCCESS;

    (void)RsCore_LockSession(instrSession);

    error = RsCore_SetAttributeViString(instrSession, repeatedCapabilityName, attributeId, RS_VAL_DIRECT_USER_CALL, value);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/* ViBoolean */
ViStatus rsetl_SetAttributeViBoolean(ViSession instrSession,
                                     ViString  repeatedCapabilityName,
                                     ViUInt32  attributeId,
                                     ViBoolean value)
{
    ViStatus error = VI_SUCCESS;

    (void)RsCore_LockSession(instrSession);

    error = RsCore_SetAttributeViBoolean(instrSession, repeatedCapabilityName, attributeId, RS_VAL_DIRECT_USER_CALL, value);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: rsetl_GetAttribute<type> Functions
 * Purpose:  These functions enable the instrument driver user to get
 *           attribute values directly.  There are typesafe versions for
 *           ViInt32, ViReal64, ViString, ViBoolean, and ViSession attributes.
 *****************************************************************************/

/* ViInt32 */
ViStatus rsetl_GetAttributeViInt32(ViSession instrSession,
                                   ViString  repeatedCapabilityName,
                                   ViUInt32  attributeId,
                                   ViInt32   *value)
{
    ViStatus error = VI_SUCCESS;

    (void)RsCore_LockSession(instrSession);
    error = RsCore_GetAttributeViInt32(instrSession, repeatedCapabilityName, attributeId, RS_VAL_DIRECT_USER_CALL, value);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/* ViReal64 */
ViStatus rsetl_GetAttributeViReal64(ViSession instrSession,
                                    ViString  repeatedCapabilityName,
                                    ViUInt32  attributeId,
                                    ViReal64  *value)
{
    ViStatus error = VI_SUCCESS;

    (void)RsCore_LockSession(instrSession);
    error = RsCore_GetAttributeViReal64(instrSession, repeatedCapabilityName, attributeId, RS_VAL_DIRECT_USER_CALL, value);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/* ViString */
ViStatus rsetl_GetAttributeViString(ViSession instrSession,
                                    ViString  repeatedCapabilityName,
                                    ViUInt32  attributeId,
                                    ViInt32   bufferSize,
                                    ViChar    value[])
{
    ViStatus error = VI_SUCCESS;

    (void)RsCore_LockSession(instrSession);

    error = RsCore_GetAttributeViString(instrSession, repeatedCapabilityName, attributeId, RS_VAL_DIRECT_USER_CALL, bufferSize, value);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/* ViBoolean */
ViStatus rsetl_GetAttributeViBoolean(ViSession instrSession,
                                     ViString  repeatedCapabilityName,
                                     ViUInt32  attributeId,
                                     ViBoolean *value)
{
    ViStatus error = VI_SUCCESS;

    (void)RsCore_LockSession(instrSession);
    error = RsCore_GetAttributeViBoolean(instrSession, repeatedCapabilityName, attributeId, RS_VAL_DIRECT_USER_CALL, value);

    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Rs_GetAttributeRepCapNameId
 * Purpose:  This function returns the repeated capability id(s) that
 *           belongs to the attribute you specify. More then one id is listed
 *           in comma separated string.
 *****************************************************************************/
ViStatus rsetl_GetAttributeRepeatedCapabilityIds(ViSession instrSession,
                                                 ViUInt32  attributeID,
                                                 ViInt32   bufferSize,
                                                 ViChar    repeatedCapabilityIds[])
{
    ViStatus error = VI_SUCCESS;

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, bufferSize, 1, RS_MAX_SHORT_MESSAGE_BUF_SIZE),
            3, "Buffer Size");

    checkErr(RsCore_GetAttributeRepCapNameIds(instrSession, attributeID, bufferSize, repeatedCapabilityIds));

Error:
    return error;
}

/*****************************************************************************
 * Function: Get Attribute Repeated Capability Id Name(s)
 * Purpose:  This function returns the repeated capability name(s) that
 *           belongs to the attribute and single repeated capability id you
 *           may specify. More then one name is listed in comma separated
 *           string.
 *****************************************************************************/
ViStatus rsetl_GetAttributeRepeatedCapabilityIdNames(ViSession instrSession,
                                                     ViUInt32  attributeID,
                                                     ViString  repeatedCapabilityId,
                                                     ViInt32   bufferSize,
                                                     ViChar    repeatedCapabilityIdNames[])
{
    ViStatus error = VI_SUCCESS;

    viCheckParm(RsCore_InvalidViInt32Range(instrSession, bufferSize, 1, RS_MAX_SHORT_MESSAGE_BUF_SIZE),
            4, "Buffer Size");

    checkErr(RsCore_GetAttributeRepCapNamesAll(instrSession,
        attributeID,
        repeatedCapabilityId,
        bufferSize,
        repeatedCapabilityIdNames));

Error:
    return error;
}

/*****************************************************************************
 * Function: rsetl_CheckAttribute<type> Functions
 * Purpose:  These functions enable the instrument driver user to check
 *           attribute values directly.  These functions check the value you
 *           specify even if you set the rsetl_ATTR_RANGE_CHECK
 *           attribute to VI_FALSE.  There are typesafe versions for ViInt32,
 *           ViReal64, ViString, ViBoolean, and ViSession datatypes.
 *****************************************************************************/

/*****************************************************************************
 * Function: Option Checking
 * Purpose:  This function switches ON/OFF option checking of the instrument
 *****************************************************************************/
ViStatus rsetl_setCheckOption(ViSession instrSession,
                              ViBoolean optionChecking)
{
    ViStatus         error = VI_SUCCESS;
    RsCoreSessionPtr rsSession = NULL;

    checkErr(RsCore_GetRsSession(instrSession, &rsSession));
    rsSession->optionChecking = optionChecking;

Error:
    return error;
}

/*****************************************************************************
 * Function: Range Checking
 * Purpose:  This function switches ON/OFF range checking of the instrument
 *****************************************************************************/
ViStatus rsetl_setCheckRange(ViSession instrSession,
                             ViBoolean rangeChecking)
{  
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_SetAttributeViBoolean(instrSession, "", RS_ATTR_RANGE_CHECK, 0, rangeChecking));

Error:
    return error;
}

/*****************************************************************************
 * Function: Instrument Status Checking
 * Purpose:  This function switches ON/OFF instrument status checking of the
 *           instrument
 *****************************************************************************/
ViStatus rsetl_setCheckStatus(ViSession instrSession,
                              ViBoolean statusChecking)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_SetAttributeViBoolean(instrSession, "", RS_ATTR_QUERY_INSTRUMENT_STATUS, 0, statusChecking));

Error:
    return error;
}

/*****************************************************************************
 * Function: Reset
 * Purpose:  This function resets the instrument.
 *****************************************************************************/
ViStatus rsetl_reset(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    if (RsCore_Simulating(instrSession) == VI_FALSE)
    {
        checkErr(rsetl_ClearStatus(instrSession));
        checkErr(RsCore_Write(instrSession, "*RST")); // IGNORE: Check double write
        checkErr(RsCore_QueryViStringShort(instrSession, "*OPC?", NULL));
    }

    checkErr(rsetl_DefaultInstrSetup(instrSession));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);

    return error;
}

/// HIFN  This function clears status.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
ViStatus rsetl_ClearStatus(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_ClearStatus(instrSession));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  This function returns the ID Query response string.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR bufferSize/Size of IDQueryResponse buffer
/// HIPAR IDQueryResponse/Returns the ID Query response string. The array should consist of at
/// HIPAR IDQueryResponse/least 256 elements.
ViStatus rsetl_IDQueryResponse(ViSession instrSession,
                               ViUInt32  bufferSize,
                               ViChar    IDQueryResponse[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    if (RsCore_Simulating(instrSession))
    {
        strncpy(IDQueryResponse, RSETL_SIMULATION_ID_QUERY, bufferSize);
        IDQueryResponse[bufferSize - 1] = 0;
        goto Error;
    }

    checkErr(rsetl_QueryViString(instrSession, "*IDN?", bufferSize, IDQueryResponse));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN  Stops further command processing until all commands sent before *WAI
/// HIFN  have been executed.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
ViStatus rsetl_ProcessAllPreviousCommands(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_Write(instrSession, "*WAI"));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Self Test
 * Purpose:  This function executes the instrument self-test and returns the
 *           result.
 *****************************************************************************/
ViStatus rsetl_self_test(ViSession instrSession,
                         ViInt16   *testResult,
                         ViChar    testMessage[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, testResult), 2, "Null address for Test Result");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, testMessage), 3, "Null address for Test Message");

    checkErr(RsCore_SelfTest(instrSession, testResult, 48, testMessage));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Self Test Results
 * Purpose:  This function executes the instrument self-test and returns the
 *           result.
 *****************************************************************************/
ViStatus rsetl_SelfTestResults(ViSession instrSession,
                               ViInt32   bufferSize,
                               ViChar    results[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringUnknownLengthToUserBuffer(instrSession, "DIAG:SERV:STES:RES?", bufferSize, results, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Revision Query
 * Purpose:  This function returns the driver and instrument revisions.
 *****************************************************************************/
ViStatus rsetl_revision_query(ViSession instrSession,
                              ViChar    instrumentDriverRevision[],
                              ViChar    firmwareRevision[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, instrumentDriverRevision), 2, "Null address for Instrument Driver Revision");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, firmwareRevision), 3, "Null address for Instrument Revision");

    checkErr(RsCore_GetAttributeViString(instrSession, NULL, RS_ATTR_SPECIFIC_DRIVER_REVISION, 0, 256, instrumentDriverRevision));
    checkErr(RsCore_GetAttributeViString(instrSession, NULL, RS_ATTR_INSTRUMENT_FIRMWARE_REVISION, 0, 256, firmwareRevision));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function:    System Version
 * Purpose:     This function queries the number of the SCPI version, which
 *              is relevant for the instrument.
 *****************************************************************************/
ViStatus rsetl_SystemVersion(ViSession instrSession,
                             ViInt32   length,
                             ViChar    systemVersion[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringUnknownLengthToUserBuffer(instrSession, "SYST:VERS?", length, systemVersion, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Error Query
 * Purpose:  This function queries the instrument error queue and returns
 *           the result.
 *****************************************************************************/
ViStatus rsetl_error_query(ViSession instrSession,
                           ViInt32   *errorCode,
                           ViChar    errorMessage[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidNullPointer(instrSession, errorCode), 2, "Null address for Error Code");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, errorMessage), 3, "Null address for Error Message");

    checkErr(RsCore_ErrorQueryAll(instrSession, errorCode, 1024, errorMessage));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Error List
 * Purpose:  This function reads all system messages and returns a list of
 *           comma separated strings.
 *****************************************************************************/
ViStatus rsetl_ErrorList(ViSession instrSession,
                         ViInt32   bufferSize,
                         ViChar    errors[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidViInt32RangeMin(instrSession, bufferSize, 0), 2, "Buffer Size");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, errors), 3, "Null address for Errors");

    checkErr(rsetl_GetAttributeViString( instrSession, "", RSETL_ATTR_SYST_ERR_LIST,
        bufferSize, errors));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Error Message
 * Purpose:  This function translates the error codes returned by this
 *           instrument driver into user-readable strings.
 *
 *           Note:  The caller can pass NULL for the vi parameter.  This
 *           is useful if one of the init functions fail.
 *****************************************************************************/
ViStatus rsetl_error_message(ViSession instrSession,
                             ViStatus  errorCode,
                             ViChar    errorMessage[])
{
    ViStatus error = VI_SUCCESS;

    (void)(RsCore_LockSession(instrSession));

    static RsCoreStringValueTable errorTable =
    {
        RSETL_ERROR_CODES_AND_MSGS,
        {0, NULL}
    };

    // all VISA and RS error codes are handled as well as codes in the table
    viCheckParm(RsCore_InvalidNullPointer(instrSession, errorMessage), 3, "Null address for Error Message");

    checkErr(RsCore_GetSpecificDriverStatusDesc(instrSession, errorCode, errorMessage, 256, errorTable));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Clear Instrument Errors
 * Purpose:  This function deletes all entries in the table SYSTEM MESSAGES.
 *****************************************************************************/
ViStatus rsetl_ClearInstrumentErrors(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_SYST_ERR_CLEAR, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Preset
 * Purpose:  This function initiates an instrument reset.
 *****************************************************************************/
ViStatus rsetl_Preset(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(rsetl_SetAttributeViString(instrSession, "", RSETL_ATTR_SYST_PRESET, NULL));

    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Get Error and Clear Error Functions
 * Purpose:  These functions enable the instrument driver user to
 *           get or clear the error information the driver associates with the
 *           RS session.
 *****************************************************************************/
ViStatus rsetl_GetError(ViSession instrSession,
                        ViStatus  *errorCode,
                        ViInt32   bufferSize,
                        ViChar    description[])
{
    ViStatus error = VI_SUCCESS;

    // Lock Session - do not jump to the end, even with invalid instrSession the function continues further
    (void)(RsCore_LockSession(instrSession));

    // Test for nulls and acquire error data
    viCheckParm(RsCore_InvalidNullPointer(instrSession, errorCode), 2, "Null address for Error");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, description), 4, "Null address for Description");

	checkErr(
		RsCore_GetErrorCompleteDescription(instrSession, &rsetl_error_message, errorCode, bufferSize, description));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

ViStatus rsetl_ClearError(ViSession instrSession)
{
    return RsCore_ClearErrorInfo(instrSession);
}

/*****************************************************************************
 * Function: WriteInstrData Function
 * Purpose:  The function enable the instrument driver user to
 *           write commands directly to the instrument.
 *
 *           Note:  The function bypass the RS attribute state caching.
 *                  WriteInstrData invalidates the cached values for all
 *                  attributes.
 *****************************************************************************/

ViStatus rsetl_WriteInstrData(ViSession instrSession,
                              ViString  writeBuffer)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    RsCore_Write(instrSession, writeBuffer);

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query ViBoolean
 * Purpose:  This function queries the ViBoolean value.
 *****************************************************************************/
ViStatus rsetl_QueryViBoolean(ViSession instrSession,
                              ViString  cmd,
                              ViBoolean *value)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidStringLength(instrSession, cmd, 1, -1), 2, "Command (string length)");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, value), 3, "Value");
    checkErr(RsCore_QueryViBoolean(instrSession, cmd, value));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query ViInt32
 * Purpose:  This function queries the ViInt32 value.
 *****************************************************************************/
ViStatus rsetl_QueryViInt32(ViSession instrSession,
                            ViString  cmd,
                            ViInt32   *value)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidStringLength(instrSession, cmd, 1, -1), 2, "Command (string length)");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, value), 3, "Value");
    checkErr(RsCore_QueryViInt32(instrSession, cmd, value));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: Query ViReal64
 * Purpose:  This function queries the ViReal64 value.
 *****************************************************************************/
ViStatus rsetl_QueryViReal64(ViSession instrSession,
                             ViString  cmd,
                             ViReal64  *value)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidStringLength(instrSession, cmd, 1, -1), 2, "Command (string length)");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, value), 3, "Value");
    checkErr(RsCore_QueryViReal64(instrSession, cmd, value));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/*****************************************************************************
 * Function: Query ViString
 * Purpose:  This function queries the ViString value.
 *****************************************************************************/
ViStatus rsetl_QueryViString(ViSession instrSession,
                             ViString  cmd,
                             ViInt32   bufferSize,
                             ViChar    value[])
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(RsCore_InvalidStringLength(instrSession, cmd, 1, -1), 2, "Command (string length)");
    viCheckParm(RsCore_InvalidNullPointer(instrSession, value), 3, "Value");
    checkErr(RsCore_QueryViStringUnknownLengthToUserBuffer(instrSession, cmd, bufferSize, value, NULL));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function sets the OPC timeout.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR OPCtimeout/This control sets the timeout value.
ViStatus rsetl_SetOPCTimeout(ViSession instrSession,
                             ViInt32   timeout)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_SetAttributeViInt32(instrSession, "", RS_ATTR_OPC_TIMEOUT, timeout),
            3, "Timeout");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}


/// HIFN This function returns the OPC timeout.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.
/// HIPAR timeout/This control returns the timeout value.
ViStatus rsetl_GetOPCTimeout(ViSession instrSession,
                             ViInt32*  timeout)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    viCheckParm(rsetl_GetAttributeViInt32(instrSession, "", RS_ATTR_OPC_TIMEOUT, timeout),
            3, "Timeout");

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN This function specifies the minimum timeout value to use (in
/// HIFN milliseconds) when accessing the device associated with the
/// HIFN given session.
/// HIFN Note that the actual timeout used may be higher than the one
/// HIFN requested.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function. The handle identifies a
/// HIPAR instrSession/particular instrument session.
/// HIPAR VISATimeout/Specifies the minimum timeout value to use (in milliseconds)
/// HIPAR VISATimeout/when accessing the device associated with the given session.
/// HIPAR VISATimeout/Note that the actual timeout used may be higher than the one
/// HIPAR VISATimeout/requested.
ViStatus rsetl_SetVISATimeout(ViSession instrSession,
                              ViUInt32  VISATimeout)
{
    return RsCore_SetVisaTimeout(instrSession, VISATimeout);
}

/// HIFN This function queries the minimum timeout value to use (in
/// HIFN milliseconds) when accessing the device associated with the
/// HIFN given session.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function. The handle identifies a
/// HIPAR instrSession/particular instrument session.
/// HIPAR VISATimeout/Queries the minimum timeout value to use (in milliseconds)
/// HIPAR VISATimeout/when accessing the device associated with the given session.
ViStatus rsetl_GetVISATimeout(ViSession instrSession,
                              ViUInt32* VISATimeout)
{
    return RsCore_GetVisaTimeout(instrSession, VISATimeout);
}

/// HIFN  This function queries the OPC.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.  The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR opc/Queries the OPC.
ViStatus rsetl_QueryOPC(ViSession instrSession,
                        ViInt32*  opc)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViInt32(instrSession, "*OPC?", opc));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN If TRUE (default after init is FALSE), the driver calls SYST:ERR? automatically in CheckStatus() when Instrument Status Error is detected.
/// HIFN Use the function rsetl_GetError afterwards to get the detailed information about the instrument error(s).
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR autoSystErrQuery/If TRUE (default after init is FALSE), the driver calls SYST:ERR? automatically in CheckStatus() when Instrument Status Error is detected.
ViStatus rsetl_ConfigureAutoSystemErrQuery(ViSession instrSession,
                                           ViBoolean autoSystErrQuery)
{
    ViStatus         error = VI_SUCCESS;
    RsCoreSessionPtr rsSession = NULL;

    checkErr(RsCore_GetRsSession(instrSession, &rsSession));
    rsSession->autoSystErrQuery = autoSystErrQuery;

Error:
    return error;
}

/// HIFN Session-related mutex switch.
/// HIFN If TRUE (default after init is FALSE), the driver sets a mutual-exclusion mechanism for every driver's hi-level function and attribute access.
/// HIFN Set this value to TRUE if you plan to use one session in more than one thread.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/The ViSession handle that you obtain from the rsetl_init or
/// HIPAR instrSession/rsetl_InitWithOptions function.The handle identifies a particular
/// HIPAR instrSession/instrument session.
/// HIPAR multiThreadLocking/Session-related mutex switch
ViStatus rsetl_ConfigureMultiThreadLocking(ViSession instrSession,
                                           ViBoolean multiThreadLocking)
{
    ViStatus         error = VI_SUCCESS;
    RsCoreSessionPtr rsSession = NULL;

    checkErr(RsCore_GetRsSession(instrSession, &rsSession));
    rsSession->multiThreadLocking = multiThreadLocking;

Error:
    return error;
}

/// HIFN Sends a command to the instrument synchronised with OPC-polling.
/// HIFN Use this function to wait for an instrument operation that can
/// HIFN take a long time to complete, e.g. self-alignment.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/This control accepts the Instrument Handle returned by the Initialize
/// HIPAR instrSession/function to select the desired instrument driver session.
/// HIPAR writeBuffer/Pass the string to be written to the instrument.
/// HIPAR timeout/This control sets the timeout value.
ViStatus rsetl_WriteCommandWithOPCSync(ViSession instrSession,
                                       ViString  writeBuffer,
                                       ViUInt32  timeout)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_WriteWithOpc(instrSession, writeBuffer, timeout));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/// HIFN Sends a query to the instrument synchronised with OPC-polling.
/// HIFN Use this function to wait for a response that can take a long
/// HIFN time to complete e.g. self-alignment, calibration or self-test.
/// HIRET Returns the status code of this operation.
/// HIPAR instrSession/This control accepts the Instrument Handle returned by the Initialize
/// HIPAR instrSession/function to select the desired instrument driver session.
/// HIPAR writeBuffer/Pass the string to be written to the instrument.
/// HIPAR timeout/This control sets the timeout value.
/// HIPAR bufferSize/Pass the maximum number of bytes to read from the instruments.
/// HIPAR readBuffer/After this function executes, this parameter contains the data
/// HIPAR readBuffer/that was read from the instrument.
/// HIPAR numBytesRead/Returns the number of bytes actually read from the instrument
/// HIPAR numBytesRead/and stored in the Read Buffer.
ViStatus rsetl_QueryWithOPCSync(ViSession instrSession,
                                ViString  writeBuffer,
                                ViUInt32  timeout,
                                ViUInt32  bufferSize,
                                ViChar    readBuffer[],
                                ViUInt32* numBytesRead)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_QueryViStringUnknownLengthToUserBufferWithOpc(instrSession, writeBuffer, timeout, bufferSize, readBuffer, (ViInt32*)numBytesRead));
    checkErr(rsetl_CheckStatus(instrSession));

Error:
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

/*****************************************************************************
 * Function: rsetl_close
 * Purpose:  This function closes the instrument.
 *
 *           Note:  This function must unlock the session before calling
 *           Rs_Dispose.
 *****************************************************************************/
ViStatus rsetl_close(ViSession instrSession)
{
    ViStatus error = VI_SUCCESS;

    checkErr(RsCore_LockSession(instrSession));

    checkErr(RsCore_ViClose(instrSession));

Error:
    (void)RsCore_Dispose(instrSession);
    (void)RsCore_UnlockSession(instrSession);
    return error;
}

