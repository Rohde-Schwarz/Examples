/*****************************************************************************
 *- Utility Function Declarations (Non-Exported) ----------------------------*
 *****************************************************************************/

#pragma once
#include <visatype.h>

ViStatus rsetl_InitAttributes(ViSession instrSession);

ViStatus rsetl_DefaultInstrSetup(ViSession openInstrSession);

ViStatus rsetl_CheckStatus(ViSession instrSession);

ViStatus rsetl_dataReadTrace(ViSession instrSession,
                             ViString  cmd,
                             ViInt32   arrayLength,
                             ViReal64  traceData[],
                             ViPInt32  noofPoints);

ViStatus rsetl_dataReadInterleaved(ViSession instrSession,
                                   ViString  cmd,
                                   ViInt32   timeout,
                                   ViInt32   arraySize,
                                   ViReal64  arrayA[],
                                   ViReal64  arrayB[],
                                   ViPInt32  actualPoints);

