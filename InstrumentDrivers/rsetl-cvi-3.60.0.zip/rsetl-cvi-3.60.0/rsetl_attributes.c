/*****************************************************************************
 *  Rohde&Schwarz Instrument Driver Specific Attribute callbacks
 *
 *  WARNING: Do not add to, delete from, or otherwise modify the contents
 *           of this source file. It is generated from DrBase repository.
 *
 *  Built on: 2021-04-26 10:41:19Z
 *****************************************************************************/

#include "rsetl.h"

/*****************************************************************************
 *- Repeated Capabilities ---------------------------------------------------*
 *****************************************************************************/

ViInt32 rsetl_RsCoreRepCapTableCount = 68;

RsCoreRepCap rsetl_RsCoreRepCapTable[68] =
  { /*
    {
      repCapName  ... Repeated capability name, e.g. "Channel"
      identifiers ... Repeated capability identifiers (comma separated values), e.g. "Ch1,Ch2,Ch3"
      cmdValues   ... Command values (comma separated values), e.g. "1,2,3"
    } */
    {
      "Marker",
      "M1,M2,M3,M4",
      "1,2,3,4",
    }, {
      "Default",
      "DEF1,DEF2,DEF3",
      "1,2,3",
    }, {
      "Destination",
      "DE1,DE2",
      "1,2",
    }, {
      "CMAP",
      "CM1,CM2,CM3,CM4,CM5,CM6,CM7,CM8,CM9,CM10,CM11,CM12,CM13,CM14,CM15,CM16,CM17,CM18,CM19,CM20,CM21,CM22,CM23,CM24,CM25,CM26",
      "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26",
    }, {
      "Limit",
      "L1,L2,L3,L4,L5,L6,L7,L8",
      "1,2,3,4,5,6,7,8",
    }, {
      "DeltaMarker",
      "DM1,DM2,DM3,DM4",
      "1,2,3,4",
    }, {
      "Trace",
      "TR1,TR2,TR3,TR4",
      "1,2,3,4",
    }, {
      "Line",
      "L1,L2",
      "1,2",
    }, {
      "Channel",
      "CH1,CH2,CH3,CH4,CH5,CH6,CH7,CH8,CH9,CH10,CH11",
      "1,2,3,4,5,6,7,8,9,10,11",
    }, {
      "StatisticMeasType",
      "StatMean,StatPeak,StatCrestFactor",
      "MEAN,PEAK,CFAC",
    }, {
      "DiagramArea",
      "DA1,DA2,DA3,DA4,DA5,DA6,DA7,DA8,DA9,DA10",
      "1,2,3,4,5,6,7,8,9,10",
    }, {
      "AnalogModulation",
      "AnalogAM,AnalogFM,AnalogPM",
      "AM,FM,PM",
    }, {
      "ResultDetector",
      "ResDetPosPeak,ResDetNegPeak,ResDetAverPeak,ResDetRMS",
      "PPE,MPE,MIDD,RMS",
    }, {
      "FMOffsetResult",
      "FMOffImm,FMOffAver",
      "IMM,AVER",
    }, {
      "AtvVisionModulResult",
      "VisCarrPow,ResPicture,Depth,SigNoiseRatio,FreqOffset,SNRNominal",
      "VCP,RPC,MDEP,SNR,LFOF,SNRN",
    }, {
      "DtvShoulderAtt",
      "SAttLow,SAttUpp",
      "SAL,SAUP",
    }, {
      "DtvOverview",
      "OvLEV,OvBBV,OvPBBV,OvTBBV,OvBBRS,OvPBBR,OvTBBR,OvPER,OvPPER,OvTPER,OvPERR,OvBROF,OvISR,OvMTB,OvFFTM,OvGINT,OvCRHP,OvCRLP,OvCID,OvTPSR,OvINT,OvLIND,OvBERL,OvPBER,OvTBER,OvTMOD,OvFERR,OvSBP,OvMTBR,OvCRAT,OvDEIN,OvBARS,OvPBAR,OvTBAR,OvLTB,OvMMTB"
      "OvDCN,OvCN,OvSNRL,OvPNO,OvCIFC",
      "LEV,BBV,PBBV,TBBV,BBRS,PBBR,TBBR,PER,PPER,TPER,PERR,BROF,ISR,MTB,FFTM,GINT,CRHP,CRLP,CID,TPSR,INT,LIND,BERL,PBER,TBER,TMOD,FERR,SBP,MTBR,CRAT,DEIN,BARS,PBAR,TBAR,LTB,MMTB"
      "DCN,CN,SNRL,PNO,CIFC",
    }, {
      "DtvModErrors",
      "MeSNR,MeLEV,MeCPH,MePILV,MeSPV,MePAER,MeCNR,MeBVF,MePBVF,MeTBVF,MeBVM,MePBVM,MeTBVM,MeMTRM,MeMARM",
      "SNR,LEV,CPH,PILV,SPV,PAER,CNR,BVF,PBVF,TBVF,BVM,PBVM,TBVM,MTRM,MARM",
    }, {
      "DtvConstellation",
      "CoMERR,CoMERP,CoBBRS,CoSPROC,CoLEV",
      "MERR,MERP,BBRS,SPR,LEV",
    }, {
      "DtvAPGDResult",
      "APGDResAMPL,APGDResPHAS,APGDResGDEL",
      "AMPL,PHAS,GDEL",
    }, {
      "AtvCarrier",
      "CN,CSO,CTB",
      "CN,CSO,CTB",
    }, {
      "AtvSoundCarrier",
      "SC1,SC2",
      "S1,S2",
    }, {
      "ModifLowUpp",
      "Low,Upp",
      "LOW,UPP",
    }, {
      "AtvCarrierResult",
      "RefPow,NoiseFloorCorr,FreqRel,CR,NoiseRefBw",
      "RPOW,NFC,MFR,,NRBW",
    }, {
      "DtvErrorMeas",
      "EVMPeak,EVMRms,MERPeak,MERRms",
      "EVMP,EVMR,MERP,MERR",
    }, {
      "MLogTrace",
      "MTR1,MTR2,MTR3,MTR4",
      "1,2,3,4",
    }, {
      "AtvAnalysisMeasValue",
      "VmeLBAR,VmeSARB,VmeBARB,VmeCLDP,VmeCLGB,VmeCLGP,VmeBD,VmeTTPA,VmeTTPK,VmeTILT,VmeSTRE,VmeSTFE,VmeLTD,VmeCLIP,VmeCLI3,VmeGPPC,VmePPPC,VmeLNL,VmeLNL1,VmeLNL2,VmeLNL3,VmeLNL4,VmeLNL5,VmeDGP,VmeDGN,VmeDG1S,VmeDG2S,VmeDG3S,VmeDG4S,VmeDG5S,VmeDPP"
      "VmeDPN,VmeDP1S,VmeDP2S,VmeDP3S,VmeDP4S,VmeDP5S,VmeICPH,VmeICPL,VmeICPS,VmeICPB,VmeICP1,VmeICP2,VmeICP3,VmeICP4,VmeICP5,VmeMRB,VmeM05P,VmeM10P,VmeM20P,VmeM40P,VmeM48P,VmeM58P,VmeNRB,VmeN05P,VmeN15P,VmeN30P,VmeN44P,VmeSXAP,VmeSXAN,VmeSXGP,VmeSXGN"
      "VmeFRB,VmeF05P,VmeF12P,VmeF20P,VmeF30P,VmeF35P,VmeF41P,VmeTRB,VmeT05P,VmeT10P,VmeT20P,VmeT30P,VmeT35P,VmeT42P",
      "LBAR,SARB,BARB,CLDP,CLGB,CLGP,BD,TTPA,TTPK,TILT,STRE,STFE,LTD,CLIP,CLI3,GPPC,PPPC,LNL,LNL1,LNL2,LNL3,LNL4,LNL5,DGP,DGN,DG1S,DG2S,DG3S,DG4S,DG5S,DPP"
      "DPN,DP1S,DP2S,DP3S,DP4S,DP5S,ICPH,ICPL,ICPS,ICPB,ICP1,ICP2,ICP3,ICP4,ICP5,MRB,M05P,M10P,M20P,M40P,M48P,M58P,NRB,N05P,N15P,N30P,N44P,SXAP,SXAN,SXGP,SXGN"
      "FRB,F05P,F12P,F20P,F30P,F35P,F41P,TRB,T05P,T10P,T20P,T30P,T35P,T42P",
    }, {
      "ModifMinMax",
      "Min,Max",
      "MIN,MAX",
    }, {
      "Subchannel",
      "SCH1,SCH2,SCH3,SCH4,SCH5,SCH6,SCH7,SCH8,SCH9,SCH10,SCH11,SCH12,SCH13,SCH14,SCH15,SCH16,SCH17,SCH18,SCH19,SCH20,SCH21,SCH22,SCH23,SCH24,SCH25,SCH26,SCH27,SCH28,SCH29,SCH30,SCH31,SCH32,SCH33,SCH34,SCH35,SCH36,SCH37,SCH38,SCH39,SCH40,SCH41,SCH42"
      "SCH43,SCH44,SCH45,SCH46,SCH47,SCH48,SCH49,SCH50,SCH51,SCH52,SCH53,SCH54,SCH55,SCH56,SCH57,SCH58,SCH59,SCH60,SCH61,SCH62,SCH63,SCH64",
      "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42"
      "43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64",
    }, {
      "TestSignal",
      "TestSigLBA,TestSigSNR,TestSigSA,TestSigBA,TestSigCLP,TestSigCLB,TestSigBD,TestSigLTD,TestSigTTP,TestSigSTD,TestSigTILT,TestSigCLIP,TestSigCLIB,TestSigGCNL,TestSigPCNL,TestSigLNL,TestSigDG,TestSigDP,TestSigMB,TestSigSX,TestSigICPM",
      "LBA,SNR,SA,BA,CLP,CLB,BD,LTD,TTP,STD,TILT,CLIP,CLIB,GCNL,PCNL,LNL,DG,DP,MB,SX,ICPM",
    }, {
      "User",
      "U1,U2,U3,U4,U5",
      "1,2,3,4,5",
    }, {
      "CATVlocation",
      "LOC1,LOC2,LOC3,LOC4,LOC5,LOC6,LOC7,LOC8,LOC9,LOC10,LOC11,LOC12,LOC13,LOC14,LOC15",
      "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15",
    }, {
      "HierarchicalLayer",
      "LayerA,LayerB,LayerC",
      "A,B,C",
    }, {
      "ISDBTmerr",
      "MerrRMS,MerrPEAK,MerrARM,MerrTRM,MerrMTBR,MerrBBV,MerrPBBV,MerrTBBV,MerrBBRS,MerrPBBR,MerrTBBR,MerrBARS,MerrPBAR,MerrTBAR,MerrPER,MerrPPER,MerrTPER,MerrPERR",
      "MERR,MERP,MARM,MTRM,MTBR,BBV,PBBV,TBBV,BBRS,PBBR,TBBR,BARS,PBAR,TBAR,PER,PPER,TPER,PERR",
    }, {
      "TMCCNextCurr",
      "TMCCCurr,TMCCNext",
      "CURR,NEXT",
    }, {
      "AudioLevel",
      "Left,Right,Pilot,SCA",
      "1,2,:PIL,:SCAR",
    }, {
      "AudioFrequency",
      "Left,Right,SCA,Spacing,Upper",
      "1,2,:SCAR,:SPAC,:UPP",
    }, {
      "DUTDeviation",
      "Left,Right,SCA",
      "1,2,:SCAR",
    }, {
      "LimitType",
      "Lower,Upper",
      "LOW,UPP",
    }, {
      "MPXDev",
      "MPX,Left,Right,Mono,Stereo",
      "MPXD,LDEV,RDEV,MDEV,SDEV",
    }, {
      "Pilot",
      "Deviation,Offset,Phase",
      "PDEV,PFOF,PPH",
    }, {
      "RDS",
      "Deviation,Offset,Phase,BER",
      "D,F,P,B",
    }, {
      "SCA",
      "MainDeviation,Offset,SubcDeviation",
      "SCD,SCS,SCSD",
    }, {
      "LimitChannel",
      "Left,Right",
      "1,2",
    }, {
      "SN",
      "R15,Q15,QI15,MR1H,AP1H,AP20,AQ20,AQI2",
      "R15,Q15,QI15,MR1H,AP1H,AP20,AQ20,AQI2",
    }, {
      "DFD",
      "D2D,D2DS,D3,DEV,F1,F2",
      "D2D,D2DS,D3,DEV,F1,F2",
    }, {
      "MPD",
      "Resp,Grad",
      "RESP,GRAD",
    }, {
      "AudioChannel",
      "Single,LeftMono,RightStereo",
      "1,1,2",
    }, {
      "PowerPeak",
      "MPower,PDeviation",
      "MPOW,PDEV",
    }, {
      "RDSFlag",
      "TP,TA,MS",
      "TPFL,TAFL,MSFL",
    }, {
      "RDSDateTime",
      "Date,LTime,UTime",
      "DATE,LTIM,UTIM",
    }, {
      "AudioPosNeg",
      "Positive,Negative",
      "POS,NEG",
    }, {
      "AudioScope",
      "PPeak,NPeak,HPeak,RMS",
      "PPE,NPE,HPE,RMS",
    }, {
      "AudioCrosstalk",
      "Crosstalk,Frequency",
      "CROS,FREQ",
    }, {
      "THD",
      "THD,Deviation,AudioFreq",
      "THD,DEV,AFR",
    }, {
      "DataID",
      "PLP,Parade",
      "DECP,DPAR",
    }, {
      "PeakRMS",
      "Peak,RMS",
      "P,R",
    }, {
      "ATSCChannel",
      "Primary,Secondary,TPC,FIC,Parade",
      "PRIM,SEC,TPC,FIC,PAR",
    }, {
      "ATSCMeasurement",
      "BBRS,BARS,PER,MPER",
      "BBRS,BARS,PER,MPERatio",
    }, {
      "DTVMPnoise",
      "MPNoise,ResPM,ResFM,Integration,RBW,AcqTime",
      "MPN,PMEF,FMEF,INT,RBW,AQT",
    }, {
      "DTVEchoPatt",
      "MERShortEq,EchoDet",
      "MERS,EDET",
    }, {
      "T2Frame",
      "FrameCount,SymPerFrame",
      "NT2,LDAT",
    }, {
      "PostSize",
      "Size,InfoSize",
      "LPS,LPIS",
    }, {
      "SBit",
      "S1,S2",
      "S1,S2",
    }, {
      "L1ID",
      "System,Cell,Network,TX",
      "SID,CID,NID,TID",
    }, {
      "PostSignaling",
      "DecodedPLP,AllPLP,Common",
      "DPLP,APLP,COMM",
    }, {
      "BitRate",
      "Ensemble,Signaling,Payload,Parade",
      "ENSB,SIGB,PAYB,PARB",
    }, {
      "DtvDVBT2Result",
      "dvbt2ResMRLO,dvbt2ResMPLO,dvbt2ResMRPL,dvbt2ResMPPL,dvbt2ResERPL,dvbt2ResEPPL,dvbt2ResITLD,dvbt2ResACQ,dvbt2ResBBCH,dvbt2ResPBBC,dvbt2ResTBBC,dvbt2ResESR,dvbt2ResPESR,dvbt2ResTESR,dvbt2ResFER,dvbt2ResPFER,dvbt2ResTFER",
      "MRLO,MPLO,MRPL,MPPL,ERPL,EPPL,ITLD,ACQ,BBCH,PBBC,TBBC,ESR,PESR,TESR,FER,PFER,TFER",
    }
  };

/*****************************************************************************
 *- Range Tables ------------------------------------------------------------*
 *****************************************************************************/

static RsCoreRangeTableDiscreteEntry rsetl_rngUnitsEntries[16] =
  {
    { RSETL_VAL_UNIT_DBM, "DBM" },
    { RSETL_VAL_UNIT_DBPW, "DBPW" },
    { RSETL_VAL_UNIT_WATT, "WATT" },
    { RSETL_VAL_UNIT_DBUV, "DBUV" },
    { RSETL_VAL_UNIT_DBMV, "DBMV" },
    { RSETL_VAL_UNIT_VOLT, "VOLT" },
    { RSETL_VAL_UNIT_DBUA, "DBUA" },
    { RSETL_VAL_UNIT_AMP, "AMP" },
    { RSETL_VAL_UNIT_DB, "DB" },
    { RSETL_VAL_UNIT_DEG, "DEG" },
    { RSETL_VAL_UNIT_RAD, "RAD" },
    { RSETL_VAL_UNIT_S, "S" },
    { RSETL_VAL_UNIT_HZ, "HZ" },
    { RSETL_VAL_UNIT_PCT, "PCT" },
    { RSETL_VAL_UNIT_UNITLESS, "UNIT" },
    { RSETL_VAL_UNIT_DBPT, "DBPT" }
  };
RsCoreRangeTableDiscrete rsetl_rngUnits = { 16, rsetl_rngUnitsEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTraceModeEntries[7] =
  {
    { RSETL_TRAC_MOD_WRITE, "WRIT" },
    { RSETL_TRAC_MOD_VIEW, "VIEW" },
    { RSETL_TRAC_MOD_AVER, "AVER" },
    { RSETL_TRAC_MOD_MAXH, "MAXH" },
    { RSETL_TRAC_MOD_MINH, "MINH" },
    { RSETL_TRAC_MOD_RMS, "RMS" },
    { RSETL_TRAC_MOD_BLANK, "BLAN" }
  };
RsCoreRangeTableDiscrete rsetl_rngTraceMode = { 7, rsetl_rngTraceModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngAmplitudeUnitsRangeTableEntries[8] =
  {
    { RSETL_VAL_AMPLITUDE_UNITS_DBM, "DBM" },
    { RSETL_VAL_AMPLITUDE_UNITS_DBMV, "DBMV" },
    { RSETL_VAL_AMPLITUDE_UNITS_DBUV, "DBUV" },
    { RSETL_VAL_AMPLITUDE_UNITS_VOLT, "V" },
    { RSETL_VAL_AMPLITUDE_UNITS_WATT, "W" },
    { RSETL_VAL_AMPLITUDE_UNITS_DBPW, "DBPW" },
    { RSETL_VAL_AMPLITUDE_UNITS_DBUA, "DBUA" },
    { RSETL_VAL_AMPLITUDE_UNITS_AMP, "AMP" }
  };
RsCoreRangeTableDiscrete rsetl_rngAmplitudeUnitsRangeTable = { 8, rsetl_rngAmplitudeUnitsRangeTableEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngAbsRelEntries[2] =
  {
    { RSETL_VAL_ABS, "ABS" },
    { RSETL_VAL_REL, "REL" }
  };
RsCoreRangeTableDiscrete rsetl_rngAbsRel = { 2, rsetl_rngAbsRelEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngESPModeEntries[3] =
  {
    { RSETL_VAL_ESP_MODE_AUTO, "AUTO" },
    { RSETL_VAL_ESP_MODE_MAN, "MAN" },
    { RSETL_VAL_ESP_MODE_USER, "USER" }
  };
RsCoreRangeTableDiscrete rsetl_rngESPMode = { 3, rsetl_rngESPModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDetectorTypeRangeTableEntries[7] =
  {
    { RSETL_VAL_DETECTOR_TYPE_AUTO_PEAK, "APE" },
    { RSETL_VAL_DETECTOR_TYPE_AVERAGE, "AVER" },
    { RSETL_VAL_DETECTOR_TYPE_MAX_PEAK, "POS" },
    { RSETL_VAL_DETECTOR_TYPE_MIN_PEAK, "NEG" },
    { RSETL_VAL_DETECTOR_TYPE_SAMPLE, "SAMP" },
    { RSETL_VAL_DETECTOR_TYPE_RMS, "RMS" },
    { RSETL_VAL_DETECTOR_TYPE_QPK, "QPE" }
  };
RsCoreRangeTableDiscrete rsetl_rngDetectorTypeRangeTable = { 7, rsetl_rngDetectorTypeRangeTableEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDISPConfPreDefColourEntries[16] =
  {
    { RSETL_VAL_DISP_COL_BLAC, "BLAC" },
    { RSETL_VAL_DISP_COL_BLUE, "BLUE" },
    { RSETL_VAL_DISP_COL_BROW, "BROW" },
    { RSETL_VAL_DISP_COL_GRE, "GRE" },
    { RSETL_VAL_DISP_COL_CYAN, "CYAN" },
    { RSETL_VAL_DISP_COL_RED, "RED" },
    { RSETL_VAL_DISP_COL_MAG, "MAG" },
    { RSETL_VAL_DISP_COL_YELL, "YELL" },
    { RSETL_VAL_DISP_COL_WHIT, "WHIT" },
    { RSETL_VAL_DISP_COL_DGRA, "DGR" },
    { RSETL_VAL_DISP_COL_LGRA, "LGR" },
    { RSETL_VAL_DISP_COL_LBLU, "LBL" },
    { RSETL_VAL_DISP_COL_LGRE, "LGR" },
    { RSETL_VAL_DISP_COL_LCY, "LCY" },
    { RSETL_VAL_DISP_COL_LRED, "LRED" },
    { RSETL_VAL_DISP_COL_LMAG, "LMAG" }
  };
RsCoreRangeTableDiscrete rsetl_rngDISPConfPreDefColour = { 16, rsetl_rngDISPConfPreDefColourEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngHcopyDeviceLangEntries[6] =
  {
    { RSETL_VAL_HCOPY_DEVICE_LANG_GDI, "GDI" },
    { RSETL_VAL_HCOPY_DEVICE_LANG_WMF, "WMF" },
    { RSETL_VAL_HCOPY_DEVICE_LANG_EWMF, "EWMF" },
    { RSETL_VAL_HCOPY_DEVICE_LANG_BMP, "BMP" },
    { RSETL_VAL_HCOPY_DEVICE_LANG_JPG, "JPG" },
    { RSETL_VAL_HCOPY_DEVICE_LANG_PNG, "PNG" }
  };
RsCoreRangeTableDiscrete rsetl_rngHcopyDeviceLang = { 6, rsetl_rngHcopyDeviceLangEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngHcopyDeviceOrientEntries[2] =
  {
    { RSETL_VAL_HCOPY_DEVICE_ORIENT_LAND, "LAND" },
    { RSETL_VAL_HCOPY_DEVICE_ORIENT_PORT, "PORT" }
  };
RsCoreRangeTableDiscrete rsetl_rngHcopyDeviceOrient = { 2, rsetl_rngHcopyDeviceOrientEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDomainEntries[2] =
  {
    { RSETL_VAL_FREQ, "FREQ" },
    { RSETL_VAL_TIME, "TIME" }
  };
RsCoreRangeTableDiscrete rsetl_rngDomain = { 2, rsetl_rngDomainEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngLinLogEntries[2] =
  {
    { RSETL_VAL_VBW_FILT_LIN, "LIN" },
    { RSETL_VAL_VBW_FILT_LOG, "LOG" }
  };
RsCoreRangeTableDiscrete rsetl_rngLinLog = { 2, rsetl_rngLinLogEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngServiceInputEntries[3] =
  {
    { RSETL_VAL_INPUT_RF, "RF" },
    { RSETL_VAL_INPUT_CAL, "CAL" },
    { RSETL_VAL_INPUT_TG, "TG" }
  };
RsCoreRangeTableDiscrete rsetl_rngServiceInput = { 3, rsetl_rngServiceInputEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngAvgTypeEntries[2] =
  {
    { RSETL_VAL_AVG_LIN, "LIN" },
    { RSETL_VAL_AVG_VID, "VID" }
  };
RsCoreRangeTableDiscrete rsetl_rngAvgType = { 2, rsetl_rngAvgTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDISPSizeWindowEntries[2] =
  {
    { RSETL_VAL_DISP_SIZE_LARGE, "LARG" },
    { RSETL_VAL_DISP_SIZE_SMALL, "SMAL" }
  };
RsCoreRangeTableDiscrete rsetl_rngDISPSizeWindow = { 2, rsetl_rngDISPSizeWindowEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngMarkerPeakListSortEntries[2] =
  {
    { RSETL_VAL_MARKER_SORT_X, "X" },
    { RSETL_VAL_MARKER_SORT_Y, "Y" }
  };
RsCoreRangeTableDiscrete rsetl_rngMarkerPeakListSort = { 2, rsetl_rngMarkerPeakListSortEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngMarkerDemodTypeEntries[2] =
  {
    { RSETL_VAL_MARKER_DEMOD_AM, "AM" },
    { RSETL_VAL_MARKER_DEMOD_FM, "FM" }
  };
RsCoreRangeTableDiscrete rsetl_rngMarkerDemodType = { 2, rsetl_rngMarkerDemodTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngMeasPowerSelectEntries[6] =
  {
    { RSETL_VAL_MEAS_POW_ACP, "ACP" },
    { RSETL_VAL_MEAS_POW_CPOW, "CPOW" },
    { RSETL_VAL_MEAS_POW_MCAC, "MCAC" },
    { RSETL_VAL_MEAS_POW_OBAN, "OBAN" },
    { RSETL_VAL_MEAS_POW_CN, "CN" },
    { RSETL_VAL_MEAS_POW_CN0, "CN0" }
  };
RsCoreRangeTableDiscrete rsetl_rngMeasPowerSelect = { 6, rsetl_rngMeasPowerSelectEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngMeasPowerStandardEntries[30] =
  {
    { RSETL_VAL_MEAS_POW_STD_NONE, "NONE" },
    { RSETL_VAL_MEAS_POW_STD_NADC, "NADC" },
    { RSETL_VAL_MEAS_POW_STD_TETRA, "TETRA" },
    { RSETL_VAL_MEAS_POW_STD_PDC, "PDC" },
    { RSETL_VAL_MEAS_POW_STD_PHS, "PHS" },
    { RSETL_VAL_MEAS_POW_STD_CDPD, "CDPD" },
    { RSETL_VAL_MEAS_POW_STD_FWCD, "FWCD" },
    { RSETL_VAL_MEAS_POW_STD_RWCD, "RWCD" },
    { RSETL_VAL_MEAS_POW_STD_F19C, "F19C" },
    { RSETL_VAL_MEAS_POW_STD_R19C, "R19C" },
    { RSETL_VAL_MEAS_POW_STD_FW3G, "FW3G" },
    { RSETL_VAL_MEAS_POW_STD_RW3G, "RW3G" },
    { RSETL_VAL_MEAS_POW_STD_D2CD, "D2CD" },
    { RSETL_VAL_MEAS_POW_STD_S2CD, "S2CD" },
    { RSETL_VAL_MEAS_POW_STD_M2CD, "M2CD" },
    { RSETL_VAL_MEAS_POW_STD_FIS95A, "FIS95A" },
    { RSETL_VAL_MEAS_POW_STD_RIS95A, "RIS95A" },
    { RSETL_VAL_MEAS_POW_STD_FIS95C0, "FIS95C0" },
    { RSETL_VAL_MEAS_POW_STD_RIS95C0, "RIS95C0" },
    { RSETL_VAL_MEAS_POW_STD_FIS95C1, "FIS95C1" },
    { RSETL_VAL_MEAS_POW_STD_RIS95C1, "RIS95C1" },
    { RSETL_VAL_MEAS_POW_STD_FJ008, "FJ008" },
    { RSETL_VAL_MEAS_POW_STD_RJ008, "RJ008" },
    { RSETL_VAL_MEAS_POW_STD_TCDM, "TCDM" },
    { RSETL_VAL_MEAS_POW_STD_FTCDM, "FTCD" },
    { RSETL_VAL_MEAS_POW_STD_RTCDM, "RTCD" },
    { RSETL_VAL_MEAS_POW_STD_AWL, "AWLAN" },
    { RSETL_VAL_MEAS_POW_STD_BWL, "BWLAN" },
    { RSETL_VAL_MEAS_POW_STD_WIM, "WIMax" },
    { RSETL_VAL_MEAS_POW_STD_WIBRO, "WIBRo" }
  };
RsCoreRangeTableDiscrete rsetl_rngMeasPowerStandard = { 30, rsetl_rngMeasPowerStandardEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngMeasPowerModeEntries[2] =
  {
    { RSETL_VAL_MEAS_POW_MODE_WRITE, "WRIT" },
    { RSETL_VAL_MEAS_POW_MODE_MAXH, "MAXH" }
  };
RsCoreRangeTableDiscrete rsetl_rngMeasPowerMode = { 2, rsetl_rngMeasPowerModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngBandFiltTypeEntries[5] =
  {
    { RSETL_VAL_FILT_TYPE_NORM, "NORM" },
    { RSETL_VAL_FILT_TYPE_FFT, "FFT" },
    { RSETL_VAL_FILT_TYPE_CFIL, "CFIL" },
    { RSETL_VAL_FILT_TYPE_RRC, "RRC" },
    { RSETL_VAL_FILT_TYPE_PULSE, "PULS" }
  };
RsCoreRangeTableDiscrete rsetl_rngBandFiltType = { 5, rsetl_rngBandFiltTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTFacUnitEntries[9] =
  {
    { RSETL_VAL_TFAC_UNIT_DB, "DB" },
    { RSETL_VAL_TFAC_UNIT_DBM, "DBM" },
    { RSETL_VAL_TFAC_UNIT_DBMV, "DBMV" },
    { RSETL_VAL_TFAC_UNIT_DBUV, "DBUV" },
    { RSETL_VAL_TFAC_UNIT_DBUVM, "DBUV/M" },
    { RSETL_VAL_TFAC_UNIT_DBUA, "DBUA" },
    { RSETL_VAL_TFAC_UNIT_DBUAM, "DBUA/M" },
    { RSETL_VAL_TFAC_UNIT_DBPW, "DBPW" },
    { RSETL_VAL_TFAC_UNIT_DBPT, "DBPT" }
  };
RsCoreRangeTableDiscrete rsetl_rngTFacUnit = { 9, rsetl_rngTFacUnitEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngFreqCentLinkEntries[3] =
  {
    { RSETL_VAL_CENT_FREQ_LINK_OFF, "OFF" },
    { RSETL_VAL_CENT_FREQ_LINK_SPAN, "SPAN" },
    { RSETL_VAL_CENT_FREQ_LINK_RBW, "RBW" }
  };
RsCoreRangeTableDiscrete rsetl_rngFreqCentLink = { 3, rsetl_rngFreqCentLinkEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngFreqModeEntries[3] =
  {
    { RSETL_VAL_FREQ_MODE_CW, "CW" },
    { RSETL_VAL_FREQ_MODE_FIX, "FIX" },
    { RSETL_VAL_FREQ_MODE_SWE, "SWE" }
  };
RsCoreRangeTableDiscrete rsetl_rngFreqMode = { 3, rsetl_rngFreqModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngOffOnAutoEntries[3] =
  {
    { RSETL_VAL_STATE_OFF, "OFF" },
    { RSETL_VAL_STATE_ON, "ON" },
    { RSETL_VAL_STATE_AUTO, "AUTO" }
  };
RsCoreRangeTableDiscrete rsetl_rngOffOnAuto = { 3, rsetl_rngOffOnAutoEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngExtMixerHarmonicTypeEntries[3] =
  {
    { RSETL_VAL_EXT_MIX_HARM_ODD, "ODD" },
    { RSETL_VAL_EXT_MIX_HARM_EVEN, "EVEN" },
    { RSETL_VAL_EXT_MIX_HARM_EODD, "EODD" }
  };
RsCoreRangeTableDiscrete rsetl_rngExtMixerHarmonicType = { 3, rsetl_rngExtMixerHarmonicTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngExtMixerHarmBandEntries[12] =
  {
    { RSETL_VAL_EXT_MIX_BAND_A, "A" },
    { RSETL_VAL_EXT_MIX_BAND_Q, "Q" },
    { RSETL_VAL_EXT_MIX_BAND_U, "U" },
    { RSETL_VAL_EXT_MIX_BAND_V, "V" },
    { RSETL_VAL_EXT_MIX_BAND_E, "E" },
    { RSETL_VAL_EXT_MIX_BAND_W, "W" },
    { RSETL_VAL_EXT_MIX_BAND_F, "F" },
    { RSETL_VAL_EXT_MIX_BAND_D, "D" },
    { RSETL_VAL_EXT_MIX_BAND_G, "G" },
    { RSETL_VAL_EXT_MIX_BAND_Y, "Y" },
    { RSETL_VAL_EXT_MIX_BAND_J, "J" },
    { RSETL_VAL_EXT_MIX_BAND_USER, "USER" }
  };
RsCoreRangeTableDiscrete rsetl_rngExtMixerHarmBand = { 12, rsetl_rngExtMixerHarmBandEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngAdjChAutoSelEntries[3] =
  {
    { RSETL_VAL_ADJ_RCHAN_AUTO_MIN, "MIN" },
    { RSETL_VAL_ADJ_RCHAN_AUTO_MAX, "MAX" },
    { RSETL_VAL_ADJ_RCHAN_AUTO_LHIG, "LHIG" }
  };
RsCoreRangeTableDiscrete rsetl_rngAdjChAutoSel = { 3, rsetl_rngAdjChAutoSelEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngAdjPresetEntries[6] =
  {
    { RSETL_VAL_ADJ_PRE_ACP, "ACP" },
    { RSETL_VAL_ADJ_PRE_CPOW, "CPOW" },
    { RSETL_VAL_ADJ_PRE_MCAC, "MCAC" },
    { RSETL_VAL_ADJ_PRE_OBAN, "OBAN" },
    { RSETL_VAL_ADJ_PRE_CN, "CN" },
    { RSETL_VAL_ADJ_PRE_CN0, "CN0" }
  };
RsCoreRangeTableDiscrete rsetl_rngAdjPreset = { 6, rsetl_rngAdjPresetEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngSourceIntExtEntries[2] =
  {
    { RSETL_VAL_SOUR_INT, "INT" },
    { RSETL_VAL_SOUR_EXT, "EXT" }
  };
RsCoreRangeTableDiscrete rsetl_rngSourceIntExt = { 2, rsetl_rngSourceIntExtEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngExtGateTrigTypeEntries[2] =
  {
    { RSETL_VAL_EGAT_TRIG_LEV, "LEV" },
    { RSETL_VAL_EGAT_TRIG_EDGE, "EDGE" }
  };
RsCoreRangeTableDiscrete rsetl_rngExtGateTrigType = { 2, rsetl_rngExtGateTrigTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngHcopyDeviceEntries[3] =
  {
    { RSETL_VAL_HCOPY_DEVICE_MEM, "\'MMEM\'" },
    { RSETL_VAL_HCOPY_DEVICE_PRN, "\'SYST:COMM:PRIN\'" },
    { RSETL_VAL_HCOPY_DEVICE_CLP, "\'SYST:COMM:CLIP\'" }
  };
RsCoreRangeTableDiscrete rsetl_rngHcopyDevice = { 3, rsetl_rngHcopyDeviceEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngPolarityEntries[2] =
  {
    { RSETL_VAL_NEG, "NEG" },
    { RSETL_VAL_POS, "POS" }
  };
RsCoreRangeTableDiscrete rsetl_rngPolarity = { 2, rsetl_rngPolarityEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngExtGateSourceEntries[2] =
  {
    { RSETL_VAL_EGAT_SOUR_EXT, "EXT" },
    { RSETL_VAL_EGAT_SOUR_IFP, "IFP" }
  };
RsCoreRangeTableDiscrete rsetl_rngExtGateSource = { 2, rsetl_rngExtGateSourceEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngSweepContModeEntries[3] =
  {
    { RSETL_VAL_SWE_MODE_AUTO, "AUTO" },
    { RSETL_VAL_SWE_MODE_LIST, "LIST" },
    { RSETL_VAL_SWE_MODE_ESYNC, "ESYNC" }
  };
RsCoreRangeTableDiscrete rsetl_rngSweepContMode = { 3, rsetl_rngSweepContModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTriggerSourceEntries[5] =
  {
    { RSETL_VAL_TRG_IMM, "IMM" },
    { RSETL_VAL_TRG_EXT, "EXT" },
    { RSETL_VAL_TRG_IFP, "IFP" },
    { RSETL_VAL_TRG_VID, "VID" },
    { RSETL_VAL_TRG_TV, "TV" }
  };
RsCoreRangeTableDiscrete rsetl_rngTriggerSource = { 5, rsetl_rngTriggerSourceEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngFileDecSeparatorEntries[2] =
  {
    { RSETL_VAL_DEC_SEP_POIN, "POIN" },
    { RSETL_VAL_DEC_SEP_COMMA, "COMM" }
  };
RsCoreRangeTableDiscrete rsetl_rngFileDecSeparator = { 2, rsetl_rngFileDecSeparatorEntries };

RsCoreRangeTableRanged rsetl_rngCalibration = { 0, 1, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngMarkerStepSizeEntries[2] =
  {
    { RSETL_VAL_MARK_STEP_SIZE_STAN, "STAN" },
    { RSETL_VAL_MARK_STEP_SIZE_POIN, "POIN" }
  };
RsCoreRangeTableDiscrete rsetl_rngMarkerStepSize = { 2, rsetl_rngMarkerStepSizeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngMpowFiltTypeEntries[3] =
  {
    { RSETL_VAL_MPOW_FTYPE_NORM, "NORM" },
    { RSETL_VAL_MPOW_FTYPE_CFIL, "CFIL" },
    { RSETL_VAL_MPOW_FTYPE_RRC, "RRC" }
  };
RsCoreRangeTableDiscrete rsetl_rngMpowFiltType = { 3, rsetl_rngMpowFiltTypeEntries };

RsCoreRangeTableRanged rsetl_rngPct = { 0, 100, "%" };

RsCoreRangeTableRanged rsetl_rngRefLevelOffset = { -100.0, 100.0, "dB" };

RsCoreRangeTableRanged rsetl_rngAdemBandRes = { 1.0, 10000000.00, "Hz" };

RsCoreRangeTableRanged rsetl_rngRefLevel = { -200.0, 200.0, "dB" };

RsCoreRangeTableRanged rsetl_rngVBW = { 1.0, 10000000.00, "Hz" };

RsCoreRangeTableRanged rsetl_rngFreqOffset = { -100000000000.00, 100000000000.00, "Hz" };

RsCoreRangeTableRanged rsetl_rngSweepCount = { 0, 32767, "" };

RsCoreRangeTableRanged rsetl_rngDISPConfPowSave = { 1, 60, "min" };

RsCoreRangeTableRanged rsetl_rngTrace = { 1, 4, "" };

RsCoreRangeTableRanged rsetl_rngExtGateDelay = { 0.0, 100.0, "[s]" };

RsCoreRangeTableRanged rsetl_rngLimits = { 1, 8, "" };

RsCoreRangeTableRanged rsetl_rngLimitOffset = { -300000000000.00, 300000000000.00, "Hz (s)" };

RsCoreRangeTableRanged rsetl_rngLimitMargin = { 0.0, 200.0, "dB" };

RsCoreRangeTableRanged rsetl_rngDISPAmplitudeRang = { 10.0, 200.0, "" };

RsCoreRangeTableRanged rsetl_rngIQSRate = { 10000.00, 326400000, "Hz" };

RsCoreRangeTableRanged rsetl_rngSwePoints = { 125, 32001, "" };

RsCoreRangeTableRanged rsetl_rngBandRatio = { 0.0001, 1.0, "" };

RsCoreRangeTableRanged rsetl_rngMarkerPeakListCount = { 0, 50, "" };

RsCoreRangeTableRanged rsetl_rngMarkerNdBDown = { -100.0, 100.0, "dB" };

RsCoreRangeTableRanged rsetl_rngMarkerDemodHoldoff = { 0.01, 1000.0, "s" };

RsCoreRangeTableRanged rsetl_rngStatNumSamples = { 100, 1000000000, "" };

RsCoreRangeTableRanged rsetl_rngMeasStatUpperLimit = { 0.00000001, 1.0, "" };

RsCoreRangeTableRanged rsetl_rngMeasStatLowerLimit = { 0.000000001, 0.1, "" };

RsCoreRangeTableRanged rsetl_rngMeasHDISTNharm = { 1, 10, "" };

RsCoreRangeTableRanged rsetl_rngSweepTime = { 0.000001, 16000.00, "s" };

RsCoreRangeTableRanged rsetl_rngSignalTrackThreshold = { -330.0, 30.0, "dBm" };

RsCoreRangeTableRanged rsetl_rngTraceMathPosition = { -100.0, 200.0, "%" };

RsCoreRangeTableRanged rsetl_rngTimeLinePos = { 0.0, 1000.0, "s" };

RsCoreRangeTableRanged rsetl_rngRBW = { 10.0, 50000000, "Hz" };

RsCoreRangeTableRanged rsetl_rngVbwRatio = { 0.01, 1000.0, "" };

RsCoreRangeTableRanged rsetl_rngAvgCount = { 0, 32767, "" };

RsCoreRangeTableRanged rsetl_rngExtMixerPorts = { 2, 3, "" };

RsCoreRangeTableRanged rsetl_rngExtMixerHarmonic = { 2, 64, "" };

RsCoreRangeTableRanged rsetl_rngExtMixerTreshold = { 0.1, 100.0, "dB" };

RsCoreRangeTableRanged rsetl_rngChannelSpacing = { 100.0, 2000000000.00, "Hz" };

RsCoreRangeTableRanged rsetl_rngCarrSignNum = { 1, 12, "" };

RsCoreRangeTableRanged rsetl_rngAdjChNum = { 0, 12, "" };

RsCoreRangeTableRanged rsetl_rngChannelBandwidth = { 100.0, 1000000000.00, "Hz" };

RsCoreRangeTableRanged rsetl_rngAdjRefTxChann = { 1, 12, "" };

RsCoreRangeTableRanged rsetl_rngPowPct = { 10.0, 99.9, "%" };

RsCoreRangeTableRanged rsetl_rngExtGateLength = { 0.000000125, 100.0, "s" };

RsCoreRangeTableRanged rsetl_rngTrigIFPowerLevel = { -50.00, -10.0, "dBm" };

RsCoreRangeTableRanged rsetl_rngTriggerDelay = { -100.0, 100.0, "s" };

RsCoreRangeTableRanged rsetl_rngSpeakerVolume = { 0, 1, "" };

RsCoreRangeTableRanged rsetl_rngLinkFactor = { 1, 100, "%" };

RsCoreRangeTableRanged rsetl_rngBias = { -0.01, 0.01, "" };

RsCoreRangeTableRanged rsetl_rngSEListRangeLimit = { -200.0, 200.0, "dBm" };

RsCoreRangeTableRanged rsetl_rngIFPowOffset = { 0.000000150, 1000, "s" };

RsCoreRangeTableRanged rsetl_rngIFPowHyst = { 3.0, 50.0, "dB" };

RsCoreRangeTableRanged rsetl_rngTriggerTimeInterval = { 0.1, 5000, "s" };

static ViReal64 rsetl_rngAttenuationRangeTableEntries[16] = { 0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75 };
RsCoreRangeTableCoerced rsetl_rngAttenuationRangeTable = { 16, rsetl_rngAttenuationRangeTableEntries, "dB" };

static ViReal64 rsetl_rngInputImpedanceEntries[2] = { 50, 75 };
RsCoreRangeTableCoerced rsetl_rngInputImpedance = { 2, rsetl_rngInputImpedanceEntries, "Ohm" };

static ViReal64 rsetl_rngInpAmptEattManEntries[7] = { 0, 5, 10, 15, 20, 25, 30 };
RsCoreRangeTableCoerced rsetl_rngInpAmptEattMan = { 7, rsetl_rngInpAmptEattManEntries, "db" };

static ViReal64 rsetl_rngFreqCountResEntries[6] = { 0.1, 1.0, 10.0, 100.0, 1.0e3, 1.0e4 };
RsCoreRangeTableCoerced rsetl_rngFreqCountRes = { 6, rsetl_rngFreqCountResEntries, "Hz" };

static ViReal64 rsetl_rngExtMixerLoPowerEntries[41] = { 13.0, 13.1, 13.2, 13.3, 13.4, 13.5, 13.6, 13.7, 13.8, 13.9, 14.0, 14.1, 14.2, 14.3, 14.4, 14.5, 14.6, 14.7, 14.8, 14.9, 15.0, 15.1, 15.2, 15.3, 15.4, 15.5, 15.6, 15.7, 15.8, 15.9, 16.0, 16.1, 16.2, 16.3, 16.4, 16.5, 16.6, 16.7, 16.8, 16.9, 17.0 };
RsCoreRangeTableCoerced rsetl_rngExtMixerLoPower = { 41, rsetl_rngExtMixerLoPowerEntries, "dBm" };

static ViReal64 rsetl_rngPmetAverCountEntries[9] = { 1, 2, 4, 8, 16, 32, 64, 128, 256 };
RsCoreRangeTableCoerced rsetl_rngPmetAverCount = { 9, rsetl_rngPmetAverCountEntries, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngServiceCombFrequencyEntries[3] =
  {
    { RSETL_VAL_SERV_COMB_FREQ_COMB1, "COMB1" },
    { RSETL_VAL_SERV_COMB_FREQ_COMB64, "COMB64" },
    { RSETL_VAL_SERV_COMB_FREQ_COMB65, "COMB65" }
  };
RsCoreRangeTableDiscrete rsetl_rngServiceCombFrequency = { 3, rsetl_rngServiceCombFrequencyEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTraceSpacingEntries[4] =
  {
    { RSETL_VAL_TRACE_SPACE_LIN, "LIN" },
    { RSETL_VAL_TRACE_SPACE_LOG, "LOG" },
    { RSETL_VAL_TRACE_SPACE_PCT, "PERC" },
    { RSETL_VAL_TRACE_SPACE_LDB, "LDB" }
  };
RsCoreRangeTableDiscrete rsetl_rngTraceSpacing = { 4, rsetl_rngTraceSpacingEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngHcopyPageSettingsEntries[3] =
  {
    { RSETL_VAL_HCOPY_ACT, "ACT" },
    { RSETL_VAL_HCOPY_ALL, "ALL" },
    { RSETL_VAL_HCOPY_SING, "SING" }
  };
RsCoreRangeTableDiscrete rsetl_rngHcopyPageSettings = { 3, rsetl_rngHcopyPageSettingsEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngInstrModeEntries[5] =
  {
    { RSETL_VAL_SAN, "SAN" },
    { RSETL_VAL_CATV, "CATV" },
    { RSETL_VAL_TSAN, "TSAN" },
    { RSETL_VAL_TSG, "TSG" },
    { RSETL_VAL_RAD, "RAD" }
  };
RsCoreRangeTableDiscrete rsetl_rngInstrMode = { 5, rsetl_rngInstrModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTGenMeasTypeEntries[2] =
  {
    { RSETL_VAL_TRACK_GEN_MEAS_TYPE_TRAN, "TRAN" },
    { RSETL_VAL_TRACK_GEN_MEAS_TYPE_REFL, "REFL" }
  };
RsCoreRangeTableDiscrete rsetl_rngTGenMeasType = { 2, rsetl_rngTGenMeasTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTGenResultTypeEntries[2] =
  {
    { RSETL_VAL_TRACK_GEN_CAL_RES_TYPE_THR, "THR" },
    { RSETL_VAL_TRACK_GEN_CAL_RES_TYPE_OPEN, "OPEN" }
  };
RsCoreRangeTableDiscrete rsetl_rngTGenResultType = { 2, rsetl_rngTGenResultTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngFmTriggerSourceEntries[7] =
  {
    { RSETL_VAL_TRG_IMM, "IMM" },
    { RSETL_VAL_TRG_EXT, "EXT" },
    { RSETL_VAL_TRG_IFP, "IFP" },
    { RSETL_VAL_TRG_FM, "FM" },
    { RSETL_VAL_TRG_AM, "AM" },
    { RSETL_VAL_TRG_PM, "PM" },
    { RSETL_VAL_TRG_AMR, "AMR" }
  };
RsCoreRangeTableDiscrete rsetl_rngFmTriggerSource = { 7, rsetl_rngFmTriggerSourceEntries };

RsCoreRangeTableRanged rsetl_rngAdemTrigAMLevelAbs = { -100, 30, "dBm" };

RsCoreRangeTableRanged rsetl_rngAdemTrigAMLevelRel = { -100, 100, "%" };

RsCoreRangeTableRanged rsetl_rngAdemTrigFMLevel = { -10000000, 10000000, "Hz" };

RsCoreRangeTableRanged rsetl_rngAdemTrigPMLevel = { -1000, 1000, "rad/deg" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCouplingEntries[2] =
  {
    { RSETL_VAL_DC, "DC" },
    { RSETL_VAL_AC, "AC" }
  };
RsCoreRangeTableDiscrete rsetl_rngCoupling = { 2, rsetl_rngCouplingEntries };

RsCoreRangeTableRanged rsetl_rngFmBwid = { 100, 50000000.00, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngAdemPhaseWrapEntries[2] =
  {
    { RSETL_VAL_ADEM_UPHAS, "UPH" },
    { RSETL_VAL_ADEM_PHAS, "PHAS" }
  };
RsCoreRangeTableDiscrete rsetl_rngAdemPhaseWrap = { 2, rsetl_rngAdemPhaseWrapEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngUnitAngleEntries[2] =
  {
    { RSETL_VAL_UNIT_ANGLE_DEG, "DEG" },
    { RSETL_VAL_UNIT_ANGLE_RAD, "RAD" }
  };
RsCoreRangeTableDiscrete rsetl_rngUnitAngle = { 2, rsetl_rngUnitAngleEntries };

static ViReal64 rsetl_rngHpasFilterFreqEntries[2] = { 50.0, 300.0 };
RsCoreRangeTableCoerced rsetl_rngHpasFilterFreq = { 2, rsetl_rngHpasFilterFreqEntries, "Hz" };

static ViReal64 rsetl_rngLpasFiltFreqEntries[3] = { 3.0E+3, 15.0E+3, 150.0E+3 };
RsCoreRangeTableCoerced rsetl_rngLpasFiltFreq = { 3, rsetl_rngLpasFiltFreqEntries, "" };

static ViReal64 rsetl_rngFiltDempTimeConstEntries[4] = { 25.0E-6, 50.0E-6, 75.0E-6, 750.0E-6 };
RsCoreRangeTableCoerced rsetl_rngFiltDempTimeConst = { 4, rsetl_rngFiltDempTimeConstEntries, "s" };

static ViReal64 rsetl_rngFiltDempPctConstEntries[3] = { 5, 10, 25 };
RsCoreRangeTableCoerced rsetl_rngFiltDempPctConst = { 3, rsetl_rngFiltDempPctConstEntries, "%" };

static RsCoreRangeTableDiscreteEntry rsetl_rngPmetMeasTimeEntries[3] =
  {
    { RSETL_VAL_PMET_MEASTIME_NORM, "NORM" },
    { RSETL_VAL_PMET_MEASTIME_SHORT, "SHOR" },
    { RSETL_VAL_PMET_MEASTIME_LONG, "LONG" }
  };
RsCoreRangeTableDiscrete rsetl_rngPmetMeasTime = { 3, rsetl_rngPmetMeasTimeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngPmetCouplingEntries[3] =
  {
    { RSETL_VAL_PMET_COUP_OFF, "OFF" },
    { RSETL_VAL_PMET_COUP_CENT, "CENT" },
    { RSETL_VAL_PMET_COUP_MARK, "MARK" }
  };
RsCoreRangeTableDiscrete rsetl_rngPmetCoupling = { 3, rsetl_rngPmetCouplingEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngPmetUnitAbsEntries[2] =
  {
    { RSETL_VAL_UNIT_DBM, "DBM" },
    { RSETL_VAL_UNIT_WATT, "WATT" }
  };
RsCoreRangeTableDiscrete rsetl_rngPmetUnitAbs = { 2, rsetl_rngPmetUnitAbsEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngPmetUnitRelEntries[2] =
  {
    { RSETL_VAL_UNIT_DB, "DB" },
    { RSETL_VAL_UNIT_PCT, "PCT" }
  };
RsCoreRangeTableDiscrete rsetl_rngPmetUnitRel = { 2, rsetl_rngPmetUnitRelEntries };

RsCoreRangeTableRanged rsetl_rngCatvEpattZoom = { 1, 20, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvMerrZoomEntries[24] =
  {
    { RSETL_VAL_CATV_MERR_ZOOM_NONE, "NONE" },
    { RSETL_VAL_CATV_MERR_ZOOM_MERR, "MERR" },
    { RSETL_VAL_CATV_MERR_ZOOM_MERP, "MERP" },
    { RSETL_VAL_CATV_MERR_ZOOM_EVMR, "EVMR" },
    { RSETL_VAL_CATV_MERR_ZOOM_EVMP, "EVMP" },
    { RSETL_VAL_CATV_MERR_ZOOM_IMB, "IMB" },
    { RSETL_VAL_CATV_MERR_ZOOM_QERR, "QERR" },
    { RSETL_VAL_CATV_MERR_ZOOM_SUP, "SUPP" },
    { RSETL_VAL_CATV_MERR_ZOOM_PJIT, "PJIT" },
    { RSETL_VAL_CATV_MERR_ZOOM_LEV, "LEV" },
    { RSETL_VAL_CATV_MERR_ZOOM_SNR, "SNR" },
    { RSETL_VAL_CATV_MERR_ZOOM_CPH, "CPH" },
    { RSETL_VAL_CATV_MERR_ZOOM_CNR, "CNR" },
    { RSETL_VAL_CATV_MERR_ZOOM_BVF, "BVF" },
    { RSETL_VAL_CATV_MERR_ZOOM_BVM, "BVM" },
    { RSETL_VAL_CATV_MERR_ZOOM_PILV, "PILV" },
    { RSETL_VAL_CATV_MERR_ZOOM_SPV, "SPV" },
    { RSETL_VAL_CATV_MERR_ZOOM_PAER, "PAER" },
    { RSETL_VAL_CATV_MERR_ZOOM_EPPL, "EPPL" },
    { RSETL_VAL_CATV_MERR_ZOOM_ERPL, "ERPL" },
    { RSETL_VAL_CATV_MERR_ZOOM_MPLO, "MPLO" },
    { RSETL_VAL_CATV_MERR_ZOOM_MRLO, "MRLO" },
    { RSETL_VAL_CATV_MERR_ZOOM_MPPL, "MPPL" },
    { RSETL_VAL_CATV_MERR_ZOOM_MRPL, "MRPL" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvMerrZoom = { 24, rsetl_rngCatvMerrZoomEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvOverZoomEntries[30] =
  {
    { RSETL_VAL_CATV_OVER_ZOOM_NONE, "NONE" },
    { RSETL_VAL_CATV_OVER_ZOOM_LEV, "LEV" },
    { RSETL_VAL_CATV_OVER_ZOOM_MERR, "MERR" },
    { RSETL_VAL_CATV_OVER_ZOOM_MERP, "MERP" },
    { RSETL_VAL_CATV_OVER_ZOOM_EVMR, "EVMR" },
    { RSETL_VAL_CATV_OVER_ZOOM_EVMP, "EVMP" },
    { RSETL_VAL_CATV_OVER_ZOOM_BBV, "BBV" },
    { RSETL_VAL_CATV_OVER_ZOOM_BBRS, "BBRS" },
    { RSETL_VAL_CATV_OVER_ZOOM_PER, "PER" },
    { RSETL_VAL_CATV_OVER_ZOOM_PERR, "PERR" },
    { RSETL_VAL_CATV_OVER_ZOOM_CFOF, "CFOF" },
    { RSETL_VAL_CATV_OVER_ZOOM_BROF, "BROF" },
    { RSETL_VAL_CATV_OVER_ZOOM_SROF, "SROF" },
    { RSETL_VAL_CATV_OVER_ZOOM_MTBR, "MTBR" },
    { RSETL_VAL_CATV_OVER_ZOOM_GINT, "GINT" },
    { RSETL_VAL_CATV_OVER_ZOOM_CRAT, "CRAT" },
    { RSETL_VAL_CATV_OVER_ZOOM_TDE, "TDE" },
    { RSETL_VAL_CATV_OVER_ZOOM_CFR, "CFR" },
    { RSETL_VAL_CATV_OVER_ZOOM_BERL, "BERL" },
    { RSETL_VAL_CATV_OVER_ZOOM_BARS, "BARS" },
    { RSETL_VAL_CATV_OVER_ZOOM_EMER, "EMER" },
    { RSETL_VAL_CATV_OVER_ZOOM_BBCH, "BBCH" },
    { RSETL_VAL_CATV_OVER_ZOOM_FER, "FER" },
    { RSETL_VAL_CATV_OVER_ZOOM_FERR, "FERR" },
    { RSETL_VAL_CATV_OVER_ZOOM_ITLD, "ITLD" },
    { RSETL_VAL_CATV_OVER_ZOOM_MRLO, "MRLO" },
    { RSETL_VAL_CATV_OVER_ZOOM_MRPL, "MRPL" },
    { RSETL_VAL_CATV_OVER_ZOOM_LTB, "LTB" },
    { RSETL_VAL_CATV_OVER_ZOOM_MMTB, "MMTB" },
    { RSETL_VAL_CATV_OVER_ZOOM_MTB, "MTB" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvOverZoom = { 30, rsetl_rngCatvOverZoomEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvConstDiagZoomEntries[5] =
  {
    { RSETL_VAL_CATV_QUAD_ZOOM_NONE, "NONE" },
    { RSETL_VAL_CATV_QUAD_ZOOM_1, "1" },
    { RSETL_VAL_CATV_QUAD_ZOOM_2, "2" },
    { RSETL_VAL_CATV_QUAD_ZOOM_3, "3" },
    { RSETL_VAL_CATV_QUAD_ZOOM_4, "4" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvConstDiagZoom = { 5, rsetl_rngCatvConstDiagZoomEntries };

RsCoreRangeTableRanged rsetl_rngCatvRFFreq = { 5000000, 1500000000.00, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvSBandEntries[3] =
  {
    { RSETL_VAL_CATV_SBAND_NORM, "NORM" },
    { RSETL_VAL_CATV_SBAND_INV, "INV" },
    { RSETL_VAL_CATV_SBAND_AUTO, "AUTO" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvSBand = { 3, rsetl_rngCatvSBandEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvModStandGroupDelayEntries[16] =
  {
    { RSETL_VAL_CATV_GDELAY_GENERAL, "GEN" },
    { RSETL_VAL_CATV_GDELAY_GHALF, "GHAL" },
    { RSETL_VAL_CATV_GDELAY_AUSTRALIA, "AUST" },
    { RSETL_VAL_CATV_GDELAY_DENMARK, "DENM" },
    { RSETL_VAL_CATV_GDELAY_NEWZELAND, "NEWZ" },
    { RSETL_VAL_CATV_GDELAY_NORWAY, "NORW" },
    { RSETL_VAL_CATV_GDELAY_SWEDENFULL, "SWED" },
    { RSETL_VAL_CATV_GDELAY_FLAT, "FLAT" },
    { RSETL_VAL_CATV_GDELAY_OIRT, "OIRT" },
    { RSETL_VAL_CATV_GDELAY_CHINA, "CHIN" },
    { RSETL_VAL_CATV_GDELAY_CCIR, "CCIR" },
    { RSETL_VAL_CATV_GDELAY_TDF, "TDF" },
    { RSETL_VAL_CATV_GDELAY_FCC, "FCC" },
    { RSETL_VAL_CATV_GDELAY_K1, "K1" },
    { RSETL_VAL_CATV_GDELAY_OIRT75, "OIRT75" },
    { RSETL_VAL_CATV_GDELAY_OIRT83, "OIRT83" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvModStandGroupDelay = { 16, rsetl_rngCatvModStandGroupDelayEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvModStandSignalTypeEntries[2] =
  {
    { RSETL_VAL_CATV_SIG_TYPE_ATV, "ATV" },
    { RSETL_VAL_CATV_SIG_TYPE_DTV, "DTV" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvModStandSignalType = { 2, rsetl_rngCatvModStandSignalTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAtvMeasEntries[15] =
  {
    { RSETL_VAL_ATV_MEAS_ASP, "ASP" },
    { RSETL_VAL_ATV_MEAS_CARR, "CARR" },
    { RSETL_VAL_ATV_MEAS_CN, "CN" },
    { RSETL_VAL_ATV_MEAS_CSO, "CSO" },
    { RSETL_VAL_ATV_MEAS_CTB, "CTB" },
    { RSETL_VAL_ATV_MEAS_HUM, "HUM" },
    { RSETL_VAL_ATV_MEAS_VMOD, "VMOD" },
    { RSETL_VAL_ATV_MEAS_VSC, "VSC" },
    { RSETL_VAL_ATV_MEAS_AVCP, "AVCP" },
    { RSETL_VAL_ATV_MEAS_ATVY, "ATVY" },
    { RSETL_VAL_ATV_MEAS_ICPM, "ICPM" },
    { RSETL_VAL_ATV_MEAS_TTP, "TTP" },
    { RSETL_VAL_ATV_MEAS_STD, "STD" },
    { RSETL_VAL_ATV_MEAS_SINX, "SINX" },
    { RSETL_VAL_ATV_MEAS_AWF, "AWF" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAtvMeas = { 15, rsetl_rngCatvAtvMeasEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAtvCarrMeasEntries[2] =
  {
    { RSETL_VAL_ATV_MEAS_CARR_CARR, "CARR" },
    { RSETL_VAL_ATV_MEAS_CARR_NOIS, "NOIS" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAtvCarrMeas = { 2, rsetl_rngCatvAtvCarrMeasEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAtvCarrMeasModeEntries[3] =
  {
    { RSETL_VAL_ATV_MEAS_MODE_INSERVICE, "ISER" },
    { RSETL_VAL_ATV_MEAS_MODE_OFFSERVICE, "OSER" },
    { RSETL_VAL_ATV_MEAS_MODE_QUIETLINE, "QLIN" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAtvCarrMeasMode = { 3, rsetl_rngCatvAtvCarrMeasModeEntries };

RsCoreRangeTableRanged rsetl_rngCatvAtvBw = { 100, 20000000.00, "" };

RsCoreRangeTableRanged rsetl_rngCatvRelPower = { -200.00, 200.00, "dB" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAtvRefPowerModeEntries[3] =
  {
    { RSETL_VAL_ATV_RPOW_MODE_RCH, "RCH" },
    { RSETL_VAL_ATV_RPOW_MODE_MCH, "MCH" },
    { RSETL_VAL_ATV_RPOW_MODE_MAN, "MAN" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAtvRefPowerMode = { 3, rsetl_rngCatvAtvRefPowerModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngUnitDbPctEntries[2] =
  {
    { RSETL_VAL_UNIT_DB, "DB" },
    { RSETL_VAL_UNIT_PCT, "PCT" }
  };
RsCoreRangeTableDiscrete rsetl_rngUnitDbPct = { 2, rsetl_rngUnitDbPctEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvPowerUnitsEntries[8] =
  {
    { RSETL_VAL_UNIT_DBM, "DBM" },
    { RSETL_VAL_UNIT_DBPW, "DBPW" },
    { RSETL_VAL_UNIT_WATT, "W" },
    { RSETL_VAL_UNIT_DBUV, "DBUV" },
    { RSETL_VAL_UNIT_DBMV, "DBMV" },
    { RSETL_VAL_UNIT_VOLT, "V" },
    { RSETL_VAL_UNIT_DBUA, "DBUA" },
    { RSETL_VAL_UNIT_AMP, "A" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvPowerUnits = { 8, rsetl_rngCatvPowerUnitsEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAtvStandardEntries[7] =
  {
    { RSETL_VAL_ATV_STAN_BG, "BG" },
    { RSETL_VAL_ATV_STAN_DK, "DK" },
    { RSETL_VAL_ATV_STAN_I, "I" },
    { RSETL_VAL_ATV_STAN_K1, "K1" },
    { RSETL_VAL_ATV_STAN_L, "L" },
    { RSETL_VAL_ATV_STAN_M, "M" },
    { RSETL_VAL_ATV_STAN_N, "N" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAtvStandard = { 7, rsetl_rngCatvAtvStandardEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAtvSoundSystemEntries[15] =
  {
    { RSETL_VAL_ATV_AUDIO_FM55NICAM585, "FM55NICAM585" },
    { RSETL_VAL_ATV_AUDIO_FM55FM5742, "FM55FM5742" },
    { RSETL_VAL_ATV_AUDIO_FM55MONO, "FM55MONO" },
    { RSETL_VAL_ATV_AUDIO_FM65NICAM585, "FM65NICAM585" },
    { RSETL_VAL_ATV_AUDIO_FM65FM6258, "FM65FM6258" },
    { RSETL_VAL_ATV_AUDIO_FM65FM6742, "FM65FM6742" },
    { RSETL_VAL_ATV_AUDIO_FM65MONO, "FM65MONO" },
    { RSETL_VAL_ATV_AUDIO_FM60NICAM6552, "FM60NICAM655" },
    { RSETL_VAL_ATV_AUDIO_FM60MONO, "FM60MONO" },
    { RSETL_VAL_ATV_AUDIO_AM65NICAM585, "AM65NICAM585" },
    { RSETL_VAL_ATV_AUDIO_AM65MONO, "AM65MONO" },
    { RSETL_VAL_ATV_AUDIO_FM45BTSC, "FM45BTSC" },
    { RSETL_VAL_ATV_AUDIO_FM45EIA_J, "FM45EIA_J" },
    { RSETL_VAL_ATV_AUDIO_FM45FM4742, "FM45FM4742" },
    { RSETL_VAL_ATV_AUDIO_FM45MONO, "FM45MONO" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAtvSoundSystem = { 15, rsetl_rngCatvAtvSoundSystemEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAtvColorSystemEntries[3] =
  {
    { RSETL_VAL_ATV_COLOR_SYSTEM_PAL, "PAL" },
    { RSETL_VAL_ATV_COLOR_SYSTEM_NTSC, "NTSC" },
    { RSETL_VAL_ATV_COLOR_SYSTEM_SECAM, "SEC" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAtvColorSystem = { 3, rsetl_rngCatvAtvColorSystemEntries };

RsCoreRangeTableRanged rsetl_rngCatvAtvTriggField = { 1, 2, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAtvTriggBarLineTypeEntries[3] =
  {
    { RSETL_VAL_ATV_BLIN_TYPE_CCIR17, "CCIR17" },
    { RSETL_VAL_ATV_BLIN_TYPE_FCC, "FCC" },
    { RSETL_VAL_ATV_BLIN_TYPE_NTC7, "NTC7" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAtvTriggBarLineType = { 3, rsetl_rngCatvAtvTriggBarLineTypeEntries };

RsCoreRangeTableRanged rsetl_rngCatvFreqOffset = { -999999, 999999, "Hz" };

RsCoreRangeTableRanged rsetl_rngCatvAbsPower = { -200, 200.00, "dBm" };

RsCoreRangeTableRanged rsetl_rngCatvHumLimitLower = { -60.0, 60, "dB" };

RsCoreRangeTableRanged rsetl_rngCatvHumLimitUpper = { 0.100, 100, "%" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvResultsEntries[2] =
  {
    { RSETL_VAL_RES_FAIL, "FAIL" },
    { RSETL_VAL_RES_PASS, "PASS" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvResults = { 2, rsetl_rngCatvResultsEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvMeasEntries[34] =
  {
    { RSETL_VAL_DTV_MEAS_DSP, "DSP" },
    { RSETL_VAL_DTV_MEAS_CONS, "CONS" },
    { RSETL_VAL_DTV_MEAS_MERR, "MERR" },
    { RSETL_VAL_DTV_MEAS_MERF, "MERF" },
    { RSETL_VAL_DTV_MEAS_EPATT, "EPAT" },
    { RSETL_VAL_DTV_MEAS_APH, "APH" },
    { RSETL_VAL_DTV_MEAS_AGR, "AGR" },
    { RSETL_VAL_DTV_MEAS_APD, "APD" },
    { RSETL_VAL_DTV_MEAS_CCDF, "CCDF" },
    { RSETL_VAL_DTV_MEAS_OVER, "OVER" },
    { RSETL_VAL_DTV_MEAS_IQIM, "IQIM" },
    { RSETL_VAL_DTV_MEAS_DREC, "DREC" },
    { RSETL_VAL_DTV_MEAS_DVCP, "DVCP" },
    { RSETL_VAL_DTV_MEAS_SCOR, "SCOR" },
    { RSETL_VAL_DTV_MEAS_EINF, "EINF" },
    { RSETL_VAL_DTV_MEAS_TMID, "TMID" },
    { RSETL_VAL_DTV_MEAS_INGR, "INGR" },
    { RSETL_VAL_DTV_MEAS_EYED, "EYED" },
    { RSETL_VAL_DTV_MEAS_L1_PRE, "L1PR" },
    { RSETL_VAL_DTV_MEAS_L1_P1, "L1P1" },
    { RSETL_VAL_DTV_MEAS_L1_P2, "L1P2" },
    { RSETL_VAL_DTV_MEAS_L1_P3, "L1P3" },
    { RSETL_VAL_DTV_MEAS_MER, "MPN" },
    { RSETL_VAL_DTV_MEAS_CFD, "CFD" },
    { RSETL_VAL_DTV_MEAS_CPD, "CPD" },
    { RSETL_VAL_DTV_MEAS_AFIC, "AFIC" },
    { RSETL_VAL_DTV_MEAS_FIC1, "FIC1" },
    { RSETL_VAL_DTV_MEAS_FIC2, "FIC2" },
    { RSETL_VAL_DTV_MEAS_ATPC, "ATPC" },
    { RSETL_VAL_DTV_MEAS_TPC1, "TPC1" },
    { RSETL_VAL_DTV_MEAS_TPC2, "TPC2" },
    { RSETL_VAL_DTV_MEAS_ASER, "ASER" },
    { RSETL_VAL_DTV_MEAS_SERV, "SERV" },
    { RSETL_VAL_DTV_MEAS_MHOV, "MHOV" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvMeas = { 34, rsetl_rngCatvDtvMeasEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngUnitSecMinEntries[3] =
  {
    { RSETL_VAL_UNIT_SEC, "s" },
    { RSETL_VAL_UNIT_MIN, "m" },
    { RSETL_VAL_UNIT_MILE, "mile" }
  };
RsCoreRangeTableDiscrete rsetl_rngUnitSecMin = { 3, rsetl_rngUnitSecMinEntries };

RsCoreRangeTableRanged rsetl_rngCatvDtvEPattVelocity = { 0.0001, 1.0, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvFilterAlphaEntries[5] =
  {
    { RSETL_VAL_CATV_DTV_ALPHA_R012, "R012" },
    { RSETL_VAL_CATV_DTV_ALPHA_R013, "R013" },
    { RSETL_VAL_CATV_DTV_ALPHA_R015, "R015" },
    { RSETL_VAL_CATV_DTV_ALPHA_R018, "R018" },
    { RSETL_VAL_CATV_DTV_ALPHA_R0115, "R0115" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvFilterAlpha = { 5, rsetl_rngCatvDtvFilterAlphaEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvStandardEntries[9] =
  {
    { RSETL_VAL_DTV_STAN_J83A, "J83A" },
    { RSETL_VAL_DTV_STAN_J83B, "J83B" },
    { RSETL_VAL_DTV_STAN_J83C, "J83C" },
    { RSETL_VAL_DTV_STAN_DMBT, "DMBT" },
    { RSETL_VAL_DTV_STAN_DVBT, "DVBT" },
    { RSETL_VAL_DTV_STAN_ATSC, "ATSC" },
    { RSETL_VAL_DTV_STAN_TDMB, "TDMB" },
    { RSETL_VAL_DTV_STAN_ISDBT, "ISDBT" },
    { RSETL_VAL_DTV_STAN_DVBT2, "DVBT2" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvStandard = { 9, rsetl_rngCatvDtvStandardEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvFormatEntries[20] =
  {
    { RSETL_VAL_DTV_FORMAT_QAM4, "QAM4" },
    { RSETL_VAL_DTV_FORMAT_QAM4NR, "QAM4NR" },
    { RSETL_VAL_DTV_FORMAT_QAM16, "QAM16" },
    { RSETL_VAL_DTV_FORMAT_QAM32, "QAM32" },
    { RSETL_VAL_DTV_FORMAT_QAM64, "QAM64" },
    { RSETL_VAL_DTV_FORMAT_QAM128, "QAM128" },
    { RSETL_VAL_DTV_FORMAT_QAM256, "QAM256" },
    { RSETL_VAL_DTV_FORMAT_QPSK, "QPSK" },
    { RSETL_VAL_DTV_FORMAT_QAM16NH, "QAM16NH" },
    { RSETL_VAL_DTV_FORMAT_QAM16H1, "QAM16H1" },
    { RSETL_VAL_DTV_FORMAT_QAM16H2, "QAM16H2" },
    { RSETL_VAL_DTV_FORMAT_QAM16H4, "QAM16H4" },
    { RSETL_VAL_DTV_FORMAT_QAM64NH, "QAM64NH" },
    { RSETL_VAL_DTV_FORMAT_QAM64H1, "QAM64H1" },
    { RSETL_VAL_DTV_FORMAT_QAM64H2, "QAM64H2" },
    { RSETL_VAL_DTV_FORMAT_QAM64H4, "QAM64H4" },
    { RSETL_VAL_DTV_FORMAT_QAM512, "QAM512" },
    { RSETL_VAL_DTV_FORMAT_QAM1024, "QAM1024" },
    { RSETL_VAL_DTV_FORMAT_VSB, "VSB" },
    { RSETL_VAL_DTV_FORMAT_BPSK, "BPSK" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvFormat = { 20, rsetl_rngCatvDtvFormatEntries };

RsCoreRangeTableRanged rsetl_rngCatvCarrSuppression = { 0, 200, "dB" };

RsCoreRangeTableRanged rsetl_rngCatvErrLimitLower = { 0, 80, "dB" };

RsCoreRangeTableRanged rsetl_rngCatvErrLimitUpper = { 0.01, 100, "%" };

RsCoreRangeTableRanged rsetl_rngCatvImbLimit = { -100, 100, "%" };

RsCoreRangeTableRanged rsetl_rngCatvPhaseJitterLimit = { 0, 180, "" };

RsCoreRangeTableRanged rsetl_rngCatvQuadratureErrLimit = { -180, 180, "" };

RsCoreRangeTableRanged rsetl_rngCatvSymbRateLimit = { -99999, 99999, "symb/s" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvTvMeasEntries[1] =
  {
    { RSETL_VAL_TV_MEAS_TILT, "TILT" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvTvMeas = { 1, rsetl_rngCatvTvMeasEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvBERSamplesEntries[7] =
  {
    { RSETL_VAL_DTV_BER_SAMP_1, "1" },
    { RSETL_VAL_DTV_BER_SAMP_10, "10" },
    { RSETL_VAL_DTV_BER_SAMP_100, "100" },
    { RSETL_VAL_DTV_BER_SAMP_1K, "1000" },
    { RSETL_VAL_DTV_BER_SAMP_10K, "10000" },
    { RSETL_VAL_DTV_BER_SAMP_100K, "100000" },
    { RSETL_VAL_DTV_BER_SAMP_1M, "1000000" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvBERSamples = { 7, rsetl_rngCatvDtvBERSamplesEntries };

RsCoreRangeTableRanged rsetl_rngCatvDtvIQSamples = { 1, 999999999, "" };

RsCoreRangeTableRanged rsetl_rngCatvDtvSNRLimit = { 0, 100, "dB" };

RsCoreRangeTableRanged rsetl_rngCatvBROFLimit = { -100.00, 100, "ppm" };

RsCoreRangeTableRanged rsetl_rngCatvLevelLimit = { -200.00, 200.00, "dBm" };

RsCoreRangeTableRanged rsetl_rngCatvPERRLimit = { 0, 99999.00, "/s" };

static RsCoreRangeTableDiscreteEntry rsetl_rngPowLevUnitsEntries[8] =
  {
    { RSETL_VAL_UNIT_DBM, "DBM" },
    { RSETL_VAL_UNIT_DBPW, "DBPW" },
    { RSETL_VAL_UNIT_WATT, "WATT" },
    { RSETL_VAL_UNIT_DBUV, "DBUV" },
    { RSETL_VAL_UNIT_DBMV, "DBMV" },
    { RSETL_VAL_UNIT_VOLT, "VOLT" },
    { RSETL_VAL_UNIT_DBUA, "DBUA" },
    { RSETL_VAL_UNIT_AMP, "AMP" }
  };
RsCoreRangeTableDiscrete rsetl_rngPowLevUnits = { 8, rsetl_rngPowLevUnitsEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDispChanImpulseResponseEntries[2] =
  {
    { RSETL_VAL_DISP_CHAN_IMP_RES_MLEV, "MLEV" },
    { RSETL_VAL_DISP_CHAN_IMP_RES_PECH, "PECH" }
  };
RsCoreRangeTableDiscrete rsetl_rngDispChanImpulseResponse = { 2, rsetl_rngDispChanImpulseResponseEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvVisionModEntries[6] =
  {
    { RSETL_VAL_CATV_VIS_DET_MPOR, "MPOR" },
    { RSETL_VAL_CATV_VIS_DET_SPOR, "SPOR" },
    { RSETL_VAL_CATV_VIS_DET_FCON, "FCON" },
    { RSETL_VAL_CATV_VIS_DET_MCON, "MCON" },
    { RSETL_VAL_CATV_VIS_DET_SCON, "SCON" },
    { RSETL_VAL_CATV_VIS_DET_ENV, "ENV" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvVisionMod = { 6, rsetl_rngCatvVisionModEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvCodeRateEntries[3] =
  {
    { RSETL_VAL_DTV_CODE_RATE_R04, "R04" },
    { RSETL_VAL_DTV_CODE_RATE_R06, "R06" },
    { RSETL_VAL_DTV_CODE_RATE_R08, "R08" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvCodeRate = { 3, rsetl_rngCatvDtvCodeRateEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvCodeRatePriorityEntries[5] =
  {
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R1_2, "R1_2" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R2_3, "R2_3" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R3_4, "R3_4" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R5_6, "R5_6" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R7_8, "R7_8" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvCodeRatePriority = { 5, rsetl_rngCatvDtvCodeRatePriorityEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvEqualStepSizeEntries[3] =
  {
    { RSETL_VAL_DTV_EQUAL_SSIZE_COAR, "COAR" },
    { RSETL_VAL_DTV_EQUAL_SSIZE_MED, "MED" },
    { RSETL_VAL_DTV_EQUAL_SSIZE_FINE, "FINE" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvEqualStepSize = { 3, rsetl_rngCatvDtvEqualStepSizeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvEqualStepSizeShrinkEntries[3] =
  {
    { RSETL_VAL_DTV_EQUAL_SSIZE_SHRINK_NONE, "NONE" },
    { RSETL_VAL_DTV_EQUAL_SSIZE_SHRINK_FAST, "FAST" },
    { RSETL_VAL_DTV_EQUAL_SSIZE_SHRINK_SLOW, "SLOW" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvEqualStepSizeShrink = { 3, rsetl_rngCatvDtvEqualStepSizeShrinkEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvFECSyncEntries[2] =
  {
    { RSETL_VAL_DTV_FEC_SYNC_FEC, "FEC" },
    { RSETL_VAL_DTV_FEC_SYNC_NFEC, "NFEC" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvFECSync = { 2, rsetl_rngCatvDtvFECSyncEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvFFTModeEntries[9] =
  {
    { RSETL_VAL_DTV_FFT_MODE_F2K, "F2K" },
    { RSETL_VAL_DTV_FFT_MODE_F4K, "F4K" },
    { RSETL_VAL_DTV_FFT_MODE_F8K, "F8K" },
    { RSETL_VAL_DTV_FFT_MODE_F1K, "F1K" },
    { RSETL_VAL_DTV_FFT_MODE_F8KE, "F8KE" },
    { RSETL_VAL_DTV_FFT_MODE_F16K, "F16K" },
    { RSETL_VAL_DTV_FFT_MODE_F16E, "F16E" },
    { RSETL_VAL_DTV_FFT_MODE_F32K, "F32K" },
    { RSETL_VAL_DTV_FFT_MODE_F32E, "F32E" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvFFTMode = { 9, rsetl_rngCatvDtvFFTModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvGIntervalEntries[11] =
  {
    { RSETL_VAL_DTV_GINT_G420, "G420" },
    { RSETL_VAL_DTV_GINT_G595, "G595" },
    { RSETL_VAL_DTV_GINT_G945, "G945" },
    { RSETL_VAL_DTV_GINT_G1_4, "G1_4" },
    { RSETL_VAL_DTV_GINT_G1_8, "G1_8" },
    { RSETL_VAL_DTV_GINT_G1_16, "G1_16" },
    { RSETL_VAL_DTV_GINT_G1_32, "G1_32" },
    { RSETL_VAL_DTV_GINT_G1_128, "G1_128" },
    { RSETL_VAL_DTV_GINT_G19_128, "G19_128" },
    { RSETL_VAL_DTV_GINT_G19_256, "G19_256" },
    { RSETL_VAL_DTV_GINT_NONE, "---" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvGInterval = { 11, rsetl_rngCatvDtvGIntervalEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvInterleaverEntries[2] =
  {
    { RSETL_VAL_DTV_INTERLEAVER_NAT, "NAT" },
    { RSETL_VAL_DTV_INTERLEAVER_IND, "IND" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvInterleaver = { 2, rsetl_rngCatvDtvInterleaverEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvLDPCModeEntries[2] =
  {
    { RSETL_VAL_DTV_LDPC_MODE_NORM, "NORM" },
    { RSETL_VAL_DTV_LDPC_MODE_BYP, "BYP" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvLDPCMode = { 2, rsetl_rngCatvDtvLDPCModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvLoopsEntries[3] =
  {
    { RSETL_VAL_DTV_LOOPS_HIGH, "HIGH" },
    { RSETL_VAL_DTV_LOOPS_MED, "MED" },
    { RSETL_VAL_DTV_LOOPS_LOW, "LOW" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvLoops = { 3, rsetl_rngCatvDtvLoopsEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvCarrierModulationEntries[2] =
  {
    { RSETL_VAL_DTV_CARR_MOD_MULT, "MULT" },
    { RSETL_VAL_DTV_CARR_MOD_SING, "SING" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvCarrierModulation = { 2, rsetl_rngCatvDtvCarrierModulationEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvSystOptEntries[4] =
  {
    { RSETL_VAL_DTV_SOPT_MOB, "MOB" },
    { RSETL_VAL_DTV_SOPT_FAST, "FAST" },
    { RSETL_VAL_DTV_SOPT_SLOW, "SLOW" },
    { RSETL_VAL_DTV_SOPT_MED, "MED" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvSystOpt = { 4, rsetl_rngCatvDtvSystOptEntries };

static ViReal64 rsetl_rngCatvDtvTimeDeinterleaverEntries[4] = { 0, 48, 240, 720 };
RsCoreRangeTableCoerced rsetl_rngCatvDtvTimeDeinterleaver = { 4, rsetl_rngCatvDtvTimeDeinterleaverEntries, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvTSOutputEntries[5] =
  {
    { RSETL_VAL_DTV_TSO_HIGH, "HIGH" },
    { RSETL_VAL_DTV_TSO_LOW, "LOW" },
    { RSETL_VAL_DTV_TSO_A, "A" },
    { RSETL_VAL_DTV_TSO_B, "B" },
    { RSETL_VAL_DTV_TSO_C, "C" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvTSOutput = { 5, rsetl_rngCatvDtvTSOutputEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvSoundEntries[16] =
  {
    { RSETL_VAL_SOUND_A1, "A1" },
    { RSETL_VAL_SOUND_A2, "A2" },
    { RSETL_VAL_SOUND_ASS, "ASS" },
    { RSETL_VAL_SOUND_ASST, "ASST" },
    { RSETL_VAL_SOUND_SAP, "SAP" },
    { RSETL_VAL_SOUND_STER, "STER" },
    { RSETL_VAL_SOUND_S1, "S1" },
    { RSETL_VAL_SOUND_S2, "S2" },
    { RSETL_VAL_SOUND_S12, "S12" },
    { RSETL_VAL_SOUND_MONO, "MONO" },
    { RSETL_VAL_SOUND_NS1, "NS1" },
    { RSETL_VAL_SOUND_NS2, "NS2" },
    { RSETL_VAL_SOUND_NS12, "NS12" },
    { RSETL_VAL_SOUND_NMON, "NMON" },
    { RSETL_VAL_SOUND_FMM, "FMM" },
    { RSETL_VAL_SOUND_AMM, "AMM" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvSound = { 16, rsetl_rngCatvSoundEntries };

RsCoreRangeTableRanged rsetl_rngCatvDispCenterPos = { -0.002, 0.002, "" };

RsCoreRangeTableRanged rsetl_rngCatvDivision = { 0.0000007, 0.0002, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvIQSourceEntries[9] =
  {
    { RSETL_VAL_DTV_IQ_SRC_PLO, "PLO" },
    { RSETL_VAL_DTV_IQ_SRC_TPS, "TPS" },
    { RSETL_VAL_DTV_IQ_SRC_P1_SYM, "P1SY" },
    { RSETL_VAL_DTV_IQ_SRC_BFD, "BFD" },
    { RSETL_VAL_DTV_IQ_SRC_L1PRE, "L1PR" },
    { RSETL_VAL_DTV_IQ_SRC_L1POST, "L1P" },
    { RSETL_VAL_DTV_IQ_SRC_BTD, "BTD" },
    { RSETL_VAL_DTV_IQ_SRC_BDE, "BDER" },
    { RSETL_VAL_DTV_IQ_SRC_ADER, "ADER" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvIQSource = { 9, rsetl_rngCatvDtvIQSourceEntries };

RsCoreRangeTableRanged rsetl_rngCatvDtvNoiseGenCN = { 0, 99.99, "dB" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvTriggerSourceEntries[10] =
  {
    { RSETL_VAL_CATV_TRG_IMM, "IMM" },
    { RSETL_VAL_CATV_TRG_EXT, "EXT" },
    { RSETL_VAL_CATV_TRG_IFP, "IFP" },
    { RSETL_VAL_CATV_TRG_VID, "VID" },
    { RSETL_VAL_CATV_TRG_TV, "TV" },
    { RSETL_VAL_CATV_TRG_AF, "AF" },
    { RSETL_VAL_CATV_TRG_FM, "FM" },
    { RSETL_VAL_CATV_TRG_PM, "PM" },
    { RSETL_VAL_CATV_TRG_AM, "AM" },
    { RSETL_VAL_CATV_TRG_AMR, "AMR" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvTriggerSource = { 10, rsetl_rngCatvTriggerSourceEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngOutputMeasModeEntries[2] =
  {
    { RSETL_VAL_OUTP_MEAS_MODE_IF, "IF" },
    { RSETL_VAL_OUTP_MEAS_MODE_VID, "VID" }
  };
RsCoreRangeTableDiscrete rsetl_rngOutputMeasMode = { 2, rsetl_rngOutputMeasModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTLinLogEntries[2] =
  {
    { RSETL_VAL_LIN, "LIN" },
    { RSETL_VAL_LOG, "LOG" }
  };
RsCoreRangeTableDiscrete rsetl_rngTLinLog = { 2, rsetl_rngTLinLogEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTrgTVerticalSyncEntries[3] =
  {
    { RSETL_VAL_TRG_TV_VSYNC_ALL, "ALL" },
    { RSETL_VAL_TRG_TV_VSYNC_ODD, "ODD" },
    { RSETL_VAL_TRG_TV_VSYNC_EVEN, "EVEN" }
  };
RsCoreRangeTableDiscrete rsetl_rngTrgTVerticalSync = { 3, rsetl_rngTrgTVerticalSyncEntries };

static ViReal64 rsetl_rngTrgTVLineSystemEntries[2] = { 525, 625 };
RsCoreRangeTableCoerced rsetl_rngTrgTVLineSystem = { 2, rsetl_rngTrgTVLineSystemEntries, "" };

RsCoreRangeTableRanged rsetl_rngTrgTVHorizontalSyncLine = { 1, 625, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngTrgTVPolarityEntries[2] =
  {
    { RSETL_VAL_TRG_TV_POLARITY_NEG, "NEG" },
    { RSETL_VAL_TRG_TV_POLARITY_POS, "POS" }
  };
RsCoreRangeTableDiscrete rsetl_rngTrgTVPolarity = { 2, rsetl_rngTrgTVPolarityEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvMLogModeEntries[14] =
  {
    { RSETL_VAL_DTV_MLOG_MODE_LEV, "LEV" },
    { RSETL_VAL_DTV_MLOG_MODE_CFOF, "CFOF" },
    { RSETL_VAL_DTV_MLOG_MODE_BROF, "BROF" },
    { RSETL_VAL_DTV_MLOG_MODE_MTB, "MTB" },
    { RSETL_VAL_DTV_MLOG_MODE_BBV, "BBV" },
    { RSETL_VAL_DTV_MLOG_MODE_BBRS, "BBRS" },
    { RSETL_VAL_DTV_MLOG_MODE_MERR, "MERR" },
    { RSETL_VAL_DTV_MLOG_MODE_EVMR, "EVMR" },
    { RSETL_VAL_DTV_MLOG_MODE_MERP, "MERP" },
    { RSETL_VAL_DTV_MLOG_MODE_EVMP, "EVMP" },
    { RSETL_VAL_DTV_MLOG_MODE_PER, "PER" },
    { RSETL_VAL_DTV_MLOG_MODE_PERR, "PERR" },
    { RSETL_VAL_DTV_MLOG_MODE_BERL, "BERL" },
    { RSETL_VAL_DTV_MLOG_MODE_BARS, "BARS" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvMLogMode = { 14, rsetl_rngCatvDtvMLogModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvMLogSpanEntries[20] =
  {
    { RSETL_VAL_DTV_MLOG_SPAN_T1MIN, "T1MIN" },
    { RSETL_VAL_DTV_MLOG_SPAN_T2MIN, "T2MIN" },
    { RSETL_VAL_DTV_MLOG_SPAN_T5MIN, "T5MIN" },
    { RSETL_VAL_DTV_MLOG_SPAN_T10MIN, "T10MIN" },
    { RSETL_VAL_DTV_MLOG_SPAN_T20MIN, "T20MIN" },
    { RSETL_VAL_DTV_MLOG_SPAN_T30MIN, "T30MIN" },
    { RSETL_VAL_DTV_MLOG_SPAN_T1H, "T1H" },
    { RSETL_VAL_DTV_MLOG_SPAN_T2H, "T2H" },
    { RSETL_VAL_DTV_MLOG_SPAN_T5H, "T5H" },
    { RSETL_VAL_DTV_MLOG_SPAN_T10H, "T10H" },
    { RSETL_VAL_DTV_MLOG_SPAN_T1D, "T1D" },
    { RSETL_VAL_DTV_MLOG_SPAN_T2D, "T2D" },
    { RSETL_VAL_DTV_MLOG_SPAN_T5D, "T5D" },
    { RSETL_VAL_DTV_MLOG_SPAN_T10D, "T10D" },
    { RSETL_VAL_DTV_MLOG_SPAN_T20D, "T20D" },
    { RSETL_VAL_DTV_MLOG_SPAN_T50D, "T50D" },
    { RSETL_VAL_DTV_MLOG_SPAN_T100D, "T100D" },
    { RSETL_VAL_DTV_MLOG_SPAN_T200D, "T200" },
    { RSETL_VAL_DTV_MLOG_SPAN_T500D, "T500D" },
    { RSETL_VAL_DTV_MLOG_SPAN_T1000D, "T1000D" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvMLogSpan = { 20, rsetl_rngCatvDtvMLogSpanEntries };

RsCoreRangeTableRanged rsetl_rngCatvAudioVolume = { -115, 12, "dB" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvTimeRangeModeEntries[2] =
  {
    { RSETL_VAL_DTV_RANGE_TIME_MODE_NORM, "NORM" },
    { RSETL_VAL_DTV_RANGE_TIME_MODE_EXT, "EXT" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvTimeRangeMode = { 2, rsetl_rngCatvDtvTimeRangeModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvChanBwidEntries[4] =
  {
    { RSETL_VAL_DTV_CHAN_BWID_5MHZ, "B5MHZ" },
    { RSETL_VAL_DTV_CHAN_BWID_6MHZ, "B6MHZ" },
    { RSETL_VAL_DTV_CHAN_BWID_7MHZ, "B7MHZ" },
    { RSETL_VAL_DTV_CHAN_BWID_8MHZ, "B8MHZ" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvChanBwid = { 4, rsetl_rngCatvDtvChanBwidEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvChanBwidDMBTEntries[1] =
  {
    { RSETL_VAL_DTV_CHAN_BWID_8MHZ, "B8MHZ" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvChanBwidDMBT = { 1, rsetl_rngCatvDtvChanBwidDMBTEntries };

RsCoreRangeTableRanged rsetl_rngCatvVModLFOF = { -500.00, 500.00, "" };

RsCoreRangeTableRanged rsetl_rngCatvVMELimit = { -999999.9, 999999.9, "" };

static ViReal64 rsetl_rngCatvAverDepthEntries[8] = { 0, 4, 8, 16, 32, 64, 128, 256 };
RsCoreRangeTableCoerced rsetl_rngCatvAverDepth = { 8, rsetl_rngCatvAverDepthEntries, "" };

RsCoreRangeTableRanged rsetl_rngCatvBVFLimit = { 0, 0.99, "" };

RsCoreRangeTableRanged rsetl_rngCatvCNRLimit = { 6, 80, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvAttModeEntries[3] =
  {
    { RSETL_VAL_ATT_MODE_LNO, "LNO" },
    { RSETL_VAL_ATT_MODE_NORM, "NORM" },
    { RSETL_VAL_ATT_MODE_LDIS, "LDIS" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvAttMode = { 3, rsetl_rngCatvAttModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvPNSequenceEntries[2] =
  {
    { RSETL_VAL_DTV_PN_SEQ_VAR, "VAR" },
    { RSETL_VAL_DTV_PN_SEQ_CONS, "CONS" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvPNSequence = { 2, rsetl_rngCatvPNSequenceEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvFICSyncEntries[2] =
  {
    { RSETL_VAL_DTV_FIC_SYNC_FIC, "FIC" },
    { RSETL_VAL_DTV_FIC_SYNC_NFIC, "NFIC" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvFICSync = { 2, rsetl_rngCatvDtvFICSyncEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvMPGSyncEntries[2] =
  {
    { RSETL_VAL_DTV_MPEG_SYNC_MPG, "MPG" },
    { RSETL_VAL_DTV_MPEG_SYNC_NMPG, "NMPG" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvMPGSync = { 2, rsetl_rngCatvDtvMPGSyncEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvEquModeEntries[3] =
  {
    { RSETL_VAL_DTV_EQU_MODE_OFF, "OFF" },
    { RSETL_VAL_DTV_EQU_MODE_ON, "ON" },
    { RSETL_VAL_DTV_EQU_MODE_FRE, "FRE" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvEquMode = { 3, rsetl_rngCatvDtvEquModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvNotchBWEntries[4] =
  {
    { RSETL_VAL_DTV_NOTCH_BW_100, "NW100HZ" },
    { RSETL_VAL_DTV_NOTCH_BW_1K, "NW1KHZ" },
    { RSETL_VAL_DTV_NOTCH_BW_10K, "NW10KHZ" },
    { RSETL_VAL_DTV_NOTCH_BW_100K, "NW100KHZ" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvNotchBW = { 4, rsetl_rngCatvDtvNotchBWEntries };

RsCoreRangeTableRanged rsetl_rngCatvDtvNFilterFreq = { 0, 10000000.00, "Hz" };

RsCoreRangeTableRanged rsetl_rngCatvDtvTransMode = { 1, 4, "" };

RsCoreRangeTableRanged rsetl_rngCatvDtvFirstCapacityUnit = { 0, 863, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvDtvProtLevelEntries[13] =
  {
    { RSETL_VAL_DTV_PROT_LEV_PL1A, "PL1A" },
    { RSETL_VAL_DTV_PROT_LEV_PL2A, "PL2A" },
    { RSETL_VAL_DTV_PROT_LEV_PL3A, "PL3A" },
    { RSETL_VAL_DTV_PROT_LEV_PL4A, "PL4A" },
    { RSETL_VAL_DTV_PROT_LEV_PL1B, "PL1B" },
    { RSETL_VAL_DTV_PROT_LEV_PL2B, "PL2B" },
    { RSETL_VAL_DTV_PROT_LEV_PL3B, "PL3B" },
    { RSETL_VAL_DTV_PROT_LEV_PL4B, "PL4B" },
    { RSETL_VAL_DTV_PROT_LEV_PL1, "PL1" },
    { RSETL_VAL_DTV_PROT_LEV_PL2, "PL2" },
    { RSETL_VAL_DTV_PROT_LEV_PL3, "PL3" },
    { RSETL_VAL_DTV_PROT_LEV_PL4, "PL4" },
    { RSETL_VAL_DTV_PROT_LEV_PL5, "PL5" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvDtvProtLevel = { 13, rsetl_rngCatvDtvProtLevelEntries };

RsCoreRangeTableRanged rsetl_rngCatvResCarr = { 0, 30.00, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvSoundModeEntries[2] =
  {
    { RSETL_VAL_CATV_SOUND_ICAR, "ICAR" },
    { RSETL_VAL_CATV_SOUND_SCAR, "SCAR" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvSoundMode = { 2, rsetl_rngCatvSoundModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvVideoClampEntries[2] =
  {
    { RSETL_VAL_CATV_VIDEO_HARD, "HARD" },
    { RSETL_VAL_CATV_VIDEO_SOFT, "SOFT" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvVideoClamp = { 2, rsetl_rngCatvVideoClampEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvVideoGenIFOutEntries[2] =
  {
    { RSETL_VAL_CATV_VIDEO_IF_OUT_IFS, "IFS" },
    { RSETL_VAL_CATV_VIDEO_IF_OUT_CCVS, "CCVS" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvVideoGenIFOut = { 2, rsetl_rngCatvVideoGenIFOutEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvVideoTestPatternEntries[13] =
  {
    { RSETL_VAL_CATV_VIDEO_PATT_CBAR75, "CBAR75" },
    { RSETL_VAL_CATV_VIDEO_PATT_CBAR100, "CBAR100" },
    { RSETL_VAL_CATV_VIDEO_PATT_WHITE, "WHITE" },
    { RSETL_VAL_CATV_VIDEO_PATT_BLACK, "BLACK" },
    { RSETL_VAL_CATV_VIDEO_PATT_FUBK, "FUBK" },
    { RSETL_VAL_CATV_VIDEO_PATT_V15KHZ, "V15KHZ" },
    { RSETL_VAL_CATV_VIDEO_PATT_V250KHZ, "V250KHZ" },
    { RSETL_VAL_CATV_VIDEO_PATT_RFIELD, "RFIELD" },
    { RSETL_VAL_CATV_VIDEO_PATT_USER1, "USER1" },
    { RSETL_VAL_CATV_VIDEO_PATT_USER2, "USER2" },
    { RSETL_VAL_CATV_VIDEO_PATT_USER3, "USER3" },
    { RSETL_VAL_CATV_VIDEO_PATT_USER4, "USER4" },
    { RSETL_VAL_CATV_VIDEO_PATT_USER5, "USER5" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvVideoTestPattern = { 13, rsetl_rngCatvVideoTestPatternEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCatvTestSignalEntries[20] =
  {
    { RSETL_VAL_CATV_TEST_SIGNAL_T17C, "T17C" },
    { RSETL_VAL_CATV_TEST_SIGNAL_T15K, "T15K" },
    { RSETL_VAL_CATV_TEST_SIGNAL_T250, "T250" },
    { RSETL_VAL_CATV_TEST_SIGNAL_T184, "T184" },
    { RSETL_VAL_CATV_TEST_SIGNAL_T186, "T186" },
    { RSETL_VAL_CATV_TEST_SIGNAL_T330, "T330" },
    { RSETL_VAL_CATV_TEST_SIGNAL_T331, "T331" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TBUR, "TBUR" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TCBN, "TCBN" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TCPF, "TCPF" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TCPN, "TCPN" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TMOD, "TMOD" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TMUL, "TMUL" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TQU, "TQU" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TSIN, "TSIN" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TSYN, "TSYN" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TTTP, "TTTP" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TUK1, "TUK1" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TUK2, "TUK2" },
    { RSETL_VAL_CATV_TEST_SIGNAL_TUK, "TUK" }
  };
RsCoreRangeTableDiscrete rsetl_rngCatvTestSignal = { 20, rsetl_rngCatvTestSignalEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngSystemPowerEntries[3] =
  {
    { RSETL_VAL_SYST_POWER_AC, "AC" },
    { RSETL_VAL_SYST_POWER_DC, "DC" },
    { RSETL_VAL_SYST_POWER_BATT, "BATT" }
  };
RsCoreRangeTableDiscrete rsetl_rngSystemPower = { 3, rsetl_rngSystemPowerEntries };

RsCoreRangeTableRanged rsetl_rngCatvPilotLimit = { 0, 2.00, "" };

RsCoreRangeTableRanged rsetl_rngCatvSignalPilotLimit = { 0.00, 20.00, "" };

RsCoreRangeTableRanged rsetl_rngCatvPilotAmplErrLimit = { -10.00, 10.00, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDispWindowModeEntries[1] =
  {
    { RSETL_VAL_DISP_MODE_ETF, "ETF" }
  };
RsCoreRangeTableDiscrete rsetl_rngDispWindowMode = { 1, rsetl_rngDispWindowModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVMeasModeEntries[3] =
  {
    { RSETL_VAL_CATV_MEAS_MODE_ATV, "ATV" },
    { RSETL_VAL_CATV_MEAS_MODE_DTV, "DTV" },
    { RSETL_VAL_CATV_MEAS_MODE_RAD, "RAD" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVMeasMode = { 3, rsetl_rngCATVMeasModeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVWavParamEntries[54] =
  {
    { RSETL_VAL_ATV_VME_LBAR, "LBAR" },
    { RSETL_VAL_ATV_VME_SARB, "SARB" },
    { RSETL_VAL_ATV_VME_BARB, "BARB" },
    { RSETL_VAL_ATV_VME_CLDP, "CLDP" },
    { RSETL_VAL_ATV_VME_CLGB, "CLGB" },
    { RSETL_VAL_ATV_VME_CLGP, "CLGP" },
    { RSETL_VAL_ATV_VME_BD, "BD" },
    { RSETL_VAL_ATV_VME_TTPA, "TTPA" },
    { RSETL_VAL_ATV_VME_TTPK, "TTPK" },
    { RSETL_VAL_ATV_VME_TILT, "TILT" },
    { RSETL_VAL_ATV_VME_STRE, "STRE" },
    { RSETL_VAL_ATV_VME_STFE, "STFE" },
    { RSETL_VAL_ATV_VME_LTD, "LTD" },
    { RSETL_VAL_ATV_VME_CLIP, "CLIP" },
    { RSETL_VAL_ATV_VME_CLI3, "CLI3" },
    { RSETL_VAL_ATV_VME_GPPC, "GPPC" },
    { RSETL_VAL_ATV_VME_PPPC, "PPPC" },
    { RSETL_VAL_ATV_VME_LNL, "LNL" },
    { RSETL_VAL_ATV_VME_DGP, "DGP" },
    { RSETL_VAL_ATV_VME_DGN, "DGN" },
    { RSETL_VAL_ATV_VME_DPP, "DPP" },
    { RSETL_VAL_ATV_VME_DPN, "DPN" },
    { RSETL_VAL_ATV_VME_ICPH, "ICPH" },
    { RSETL_VAL_ATV_VME_ICPL, "ICPL" },
    { RSETL_VAL_ATV_VME_MRB, "MRB" },
    { RSETL_VAL_ATV_VME_M05P, "M05P" },
    { RSETL_VAL_ATV_VME_M10P, "M10P" },
    { RSETL_VAL_ATV_VME_M20P, "M20P" },
    { RSETL_VAL_ATV_VME_M40P, "M40P" },
    { RSETL_VAL_ATV_VME_M48P, "M48P" },
    { RSETL_VAL_ATV_VME_M58P, "M58P" },
    { RSETL_VAL_ATV_VME_NRB, "NRB" },
    { RSETL_VAL_ATV_VME_N05P, "N05P" },
    { RSETL_VAL_ATV_VME_N15P, "N15P" },
    { RSETL_VAL_ATV_VME_N30P, "N30P" },
    { RSETL_VAL_ATV_VME_N44P, "N44P" },
    { RSETL_VAL_ATV_VME_SXAP, "SXAP" },
    { RSETL_VAL_ATV_VME_SXAN, "SXAN" },
    { RSETL_VAL_ATV_VME_SXGP, "SXGP" },
    { RSETL_VAL_ATV_VME_SXGN, "SXGN" },
    { RSETL_VAL_ATV_VME_FRB, "FRB" },
    { RSETL_VAL_ATV_VME_F05P, "F05P" },
    { RSETL_VAL_ATV_VME_F12P, "F12P" },
    { RSETL_VAL_ATV_VME_F20P, "F20P" },
    { RSETL_VAL_ATV_VME_F30P, "F30P" },
    { RSETL_VAL_ATV_VME_F35P, "F35P" },
    { RSETL_VAL_ATV_VME_F41P, "F41P" },
    { RSETL_VAL_ATV_VME_TRB, "TRB" },
    { RSETL_VAL_ATV_VME_T05P, "T05P" },
    { RSETL_VAL_ATV_VME_T10P, "T10P" },
    { RSETL_VAL_ATV_VME_T20P, "T20P" },
    { RSETL_VAL_ATV_VME_T30P, "T30P" },
    { RSETL_VAL_ATV_VME_T35P, "T35P" },
    { RSETL_VAL_ATV_VME_T42P, "T42P" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVWavParam = { 54, rsetl_rngCATVWavParamEntries };

RsCoreRangeTableRanged rsetl_rngCATVWavLoc = { 0, 14, "" };

RsCoreRangeTableRanged rsetl_rngCATVOOBETranPowerRange = { 1, 8, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVOOBEMaskTypeEntries[7] =
  {
    { RSETL_VAL_DTV_MASK_TYPE_CRIT, "CRIT" },
    { RSETL_VAL_DTV_MASK_TYPE_SUB, "SUB" },
    { RSETL_VAL_DTV_MASK_TYPE_NONE, "NONE" },
    { RSETL_VAL_DTV_MASK_TYPE_C1, "C1" },
    { RSETL_VAL_DTV_MASK_TYPE_C2, "C2" },
    { RSETL_VAL_DTV_MASK_TYPE_C3, "C3" },
    { RSETL_VAL_DTV_MASK_TYPE_C4, "C4" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVOOBEMaskType = { 7, rsetl_rngCATVOOBEMaskTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVOOBECountryEntries[2] =
  {
    { RSETL_VAL_DTV_COUNTRY_JAPAN, "JAP" },
    { RSETL_VAL_DTV_COUNTRY_BRAZIL, "BRAZ" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVOOBECountry = { 2, rsetl_rngCATVOOBECountryEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVEyeDiagramTimeSpanEntries[10] =
  {
    { RSETL_VAL_DTV_TIME_SPAN_S1_4, "S1_4" },
    { RSETL_VAL_DTV_TIME_SPAN_S1_2, "S1_2" },
    { RSETL_VAL_DTV_TIME_SPAN_S1, "S1" },
    { RSETL_VAL_DTV_TIME_SPAN_S2, "S2" },
    { RSETL_VAL_DTV_TIME_SPAN_S3, "S3" },
    { RSETL_VAL_DTV_TIME_SPAN_S4, "S4" },
    { RSETL_VAL_DTV_TIME_SPAN_S5, "S5" },
    { RSETL_VAL_DTV_TIME_SPAN_S6, "S6" },
    { RSETL_VAL_DTV_TIME_SPAN_S7, "S7" },
    { RSETL_VAL_DTV_TIME_SPAN_S8, "S8" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVEyeDiagramTimeSpan = { 10, rsetl_rngCATVEyeDiagramTimeSpanEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVISDBTConstSelectEntries[5] =
  {
    { RSETL_VAL_DTV_CONS_SEL_SUM, "SUM" },
    { RSETL_VAL_DTV_CONS_SEL_A, "A" },
    { RSETL_VAL_DTV_CONS_SEL_B, "B" },
    { RSETL_VAL_DTV_CONS_SEL_C, "C" },
    { RSETL_VAL_DTV_CONS_SEL_ABC, "ABC" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVISDBTConstSelect = { 5, rsetl_rngCATVISDBTConstSelectEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVISDBTXAxisUnitEntries[3] =
  {
    { RSETL_VAL_DTV_X_AXIS_UNIT_BOTH, "BOTH" },
    { RSETL_VAL_DTV_X_AXIS_UNIT_CARR, "CARR" },
    { RSETL_VAL_DTV_X_AXIS_UNIT_SEG, "SEGM" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVISDBTXAxisUnit = { 3, rsetl_rngCATVISDBTXAxisUnitEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVISDBTCodeRateEntries[7] =
  {
    { RSETL_VAL_DTV_FUNC_CODE_RATE_R1_2, "R1_2" },
    { RSETL_VAL_DTV_FUNC_CODE_RATE_R2_3, "R2_3" },
    { RSETL_VAL_DTV_FUNC_CODE_RATE_R3_4, "R3_4" },
    { RSETL_VAL_DTV_FUNC_CODE_RATE_R5_6, "R5_6" },
    { RSETL_VAL_DTV_FUNC_CODE_RATE_R7_8, "R7_8" },
    { RSETL_VAL_NA, "n/a" },
    { RSETL_VAL_NAN, "---" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVISDBTCodeRate = { 7, rsetl_rngCATVISDBTCodeRateEntries };

static ViReal64 rsetl_rngCATVISDBTTimeDeinterleaverEntries[4] = { 0, 4, 8, 16 };
RsCoreRangeTableCoerced rsetl_rngCATVISDBTTimeDeinterleaver = { 4, rsetl_rngCATVISDBTTimeDeinterleaverEntries, "" };

RsCoreRangeTableRanged rsetl_rngCATVISDBTSegments = { 0, 13, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVISDBTModulationEntries[6] =
  {
    { RSETL_VAL_DTV_MODUL_QPSK, "QPSK" },
    { RSETL_VAL_DTV_MODUL_DQPSK, "DQPSK" },
    { RSETL_VAL_DTV_MODUL_QAM16, "QAM16" },
    { RSETL_VAL_DTV_MODUL_QAM64, "QAM64" },
    { RSETL_VAL_NA, "n/a" },
    { RSETL_VAL_NAN, "---" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVISDBTModulation = { 6, rsetl_rngCATVISDBTModulationEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVISDBTFFTWindowPositionEntries[2] =
  {
    { RSETL_VAL_DTV_WPOS_AUTO, "AUTO" },
    { RSETL_VAL_DTV_WPOS_MAN, "MAN" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVISDBTFFTWindowPosition = { 2, rsetl_rngCATVISDBTFFTWindowPositionEntries };

RsCoreRangeTableRanged rsetl_rngCATVISDBTFFTWindowOffset = { -50, 50, "" };

RsCoreRangeTableRanged rsetl_rngCATVISDBTMerr = { 0, 80.00, "dB" };

RsCoreRangeTableRanged rsetl_rngCATVISDBTBARS = { 0, 0.005, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioMeasEntries[17] =
  {
    { RSETL_VAL_RADIO_MEAS_SPECTRUM, "SPEC" },
    { RSETL_VAL_RADIO_MEAS_OVERVIEW, "OVER" },
    { RSETL_VAL_RADIO_MEAS_AUDIO_SPECTRUM, "ASP" },
    { RSETL_VAL_RADIO_MEAS_AUDIO_SCOPE, "ASC" },
    { RSETL_VAL_RADIO_MEAS_AUDIO_LEVEL, "ALEV" },
    { RSETL_VAL_RADIO_MEAS_MPX_POWER, "MPOW" },
    { RSETL_VAL_RADIO_MEAS_MPX_DEV_DISTR, "DDIS" },
    { RSETL_VAL_RADIO_MEAS_MULTIPATH, "MDET" },
    { RSETL_VAL_RADIO_MEAS_THD, "THD" },
    { RSETL_VAL_RADIO_MEAS_DFD, "DFD" },
    { RSETL_VAL_RADIO_MEAS_SN, "SN" },
    { RSETL_VAL_RADIO_MEAS_CROSSTALK, "CROS" },
    { RSETL_VAL_RADIO_MEAS_FREQ_RESPONSE, "FRES" },
    { RSETL_VAL_RADIO_MEAS_RDS, "RDS" },
    { RSETL_VAL_RADIO_MEAS_LOG, "DREC" },
    { RSETL_VAL_RADIO_MEAS_OBW, "OBW" },
    { RSETL_VAL_RADIO_MEAS_DVI, "DVI" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioMeas = { 17, rsetl_rngRadioMeasEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioStandardEntries[2] =
  {
    { RSETL_VAL_RADIO_FM_STEREO, "FM_S" },
    { RSETL_VAL_RADIO_FM_MONO, "FM_M" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioStandard = { 2, rsetl_rngRadioStandardEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioBandwidthEntries[6] =
  {
    { RSETL_VAL_RADIO_BW_150K, "B150" },
    { RSETL_VAL_RADIO_BW_200K, "B200" },
    { RSETL_VAL_RADIO_BW_250K, "B250" },
    { RSETL_VAL_RADIO_BW_300K, "B300" },
    { RSETL_VAL_RADIO_BW_350K, "B350" },
    { RSETL_VAL_RADIO_BW_400K, "B400" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioBandwidth = { 6, rsetl_rngRadioBandwidthEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioDataEntries[3] =
  {
    { RSETL_VAL_RADIO_DATA_NONE, "NONE" },
    { RSETL_VAL_RADIO_DATA_RDS, "RDS" },
    { RSETL_VAL_RADIO_DATA_DARC, "DARC" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioData = { 3, rsetl_rngRadioDataEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioSCAEntries[3] =
  {
    { RSETL_VAL_RADIO_SCA_OFF, "OFF" },
    { RSETL_VAL_RADIO_SCA_NARROW, "NARR" },
    { RSETL_VAL_RADIO_SCA_WIDE, "WIDE" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioSCA = { 3, rsetl_rngRadioSCAEntries };

RsCoreRangeTableRanged rsetl_rngRadioDUTLevel = { -12, 12, "dBu" };

RsCoreRangeTableRanged rsetl_rngRadioDUTDeviation = { 10.0, 150.0e3, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioYScalingEntries[2] =
  {
    { RSETL_VAL_TRACE_SPACE_LIN, "LIN" },
    { RSETL_VAL_TRACE_SPACE_LOG, "LOG" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioYScaling = { 2, rsetl_rngRadioYScalingEntries };

RsCoreRangeTableRanged rsetl_rngRadioSweepPoints = { 1, 1000, "" };

RsCoreRangeTableRanged rsetl_rngRadioStart = { 0, 99.999e3, "Hz" };

RsCoreRangeTableRanged rsetl_rngRadioStopCenter = { 0, 100.0e3, "Hz" };

RsCoreRangeTableRanged rsetl_rngRadioSpan = { 100, 100.0e3, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioZoomEntries[20] =
  {
    { RSETL_VAL_RADIO_ZOOM_NONE, "NONE" },
    { RSETL_VAL_RADIO_ZOOM_LEVEL, "LEV" },
    { RSETL_VAL_RADIO_ZOOM_CF_OFFSET, "CFOF" },
    { RSETL_VAL_RADIO_ZOOM_MPX_DEV, "MPXD" },
    { RSETL_VAL_RADIO_ZOOM_L_DEV, "LD" },
    { RSETL_VAL_RADIO_ZOOM_R_DEV, "RD" },
    { RSETL_VAL_RADIO_ZOOM_M_DEV, "MDEV" },
    { RSETL_VAL_RADIO_ZOOM_S_DEV, "SDEV" },
    { RSETL_VAL_RADIO_ZOOM_PILOT_DEV, "PDEV" },
    { RSETL_VAL_RADIO_ZOOM_AM_MOD_DEPTH, "AMMD" },
    { RSETL_VAL_RADIO_ZOOM_PILOT_FREQ_OFFSET, "PFR" },
    { RSETL_VAL_RADIO_ZOOM_PILOT_PHA_OFFSET, "PPH" },
    { RSETL_VAL_RADIO_ZOOM_RDS_DEV, "RDSD" },
    { RSETL_VAL_RADIO_ZOOM_RDS_FREQ_OFFSET, "RDSF" },
    { RSETL_VAL_RADIO_ZOOM_RDS_PHA_OFFSET, "RDSP" },
    { RSETL_VAL_RADIO_ZOOM_RDS_BER, "RDSB" },
    { RSETL_VAL_RADIO_ZOOM_DARC_DEV, "DARC" },
    { RSETL_VAL_RADIO_ZOOM_SCA_CARR_DEV, "SCD" },
    { RSETL_VAL_RADIO_ZOOM_SCA_OFFSET, "SCS" },
    { RSETL_VAL_RADIO_ZOOM_SCA_DEV, "SCSD" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioZoom = { 20, rsetl_rngRadioZoomEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioTypeEntries[5] =
  {
    { RSETL_VAL_FREQ_RESPONSE_ARMS, "ARMS" },
    { RSETL_VAL_FREQ_RESPONSE_ASEL, "ASEL" },
    { RSETL_VAL_FREQ_RESPONSE_LRBA, "RLB" },
    { RSETL_VAL_FREQ_RESPONSE_PHASE, "PHAS" },
    { RSETL_VAL_FREQ_RESPONSE_APH, "APH" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioType = { 5, rsetl_rngRadioTypeEntries };

RsCoreRangeTableRanged rsetl_rngRadioRefFreq = { 10.0, 100.0e3, "Hz" };

RsCoreRangeTableRanged rsetl_rngRadioPhaseRange = { 0.1, 100000, "deg" };

RsCoreRangeTableRanged rsetl_rngRadioFreqRange = { 0.1, 200.0, "dB" };

RsCoreRangeTableRanged rsetl_rngRadioRefPos = { -1000, 1000, "%" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCrosstalkTypeEntries[3] =
  {
    { RSETL_VAL_CROSSTALK_LINEAR, "LIN" },
    { RSETL_VAL_CROSSTALK_NO_LINEAR, "NLIN" },
    { RSETL_VAL_CROSSTALK_COMBINED, "LINL" }
  };
RsCoreRangeTableDiscrete rsetl_rngCrosstalkType = { 3, rsetl_rngCrosstalkTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCrosstalkReferenceEntries[7] =
  {
    { RSETL_VAL_CROSSTALK_REF_LR, "LR" },
    { RSETL_VAL_CROSSTALK_REF_L, "L" },
    { RSETL_VAL_CROSSTALK_REF_R, "R" },
    { RSETL_VAL_CROSSTALK_REF_MS, "MS" },
    { RSETL_VAL_CROSSTALK_REF_M, "M" },
    { RSETL_VAL_CROSSTALK_REF_S, "S" },
    { RSETL_VAL_CROSSTALK_REF_RDEV, "RDEV" }
  };
RsCoreRangeTableDiscrete rsetl_rngCrosstalkReference = { 7, rsetl_rngCrosstalkReferenceEntries };

RsCoreRangeTableRanged rsetl_rngRadioDeviation = { 1.0, 150.0e3, "Hz" };

RsCoreRangeTableRanged rsetl_rngRadioMPXRefPos = { -20.0, 18.0, "" };

RsCoreRangeTableRanged rsetl_rngRadioPowerRange = { 1.0, 50.0, "dB" };

RsCoreRangeTableRanged rsetl_rngRadioPeakDev = { 1.0, 150.0e3, "Hz" };

RsCoreRangeTableRanged rsetl_rngRadioSampleCount = { 100, 12000000, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioSignalPathEntries[13] =
  {
    { RSETL_VAL_RADIO_PATH_MPX, "MPX" },
    { RSETL_VAL_RADIO_PATH_AM, "AM" },
    { RSETL_VAL_RADIO_PATH_LR, "LR" },
    { RSETL_VAL_RADIO_PATH_L, "L" },
    { RSETL_VAL_RADIO_PATH_R, "R" },
    { RSETL_VAL_RADIO_PATH_MS, "MS" },
    { RSETL_VAL_RADIO_PATH_M, "M" },
    { RSETL_VAL_RADIO_PATH_S, "S" },
    { RSETL_VAL_RADIO_PATH_PILOT, "PIL" },
    { RSETL_VAL_RADIO_PATH_RDS_SC, "RDSS" },
    { RSETL_VAL_RADIO_PATH_DARC_SC, "DARC" },
    { RSETL_VAL_RADIO_PATH_SCA_SC, "SCAS" },
    { RSETL_VAL_RADIO_PATH_SCA, "SCA" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioSignalPath = { 13, rsetl_rngRadioSignalPathEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioDeemphasisEntries[3] =
  {
    { RSETL_VAL_RADIO_DEEMPHASIS_OFF, "OFF" },
    { RSETL_VAL_RADIO_DEEMPHASIS_D50, "D50" },
    { RSETL_VAL_RADIO_DEEMPHASIS_D75, "D75" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioDeemphasis = { 3, rsetl_rngRadioDeemphasisEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioAGenTypeEntries[3] =
  {
    { RSETL_VAL_AUDIO_GEN_ANALOG, "ANAL" },
    { RSETL_VAL_AUDIO_GEN_MPX, "ALR" },
    { RSETL_VAL_AUDIO_GEN_ALR, "MPX" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioAGenType = { 3, rsetl_rngRadioAGenTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioAGenSignalEntries[8] =
  {
    { RSETL_VAL_AUDIO_SIG_OFF, "OFF" },
    { RSETL_VAL_AUDIO_SIG_AF, "AF" },
    { RSETL_VAL_AUDIO_SIG_L, "L" },
    { RSETL_VAL_AUDIO_SIG_R, "R" },
    { RSETL_VAL_AUDIO_SIG_LGR, "LGR" },
    { RSETL_VAL_AUDIO_SIG_LMR, "LMR" },
    { RSETL_VAL_AUDIO_SIG_LUR, "LUR" },
    { RSETL_VAL_AUDIO_SIG_SCA, "SCA" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioAGenSignal = { 8, rsetl_rngRadioAGenSignalEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioAGenConfigEntries[2] =
  {
    { RSETL_VAL_AUDIO_CON_LRM, "LRM" },
    { RSETL_VAL_AUDIO_CON_MRN, "MRN" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioAGenConfig = { 2, rsetl_rngRadioAGenConfigEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioAGenAmplitudeEntries[3] =
  {
    { RSETL_VAL_AUDIO_AMP_LEVEL, "LEV" },
    { RSETL_VAL_AUDIO_AMP_VOLTAGE, "VOLT" },
    { RSETL_VAL_AUDIO_AMP_DUT, "DUT" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioAGenAmplitude = { 3, rsetl_rngRadioAGenAmplitudeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioAGenWaveformEntries[3] =
  {
    { RSETL_VAL_AUDIO_SINGLE, "ST" },
    { RSETL_VAL_AUDIO_DUAL_CONST, "DTCS" },
    { RSETL_VAL_AUDIO_DUAL_IND, "DTIF" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioAGenWaveform = { 3, rsetl_rngRadioAGenWaveformEntries };

RsCoreRangeTableRanged rsetl_rngRadioAGenLevel = { -60, 19.208, "dBu" };

RsCoreRangeTableRanged rsetl_rngRadioAGenFrequency = { 10.0, 100.0e3, "Hz" };

RsCoreRangeTableRanged rsetl_rngRadioAGenDeviation = { 0.0, 150.0e3, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioPhasisEntries[5] =
  {
    { RSETL_VAL_AUDIO_PHASIS_OFF, "OFF" },
    { RSETL_VAL_AUDIO_PHASIS_D50, "D50" },
    { RSETL_VAL_AUDIO_PHASIS_D75, "D75" },
    { RSETL_VAL_AUDIO_PHASIS_D100, "D100" },
    { RSETL_VAL_AUDIO_PHASIS_D150, "D150" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioPhasis = { 5, rsetl_rngRadioPhasisEntries };

RsCoreRangeTableRanged rsetl_rngRadioAGenDUTDeviation = { 10.0, 150.0e3, "Hz" };

RsCoreRangeTableRanged rsetl_rngRadioSNTHDLimit = { 0.0, 100.0, "" };

RsCoreRangeTableRanged rsetl_rngRadioDFDLimit = { 0.0, 100., "" };

RsCoreRangeTableRanged rsetl_rngRadioMPXLimit = { -2, 20, "" };

RsCoreRangeTableRanged rsetl_rngRadioMPXPeakLimit = { 0, 150e3, "" };

RsCoreRangeTableRanged rsetl_rngrsetl_rngRadioMPDetectLimit = { 0, 100, "" };

RsCoreRangeTableRanged rsetl_rngDTVDispFrameCell = { 1, 999999999, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioPowPeakMeasEntries[3] =
  {
    { RSETL_VAL_RADIO_MPX_POWER, "MPPD" },
    { RSETL_VAL_RADIO_PEAK_DEVIATION, "MPOW" },
    { RSETL_VAL_RADIO_MPX_POWER_PEAK, "PDEV" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioPowPeakMeas = { 3, rsetl_rngRadioPowPeakMeasEntries };

RsCoreRangeTableRanged rsetl_rngRadioPilDeviation = { 0, 10000, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioOutSignalEntries[5] =
  {
    { RSETL_VAL_RADIO_OUTPUT_AUTO, "AUTO" },
    { RSETL_VAL_RADIO_OUTPUT_MONO, "MONO" },
    { RSETL_VAL_RADIO_OUTPUT_STEREO, "STER" },
    { RSETL_VAL_RADIO_OUTPUT_MS, "MS" },
    { RSETL_VAL_RADIO_OUTPUT_GENERATOR, "GEN" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioOutSignal = { 5, rsetl_rngRadioOutSignalEntries };

RsCoreRangeTableRanged rsetl_rngRadioOutDeviation = { 20.0e3, 160.0e3, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioOutCCVSEntries[7] =
  {
    { RSETL_VAL_RADIO_OUTPUT_CCVS_OFF, "OFF" },
    { RSETL_VAL_RADIO_OUTPUT_CCVS_MPX, "MPX" },
    { RSETL_VAL_RADIO_OUTPUT_CCVS_AES_EBU, "AES" },
    { RSETL_VAL_RADIO_OUTPUT_CCVS_PILOT, "PIL" },
    { RSETL_VAL_RADIO_OUTPUT_CCVS_RDS, "RDS" },
    { RSETL_VAL_RADIO_OUTPUT_CCVS_DARC, "DARC" },
    { RSETL_VAL_RADIO_OUTPUT_CCVS_SCA, "SCA" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioOutCCVS = { 7, rsetl_rngRadioOutCCVSEntries };

RsCoreRangeTableRanged rsetl_rngDispRefPos = { -500, 500, "%" };

RsCoreRangeTableRanged rsetl_rngDispRefDev = { 1.0, 10.0e3, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngTraceScalingEntries[2] =
  {
    { RSETL_VAL_TRACE_SPACE_LIN, "LIN" },
    { RSETL_VAL_TRACE_SPACE_LOG, "LOG" }
  };
RsCoreRangeTableDiscrete rsetl_rngTraceScaling = { 2, rsetl_rngTraceScalingEntries };

RsCoreRangeTableRanged rsetl_rngDispMerRange = { 1.0, 200.0, "dB" };

RsCoreRangeTableRanged rsetl_rngMERFreqStartStopCenter = { 0.0, 4.0e3, "Hz" };

RsCoreRangeTableRanged rsetl_rngMERFreqSpan = { 1.0, 4.0e3, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVEchoOffModeEntries[2] =
  {
    { RSETL_VAL_STATE_AUTO, "AUTO" },
    { RSETL_VAL_STATE_MAN, "MAN" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVEchoOffMode = { 2, rsetl_rngDTVEchoOffModeEntries };

RsCoreRangeTableRanged rsetl_rngDTVEchoOffTreshold = { -42.0, 0.0, "dB" };

RsCoreRangeTableRanged rsetl_rngDTVEchoFFETaps = { 3, 15, "" };

RsCoreRangeTableRanged rsetl_rngDTVEchoFFESec = { -37.5e-6, -0.4288e-6, "s" };

RsCoreRangeTableRanged rsetl_rngDTVEchoDFETaps = { 3.0, 108.0, "" };

RsCoreRangeTableRanged rsetl_rngDTVEchoDFESec = { 0.4288e-6, 270e-6, "s" };

RsCoreRangeTableRanged rsetl_rngDTVVelFactor = { 0.0001, 1.0, "" };

RsCoreRangeTableRanged rsetl_rngDTVLogGPSPort = { 1, 16, "" };

RsCoreRangeTableRanged rsetl_rngDTVCNFreq = { -1.5e9, 1.5e9, "" };

RsCoreRangeTableRanged rsetl_rngDTVCNBandwidth = { 10.0, 100.0e6, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVDataModeEntries[2] =
  {
    { RSETL_VAL_DTV_AUTO, "AUTO" },
    { RSETL_VAL_DTV_MANUAL, "MAN" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVDataMode = { 2, rsetl_rngDTVDataModeEntries };

RsCoreRangeTableRanged rsetl_rngDTVDataPLP = { 0, 127, "" };

RsCoreRangeTableRanged rsetl_rngDTVDataParade = { 0, 127, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVDVBSystemEntries[2] =
  {
    { RSETL_VAL_DTV_TS_SISO, "SISO" },
    { RSETL_VAL_DTV_TS_MISO, "MISO" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVDVBSystem = { 2, rsetl_rngDTVDVBSystemEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVDVBPilPatEntries[7] =
  {
    { RSETL_VAL_DTV_PILOT_PP1, "PP1" },
    { RSETL_VAL_DTV_PILOT_PP2, "PP2" },
    { RSETL_VAL_DTV_PILOT_PP3, "PP3" },
    { RSETL_VAL_DTV_PILOT_PP4, "PP4" },
    { RSETL_VAL_DTV_PILOT_PP5, "PP5" },
    { RSETL_VAL_DTV_PILOT_PP6, "PP6" },
    { RSETL_VAL_DTV_PILOT_PP7, "PP7" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVDVBPilPat = { 7, rsetl_rngDTVDVBPilPatEntries };

RsCoreRangeTableRanged rsetl_rngDTVDVBDataSymbol = { 3, 4059, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVPLPPayloadEntries[4] =
  {
    { RSETL_VAL_DTV_PLP_TS, "TS" },
    { RSETL_VAL_DTV_PLP_GFPS, "GFPS" },
    { RSETL_VAL_DTV_PLP_GCS, "GCS" },
    { RSETL_VAL_DTV_PLP_GSE, "GSE" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVPLPPayload = { 4, rsetl_rngDTVPLPPayloadEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVPLPCodeRateEntries[6] =
  {
    { RSETL_VAL_DTV_CODE_RATE_12, "R1_2" },
    { RSETL_VAL_DTV_CODE_RATE_35, "R3_5" },
    { RSETL_VAL_DTV_CODE_RATE_23, "R2_3" },
    { RSETL_VAL_DTV_CODE_RATE_34, "R3_4" },
    { RSETL_VAL_DTV_CODE_RATE_45, "R4_5" },
    { RSETL_VAL_DTV_CODE_RATE_56, "R5_6" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVPLPCodeRate = { 6, rsetl_rngDTVPLPCodeRateEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVPLPModulationEntries[4] =
  {
    { RSETL_VAL_DTV_PLP_MOD_QPSK, "QPSK" },
    { RSETL_VAL_DTV_PLP_MOD_QAM16, "QAM16" },
    { RSETL_VAL_DTV_PLP_MOD_QAM64, "QAM64" },
    { RSETL_VAL_DTV_PLP_MOD_QAM256, "QAM256" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVPLPModulation = { 4, rsetl_rngDTVPLPModulationEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVPLPFECTypeEntries[2] =
  {
    { RSETL_VAL_DTV_PLP_FEC_SHORT, "SHOR" },
    { RSETL_VAL_DTV_PLP_FEC_NORMAL, "NORM" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVPLPFECType = { 2, rsetl_rngDTVPLPFECTypeEntries };

RsCoreRangeTableRanged rsetl_rngDTVPLPBlocks = { 1, 1023, "" };

RsCoreRangeTableRanged rsetl_rngDTVPLPTIBlocks = { 0, 255, "" };

RsCoreRangeTableRanged rsetl_rngCatvMERL1Lower = { 0, 80, "dB" };

RsCoreRangeTableRanged rsetl_rngCatvMERL1Upper = { 0.01, 100, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVTransSystEntries[3] =
  {
    { RSETL_VAL_DVBT2_SISO, "SISO" },
    { RSETL_VAL_DVBT2_MISO, "MISO" },
    { RSETL_VAL_DVBT2_NTO2, "NTO2" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVTransSyst = { 3, rsetl_rngDTVTransSystEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVConstelationEntries[4] =
  {
    { RSETL_VAL_DVBT2_BPSK, "BPSK" },
    { RSETL_VAL_DVBT2_QPSK, "QPSK" },
    { RSETL_VAL_DVBT2_QAM16, "QAM16" },
    { RSETL_VAL_DVBT2_QAM64, "QAM64" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVConstelation = { 4, rsetl_rngDTVConstelationEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVCodeRateEntries[2] =
  {
    { RSETL_VAL_DVBT2_RESERVED, "RES" },
    { RSETL_VAL_DVBT2_POST_CODE_RATE_1_2, "R1_2" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVCodeRate = { 2, rsetl_rngDTVCodeRateEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVFECTypeEntries[2] =
  {
    { RSETL_VAL_DVBT2_RESERVED, "RES" },
    { RSETL_VAL_DVBT2_FEC_SHORT, "SHOR" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVFECType = { 2, rsetl_rngDTVFECTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVPAPREntries[9] =
  {
    { RSETL_VAL_DVBT2_RESERVED, "RES" },
    { RSETL_VAL_DVBT2_PAPR_NONE, "NONE" },
    { RSETL_VAL_DVBT2_PAPR_ACE, "ACE" },
    { RSETL_VAL_DVBT2_PAPR_TR, "TR" },
    { RSETL_VAL_DVBT2_PAPR_ACTR, "ACTR" },
    { RSETL_VAL_DVBT2_PAPR_LAPT, "LAPT" },
    { RSETL_VAL_DVBT2_PAPR_LATR, "LATR" },
    { RSETL_VAL_DVBT2_PAPR_LAAC, "LAAC" },
    { RSETL_VAL_DVBT2_PAPR_LAAT, "LAAT" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVPAPR = { 9, rsetl_rngDTVPAPREntries };

RsCoreRangeTableRanged rsetl_rngRadioAGenFreqSpac = { 1.0, 99990, "Hz" };

RsCoreRangeTableRanged rsetl_rngRadioAGenFreqUpp = { 11.0, 100000, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVGetDigitalTVCodeRateEntries[7] =
  {
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R1_2, "R1_2" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R2_3, "R2_3" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R3_4, "R3_4" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R5_6, "R5_6" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R3_5, "R3_5" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_R4_5, "R4_5" },
    { RSETL_VAL_DTV_CODE_RATE_PRIOR_RES, "RES" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVGetDigitalTVCodeRate = { 7, rsetl_rngCATVGetDigitalTVCodeRateEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVGetDigitalTVCFrameEntries[3] =
  {
    { RSETL_VAL_CATV_CONTROL_FRAME_UNDEFINED, "\'---\'" },
    { RSETL_VAL_CATV_CONTROL_FRAME_NOT_PRESENT, "\'0\'" },
    { RSETL_VAL_CATV_CONTROL_FRAME_PRESENT, "\'1\'" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVGetDigitalTVCFrame = { 3, rsetl_rngCATVGetDigitalTVCFrameEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngCATVDTVL1StreamTypeResultEntries[4] =
  {
    { RSETL_VAL_DVBT2_RESERVED, "RES" },
    { RSETL_VAL_DVBT2_STYPE_TS_ONLY, "TSON" },
    { RSETL_VAL_DVBT2_STYPE_GENERIC, "GEN" },
    { RSETL_VAL_DVBT2_STYPE_TS_GEN, "TSGE" }
  };
RsCoreRangeTableDiscrete rsetl_rngCATVDTVL1StreamTypeResult = { 4, rsetl_rngCATVDTVL1StreamTypeResultEntries };

RsCoreRangeTableRanged rsetl_rngCATVAttenuationDrive = { 0.0, 50.0, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDisplayMISOEntries[4] =
  {
    { RSETL_VAL_DTV_MISO_DISPLAY_SUM, "SUM" },
    { RSETL_VAL_DTV_MISO_DISPLAY_GRP1, "GRP1" },
    { RSETL_VAL_DTV_MISO_DISPLAY_GRP2, "GRP2" },
    { RSETL_VAL_DTV_MISO_DISPLAY_GRPS, "GRPS" }
  };
RsCoreRangeTableDiscrete rsetl_rngDisplayMISO = { 4, rsetl_rngDisplayMISOEntries };

RsCoreRangeTableRanged rsetl_rngCATVDigitalTVATSCSelectParadeByService = { 1, 256, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVISSYProcessingEntries[2] =
  {
    { RSETL_VAL_DTV_ISSY_COMPLIANT, "COMP" },
    { RSETL_VAL_DTV_ISSY_TOLERANT, "TOL" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVISSYProcessing = { 2, rsetl_rngDTVISSYProcessingEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVT2ProfileEntries[2] =
  {
    { RSETL_VAL_DTV_T2_PROFILE_T2BASE, "T2B" },
    { RSETL_VAL_DTV_T2_PROFILE_T2LITE, "T2L" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVT2Profile = { 2, rsetl_rngDTVT2ProfileEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioSpectrumMaskEntries[4] =
  {
    { RSETL_VAL_RADIO_SPECTRUM_MASK_PSHQ, "PSHQ" },
    { RSETL_VAL_RADIO_SPECTRUM_MASK_K200, "K200" },
    { RSETL_VAL_RADIO_SPECTRUM_MASK_K250, "K250" },
    { RSETL_VAL_RADIO_SPECTRUM_MASK_K300, "K300" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioSpectrumMask = { 4, rsetl_rngRadioSpectrumMaskEntries };

RsCoreRangeTableRanged rsetl_rngDTVAmplitudeNoiseLowerLimit = { 0.0, 120.0, "" };

RsCoreRangeTableRanged rsetl_rngDTVImageRejectionLowerLimit = { 0.0, 120.0, "" };

RsCoreRangeTableRanged rsetl_rngMERRMSLow = { 0.0, 80.0, "" };

RsCoreRangeTableRanged rsetl_rngMERRMSUpp = { 0.01, 100.0, "" };

RsCoreRangeTableRanged rsetl_rngPhaseNoiseLowerLimit = { 0.0, 120.0, "" };

RsCoreRangeTableRanged rsetl_rngMarkerRadioProbabilityValue = { 0, 1, "" };

RsCoreRangeTableRanged rsetl_rngRadioMPXDeviationLimit = { 0.0, 150000.0, "" };

RsCoreRangeTableRanged rsetl_rngRadioMPXOBWUpperLimit = { 0.0, 500000.0, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTVShoulderGuidelineEntries[3] =
  {
    { RSETL_VAL_DTV_SHOULDER_GUIDELINE_ETSI, "ETSI" },
    { RSETL_VAL_DTV_SHOULDER_GUIDELINE_TRAN, "TRAN" },
    { RSETL_VAL_DTV_SHOULDER_GUIDELINE_EXC, "EXC" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTVShoulderGuideline = { 3, rsetl_rngDTVShoulderGuidelineEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTMBPowerBoostEntries[3] =
  {
    { RSETL_VAL_DTMB_POWER_BOOST_OFF, "OFF" },
    { RSETL_VAL_DTMB_POWER_BOOST_ON, "ON" },
    { RSETL_VAL_DTMB_POWER_BOOST_AUTO, "AUTO" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTMBPowerBoost = { 3, rsetl_rngDTMBPowerBoostEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTMBPowerNormalizationEntries[3] =
  {
    { RSETL_VAL_DTMB_POWER_NORMALIZATION_AUTO, "AUTO" },
    { RSETL_VAL_DTMB_POWER_NORMALIZATION_MAX, "MAX" },
    { RSETL_VAL_DTMB_POWER_NORMALIZATION_RMS, "RMS" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTMBPowerNormalization = { 3, rsetl_rngDTMBPowerNormalizationEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTMBPowerReferenceEntries[2] =
  {
    { RSETL_VAL_DTMB_POWER_REFERENCE_STDC, "STDC" },
    { RSETL_VAL_DTMB_POWER_REFERENCE_QAM4, "QAM4" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTMBPowerReference = { 2, rsetl_rngDTMBPowerReferenceEntries };

static ViReal64 rsetl_rngDTMBESRTimebaseEntries[3] = { 20, 60, 300 };
RsCoreRangeTableCoerced rsetl_rngDTMBESRTimebase = { 3, rsetl_rngDTMBESRTimebaseEntries, "" };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioMPXSamplesEntries[2] =
  {
    { RSETL_VAL_RADIO_MPX_SAMPLES_PKHOLD, "PKH" },
    { RSETL_VAL_RADIO_MPX_SAMPLES_RAW, "RAW" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioMPXSamples = { 2, rsetl_rngRadioMPXSamplesEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngRadioMPXTimeSpanEntries[20] =
  {
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T1MIN, "T1MIN" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T2MIN, "T2MIN" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T5MIN, "T5MIN" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T10MIN, "T10MIN" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T20MIN, "T20MIN" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T30MIN, "T30MIN" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T1H, "T1H" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T2H, "T2H" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T5H, "T5H" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T10H, "T10H" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T1D, "T1D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T2D, "T2D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T5D, "T5D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T10D, "T10D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T20D, "T20D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T50D, "T50D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T100D, "T100D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T200D, "T200D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T500D, "T500D" },
    { RSETL_VAL_RADIO_MPX_TIME_SPAN_T1000D, "T1000D" }
  };
RsCoreRangeTableDiscrete rsetl_rngRadioMPXTimeSpan = { 20, rsetl_rngRadioMPXTimeSpanEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngDTMBBERIndicationEntries[2] =
  {
    { RSETL_VAL_DTMB_BER_INDICATION_BERL, "BERL" },
    { RSETL_VAL_DTMB_BER_INDICATION_BBCH, "BBCH" }
  };
RsCoreRangeTableDiscrete rsetl_rngDTMBBERIndication = { 2, rsetl_rngDTMBBERIndicationEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngIQCarrierTypeEntries[6] =
  {
    { RSETL_VAL_IQ_CARRIER_TYPE_FHON, "FHON" },
    { RSETL_VAL_IQ_CARRIER_TYPE_FHOFF, "FHOF" },
    { RSETL_VAL_IQ_CARRIER_TYPE_SION, "SION" },
    { RSETL_VAL_IQ_CARRIER_TYPE_SIOFF, "SIOF" },
    { RSETL_VAL_IQ_CARRIER_TYPE_DAON, "DAON" },
    { RSETL_VAL_IQ_CARRIER_TYPE_DAOFF, "DAOF" }
  };
RsCoreRangeTableDiscrete rsetl_rngIQCarrierType = { 6, rsetl_rngIQCarrierTypeEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngGPSDeviceEntries[4] =
  {
    { RSETL_VAL_GPS_DEVICE_NONE, "NONE" },
    { RSETL_VAL_GPS_DEVICE_NMEA, "NMEA" },
    { RSETL_VAL_GPS_DEVICE_PPS, "PPS" },
    { RSETL_VAL_GPS_DEVICE_PPS2, "PPS2" }
  };
RsCoreRangeTableDiscrete rsetl_rngGPSDevice = { 4, rsetl_rngGPSDeviceEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngGPSPinDirectionEntries[2] =
  {
    { RSETL_VAL_GPS_PIN_DIRECTION_FORW, "FORW" },
    { RSETL_VAL_GPS_PIN_DIRECTION_BACK, "BACK" }
  };
RsCoreRangeTableDiscrete rsetl_rngGPSPinDirection = { 2, rsetl_rngGPSPinDirectionEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngGPSTSMXCalibrationStatusEntries[5] =
  {
    { RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_INV, "INV" },
    { RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_NONE, "NONE" },
    { RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_ONG, "ONG" },
    { RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_COAR, "COAR" },
    { RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_FINE, "FINE" }
  };
RsCoreRangeTableDiscrete rsetl_rngGPSTSMXCalibrationStatus = { 5, rsetl_rngGPSTSMXCalibrationStatusEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngGPSTSMXStatusEntries[4] =
  {
    { RSETL_VAL_GPS_TSMX_STATUS_INV, "INV" },
    { RSETL_VAL_GPS_TSMX_STATUS_INC, "INC" },
    { RSETL_VAL_GPS_TSMX_STATUS_FAIL, "FAIL" },
    { RSETL_VAL_GPS_TSMX_STATUS_OK, "OK" }
  };
RsCoreRangeTableDiscrete rsetl_rngGPSTSMXStatus = { 4, rsetl_rngGPSTSMXStatusEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngGPSStatusEntries[5] =
  {
    { RSETL_VAL_GPS_STATUS_OFF, "OFF" },
    { RSETL_VAL_GPS_STATUS_NCON, "NCON" },
    { RSETL_VAL_GPS_STATUS_NSAT, "NSAT" },
    { RSETL_VAL_GPS_STATUS_DREC, "DREC" },
    { RSETL_VAL_GPS_STATUS_OK, "OK" }
  };
RsCoreRangeTableDiscrete rsetl_rngGPSStatus = { 5, rsetl_rngGPSStatusEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTSGeneratorWaveformEntries[3] =
  {
    { RSETL_VAL_TSGEN_WAVEFORM_SINE, "SINE" },
    { RSETL_VAL_TSGEN_WAVEFORM_SQU, "SQU" },
    { RSETL_VAL_TSGEN_WAVEFORM_TRI, "TRI" }
  };
RsCoreRangeTableDiscrete rsetl_rngTSGeneratorWaveform = { 3, rsetl_rngTSGeneratorWaveformEntries };

RsCoreRangeTableRanged rsetl_rngTSGeneratorPCRJitterFrequency = { 0.001, 100000.0, "Hz" };

static RsCoreRangeTableDiscreteEntry rsetl_rngTSGeneratorPacketLengthEntries[3] =
  {
    { RSETL_VAL_TSGEN_PACKET_LENGTH_P188, "P188" },
    { RSETL_VAL_TSGEN_PACKET_LENGTH_P204, "P204" },
    { RSETL_VAL_TSGEN_PACKET_LENGTH_P208, "P208" }
  };
RsCoreRangeTableDiscrete rsetl_rngTSGeneratorPacketLength = { 3, rsetl_rngTSGeneratorPacketLengthEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTSGeneratorSerialOutputEntries[3] =
  {
    { RSETL_VAL_TSGEN_SERIAL_OUTPUT_ASIB, "ASIB" },
    { RSETL_VAL_TSGEN_SERIAL_OUTPUT_ASIC, "ASIC" },
    { RSETL_VAL_TSGEN_SERIAL_OUTPUT_SMPT, "SMPT" }
  };
RsCoreRangeTableDiscrete rsetl_rngTSGeneratorSerialOutput = { 3, rsetl_rngTSGeneratorSerialOutputEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTSRecorderInputEntries[4] =
  {
    { RSETL_VAL_TSREC_INPUT_ASII, "ASII" },
    { RSETL_VAL_TSREC_INPUT_ASIE, "ASIE" },
    { RSETL_VAL_TSREC_INPUT_SMPT, "SMPT" },
    { RSETL_VAL_TSREC_INPUT_OFF, "OFF" }
  };
RsCoreRangeTableDiscrete rsetl_rngTSRecorderInput = { 4, rsetl_rngTSRecorderInputEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTSGeneratorRecorderStatusEntries[4] =
  {
    { RSETL_VAL_TSGEN_REC_STATUS_STOP, "STOP" },
    { RSETL_VAL_TSGEN_REC_STATUS_PLAY, "PLAY" },
    { RSETL_VAL_TSGEN_REC_STATUS_PAUSE, "PAUS" },
    { RSETL_VAL_TSGEN_REC_STATUS_RECORD, "REC" }
  };
RsCoreRangeTableDiscrete rsetl_rngTSGeneratorRecorderStatus = { 4, rsetl_rngTSGeneratorRecorderStatusEntries };

static RsCoreRangeTableDiscreteEntry rsetl_rngTSGeneratorRecorderModeEntries[2] =
  {
    { RSETL_VAL_TSGEN_REC_MODE_GENERATOR, "PLAY" },
    { RSETL_VAL_TSGEN_REC_MODE_RECORDER, "REC" }
  };
RsCoreRangeTableDiscrete rsetl_rngTSGeneratorRecorderMode = { 2, rsetl_rngTSGeneratorRecorderModeEntries };


/*****************************************************************************
 *- Attributes --------------------------------------------------------------*
 *****************************************************************************/

RsCoreAttribute  g_RSETL_RS_ATTR_RANGE_CHECK =
  {
    RS_ATTR_RANGE_CHECK,
    "Range Check",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_QUERY_INSTRUMENT_STATUS =
  {
    RS_ATTR_QUERY_INSTRUMENT_STATUS,
    "Query Instrument Status",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SIMULATE =
  {
    RS_ATTR_SIMULATE,
    "Simulate",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_DESCRIPTION =
  {
    RS_ATTR_SPECIFIC_DRIVER_DESCRIPTION,
    "Driver Description",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_PREFIX =
  {
    RS_ATTR_SPECIFIC_DRIVER_PREFIX,
    "Driver Prefix",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_LOCATOR =
  {
    RS_ATTR_SPECIFIC_DRIVER_LOCATOR,
    "Driver Locator",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_VENDOR =
  {
    RS_ATTR_SPECIFIC_DRIVER_VENDOR,
    "Driver Vendor",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_REVISION =
  {
    RS_ATTR_SPECIFIC_DRIVER_REVISION,
    "Driver Revision",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MAJOR_VERSION =
  {
    RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MAJOR_VERSION,
    "Class Specification Major Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MINOR_VERSION =
  {
    RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MINOR_VERSION,
    "Class Specification Minor Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SUPPORTED_INSTRUMENT_MODELS =
  {
    RS_ATTR_SUPPORTED_INSTRUMENT_MODELS,
    "Supported Instrument Models",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_GROUP_CAPABILITIES =
  {
    RS_ATTR_GROUP_CAPABILITIES,
    "Class Group Capabilities",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_FUNCTION_CAPABILITIES =
  {
    RS_ATTR_FUNCTION_CAPABILITIES,
    "Function Capabilities",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_CHANNEL_COUNT =
  {
    RS_ATTR_CHANNEL_COUNT,
    "Channel Count",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_DRIVER_SETUP =
  {
    RS_ATTR_DRIVER_SETUP,
    "Driver Setup",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_INSTRUMENT_MANUFACTURER =
  {
    RS_ATTR_INSTRUMENT_MANUFACTURER,
    "Instrument Manufacturer",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "Rohde&Schwarz",
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_INSTRUMENT_MODEL =
  {
    RS_ATTR_INSTRUMENT_MODEL,
    "Instrument Model",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_INSTRUMENT_FIRMWARE_REVISION =
  {
    RS_ATTR_INSTRUMENT_FIRMWARE_REVISION,
    "Instrument Firmware Revision",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_OPTIONS_LIST =
  {
    RS_ATTR_OPTIONS_LIST,
    "Options List",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_IO_RESOURCE_DESCRIPTOR =
  {
    RS_ATTR_IO_RESOURCE_DESCRIPTOR,
    "Resource Descriptor",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_LOGICAL_NAME =
  {
    RS_ATTR_LOGICAL_NAME,
    "Logical Name",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_PRIMARY_ERROR =
  {
    RS_ATTR_PRIMARY_ERROR,
    "Primary Error",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SECONDARY_ERROR =
  {
    RS_ATTR_SECONDARY_ERROR,
    "Secondary Error",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_ERROR_ELABORATION =
  {
    RS_ATTR_ERROR_ELABORATION,
    "Error Elaboration",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_MAJOR_VERSION =
  {
    RS_ATTR_SPECIFIC_DRIVER_MAJOR_VERSION,
    "Driver Major Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_MINOR_VERSION =
  {
    RS_ATTR_SPECIFIC_DRIVER_MINOR_VERSION,
    "Driver Minor Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_SPECIFIC_DRIVER_MINOR_MINOR_VERSION =
  {
    RS_ATTR_SPECIFIC_DRIVER_MINOR_MINOR_VERSION,
    "Driver Minor Minor Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_CLASS_DRIVER_MAJOR_VERSION =
  {
    RS_ATTR_CLASS_DRIVER_MAJOR_VERSION,
    "Class Major Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_CLASS_DRIVER_MINOR_VERSION =
  {
    RS_ATTR_CLASS_DRIVER_MINOR_VERSION,
    "Class Minor Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_ENGINE_MAJOR_VERSION =
  {
    RS_ATTR_ENGINE_MAJOR_VERSION,
    "Engine Major Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_ENGINE_MINOR_VERSION =
  {
    RS_ATTR_ENGINE_MINOR_VERSION,
    "Engine Minor Version",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_ENGINE_REVISION =
  {
    RS_ATTR_ENGINE_REVISION,
    "Engine Revision",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_RS_ATTR_OPC_TIMEOUT =
  {
    RS_ATTR_OPC_TIMEOUT,
    "Operation Complete (OPC) Timeout",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    NULL, // No command
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_AMPLITUDE_UNITS =
  {
    RSETL_ATTR_AMPLITUDE_UNITS,
    "Amplitude Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAmplitudeUnitsRangeTable, NULL, NULL,
    "UNIT:POW",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_AMPLITUDE_UNITS_DBM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INSTR_MODE =
  {
    RSETL_ATTR_INSTR_MODE,
    "Instrument Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngInstrMode, NULL, NULL,
    "INST:SEL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ATTENUATION =
  {
    RSETL_ATTR_ATTENUATION,
    "Attenuation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, &rsetl_rngAttenuationRangeTable,
    "INP:ATT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ATTENUATION_AUTO =
  {
    RSETL_ATTR_ATTENUATION_AUTO,
    "Attenuation Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:ATT:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_START =
  {
    RSETL_ATTR_FREQUENCY_START,
    "Frequency Start",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:FREQ:STAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_STOP =
  {
    RSETL_ATTR_FREQUENCY_STOP,
    "Frequency Stop",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:FREQ:STOP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3.0e9,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_OFFSET =
  {
    RSETL_ATTR_FREQUENCY_OFFSET,
    "Frequency Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngFreqOffset, NULL,
    "SENS:FREQ:OFFS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_CENTER =
  {
    RSETL_ATTR_FREQUENCY_CENTER,
    "Center Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:FREQ:CENT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.5E+9,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_CENTER_STEP =
  {
    RSETL_ATTR_FREQUENCY_CENTER_STEP,
    "Center Frequency Step",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:FREQ:CENT:STEP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_STEP_AUTO =
  {
    RSETL_ATTR_FREQUENCY_STEP_AUTO,
    "Center Frequency Step Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:FREQ:CENT:STEP:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_CENTER_LINK =
  {
    RSETL_ATTR_FREQUENCY_CENTER_LINK,
    "Center Frequency Coupling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngFreqCentLink, NULL, NULL,
    "SENS:FREQ:CENT:STEP:LINK",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CENT_FREQ_LINK_SPAN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_CENTER_LINK_FACTOR =
  {
    RSETL_ATTR_FREQUENCY_CENTER_LINK_FACTOR,
    "Center Frequency Coupling Factor",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngLinkFactor, NULL,
    "SENS:FREQ:CENT:STEP:LINK:FACT",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_SPAN =
  {
    RSETL_ATTR_FREQUENCY_SPAN,
    "Frequency Span",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:FREQ:SPAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.5E+9,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_SPAN_FULL =
  {
    RSETL_ATTR_FREQUENCY_SPAN_FULL,
    "Full Frequency Span",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SENS:FREQ:SPAN:FULL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FREQUENCY_MODE =
  {
    RSETL_ATTR_FREQUENCY_MODE,
    "Frequency Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngFreqMode, NULL, NULL,
    "SENS:FREQ:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_FREQ_MODE_SWE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INPUT_IMPEDANCE =
  {
    RSETL_ATTR_INPUT_IMPEDANCE,
    "Input Impedance",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, &rsetl_rngInputImpedance,
    "INP:IMP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    50.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INPUT_IQ_STATE =
  {
    RSETL_ATTR_INPUT_IQ_STATE,
    "Input IQ State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:SEL:IQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B201",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_NUMBER_OF_SWEEPS =
  {
    RSETL_ATTR_NUMBER_OF_SWEEPS,
    "Number of Sweeps",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngSweepCount, NULL,
    "SENS:SWE:COUN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_LEVEL =
  {
    RSETL_ATTR_REFERENCE_LEVEL,
    "Reference Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:Y:RLEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -20.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_LEVEL_OFFSET =
  {
    RSETL_ATTR_REFERENCE_LEVEL_OFFSET,
    "Reference Level Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "DISP:WIND:TRAC:Y:RLEV:OFFS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RESOLUTION_BANDWIDTH =
  {
    RSETL_ATTR_RESOLUTION_BANDWIDTH,
    "Resolution Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRBW, NULL,
    "SENS:BAND",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0E+6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RESOLUTION_BANDWIDTH_AUTO =
  {
    RSETL_ATTR_RESOLUTION_BANDWIDTH_AUTO,
    "Resolution Bandwidth Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:BAND:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RESOLUTION_BANDWIDTH_RATIO =
  {
    RSETL_ATTR_RESOLUTION_BANDWIDTH_RATIO,
    "Resolution Bandwidth Ratio",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngBandRatio, NULL,
    "SENS:BAND:RAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.02,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SWEEP_MODE_CONTINUOUS =
  {
    RSETL_ATTR_SWEEP_MODE_CONTINUOUS,
    "Sweep Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INIT:CONT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SWEEP_TIME =
  {
    RSETL_ATTR_SWEEP_TIME,
    "Sweep Time",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngSweepTime, NULL,
    "SENS:SWE:TIME",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    5.0E-3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SWEEP_TIME_AUTO =
  {
    RSETL_ATTR_SWEEP_TIME_AUTO,
    "Sweep Time Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:SWE:TIME:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SWEEP_POINTS =
  {
    RSETL_ATTR_SWEEP_POINTS,
    "Sweep Points",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngSwePoints, NULL,
    "SENS:SWE:POIN",
    // Defaults I32, I64, Float, Bool, String
    501,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SWEEP_COUNT_CURRENT =
  {
    RSETL_ATTR_SWEEP_COUNT_CURRENT,
    "Get Sweep Count Current",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SENS:SWE:COUN:CURR?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_VERTICAL_SCALE =
  {
    RSETL_ATTR_VERTICAL_SCALE,
    "Vertical Scale",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTraceSpacing, NULL, NULL,
    "DISP:WIND:TRAC:Y:SPAC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TRACE_SPACE_LOG,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_VIDEO_BANDWIDTH =
  {
    RSETL_ATTR_VIDEO_BANDWIDTH,
    "Video Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngVBW, NULL,
    "SENS:BAND:VID",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0E+6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_VIDEO_BANDWIDTH_AUTO =
  {
    RSETL_ATTR_VIDEO_BANDWIDTH_AUTO,
    "Video Bandwidth Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:BAND:VID:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_VIDEO_BANDWIDTH_RATIO =
  {
    RSETL_ATTR_VIDEO_BANDWIDTH_RATIO,
    "Video Bandwidth Ratio",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngVbwRatio, NULL,
    "SENS:BAND:VID:RAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_ABORT =
  {
    RSETL_ATTR_MEAS_ABORT,
    "Abort",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "ABOR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INIT =
  {
    RSETL_ATTR_INIT,
    "Initiate",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "INIT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INIT_CONT =
  {
    RSETL_ATTR_INIT_CONT,
    "Initiate Continuous",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INIT:CONT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INIT_SW_TRIGGER =
  {
    RSETL_ATTR_INIT_SW_TRIGGER,
    "Send Software Trigger",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "*TRG",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INIT_CONMEAS =
  {
    RSETL_ATTR_INIT_CONMEAS,
    "Continue Measurement",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "INIT:CONM;*WAI",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_AVG_STATE =
  {
    RSETL_ATTR_AVG_STATE,
    "Averaging State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:AVER:STAT{Trace}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_AVG_TYPE =
  {
    RSETL_ATTR_AVG_TYPE,
    "Averaging Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAvgType, NULL, NULL,
    "SENS:AVER:TYPE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_AVG_LIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_AVG_COUNT =
  {
    RSETL_ATTR_AVG_COUNT,
    "Averaging Count",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngAvgCount, NULL,
    "SENS:AVER:COUN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_AVG_COUNT_AUTO =
  {
    RSETL_ATTR_AVG_COUNT_AUTO,
    "Averaging Count Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:AVER:COUN:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RESOLUTION_BANDWIDTH_FILTER_TYPE =
  {
    RSETL_ATTR_RESOLUTION_BANDWIDTH_FILTER_TYPE,
    "Resolution Bandwidth Filter Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngBandFiltType, NULL, NULL,
    "SENS:BAND:TYPE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_FILT_TYPE_NORM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_VIDEO_BANDWIDTH_TYPE =
  {
    RSETL_ATTR_VIDEO_BANDWIDTH_TYPE,
    "Video Bandwidth Filter Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngLinLog, NULL, NULL,
    "SENS:BAND:VID:TYPE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_VBW_FILT_LIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACE_STATE =
  {
    RSETL_ATTR_TRACE_STATE,
    "Trace State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:TRACE{Trace}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACE_RESET_BEHAVIOR =
  {
    RSETL_ATTR_TRACE_RESET_BEHAVIOR,
    "Trace Reset Behavior",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC{Trace}:MODE:HCON",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACE_TYPE =
  {
    RSETL_ATTR_TRACE_TYPE,
    "Trace Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTraceMode, NULL, NULL,
    "DISP:WIND:TRAC{Trace}:MODe",
    // Defaults I32, I64, Float, Bool, String
    RSETL_TRAC_MOD_WRITE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACE_MATH_STATE =
  {
    RSETL_ATTR_TRACE_MATH_STATE,
    "Trace Math State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MATH:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACE_MATH_POSITION =
  {
    RSETL_ATTR_TRACE_MATH_POSITION,
    "Trace Math Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngTraceMathPosition, NULL,
    "CALC:MATH:POS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    50.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DETECTOR_TYPE =
  {
    RSETL_ATTR_DETECTOR_TYPE,
    "Detector Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDetectorTypeRangeTable, NULL, NULL,
    "SENS:DET{Trace}:FUNC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DETECTOR_TYPE_AUTO_PEAK,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DETECTOR_TYPE_AUTO =
  {
    RSETL_ATTR_DETECTOR_TYPE_AUTO,
    "Detector Type Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DET{Trace}:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CALIBRATION_CHECK =
  {
    RSETL_ATTR_CALIBRATION_CHECK,
    "Calibration Check",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, &rsetl_rngCalibration, NULL,
    "*CLS;CAL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CALIBRATION =
  {
    RSETL_ATTR_CALIBRATION,
    "Calibration Start",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "*CLS;CAL ALL;*OPC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_DONT_CHECK_STATUS,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CALIBRATION_ABORT =
  {
    RSETL_ATTR_CALIBRATION_ABORT,
    "Calibration Abort",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CAL:ABOR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CALIBRATION_RESULT_QUERY =
  {
    RSETL_ATTR_CALIBRATION_RESULT_QUERY,
    "Calibration Result Query",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CAL:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CALIBRATION_STATE =
  {
    RSETL_ATTR_CALIBRATION_STATE,
    "Calibration State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CAL:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INP_UPORT_STATE =
  {
    RSETL_ATTR_INP_UPORT_STATE,
    "User Ports State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:UPOR:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_INP_UPORT_VALUE =
  {
    RSETL_ATTR_INP_UPORT_VALUE,
    "User Ports Control Lines",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "INP:UPOR?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "val",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_stringToBin_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_OUT_UPORT_VALUE =
  {
    RSETL_ATTR_OUT_UPORT_VALUE,
    "User Ports Output Control Lines",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "OUTP:UPOR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "165",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_stringToBin_ReadCallback,
    rsetl_stringToBin_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_REF_VALUE =
  {
    RSETL_ATTR_DISP_REF_VALUE,
    "Display Reference Value",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:Y:RVAL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_COUP_REF_LEV =
  {
    RSETL_ATTR_DISP_COUP_REF_LEV,
    "Display Coupled Reference Level",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:Y:SCAL:RVAL:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_REF_POSITION =
  {
    RSETL_ATTR_DISP_REF_POSITION,
    "Display Reference Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPct, NULL,
    "DISP:WIND:TRAC:Y:RPOS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_FREQ_STATE =
  {
    RSETL_ATTR_DISP_FREQ_STATE,
    "Display Frequency State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:ANN:FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_TIME_STATE =
  {
    RSETL_ATTR_DISP_TIME_STATE,
    "Display Time State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:TIME",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_LOGO =
  {
    RSETL_ATTR_DISP_LOGO,
    "Display Logo",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:LOGO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_COMMENT_STATE =
  {
    RSETL_ATTR_DISP_COMMENT_STATE,
    "Display Comment State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:TEXT:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_COMMENT =
  {
    RSETL_ATTR_DISP_COMMENT,
    "Display Comment",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "DISP:WIND:TEXT:DATA",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_PWR_SAVE_STATE =
  {
    RSETL_ATTR_DISP_PWR_SAVE_STATE,
    "Display Power Save State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:PSAV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_PWR_SAVE_HOLDOFF =
  {
    RSETL_ATTR_DISP_PWR_SAVE_HOLDOFF,
    "Display Power Save Holdoff",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngDISPConfPowSave, NULL,
    "DISP:PSAV:HOLD",
    // Defaults I32, I64, Float, Bool, String
    15,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_WINDOW_SIZE =
  {
    RSETL_ATTR_DISP_WINDOW_SIZE,
    "Display Window Size",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDISPSizeWindow, NULL, NULL,
    "DISP:SIZE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DISP_SIZE_SMALL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_COL_PRESET =
  {
    RSETL_ATTR_DISP_COL_PRESET,
    "Display Color Preset",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "DISP:CMAP:DEF{Default}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_COL_PREDEFINED =
  {
    RSETL_ATTR_DISP_COL_PREDEFINED,
    "Display Color Predefined",
    RS_VAL_WRITE_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDISPConfPreDefColour, NULL, NULL,
    "DISP:CMAP{CMAP}:PDEF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_LOG_RANGE =
  {
    RSETL_ATTR_DISP_LOG_RANGE,
    "Display Log Range",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDISPAmplitudeRang, NULL,
    "DISP:WIND:TRAC:Y",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_AMPLITUDE_GRID_MODE =
  {
    RSETL_ATTR_DISP_AMPLITUDE_GRID_MODE,
    "Display Amplitude Grid Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAbsRel, NULL, NULL,
    "DISP:WIND:TRAC:Y:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ABS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_SINGLE_SWEEP =
  {
    RSETL_ATTR_DISP_SINGLE_SWEEP,
    "Display During Single Sweep",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INIT:DISP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_UPDATE =
  {
    RSETL_ATTR_DISP_UPDATE,
    "Display Update",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SYST:DISP:UPD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_FP_KEYS =
  {
    RSETL_ATTR_DISP_FP_KEYS,
    "Display Front Panel Keys",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SYST:DISP:FPAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_UNIT_POWER =
  {
    RSETL_ATTR_UNIT_POWER,
    "Configure Display Unit Power",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAmplitudeUnitsRangeTable, NULL, NULL,
    "CALC:UNIT:POW",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_AMPLITUDE_UNITS_DBM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_CHANNEL_IMPULSE_RESPONSE =
  {
    RSETL_ATTR_DISP_CHANNEL_IMPULSE_RESPONSE,
    "Display Channel Impulse Response",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDispChanImpulseResponse, NULL, NULL,
    "DISP:WIND:TRAC:Y:SCAL:ZPOS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DISP_CHAN_IMP_RES_MLEV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_MER_VS_FREQ =
  {
    RSETL_ATTR_DISP_MER_VS_FREQ,
    "Display MER vs Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:Y:SCAL:MER:INV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISPL_SET_TO_FOREGROUND =
  {
    RSETL_ATTR_DISPL_SET_TO_FOREGROUND,
    "Display Set To Foreground",
    RS_VAL_WRITE_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDispWindowMode, NULL, NULL,
    "DISP:DEV:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DISP_MODE_ETF,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_MER_PHASE_REFERENCE_POSITION =
  {
    RSETL_ATTR_DISP_MER_PHASE_REFERENCE_POSITION,
    "Display MER Phase Reference Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDispRefPos, NULL,
    "DISP:TRAC:Y:DTV:MPN:RPOS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_MER_PHASE_REFERENCE_DEVIATION =
  {
    RSETL_ATTR_DISP_MER_PHASE_REFERENCE_DEVIATION,
    "Display MER Phase Reference Deviation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDispRefDev, NULL,
    "DISP:TRAC:Y:DTV:MPN:RDEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_MER_PHASE_DEVIATION_SCALING =
  {
    RSETL_ATTR_DISP_MER_PHASE_DEVIATION_SCALING,
    "Display MER Phase Deviation Scaling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTraceScaling, NULL, NULL,
    "DISP:TRAC:Y:DTV:MPN:SPAC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TRACE_SPACE_LOG,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_MER_PHASE_DEVIATION_RANGE =
  {
    RSETL_ATTR_DISP_MER_PHASE_DEVIATION_RANGE,
    "Display MER Phase Deviation Range",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDispMerRange, NULL,
    "DISP:TRAC:Y:DTV:MPN:DRAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_GPS_POSITION =
  {
    RSETL_ATTR_DISP_GPS_POSITION,
    "Display GPS Position",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:MEAS:OVER:GPS:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_PEAK_LIST =
  {
    RSETL_ATTR_DISP_PEAK_LIST,
    "Display Peak List",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:LIST:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_DIAGRAM_FULL_SIZE =
  {
    RSETL_ATTR_DISP_DIAGRAM_FULL_SIZE,
    "Display Diagram Full Size",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:DIAG:FULL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DISP_MISO =
  {
    RSETL_ATTR_DISP_MISO,
    "Display MISO",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDisplayMISO, NULL, NULL,
    "DISP:WIND:MEAS:EPAT:MIS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_MISO_DISPLAY_GRPS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TFAC_SEL_NAME =
  {
    RSETL_ATTR_TFAC_SEL_NAME,
    "Transducer Factor Select Name",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SENS:CORR:TRAN:SEL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TFAC_UNIT =
  {
    RSETL_ATTR_TFAC_UNIT,
    "Transducer Factor Unit",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTFacUnit, NULL, NULL,
    "SENS:CORR:TRAN:UNIT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TFAC_UNIT_DB,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedInt_ReadCallback,
    rsetl_quotedInt_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TFAC_SCALING =
  {
    RSETL_ATTR_TFAC_SCALING,
    "Transducer Factor Scaling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTLinLog, NULL, NULL,
    "SENS:CORR:TRAN:SCAL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_LIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TFAC_COMMENT =
  {
    RSETL_ATTR_TFAC_COMMENT,
    "Transducer Factor Comment",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SENS:CORR:TRAN:COMM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "Default comment",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TFAC_STATE =
  {
    RSETL_ATTR_TFAC_STATE,
    "Transducer Factor State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:CORR:TRAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TFAC_DELETE =
  {
    RSETL_ATTR_TFAC_DELETE,
    "Transducer Factor Delete",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SENS:CORR:TRAN:DEL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TFAC_DISPLAY =
  {
    RSETL_ATTR_TFAC_DISPLAY,
    "Transducer Factor Display",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:CORR:TRAN:VIEW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TFAC_ADJ_STATE =
  {
    RSETL_ATTR_TFAC_ADJ_STATE,
    "Transducer Factor Automatic Adjustment State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:CORR:TRAN:ADJ:RLEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_AMPLITUDE =
  {
    RSETL_ATTR_MARKER_AMPLITUDE,
    "Marker Amplitude",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:Y?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_ENABLED =
  {
    RSETL_ATTR_MARKER_ENABLED,
    "Marker State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_POSITION =
  {
    RSETL_ATTR_MARKER_POSITION,
    "Marker Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:X",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_TRACE =
  {
    RSETL_ATTR_MARKER_TRACE,
    "Assign Marker to Trace",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngTrace, NULL,
    "CALC:MARK{Marker}:TRAC",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_AOFF =
  {
    RSETL_ATTR_MARKER_AOFF,
    "All Markers Off",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK:AOFF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_LOEX =
  {
    RSETL_ATTR_MARKER_LOEX,
    "Marker Local Oscillator Suppression",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:LOEX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SIGNAL_TRACK_ENABLED =
  {
    RSETL_ATTR_SIGNAL_TRACK_ENABLED,
    "Signal Track State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:STR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SIGNAL_TRACK_BWID =
  {
    RSETL_ATTR_SIGNAL_TRACK_BWID,
    "Signal Track Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:STR:BWID",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    250.0e+6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SIGNAL_TRACK_THRESHOLD =
  {
    RSETL_ATTR_SIGNAL_TRACK_THRESHOLD,
    "Signal Track Threshold",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngSignalTrackThreshold, NULL,
    "CALC:MARK:FUNC:STR:THR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -120.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SIGNAL_TRACK_TRACE =
  {
    RSETL_ATTR_SIGNAL_TRACK_TRACE,
    "Signal Track Trace",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngTrace, NULL,
    "CALC:MARK:FUNC:STR:TRAC",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_STEP_SIZE =
  {
    RSETL_ATTR_MARKER_STEP_SIZE,
    "Marker Step Size",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngMarkerStepSize, NULL, NULL,
    "CALC:MARK:X:SSIZ",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_MARK_STEP_SIZE_STAN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_PROBABILITY =
  {
    RSETL_ATTR_MARKER_PROBABILITY,
    "Marker Probability",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPct, NULL,
    "CALC:MARK{Marker}:Y:PERC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_RADIO_PROBABILITY =
  {
    RSETL_ATTR_MARKER_RADIO_PROBABILITY,
    "Marker Radio Probability",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPct, NULL,
    "CALC:MARK{Marker}:Y:PERP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_RADIO_PROBABILITY_VALUE =
  {
    RSETL_ATTR_MARKER_RADIO_PROBABILITY_VALUE,
    "Marker Radio Probability Value",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMarkerRadioProbabilityValue, NULL,
    "CALC:MARK{Marker}:Y:PERV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.000001,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_RADIO_DEVIATION =
  {
    RSETL_ATTR_MARKER_RADIO_DEVIATION,
    "Marker Radio Deviation",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:X:PERD?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_MIN_RIGHT =
  {
    RSETL_ATTR_MARKER_SEARCH_MIN_RIGHT,
    "Marker Search Right Minimum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:MIN:RIGH",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_MIN_LEFT =
  {
    RSETL_ATTR_MARKER_SEARCH_MIN_LEFT,
    "Marker Search Left Minimum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:MIN:LEFT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_PEAK =
  {
    RSETL_ATTR_MARKER_SEARCH_PEAK,
    "Marker Search Peak Maximum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:MAX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_PEAK_NEXT =
  {
    RSETL_ATTR_MARKER_SEARCH_PEAK_NEXT,
    "Marker Search Peak Next Maximum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:MAX:NEXT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_PEAK_RIGHT =
  {
    RSETL_ATTR_MARKER_SEARCH_PEAK_RIGHT,
    "Marker Search Peak Right Maximum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:MAX:RIGH",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_PEAK_LEFT =
  {
    RSETL_ATTR_MARKER_SEARCH_PEAK_LEFT,
    "Marker Search Peak Left Maximum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:MAX:LEFT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_MIN =
  {
    RSETL_ATTR_MARKER_SEARCH_MIN,
    "Marker Search Peak Minimum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:MIN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_MIN_NEXT =
  {
    RSETL_ATTR_MARKER_SEARCH_MIN_NEXT,
    "Marker Search Next Minimum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:MIN:NEXT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_PEAK_AUTO =
  {
    RSETL_ATTR_MARKER_SEARCH_PEAK_AUTO,
    "Marker Search Peak Maximum Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:MAX:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_MIN_AUTO =
  {
    RSETL_ATTR_MARKER_SEARCH_MIN_AUTO,
    "Marker Search Minimum Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:MIN:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_THRESHOLD_STATE =
  {
    RSETL_ATTR_MARKER_THRESHOLD_STATE,
    "Marker Threshold State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:THR:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_THRESHOLD =
  {
    RSETL_ATTR_MARKER_THRESHOLD,
    "Marker Threshold",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:THR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PEAK_EXCURSION =
  {
    RSETL_ATTR_PEAK_EXCURSION,
    "Marker Peak Excursion",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:PEXC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_LIMITS_STATE =
  {
    RSETL_ATTR_MARKER_SEARCH_LIMITS_STATE,
    "Marker Search Limits State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:X:SLIM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_LIMITS_LEFT =
  {
    RSETL_ATTR_MARKER_SEARCH_LIMITS_LEFT,
    "Marker Search Limits Left",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:X:SLIM:LEFT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_SEARCH_LIMITS_RIGHT =
  {
    RSETL_ATTR_MARKER_SEARCH_LIMITS_RIGHT,
    "Marker Search Limits Right",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:X:SLIM:RIGHT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_PEAK_LIST_COUNT =
  {
    RSETL_ATTR_MARKER_PEAK_LIST_COUNT,
    "Marker Peak List Count",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngMarkerPeakListCount, NULL,
    "CALC:MARK{Marker}:FUNC:FPE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_PEAK_LIST_FOUND =
  {
    RSETL_ATTR_MARKER_PEAK_LIST_FOUND,
    "Marker Peak List Found",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:FUNC:FPE:COUN?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_PEAK_LIST_SORT =
  {
    RSETL_ATTR_MARKER_PEAK_LIST_SORT,
    "Marker Peak List Sort",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngMarkerPeakListSort, NULL, NULL,
    "CALC:MARK{Marker}:FUNC:FPE:SORT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_MARKER_SORT_X,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_ZOOM =
  {
    RSETL_ATTR_MARKER_ZOOM,
    "Marker Zoom",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:ZOOM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_DEMOD_STATE =
  {
    RSETL_ATTR_MARKER_DEMOD_STATE,
    "Marker Demodulation State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:FUNC:DEM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_DEMOD_TYPE =
  {
    RSETL_ATTR_MARKER_DEMOD_TYPE,
    "Marker Demodulation Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngMarkerDemodType, NULL, NULL,
    "CALC:MARK:FUNC:DEM:SEL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_MARKER_DEMOD_AM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_DEMOD_HOLDOFF =
  {
    RSETL_ATTR_MARKER_DEMOD_HOLDOFF,
    "Marker Demodulation Holdoff",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMarkerDemodHoldoff, NULL,
    "CALC:MARK:FUNC:DEM:HOLD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0e-3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_DEMOD_CONT =
  {
    RSETL_ATTR_MARKER_DEMOD_CONT,
    "Marker Demodulation Continuous",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:DEM:CONT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_TO_CENTER =
  {
    RSETL_ATTR_MARKER_TO_CENTER,
    "Marker To Center",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:FUNC:CENT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_TO_STEP =
  {
    RSETL_ATTR_MARKER_TO_STEP,
    "Marker To Step Width",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:FUNC:CST",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_TO_REFERENCE =
  {
    RSETL_ATTR_MARKER_TO_REFERENCE,
    "Marker To Reference",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:FUNC:REF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_REF_STATE =
  {
    RSETL_ATTR_MARKER_REF_STATE,
    "Marker Fixed Reference State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DELT:FUNC:FIX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_REF_LEVEL =
  {
    RSETL_ATTR_MARKER_REF_LEVEL,
    "Marker Fixed Ref Point Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "CALC:DELT:FUNC:FIX:RPO:Y",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_REF_LEVEL_OFFSET =
  {
    RSETL_ATTR_MARKER_REF_LEVEL_OFFSET,
    "Marker Fixed Ref Point Level Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevelOffset, NULL,
    "CALC:DELT:FUNC:FIX:RPO:Y:OFFS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_REF_FREQ =
  {
    RSETL_ATTR_MARKER_REF_FREQ,
    "Marker Fixed Ref Point Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DELT:FUNC:FIX:RPO:X",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_REF_PEAK =
  {
    RSETL_ATTR_MARKER_REF_PEAK,
    "Marker Fixed Ref Point Peak Search",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT:FUNC:FIX:RPO:MAX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_STATE =
  {
    RSETL_ATTR_REFERENCE_MARKER_STATE,
    "Delta Marker State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_MODE =
  {
    RSETL_ATTR_REFERENCE_MARKER_MODE,
    "Delta Marker Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAbsRel, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_REL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_POSITION =
  {
    RSETL_ATTR_REFERENCE_MARKER_POSITION,
    "Delta Marker Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:X",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_REL_POSITION =
  {
    RSETL_ATTR_REFERENCE_MARKER_REL_POSITION,
    "Delta Marker Relative Position",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:X:REL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_AMPLITUDE =
  {
    RSETL_ATTR_REFERENCE_MARKER_AMPLITUDE,
    "Delta Marker Amplitude",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:Y?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_TRACE =
  {
    RSETL_ATTR_REFERENCE_MARKER_TRACE,
    "Delta Marker Assign Trace",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngTrace, NULL,
    "CALC:DELT{DeltaMarker}:TRAC",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_AOFF =
  {
    RSETL_ATTR_REFERENCE_MARKER_AOFF,
    "Delta Marker All Off",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT:AOFF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_PEAK =
  {
    RSETL_ATTR_REFERENCE_MARKER_PEAK,
    "Delta Marker Peak",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MAX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT =
  {
    RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT,
    "Delta Marker Peak Next",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MAX:NEXT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_RIGHT =
  {
    RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_RIGHT,
    "Delta Marker Peak Next Right",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MAX:RIGH",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_LEFT =
  {
    RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_LEFT,
    "Delta Marker Peak Next Left",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MAXimum:LEFT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_MIN =
  {
    RSETL_ATTR_REFERENCE_MARKER_MIN,
    "Delta Marker Minimum",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MIN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT =
  {
    RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT,
    "Delta Marker Minimum Next",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MIN:NEXT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_RIGHT =
  {
    RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_RIGHT,
    "Delta Marker Minimum Next Right",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MIN:RIGH",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_LEFT =
  {
    RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_LEFT,
    "Delta Marker Minimum Next Left",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:DELT{DeltaMarker}:MIN:LEFT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_STATE =
  {
    RSETL_LIMIT_STATE,
    "Limit Check State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:LIM{Limit}:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_CLEAR =
  {
    RSETL_LIMIT_CLEAR,
    "Limit Check Clear",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:LIM{Limit}:CLE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_ASSIGN_TRACE =
  {
    RSETL_LIMIT_ASSIGN_TRACE,
    "Limit Line Assign Trace",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngTrace, NULL,
    "CALC:LIM{Limit}:TRAC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_UNITS =
  {
    RSETL_LIMIT_UNITS,
    "Limit Line Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngUnits, NULL, NULL,
    "CALC:LIM{Limit}:UNIT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_COMMENT =
  {
    RSETL_LIMIT_COMMENT,
    "Limit Line Comment",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:LIM{Limit}:COMM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_COPY =
  {
    RSETL_LIMIT_COPY,
    "Limit Line Copy",
    RS_VAL_WRITE_ONLY,
    RS_VAL_INT32,
    NULL, &rsetl_rngLimits, NULL,
    "CALC:LIM{Limit}:COPY",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_NAME =
  {
    RSETL_LIMIT_NAME,
    "Limit Line Name",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:LIM{Limit}:NAME",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_DELETE =
  {
    RSETL_LIMIT_DELETE,
    "Limit Line Delete",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:LIM{Limit}:DELete",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_CONTROL_DOMAIN =
  {
    RSETL_LIMIT_CONTROL_DOMAIN,
    "Limit Line Control Domain",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDomain, NULL, NULL,
    "CALC:LIM{Limit}:CONT:DOM",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_FREQ,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_CONTROL_SPACING =
  {
    RSETL_LIMIT_CONTROL_SPACING,
    "Limit Line Control Spacing",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngLinLog, NULL, NULL,
    "CALC:LIM{Limit}:CONT:SPAC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_VBW_FILT_LIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_CONTROL_SCALING =
  {
    RSETL_LIMIT_CONTROL_SCALING,
    "Limit Line Control Scaling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAbsRel, NULL, NULL,
    "CALC:LIM{Limit}:CONT:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ABS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_CONTROL_OFFSET =
  {
    RSETL_LIMIT_CONTROL_OFFSET,
    "Limit Line Control Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngLimitOffset, NULL,
    "CALC:LIM{Limit}:CONT:OFFS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_CONTROL_SHIFT =
  {
    RSETL_LIMIT_CONTROL_SHIFT,
    "Limit Line Control Shift",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngLimitOffset, NULL,
    "CALC:LIM{Limit}:CONT:SHIF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_LOWER_STATE =
  {
    RSETL_LIMIT_LOWER_STATE,
    "Limit Line Lower State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:LIM{Limit}:LOW:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_LOWER_SCALING =
  {
    RSETL_LIMIT_LOWER_SCALING,
    "Limit Line Lower Scaling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAbsRel, NULL, NULL,
    "CALC:LIM{Limit}:LOW:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ABS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_LOWER_SPACING =
  {
    RSETL_LIMIT_LOWER_SPACING,
    "Limit Line Lower Spacing",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngLinLog, NULL, NULL,
    "CALC:LIM{Limit}:LOW:SPAC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_VBW_FILT_LIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_LOWER_MARGIN =
  {
    RSETL_LIMIT_LOWER_MARGIN,
    "Limit Line Lower Margin",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngLimitMargin, NULL,
    "CALC:LIM{Limit}:LOW:MARG",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_LOWER_THRESHOLD =
  {
    RSETL_LIMIT_LOWER_THRESHOLD,
    "Limit Line Lower Threshold",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "CALC:LIM{Limit}:LOW:THR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -200.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_LOWER_OFFSET =
  {
    RSETL_LIMIT_LOWER_OFFSET,
    "Limit Line Lower Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "CALC:LIM{Limit}:LOW:OFFS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_LOWER_SHIFT =
  {
    RSETL_LIMIT_LOWER_SHIFT,
    "Limit Line Lower Shift",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngLimitOffset, NULL,
    "CALC:LIM{Limit}:LOW:SHIF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_UPPER_STATE =
  {
    RSETL_LIMIT_UPPER_STATE,
    "Limit Line Upper State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:LIM{Limit}:UPP:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_UPPER_SCALING =
  {
    RSETL_LIMIT_UPPER_SCALING,
    "Limit Line Upper Scaling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAbsRel, NULL, NULL,
    "CALC:LIM{Limit}:UPP:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ABS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_UPPER_SPACING =
  {
    RSETL_LIMIT_UPPER_SPACING,
    "Limit Line Upper Spacing",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngLinLog, NULL, NULL,
    "CALC:LIM{Limit}:UPP:SPAC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_VBW_FILT_LIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_UPPER_MARGIN =
  {
    RSETL_LIMIT_UPPER_MARGIN,
    "Limit Line Upper Margin",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngLimitMargin, NULL,
    "CALC:LIM{Limit}:UPP:MARG",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_UPPER_THRESHOLD =
  {
    RSETL_LIMIT_UPPER_THRESHOLD,
    "Limit Line Upper Threshold",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "CALC:LIM{Limit}:UPP:THR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -200.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_UPPER_OFFSET =
  {
    RSETL_LIMIT_UPPER_OFFSET,
    "Limit Line Upper Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "CALC:LIM{Limit}:UPP:OFFS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_UPPER_SHIFT =
  {
    RSETL_LIMIT_UPPER_SHIFT,
    "Limit Line Upper Shift",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngLimitOffset, NULL,
    "CALC:LIM{Limit}:UPP:SHIF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_THRLINE_STATE =
  {
    RSETL_ATTR_THRLINE_STATE,
    "Threshold Line State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:THR:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_THRLINE_POSITION =
  {
    RSETL_ATTR_THRLINE_POSITION,
    "Threshold Line Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:THR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DLINE_STATE =
  {
    RSETL_ATTR_DLINE_STATE,
    "Display Line State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DLIN{Line}:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_DLINE_POSITION =
  {
    RSETL_ATTR_DLINE_POSITION,
    "Display Line Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DLIN{Line}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FLINE_STATE =
  {
    RSETL_ATTR_FLINE_STATE,
    "Frequency Line State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:FLIN{Line}:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FLINE_POSITION =
  {
    RSETL_ATTR_FLINE_POSITION,
    "Frequency Line Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:FLIN{Line}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TLINE_STATE =
  {
    RSETL_ATTR_TLINE_STATE,
    "Time Line State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:TLIN{Line}:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TLINE_POSITION =
  {
    RSETL_ATTR_TLINE_POSITION,
    "Time Line Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngTimeLinePos, NULL,
    "CALC:TLIN{Line}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_SOURCE =
  {
    RSETL_ATTR_TRIGGER_SOURCE,
    "Trigger Source",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTriggerSource, NULL, NULL,
    "TRIG:SOUR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TRG_IMM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_DELAY =
  {
    RSETL_ATTR_TRIGGER_DELAY,
    "Trigger Delay",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngTriggerDelay, NULL,
    "TRIG:HOLD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_SLOPE =
  {
    RSETL_ATTR_TRIGGER_SLOPE,
    "Trigger Slope",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPolarity, NULL, NULL,
    "TRIG:SLOP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_POS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_EXTERNAL_GATE =
  {
    RSETL_ATTR_EXTERNAL_GATE,
    "External Gate",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:SWE:EGAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_EXTERNAL_GATE_HOLD =
  {
    RSETL_ATTR_EXTERNAL_GATE_HOLD,
    "External Gate Delay",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngExtGateDelay, NULL,
    "SENS:SWE:EGAT:HOLD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_EXTERNAL_GATE_TRIGGER_TYPE =
  {
    RSETL_ATTR_EXTERNAL_GATE_TRIGGER_TYPE,
    "External Gate Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngExtGateTrigType, NULL, NULL,
    "SENS:SWE:EGAT:TYPE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_EGAT_TRIG_EDGE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_EXTERNAL_GATE_POLARITY =
  {
    RSETL_ATTR_EXTERNAL_GATE_POLARITY,
    "External Gate Polarity",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPolarity, NULL, NULL,
    "SENS:SWE:EGATe:POL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_POS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_EXTERNAL_GATE_LENGTH =
  {
    RSETL_ATTR_EXTERNAL_GATE_LENGTH,
    "External Gate Length",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngExtGateLength, NULL,
    "SENS:SWE:EGAT:LENG",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.25e-7,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_EXTERNAL_GATE_SIGNAL_SOURCE =
  {
    RSETL_ATTR_EXTERNAL_GATE_SIGNAL_SOURCE,
    "External Gate Signal Source",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngExtGateSource, NULL, NULL,
    "SENS:SWE:EGAT:SOUR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_EGAT_SOUR_IFP,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_VIDEO_TRIGGER_LEVEL =
  {
    RSETL_ATTR_VIDEO_TRIGGER_LEVEL,
    "Video Trigger Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPct, NULL,
    "TRIG:LEV:VID",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    50.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_IFP_LEVEL =
  {
    RSETL_ATTR_TRIGGER_IFP_LEVEL,
    "Trigger IF Power Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngTrigIFPowerLevel, NULL,
    "TRIG:LEV:IFP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -20.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_IFP_OFFSET =
  {
    RSETL_ATTR_TRIGGER_IFP_OFFSET,
    "Trigger IF Power Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngIFPowOffset, NULL,
    "TRIG:IFP:HOLD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    150.0e-9,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_IFP_HYSTERESIS =
  {
    RSETL_ATTR_TRIGGER_IFP_HYSTERESIS,
    "Trigger IF Power Hysteresis",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngIFPowHyst, NULL,
    "TRIG:IFP:HYST",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_TV_FREE_RUN_TRIG_MODE =
  {
    RSETL_ATTR_TRIGGER_TV_FREE_RUN_TRIG_MODE,
    "Trigger TV Free Run Trigger Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TRIG:SEQ:VID:CONT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B6",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_TV_VERTICAL_SYNC =
  {
    RSETL_ATTR_TRIGGER_TV_VERTICAL_SYNC,
    "Trigger TV Vertical Synchronization",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTrgTVerticalSync, NULL, NULL,
    "TRIG:SEQ:VID:FIEL:SEL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TRG_TV_VSYNC_ALL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B6",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_TV_LINE_SYSTEM =
  {
    RSETL_ATTR_TRIGGER_TV_LINE_SYSTEM,
    "Trigger TV Line System",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, &rsetl_rngTrgTVLineSystem,
    "TRIG:SEQ:VID:FORM:LPFR",
    // Defaults I32, I64, Float, Bool, String
    625,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B6",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_TV_HORIZONTAL_SYNC_LINE_NUMBER =
  {
    RSETL_ATTR_TRIGGER_TV_HORIZONTAL_SYNC_LINE_NUMBER,
    "Trigger TV Horizontal Sync Line Number",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngTrgTVHorizontalSyncLine, NULL,
    "TRIG:SEQ:VID:LINE:NUMB",
    // Defaults I32, I64, Float, Bool, String
    17,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B6",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRIGGER_TV_VIDEO_SYNC_SIGNAL_POLARITY =
  {
    RSETL_ATTR_TRIGGER_TV_VIDEO_SYNC_SIGNAL_POLARITY,
    "Trigger TV Video Sync Signal Polarity",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTrgTVPolarity, NULL, NULL,
    "TRIG:SEQ:VID:SSIG:POL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TRG_TV_POLARITY_NEG,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_AMPL_PREAMPLIFIER =
  {
    RSETL_ATTR_AMPL_PREAMPLIFIER,
    "Amplitude Preamplifier State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:GAIN:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_EXTERN_PREAMP_GAIN =
  {
    RSETL_ATTR_EXTERN_PREAMP_GAIN,
    "External Preamplifier Gain",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "SENS:CORR:EGA:INP:MAGN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_LIMIT_CHECK_RESULT =
  {
    RSETL_LIMIT_CHECK_RESULT,
    "Limit Check Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:LIM{Limit}:FAIL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACK_GEN_STATE =
  {
    RSETL_ATTR_TRACK_GEN_STATE,
    "Tracking Generator State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "OUTP:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACK_GEN_CORR_STATE =
  {
    RSETL_ATTR_TRACK_GEN_CORR_STATE,
    "Tracking Generator Correction State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:CORR:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACK_GEN_RECALL_SETTINGS =
  {
    RSETL_ATTR_TRACK_GEN_RECALL_SETTINGS,
    "Tracking Generator Recall Settings",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SENS:CORR:REC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACK_GEN_MEAS_TYPE =
  {
    RSETL_ATTR_TRACK_GEN_MEAS_TYPE,
    "Tracking Generator Measurement Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTGenMeasType, NULL, NULL,
    "SENS:CORR:METH",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TRACK_GEN_MEAS_TYPE_TRAN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACK_GEN_CAL_RESULT_TYPE =
  {
    RSETL_ATTR_TRACK_GEN_CAL_RESULT_TYPE,
    "Tracking Generator Calibration Result Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTGenResultType, NULL, NULL,
    "SENS:CORR:COLL:ACQ",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TRACK_GEN_CAL_RES_TYPE_THR,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL =
  {
    RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL,
    "Tracking Generator Output Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SOUR:POW:LEV:IMM:AMPL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -20.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL_OFFSET =
  {
    RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL_OFFSET,
    "Tracking Generator Output Level Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "SOUR:POW:LEV:IMM:OFFS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_NOISE_STATE =
  {
    RSETL_ATTR_MARKER_NOISE_STATE,
    "Marker Noise Measurement State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:FUNC:NOIS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_NOISE_RESULT =
  {
    RSETL_ATTR_MARKER_NOISE_RESULT,
    "Marker Noise Measurement Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:FUNC:NOIS:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_PNO_STATE =
  {
    RSETL_ATTR_REFERENCE_MARKER_PNO_STATE,
    "Delta Marker Phase Noise State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DELT:FUNC:PNO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_REFERENCE_MARKER_PNO_RESULT =
  {
    RSETL_ATTR_REFERENCE_MARKER_PNO_RESULT,
    "Delta Marker Phase Noise Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DELT:FUNC:PNO:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_FREQUENCY_COUNTER_ENABLED =
  {
    RSETL_ATTR_MARKER_FREQUENCY_COUNTER_ENABLED,
    "Frequency Counter State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:COUN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_FREQUENCY_COUNTER_RESOLUTION =
  {
    RSETL_ATTR_MARKER_FREQUENCY_COUNTER_RESOLUTION,
    "Frequency Counter Resolution",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, &rsetl_rngFreqCountRes,
    "CALC:MARK:COUN:RES",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_COUNT =
  {
    RSETL_ATTR_MARKER_COUNT,
    "Frequency Counter Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK{Marker}:COUN:FREQ?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_NDB_STATE =
  {
    RSETL_ATTR_MARKER_NDB_STATE,
    "Marker N dB Down State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:NDBD:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_NDB_VAL =
  {
    RSETL_ATTR_MARKER_NDB_VAL,
    "Marker N dB Down Value",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMarkerNdBDown, NULL,
    "CALC:MARK:FUNC:NDBD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MARKER_NDB_RESULT =
  {
    RSETL_ATTR_MARKER_NDB_RESULT,
    "Marker N dB Down Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:NDBD:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_LIST_POW_STATE_OFF =
  {
    RSETL_ATTR_LIST_POW_STATE_OFF,
    "List Power Measurement Deactivation",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SENS:LIST:POW:STAT OFF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_STATE =
  {
    RSETL_ATTR_MEAS_TDOM_STATE,
    "Time Domain Power State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_PEAK =
  {
    RSETL_ATTR_MEAS_TDOM_PEAK,
    "Time Domain Power Peak State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:PPE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_RMS =
  {
    RSETL_ATTR_MEAS_TDOM_RMS,
    "Time Domain Power RMS State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:RMS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_MEAN =
  {
    RSETL_ATTR_MEAS_TDOM_MEAN,
    "Time Domain Power Mean State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:MEAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_SDEV =
  {
    RSETL_ATTR_MEAS_TDOM_SDEV,
    "Time Domain Power Standard Deviation State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:SDEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_AVG =
  {
    RSETL_ATTR_MEAS_TDOM_AVG,
    "Time Domain Power Average",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:AVER",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_MAX_HOLD =
  {
    RSETL_ATTR_MEAS_TDOM_MAX_HOLD,
    "Time Domain Power Max Hold",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:PHOL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_MODE =
  {
    RSETL_ATTR_MEAS_TDOM_MODE,
    "Time Domain Power Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAbsRel, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ABS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_AOFF =
  {
    RSETL_ATTR_MEAS_TDOM_AOFF,
    "Time Domain Power All Off",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:AOFF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_SET_REFERENCE =
  {
    RSETL_ATTR_MEAS_TDOM_SET_REFERENCE,
    "Time Domain Power Set Reference",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "*WAI;:CALC:MARK:FUNC:SUMM:REF:AUTO ONCE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_PEAK_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_PEAK_RESULT,
    "Time Domain Power Peak Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:PPE:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_RMS_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_RMS_RESULT,
    "Time Domain Power RMS Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:RMS:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_MEAN_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_MEAN_RESULT,
    "Time Domain Power Mean Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:MEAN:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_SDEV_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_SDEV_RESULT,
    "Time Domain Power Standard Deviation Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:SDEV:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_AVG_PEAK_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_AVG_PEAK_RESULT,
    "Time Domain Power Averaged Peak Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:PPE:AVER:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_AVG_RMS_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_AVG_RMS_RESULT,
    "Time Domain Power Averaged RMS Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:RMS:AVER:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_AVG_MEAN_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_AVG_MEAN_RESULT,
    "Time Domain Power Averaged Mean Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:MEAN:AVER:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_AVG_SDEV_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_AVG_SDEV_RESULT,
    "Time Domain Power Averaged Standard Deviation Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:SDEV:AVER:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RESULT,
    "Time Domain Power Peak Hold Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:PPE:PHOL:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RMS_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RMS_RESULT,
    "Time Domain Power Peak Hold RMS Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:RMS:PHOL:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_MEAN_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_MEAN_RESULT,
    "Time Domain Power Peak Hold Mean Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:MEAN:PHOL:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_SDEV_RESULT =
  {
    RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_SDEV_RESULT,
    "Time Domain Power Peak Hold Standard Deviation Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:SUMM:SDEV:PHOL:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_SELECT =
  {
    RSETL_ATTR_MEAS_POW_SELECT,
    "Power Select",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngMeasPowerSelect, NULL, NULL,
    "CALC:MARK:FUNC:POW:SEL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_OFF =
  {
    RSETL_ATTR_MEAS_POW_OFF,
    "Power Off",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:POW OFF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_ADJ_NUM =
  {
    RSETL_ATTR_MEAS_POW_ADJ_NUM,
    "Power Number Of Adjacent Channels",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngAdjChNum, NULL,
    "SENS:POW:ACH:ACP",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_ADJ_MODE =
  {
    RSETL_ATTR_MEAS_POW_ADJ_MODE,
    "Power Adjacent Channel Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAbsRel, NULL, NULL,
    "SENS:POW:ACH:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ABS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_MODE =
  {
    RSETL_ATTR_MEAS_POW_MODE,
    "Power Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngMeasPowerMode, NULL, NULL,
    "CALC:MARK:FUNC:POW:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_MEAS_POW_MODE_WRITE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_RESULT_MODE =
  {
    RSETL_ATTR_MEAS_POW_RESULT_MODE,
    "Power Result Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:POW:RES:PHZ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_CHANNEL_SPACING =
  {
    RSETL_ATTR_MEAS_POW_CHANNEL_SPACING,
    "Power Channel Spacing",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngChannelSpacing, NULL,
    "SENS:POW:ACH:SPAC:CHAN{Channel}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    20.0e+3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_SPACING =
  {
    RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_SPACING,
    "Power Adjacent Channel Spacing",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngChannelSpacing, NULL,
    "SENS:POW:ACH:SPAC:ACH",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    14.0e+3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_ALT_CHANNEL_SPACING =
  {
    RSETL_ATTR_MEAS_POW_ALT_CHANNEL_SPACING,
    "Power Alternate Adjacent Channel Spacing",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngChannelSpacing, NULL,
    "SENS:POW:ACH:SPAC:ALT{Channel}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    40.0e+3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_CHANNEL_BANDWIDTH =
  {
    RSETL_ATTR_MEAS_POW_CHANNEL_BANDWIDTH,
    "Power Channel Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngChannelBandwidth, NULL,
    "SENS:POW:ACH:BAND",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    14.0e+3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_BANDWIDTH =
  {
    RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_BANDWIDTH,
    "Power Adjacent Channel Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngChannelBandwidth, NULL,
    "SENS:POW:ACH:BAND:ACH",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    14.0e+3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_ALT_CHANNEL_BANDWIDTH =
  {
    RSETL_ATTR_MEAS_POW_ALT_CHANNEL_BANDWIDTH,
    "Power Alternate Adjacent Channel Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngChannelBandwidth, NULL,
    "SENS:POW:ACH:BAND:ALT{Channel}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    14.0e+3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_TRACE =
  {
    RSETL_ATTR_MEAS_POW_TRACE,
    "Power Channel Power Trace",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngTrace, NULL,
    "SENS:POW:TRAC",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_STANDARD =
  {
    RSETL_ATTR_MEAS_POW_STANDARD,
    "Power Standard",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngMeasPowerStandard, NULL, NULL,
    "CALC:MARK:FUNC:POW:PRES",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_MEAS_POW_STD_NONE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_REF_VALUE =
  {
    RSETL_ATTR_MEAS_POW_REF_VALUE,
    "Power Channel Power To Reference Value",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SENS:POW:ACH:REF:AUTO ONCE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_ADJ_PRESET =
  {
    RSETL_ATTR_MEAS_POW_ADJ_PRESET,
    "Power Preset Adjacent Channel",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAdjPreset, NULL, NULL,
    "SENS:POW:ACH:PRES",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ADJ_PRE_ACP,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_ACP_HSP =
  {
    RSETL_ATTR_MEAS_ACP_HSP,
    "ACP Fast ACP State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:POW:HSP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_ACP_PRESET_REF_LEVEL =
  {
    RSETL_ATTR_MEAS_ACP_PRESET_REF_LEVEL,
    "ACP Adjust Reference Level",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SENS:POW:ACH:PRES:RLEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_ACP_LIMIT_STATE =
  {
    RSETL_ATTR_MEAS_ACP_LIMIT_STATE,
    "ACP Limit Check State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:LIM:ACP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_ACP_LIMIT_REL_STATE =
  {
    RSETL_ATTR_MEAS_ACP_LIMIT_REL_STATE,
    "ACP Limit Check Relative State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:LIM:ACP:ACH:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_ACP_LIMIT_ABS_STATE =
  {
    RSETL_ATTR_MEAS_ACP_LIMIT_ABS_STATE,
    "ACP Limit Check Absolute State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:LIM:ACP:ACH:ABS:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_ACP_ALT_LIMIT_REL_STATE =
  {
    RSETL_ATTR_MEAS_ACP_ALT_LIMIT_REL_STATE,
    "ACP Alternate Limit Check Relative State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:LIM:ACP:ALT{Channel}:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_ACP_ALT_LIMIT_ABS_STATE =
  {
    RSETL_ATTR_MEAS_ACP_ALT_LIMIT_ABS_STATE,
    "ACP Alternate Limit Check Absolute State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:LIM:ACP:ALT{Channel}:ABS:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_CARR_SIG_NUM =
  {
    RSETL_ATTR_MEAS_POW_CARR_SIG_NUM,
    "Power Carrier Signals Number",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCarrSignNum, NULL,
    "SENS:POW:ACH:TXCH:COUN",
    // Defaults I32, I64, Float, Bool, String
    4,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_REF_CHAN_SEL_AUTO =
  {
    RSETL_ATTR_MEAS_POW_REF_CHAN_SEL_AUTO,
    "Power Reference Channel Automatic Selection",
    RS_VAL_WRITE_ONLY,
    RS_VAL_INT32,
    &rsetl_rngAdjChAutoSel, NULL, NULL,
    "SENS:POW:ACH:REF:TXCH:AUTO",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ADJ_RCHAN_AUTO_MIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_ADJ_REF_TXCHANNEL =
  {
    RSETL_ATTR_MEAS_POW_ADJ_REF_TXCHANNEL,
    "Power Transmission Channel As Reference Channel",
    RS_VAL_WRITE_ONLY,
    RS_VAL_INT32,
    NULL, &rsetl_rngAdjRefTxChann, NULL,
    "SENS:POW:ACH:REF:TXCH:MAN",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_POW_BANDWIDTH =
  {
    RSETL_ATTR_MEAS_POW_BANDWIDTH,
    "Power Percentage Of Power Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPowPct, NULL,
    "SENS:POW:BAND",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    99.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_APD_STATE =
  {
    RSETL_ATTR_MEAS_STAT_APD_STATE,
    "Signal Statistic APD State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:STAT:APD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_CCDF_STATE =
  {
    RSETL_ATTR_MEAS_STAT_CCDF_STATE,
    "Signal Statistic CCDF State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:STAT:CCDF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_SAMPLES =
  {
    RSETL_ATTR_MEAS_STAT_SAMPLES,
    "Signal Statistic Number of Samples",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngStatNumSamples, NULL,
    "CALC:STAT:NSAM",
    // Defaults I32, I64, Float, Bool, String
    100000,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_X_REF =
  {
    RSETL_ATTR_MEAS_STAT_X_REF,
    "Signal Statistic Scaling X Ref Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:STAT:SCAL:X:RLEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -20.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_X_RANGE =
  {
    RSETL_ATTR_MEAS_STAT_X_RANGE,
    "Signal Statistic Scaling X Range",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDISPAmplitudeRang, NULL,
    "CALC:STAT:SCAL:X:RANG",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_Y_MIN =
  {
    RSETL_ATTR_MEAS_STAT_Y_MIN,
    "Signal Statistic Scaling Y Minimum",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMeasStatLowerLimit, NULL,
    "CALC:STAT:SCAL:Y:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0e-6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_Y_MAX =
  {
    RSETL_ATTR_MEAS_STAT_Y_MAX,
    "Signal Statistic Scaling Y Maximum",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMeasStatUpperLimit, NULL,
    "CALC:STAT:SCAL:Y:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_ADJ =
  {
    RSETL_ATTR_MEAS_STAT_ADJ,
    "Signal Statistic Adjust Settings",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:STAT:SCAL:AUTO ONCE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_STAT_PRESET =
  {
    RSETL_ATTR_MEAS_STAT_PRESET,
    "Signal Statistic Default Setting",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:STAT:PRES",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_STAT_RESULT =
  {
    RSETL_ATTR_STAT_RESULT,
    "Signal Statistic Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:STAT:RES{Trace}? {StatisticMeasType}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_MDEPTH_STATE =
  {
    RSETL_ATTR_MEAS_MDEPTH_STATE,
    "Modulation Depth State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:MDEP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_MDEPTH_RESULT =
  {
    RSETL_ATTR_MEAS_MDEPTH_RESULT,
    "Modulation Depth Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:MDEP:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_MDEPTH_SEARCH =
  {
    RSETL_ATTR_MEAS_MDEPTH_SEARCH,
    "Modulation Depth Search",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:MDEP:SEAR ONCE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TOI_STATE =
  {
    RSETL_ATTR_MEAS_TOI_STATE,
    "TOI State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:TOI",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TOI_RESULT =
  {
    RSETL_ATTR_MEAS_TOI_RESULT,
    "TOI Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:TOI:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_TOI_SEARCH =
  {
    RSETL_ATTR_MEAS_TOI_SEARCH,
    "TOI Search Signal",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:TOI:SEAR ONCE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_HDIST_STATE =
  {
    RSETL_ATTR_MEAS_HDIST_STATE,
    "Harmonic Distortion State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:HARM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_HDIST_NOOFHARM =
  {
    RSETL_ATTR_MEAS_HDIST_NOOFHARM,
    "Harmonic Distortion No Of Harmonics",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngMeasHDISTNharm, NULL,
    "CALC:MARK:FUNC:HARM:NHAR",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_HDIST_RBWAUTO =
  {
    RSETL_ATTR_MEAS_HDIST_RBWAUTO,
    "Harmonic Distortion RBW Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:HARM:BAND:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MEAS_HDIST_PRESET =
  {
    RSETL_ATTR_MEAS_HDIST_PRESET,
    "Harmonic Distortion Adjust Settings",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:HARM:PRES",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MPOW_MIN =
  {
    RSETL_ATTR_MPOW_MIN,
    "Burst Power Minimum Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "*WAI;SENS:MPOW:RES:MIN?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_MPOW_FTYPE =
  {
    RSETL_ATTR_MPOW_FTYPE,
    "Burst Power Filter Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngMpowFiltType, NULL, NULL,
    "SENS:MPOW:FTYP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_MPOW_FTYPE_NORM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_IQ_SAMPLE_RATE =
  {
    RSETL_ATTR_IQ_SAMPLE_RATE,
    "IQ Sample Rate",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngIQSRate, NULL,
    "TRAC:IQ:SRAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    32.0e+6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_IQ_DATA_STATE =
  {
    RSETL_ATTR_IQ_DATA_STATE,
    "IQ Data Acquisition",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TRAC:IQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_IQ_DATA_AVER_STATE =
  {
    RSETL_ATTR_IQ_DATA_AVER_STATE,
    "IQ Data Averaging State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TRAC:IQ:AVER",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_IQ_DATA_AVER_COUNT =
  {
    RSETL_ATTR_IQ_DATA_AVER_COUNT,
    "IQ Data Averaging Count",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngSweepCount, NULL,
    "TRAC:IQ:AVER:COUN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_IQ_DATA_SYNC =
  {
    RSETL_ATTR_IQ_DATA_SYNC,
    "IQ Data Synchronization",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TRAC:IQ:SYNC:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SERVICE_INPUT_SOURCE =
  {
    RSETL_ATTR_SERVICE_INPUT_SOURCE,
    "Service Input Source",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngServiceInput, NULL, NULL,
    "DIAG:SERV:INP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_INPUT_RF,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SERVICE_INPUT_COMB_FREQUENCY =
  {
    RSETL_ATTR_SERVICE_INPUT_COMB_FREQUENCY,
    "Service Input Comb Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngServiceCombFrequency, NULL, NULL,
    "DIAG:SERV:INP:PULS:PRAT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_SERV_COMB_FREQ_COMB1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SERVICE_NOISE_SOURCE =
  {
    RSETL_ATTR_SERVICE_NOISE_SOURCE,
    "Service Noise Source",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DIAG:SERV:NSO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B5",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SERVICE_STEST_RESULTS =
  {
    RSETL_ATTR_SERVICE_STEST_RESULTS,
    "Self Test Results",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "DIAG:SERV:STES:RES?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SERVICE_STEST =
  {
    RSETL_ATTR_SERVICE_STEST,
    "Self Test",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "*TST?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_RECALL =
  {
    RSETL_ATTR_FILE_RECALL,
    "File Recall",
    RS_VAL_WRITE_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:LOAD:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    rsetl_FileStateSpecialFormat_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_STARTUP_RECALL =
  {
    RSETL_ATTR_FILE_STARTUP_RECALL,
    "File Startup Recall",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:LOAD:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    rsetl_FileStateSpecialFormat_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_SAVE =
  {
    RSETL_ATTR_FILE_SAVE,
    "File Save",
    RS_VAL_WRITE_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:STOR:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    rsetl_FileStateSpecialFormat_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_DATA_CLEAR =
  {
    RSETL_ATTR_FILE_DATA_CLEAR,
    "File Data Set Clear",
    RS_VAL_WRITE_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:CLE:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    rsetl_FileStateSpecialFormat_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_DATA_CLEAR_ALL =
  {
    RSETL_ATTR_FILE_DATA_CLEAR_ALL,
    "File Data Set Clear All",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "MMEM:CLE:ALL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_DEC_SEPARATOR =
  {
    RSETL_ATTR_FILE_DEC_SEPARATOR,
    "File Decimal Separator",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngFileDecSeparator, NULL, NULL,
    "FORM:DEXP:DSEP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DEC_SEP_POIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_MANAGER_EDIT_PATH =
  {
    RSETL_ATTR_FILE_MANAGER_EDIT_PATH,
    "File Manager Edit Path",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:CDIR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_MANAGER_DELETE =
  {
    RSETL_ATTR_FILE_MANAGER_DELETE,
    "File Manager Delete",
    RS_VAL_WRITE_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:DEL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_MANAGER_MAKE_DIR =
  {
    RSETL_ATTR_FILE_MANAGER_MAKE_DIR,
    "File Manager Make Directory",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:MDIR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_MANAGER_EDIT_PATH_DEVICE =
  {
    RSETL_ATTR_FILE_MANAGER_EDIT_PATH_DEVICE,
    "File Manager Edit Path Device",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:MSIS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_MANAGER_DELETE_DIR =
  {
    RSETL_ATTR_FILE_MANAGER_DELETE_DIR,
    "File Manager Delete Directory",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:RDIR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_SOURCE_CAL_DATA =
  {
    RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_SOURCE_CAL_DATA,
    "File Items to Save Recall Select Source Cal Data",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "MMEM:SEL:SCD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAN =
  {
    RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAN,
    "File Items to Save Recall Select All Transducers",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "MMEM:SEL:TRAN:ALL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_HWSETTINGS =
  {
    RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_HWSETTINGS,
    "File Items to Save Recall Select HW Settings",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "MMEM:SEL:HWS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAC =
  {
    RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAC,
    "File Items to Save Recall Select Trace",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "MMEM:SEL:TRAC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_LINE =
  {
    RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_LINE,
    "File Items to Save Recall Select Lines",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "MMEM:SEL:LIN:ALL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_ALL =
  {
    RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_ALL,
    "File Items to Save Recall All",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "MMEM:SEL:ALL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_NONE =
  {
    RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_NONE,
    "File Items to Save Recall None",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "MMEM:SEL:NONE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_DEFAULT =
  {
    RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_DEFAULT,
    "File Items to Save Recall Default",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "MMEM:SEL:DEF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_ABORT =
  {
    RSETL_ATTR_HCOPY_ABORT,
    "Hcopy Abort",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "HCOP:ABOR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_COLOR_DEF =
  {
    RSETL_ATTR_HCOPY_COLOR_DEF,
    "Hcopy Color Default",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "HCOP:CMAP:DEF{Default}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_COLOR =
  {
    RSETL_ATTR_HCOPY_COLOR,
    "Hcopy Color",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "HCOP:DEV:COL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_PRINT =
  {
    RSETL_ATTR_HCOPY_PRINT,
    "Hcopy Print",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "HCOP:IMM{Destination}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_PRINT_NEXT =
  {
    RSETL_ATTR_HCOPY_PRINT_NEXT,
    "Hcopy Print Next",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "HCOP:IMM{Destination}:NEXT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_DEVICE_DESTINATION =
  {
    RSETL_ATTR_HCOPY_DEVICE_DESTINATION,
    "Hcopy Device Destination",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngHcopyDevice, NULL, NULL,
    "HCOP:DEST{Destination}",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_HCOPY_DEVICE_MEM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_COLOR_PREDEFINED =
  {
    RSETL_ATTR_HCOPY_COLOR_PREDEFINED,
    "Hcopy Color Predefined",
    RS_VAL_WRITE_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDISPConfPreDefColour, NULL, NULL,
    "HCOP:CMAP{CMAP}:PDEF",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DISP_COL_BLAC,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM =
  {
    RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM,
    "Hcopy Device Language Output Format",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngHcopyDeviceLang, NULL, NULL,
    "HCOP:DEV:LANG",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_PRINT_SCREEN =
  {
    RSETL_ATTR_HCOPY_PRINT_SCREEN,
    "Hcopy Print Screen",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "HCOP:ITEM:ALL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_COMM_SCR =
  {
    RSETL_ATTR_HCOPY_COMM_SCR,
    "Hcopy Comment Screen",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "HCOP:ITEM:WIND:TEXT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_PRINT_TRACE =
  {
    RSETL_ATTR_HCOPY_PRINT_TRACE,
    "Hcopy Print Trace",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "HCOP:ITEM:WIND:TRAC:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_DEVICE_ORIENTATION =
  {
    RSETL_ATTR_HCOPY_DEVICE_ORIENTATION,
    "Hcopy Device Orientation",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngHcopyDeviceOrient, NULL, NULL,
    "HCOP:PAGE:ORI{Destination}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_FILE_NAME =
  {
    RSETL_ATTR_HCOPY_FILE_NAME,
    "Hcopy File Name",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "MMEM:NAME",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_PRINTER =
  {
    RSETL_ATTR_HCOPY_PRINTER,
    "Hardcopy Select Printer",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SYST:COMM:PRIN:SEL{Destination}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_quotedString_ReadCallback,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_PRINTER_NEXT =
  {
    RSETL_ATTR_HCOPY_PRINTER_NEXT,
    "Hardcopy Get Next Printer",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SYST:COMM:PRIN:ENUM:NEXT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_HCOPY_PRINTER_FIRST =
  {
    RSETL_ATTR_HCOPY_PRINTER_FIRST,
    "Hardcopy Get First Printer",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SYST:COMM:PRIN:ENUM:FIRS?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ROSC_SOURCE =
  {
    RSETL_ATTR_ROSC_SOURCE,
    "Reference Oscillator Source",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngSourceIntExt, NULL, NULL,
    "ROSC:SOUR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_SOUR_INT,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SYST_ERR =
  {
    RSETL_ATTR_SYST_ERR,
    "System Error",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SYST:ERR?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SYST_ERR_LIST =
  {
    RSETL_ATTR_SYST_ERR_LIST,
    "System Error List",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SYST:ERR:LIST?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SYST_ERR_CLEAR =
  {
    RSETL_ATTR_SYST_ERR_CLEAR,
    "Clear Errors",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SYST:ERR:CLE:ALL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SYST_PRESET =
  {
    RSETL_ATTR_SYST_PRESET,
    "System Preset",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SYST:PRES",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SYST_VERSION =
  {
    RSETL_ATTR_SYST_VERSION,
    "System Version",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SYST:VERS?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "0",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SYST_SPEAKER =
  {
    RSETL_ATTR_SYST_SPEAKER,
    "Speaker Volume",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngSpeakerVolume, NULL,
    "SYST:SPE:VOL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_OUTPUT_MEAS_MODE =
  {
    RSETL_ATTR_OUTPUT_MEAS_MODE,
    "Output Measurement Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngOutputMeasMode, NULL, NULL,
    "OUTP:IF:SOUR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_OUTP_MEAS_MODE_IF,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B5",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_SYSTEM_POWER_SUPPLY =
  {
    RSETL_ATTR_SYSTEM_POWER_SUPPLY,
    "System Power Supply",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngSystemPower, NULL, NULL,
    "SYST:SPOW?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_TRIGGER_SOURCE =
  {
    RSETL_ATTR_FMDEM_TRIGGER_SOURCE,
    "FM Demod Trigger Source",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngFmTriggerSource, NULL, NULL,
    "TRIG:SOUR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TRG_IMM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_ABS =
  {
    RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_ABS,
    "Analog Demod Trigger AM Level Abs",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngAdemTrigAMLevelAbs, NULL,
    "TRIG:LEV:AM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -20.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_REL =
  {
    RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_REL,
    "Analog Demod Trigger AM Level Relative",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngAdemTrigAMLevelRel, NULL,
    "TRIG:LEV:AM:REL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_TRIGGER_FM_LEVEL =
  {
    RSETL_ATTR_ADEM_TRIGGER_FM_LEVEL,
    "Analog Demod Trigger FM Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngAdemTrigFMLevel, NULL,
    "TRIG:LEV:FM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_TRIGGER_PM_LEVEL =
  {
    RSETL_ATTR_ADEM_TRIGGER_PM_LEVEL,
    "Analog Demod Trigger PM Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngAdemTrigPMLevel, NULL,
    "TRIG:LEV:PM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_DISPLAY_PDIV =
  {
    RSETL_ATTR_FMDEM_DISPLAY_PDIV,
    "FM Demod Display Pdiv",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:Y:PDIV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_STATE =
  {
    RSETL_ATTR_FMDEM_STATE,
    "FM Demod State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "ADEM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_AF_COUP =
  {
    RSETL_ATTR_FMDEM_AF_COUP,
    "FM Demod AF Coupling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCoupling, NULL, NULL,
    "ADEM:AF:COUP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_AC,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_MTIM =
  {
    RSETL_ATTR_FMDEM_MTIM,
    "FM Demod Meas Time",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:MTIM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    62.625E-6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_BAND_DEM =
  {
    RSETL_ATTR_FMDEM_BAND_DEM,
    "FM Demod Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngFmBwid, NULL,
    "ADEM:BAND:DEM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    5.0E+6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_RLEN =
  {
    RSETL_ATTR_FMDEM_RLEN,
    "FM Demod Record Length",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:RLEN?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_SRATE =
  {
    RSETL_ATTR_FMDEM_SRATE,
    "FM Demod Sampling Rate",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:SRAT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_ZOOM =
  {
    RSETL_ATTR_FMDEM_ZOOM,
    "FM Demod Zoom State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "ADEM:ZOOM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_ZOOM_START =
  {
    RSETL_ATTR_FMDEM_ZOOM_START,
    "FM Demod Zoom Start",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:ZOOM:STAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_PHASE_WRAP =
  {
    RSETL_ATTR_ADEM_PHASE_WRAP,
    "Analog Demod Phase Wrap",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAdemPhaseWrap, NULL, NULL,
    "CALC:FORM",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ADEM_UPHAS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_UNIT_ANGLE =
  {
    RSETL_ATTR_ADEM_UNIT_ANGLE,
    "Analog Demod Unit Angle",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngUnitAngle, NULL, NULL,
    "CALC:UNIT:ANGL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_ANGLE_RAD,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_PM_RPO_X =
  {
    RSETL_ATTR_ADEM_PM_RPO_X,
    "Analog Demod Zero Phase Ref Point",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:PM:RPO:X",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0E-6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_AF_CENTER =
  {
    RSETL_ATTR_FMDEM_AF_CENTER,
    "FM Demod AF Center Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:AF:CENT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.25E6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_AF_SPAN =
  {
    RSETL_ATTR_FMDEM_AF_SPAN,
    "FM Demod AF Span",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:AF:SPAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    2.5E6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_AF_START =
  {
    RSETL_ATTR_FMDEM_AF_START,
    "FM Demod AF Start Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:AF:STAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_AF_STOP =
  {
    RSETL_ATTR_FMDEM_AF_STOP,
    "FM Demod AF Stop Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:AF:STOP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    2.5E6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_AF_FULL_SPAN =
  {
    RSETL_ATTR_FMDEM_AF_FULL_SPAN,
    "FM Demod AF Full Span",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "ADEM:AF:SPAN:FULL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_BAND_RES =
  {
    RSETL_ATTR_FMDEM_BAND_RES,
    "FM Demod RF Spectrum Resolution Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngAdemBandRes, NULL,
    "ADEM:SPEC:BAND",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    61.2E+3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_SPEC_SPAN =
  {
    RSETL_ATTR_FMDEM_SPEC_SPAN,
    "FM Demod RF Spectrum Span",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:SPEC:SPAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    5.0E+6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_SPEC_ZOOM =
  {
    RSETL_ATTR_FMDEM_SPEC_ZOOM,
    "FM Demod RF Spectrum Zoom",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:SPEC:SPAN:ZOOM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    5.0E+6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_FILT_HPAS_STAT =
  {
    RSETL_ATTR_FMDEM_FILT_HPAS_STAT,
    "FM Demod High Pass AF Filter State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "FILT:HPAS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_FILT_HPAS_FREQ =
  {
    RSETL_ATTR_FMDEM_FILT_HPAS_FREQ,
    "FM Demod High Pass AF Filter Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, &rsetl_rngHpasFilterFreq,
    "FILT:HPAS:FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    50.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_FILT_LPAS_STAT =
  {
    RSETL_ATTR_FMDEM_FILT_LPAS_STAT,
    "FM Demod Low Pass AF Filter State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "FILT:LPAS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_FILT_DEMP_STAT =
  {
    RSETL_ATTR_FMDEM_FILT_DEMP_STAT,
    "FM Demod Deemphasis State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "FILT:DEMP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_FILT_LPAS_FREQ =
  {
    RSETL_ATTR_FMDEM_FILT_LPAS_FREQ,
    "FM Demod Low Pass AF Filter Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, &rsetl_rngLpasFiltFreq,
    "FILT:LPAS:FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3.0e+3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_FILT_DEMP_TCON =
  {
    RSETL_ATTR_FMDEM_FILT_DEMP_TCON,
    "FM Demod Deemphasis Time Constant",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, &rsetl_rngFiltDempTimeConst,
    "FILT:DEMP:TCON",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    25.0E-6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_FILT_LPAS_FREQ_REL =
  {
    RSETL_ATTR_ADEM_FILT_LPAS_FREQ_REL,
    "Analog Demod Low Pass Filter Frequency Relative",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, &rsetl_rngFiltDempPctConst,
    "SENS:FILT:LPAS:FREQ:REL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    25.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_AFR_RES =
  {
    RSETL_ATTR_FMDEM_AFR_RES,
    "FM Demod Audio Frequency Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:ADEM:AFR:RES{Trace}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_FERR_RES =
  {
    RSETL_ATTR_FMDEM_FERR_RES,
    "FM Demod Frequency Error Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:ADEM:FERR:RES{Trace}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_SIN_RES =
  {
    RSETL_ATTR_FMDEM_SIN_RES,
    "FM Demod SINAD Measurement Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:ADEM:SIN:RES{Trace}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_THD_RES =
  {
    RSETL_ATTR_FMDEM_THD_RES,
    "FM Demod THD Measurement Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:ADEM:THD:RES{Trace}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_FMDEM_CARR_RES =
  {
    RSETL_ATTR_FMDEM_CARR_RES,
    "FM Demod Carrier Power Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:ADEM:CARR:RES{Trace}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_SUMM_RES =
  {
    RSETL_ATTR_ADEM_SUMM_RES,
    "Analog Demod Summary Result Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:MARK:FUNC:ADEM:{AnalogModulation}:RES{Trace}? {ResultDetector}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ADEM_FM_OFFSET =
  {
    RSETL_ATTR_ADEM_FM_OFFSET,
    "Analog Demod FM Offset",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "ADEM:FM:OFFS? {FMOffsetResult}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K7",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_REL =
  {
    RSETL_ATTR_PMET_REL,
    "PWM Reference value",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRefLevel, NULL,
    "CALC:PMET:REL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_REL_AUTO =
  {
    RSETL_ATTR_PMET_REL_AUTO,
    "PWM Measure To Reference",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:PMET:REL:AUTO ONCE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_FREQ =
  {
    RSETL_ATTR_PMET_FREQ,
    "PWM Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:PMET:FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    50000000,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_MEAS_TIME =
  {
    RSETL_ATTR_PMET_MEAS_TIME,
    "PWM Measurement Time",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPmetMeasTime, NULL, NULL,
    "SENS:PMET:MTIM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_COUPLING =
  {
    RSETL_ATTR_PMET_COUPLING,
    "PWM Frequency Coupling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPmetCoupling, NULL, NULL,
    "SENS:PMET:FREQ:LINK",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_PMET_COUP_CENT,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_ZERO =
  {
    RSETL_ATTR_PMET_ZERO,
    "PWM Zero",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    ":CAL:PMET:ZERO:AUTO ONCE;*WAI",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_UNIT_ABS =
  {
    RSETL_ATTR_PMET_UNIT_ABS,
    "PWM Absolute Unit",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPmetUnitAbs, NULL, NULL,
    "UNIT:PMET:POW",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_DBM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_UNIT_REL =
  {
    RSETL_ATTR_PMET_UNIT_REL,
    "PWM Relative Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPmetUnitRel, NULL, NULL,
    "UNIT:PMET:POW:RAT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_DB,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_STATE =
  {
    RSETL_ATTR_PMET_STATE,
    "PWM Power Meter State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:PMET",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_AVERAGE_AUTO =
  {
    RSETL_ATTR_PMET_AVERAGE_AUTO,
    "PWM Averaging State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:PMET:MTIM:AVER:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_AVERAGE_COUNT =
  {
    RSETL_ATTR_PMET_AVERAGE_COUNT,
    "PWM Averaging Count",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, &rsetl_rngPmetAverCount,
    "SENS:PMET:MTIM:AVER:COUN",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_REF_LEVEL_OFFSET_STATE =
  {
    RSETL_ATTR_PMET_REF_LEVEL_OFFSET_STATE,
    "PWM Reference Level Offset State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:PMET:ROFF:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_BARGRAPH_STATE =
  {
    RSETL_ATTR_PMET_BARGRAPH_STATE,
    "PWM Result Display",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:PMET:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    0,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_RELATIVE =
  {
    RSETL_ATTR_PMET_RELATIVE,
    "PWM Rel/Abs Display",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:PMET:REL:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_READ =
  {
    RSETL_ATTR_PMET_READ,
    "PWM Read Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "READ:PMET?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_PMET_FETCH =
  {
    RSETL_ATTR_PMET_FETCH,
    "PWM Fetch Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "FETC:PMET?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K9",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_MODE =
  {
    RSETL_ATTR_CATV_MODE,
    "CATV Mode",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "INST:SEL CATV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_MEAS_MODE =
  {
    RSETL_ATTR_CATV_MEAS_MODE,
    "CATV Measurement Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVMeasMode, NULL, NULL,
    "SET:TV:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_MEAS_MODE_ATV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_Y_SCALE_AUTO =
  {
    RSETL_ATTR_CATV_Y_SCALE_AUTO,
    "CATV Y Axis Auto Scaling",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "DISP:TRAC:Y:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_EPAT_ZOOM_STATE =
  {
    RSETL_ATTR_CATV_EPAT_ZOOM_STATE,
    "CATV Echo Pattern Zoom State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:ZOOM:EPAT:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_EPAT_ZOOM_FACTOR =
  {
    RSETL_ATTR_CATV_EPAT_ZOOM_FACTOR,
    "CATV Echo Pattern Zoom Factor",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvEpattZoom, NULL,
    "DISP:ZOOM:EPAT",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_EPAT_MEAS_SORT =
  {
    RSETL_ATTR_CATV_EPAT_MEAS_SORT,
    "CATV Echo Pattern Measurement Sorting",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:SORT:TIME:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_MERR_ZOOM =
  {
    RSETL_ATTR_CATV_MERR_ZOOM,
    "CATV Modulation Error Zoom",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvMerrZoom, NULL, NULL,
    "DISP:ZOOM:MERR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_MERR_ZOOM_NONE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_OVER_ZOOM =
  {
    RSETL_ATTR_CATV_OVER_ZOOM,
    "CATV Overview Zoom",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvOverZoom, NULL, NULL,
    "DISP:ZOOM:OVER",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_OVER_ZOOM_NONE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_QUAD_ZOOM =
  {
    RSETL_ATTR_CATV_QUAD_ZOOM,
    "CATV Constellation Diagram Zoom",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvConstDiagZoom, NULL, NULL,
    "DISP:ZOOM:QUAD",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_QUAD_ZOOM_NONE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_TRACE_MODE_FREEZE =
  {
    RSETL_ATTR_CATV_TRACE_MODE_FREEZE,
    "CATV Constellation Diagram Display Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:TRAC{Trace}:MODE:FRE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_X_AXIS_AUTO_SCALING =
  {
    RSETL_ATTR_CATV_X_AXIS_AUTO_SCALING,
    "CATV X Axis Auto Scaling",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:X:SCAL:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DISPLAY_CENTER_POSITION =
  {
    RSETL_ATTR_CATV_DISPLAY_CENTER_POSITION,
    "CATV Display Center Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvDispCenterPos, NULL,
    "DISP:WIND:TRAC:X:SCAL:CENT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DISPAY_DIVISION =
  {
    RSETL_ATTR_CATV_DISPAY_DIVISION,
    "CATV Display Division",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvDivision, NULL,
    "DISP:WIND:TRAC:X:SCAL:DIV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0e-6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_CHANNEL =
  {
    RSETL_ATTR_CATV_CHANNEL,
    "CATV Measurement Channel",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "FREQ:CHAN",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_RF_FREQUENCY =
  {
    RSETL_ATTR_CATV_RF_FREQUENCY,
    "CATV RF Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvRFFreq, NULL,
    "FREQ:RF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    48250000,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_RF_FREQUENCY_STEP_SIZE =
  {
    RSETL_ATTR_CATV_RF_FREQUENCY_STEP_SIZE,
    "CATV RF Frequency Step Size",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "FREQ:STEP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_SWEEP_SPACING =
  {
    RSETL_ATTR_CATV_SWEEP_SPACING,
    "CATV Frequency Axis Labeling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngAbsRel, NULL, NULL,
    "SWE:SPAC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_REL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_SIDE_BAND =
  {
    RSETL_ATTR_CATV_SIDE_BAND,
    "CATV Side Band",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvSBand, NULL, NULL,
    ":DDEM:SBAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_SBAND_AUTO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_MODUL_STANDARD =
  {
    RSETL_ATTR_CATV_MODUL_STANDARD,
    "CATV Modulation Standard",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "TV:MST:NAME",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_MODUL_STANDARD_GDELAY =
  {
    RSETL_ATTR_CATV_MODUL_STANDARD_GDELAY,
    "CATV Modulation Standard Group Delay",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvModStandGroupDelay, NULL, NULL,
    "TV:MST:FILT:GDEL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_GDELAY_GENERAL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_MODUL_STANDARD_SIG_TYPE =
  {
    RSETL_ATTR_CATV_MODUL_STANDARD_SIG_TYPE,
    "CATV Modulation Standard Signal Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvModStandSignalType, NULL, NULL,
    "TV:MST:STYP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_SIG_TYPE_ATV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_PRES_STATE =
  {
    RSETL_ATTR_CATV_PRES_STATE,
    "CATV Preselection State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:PRES:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATT_MODE =
  {
    RSETL_ATTR_CATV_ATT_MODE,
    "CATV Attenuation Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAttMode, NULL, NULL,
    "INP:ATT:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATT_MODE_LNO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_SOUND_CHAN =
  {
    RSETL_ATTR_CATV_SOUND_CHAN,
    "CATV Sound Channel",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvSound, NULL, NULL,
    "SENS:SOUN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_SOUND_A1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_TRIGGER_SOURCE =
  {
    RSETL_ATTR_CATV_GET_TRIGGER_SOURCE,
    "Query CATV Trigger Source",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvTriggerSource, NULL, NULL,
    "TRIG:SEQ:SOUR?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_TRG_IMM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_AUDIO_STATE =
  {
    RSETL_ATTR_CATV_AUDIO_STATE,
    "CATV Audio State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "AUD:VOL:MODE:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_AUDIO_VOLUME =
  {
    RSETL_ATTR_CATV_AUDIO_VOLUME,
    "CATV Audio Volume",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvAudioVolume, NULL,
    "AUD:VOL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -6.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_REFERENCE_LEVEL_AUTO =
  {
    RSETL_ATTR_CATV_REFERENCE_LEVEL_AUTO,
    "CATV Reference Level Auto",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:Y:SCAL:RLEV:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_LEVEL_DISPLAY =
  {
    RSETL_ATTR_CATV_LEVEL_DISPLAY,
    "CATV Level Display",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:Y:SCAL:LEV:REL:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_INPUT_SELECT =
  {
    RSETL_ATTR_CATV_INPUT_SELECT,
    "CATV Input Selection",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:SEL:IQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B201",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_INPUT_SELECT_MPX =
  {
    RSETL_ATTR_CATV_INPUT_SELECT_MPX,
    "CATV Input Selection MPX",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:SEL:MPX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "B201|K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_VISION_MODULATION =
  {
    RSETL_ATTR_CATV_VISION_MODULATION,
    "CATV Vision Modulation",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvVisionMod, NULL, NULL,
    "SENS:ADEM:LOOP:VCAR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_VIS_DET_MPOR,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATTENUATOR_STATE =
  {
    RSETL_ATTR_CATV_ATTENUATOR_STATE,
    "CATV Attenuator State",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:ATT:CHAN:STAT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATTENUATION_DRIVE_MODE =
  {
    RSETL_ATTR_CATV_ATTENUATION_DRIVE_MODE,
    "CATV Attenuation Drive Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:ATT:DRIV:MODE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATTENUATION_DRIVE_RESERVE =
  {
    RSETL_ATTR_CATV_ATTENUATION_DRIVE_RESERVE,
    "CATV Attenuation Drive Reserve",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCATVAttenuationDrive, NULL,
    "INP:ATT:DRIV:RES",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.8,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATTENUATION_DRIVE_HYSTERESIS =
  {
    RSETL_ATTR_CATV_ATTENUATION_DRIVE_HYSTERESIS,
    "CATV Attenuation Drive Hysteresis",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCATVAttenuationDrive, NULL,
    "INP:ATT:DRIV:HYST",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_QUERY_CATV_AMPL_PREAMPLIFIER_STATE =
  {
    RSETL_ATTR_QUERY_CATV_AMPL_PREAMPLIFIER_STATE,
    "Query CATV Amplitude Preamplifier State",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "INP:GAIN:ACT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_MEAS =
  {
    RSETL_ATTR_CATV_ATV_MEAS,
    "CATV Analog TV Measurement",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAtvMeas, NULL, NULL,
    "CONF:ATV:MEAS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_MEAS_ASP,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_MEAS =
  {
    RSETL_ATTR_CATV_ATV_CARR_MEAS,
    "CATV Analog TV Carrier Measurement",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAtvCarrMeas, NULL, NULL,
    "CONF:ATV:{AtvCarrier}:MEAS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_MEAS_CARR_CARR,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_MEAS_MODE =
  {
    RSETL_ATTR_CATV_ATV_MEAS_MODE,
    "CATV Analog TV Carrier Measurement Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAtvCarrMeasMode, NULL, NULL,
    "SENS:ATV:{AtvCarrier}:MEAS:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_MEAS_MODE_INSERVICE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_BWID =
  {
    RSETL_ATTR_CATV_ATV_BWID,
    "CATV Analog TV Carrier Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvAtvBw, NULL,
    ":ATV:{AtvCarrier}:BWID",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    5000000,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_FREQ_NEXT =
  {
    RSETL_ATTR_CATV_ATV_FREQ_NEXT,
    "CATV Analog TV Carrier Next Frequency",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, &rsetl_rngCatvAtvBw, NULL,
    ":ATV:{AtvCarrier}:CFR:NEXT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_NOISE_FLOOR_CORRECTION =
  {
    RSETL_ATTR_CATV_ATV_NOISE_FLOOR_CORRECTION,
    "CATV Analog TV Carrier Noise Floor Correction",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    ":ATV:{AtvCarrier}:POW:NCOR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_REF_CHANNEL_MANUAL =
  {
    RSETL_ATTR_CATV_ATV_REF_CHANNEL_MANUAL,
    "CATV Analog TV Carrier Reference Channel Manual",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    ":ATV:{AtvCarrier}:POW:REF:CHAN:MAN",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_REF_POWER_MANUAL =
  {
    RSETL_ATTR_CATV_ATV_REF_POWER_MANUAL,
    "CATV Analog TV Carrier Reference Power Manual",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvRelPower, NULL,
    ":ATV:{AtvCarrier}:POW:REF:MAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_REF_POWER_MODE =
  {
    RSETL_ATTR_CATV_ATV_REF_POWER_MODE,
    "CATV Analog TV Carrier Reference Power Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAtvRefPowerMode, NULL, NULL,
    ":ATV:{AtvCarrier}:POW:REF:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_RPOW_MODE_MCH,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_HUM_UNIT =
  {
    RSETL_ATTR_CATV_ATV_HUM_UNIT,
    "CATV Analog TV Hum Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngUnitDbPct, NULL, NULL,
    "CALC:ATV:UNIT:POW:HUM",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_DB,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_VCP_UNIT =
  {
    RSETL_ATTR_CATV_ATV_VCP_UNIT,
    "CATV Analog TV Vision Carrier Power Abs Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvPowerUnits, NULL, NULL,
    "CALC:ATV:UNIT:POW:VCP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_DBM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_VMOD_UNIT =
  {
    RSETL_ATTR_CATV_ATV_VMOD_UNIT,
    "CATV Analog TV Vision Modulation Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvPowerUnits, NULL, NULL,
    "CALC:ATV:UNIT:POW:VMOD:VCP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_DBM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_STANDARD =
  {
    RSETL_ATTR_CATV_ATV_STANDARD,
    "CATV Analog TV Standard",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAtvStandard, NULL, NULL,
    "SET:TV:STAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_STAN_BG,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_SOUND_SYSTEM =
  {
    RSETL_ATTR_CATV_ATV_SOUND_SYSTEM,
    "CATV Analog TV Sound System",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAtvSoundSystem, NULL, NULL,
    "SET:TV:STAN:AUD",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_AUDIO_FM55NICAM585,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_COLOR =
  {
    RSETL_ATTR_CATV_ATV_COLOR,
    "CATV Analog TV Color",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAtvColorSystem, NULL, NULL,
    "SET:TV:STAN:COL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_COLOR_SYSTEM_PAL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_TRIGGER_BAR_FIELD =
  {
    RSETL_ATTR_CATV_ATV_TRIGGER_BAR_FIELD,
    "CATV Analog TV Bar Field",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvAtvTriggField, NULL,
    "TRIG:VID:BFI",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE =
  {
    RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE,
    "CATV Analog TV Bar Line",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "TRIG:VID:BLIN",
    // Defaults I32, I64, Float, Bool, String
    18,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE_TYPE =
  {
    RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE_TYPE,
    "CATV Analog TV Bar Line Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvAtvTriggBarLineType, NULL, NULL,
    "TRIG:VID:BLIN:TYPE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_BLIN_TYPE_CCIR17,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_FIELD =
  {
    RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_FIELD,
    "CATV Analog TV Video Scope Active Field",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvAtvTriggField, NULL,
    "TRIG:VID:FIEL",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_LINE =
  {
    RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_LINE,
    "CATV Analog TV Video Scope Line",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "TRIG:VID:LINE",
    // Defaults I32, I64, Float, Bool, String
    17,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_TRIGGER_QLINE_FIELD =
  {
    RSETL_ATTR_CATV_ATV_TRIGGER_QLINE_FIELD,
    "CATV Analog TV Quiet Line Field",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvAtvTriggField, NULL,
    "TRIG:VID:QFI",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_TRIGGER_QUIET_LINE =
  {
    RSETL_ATTR_CATV_ATV_TRIGGER_QUIET_LINE,
    "CATV Analog TV Quiet Line",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "TRIG:VID:QLIN",
    // Defaults I32, I64, Float, Bool, String
    22,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_MEAS_TEST_SIGNAL =
  {
    RSETL_ATTR_CATV_ATV_MEAS_TEST_SIGNAL,
    "CATV Analog TV Measurement Test Signal",
    RS_VAL_WRITE_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvTestSignal, NULL, NULL,
    "SENS:ATV:VME:TSIG {TestSignal},",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_TEST_SIGNAL_T17C,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_ATV_MEAS_TEST_SIGNAL =
  {
    RSETL_ATTR_CATV_GET_ATV_MEAS_TEST_SIGNAL,
    "CATV Get Analog TV Measurement Test Signal",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvTestSignal, NULL, NULL,
    "SENS:ATV:VME:TSIG? {TestSignal}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_AVER_DEPTH =
  {
    RSETL_ATTR_CATV_ATV_AVER_DEPTH,
    "CATV Analog TV Averaging Depth",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, &rsetl_rngCatvAverDepth,
    "CALC:AVER:VME:COUN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_AVER_RESET =
  {
    RSETL_ATTR_CATV_ATV_AVER_RESET,
    "CATV Analog TV Averaging Reset",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:AVER:VME:CLE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_ATV_ACHIEVED_AVER_DEPTH =
  {
    RSETL_ATTR_CATV_GET_ATV_ACHIEVED_AVER_DEPTH,
    "CATV Get Analog TV Achieved Averaging Depth",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "READ:AVER:VME:COUNt?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_RESIDUAL_CARRIER_STATE =
  {
    RSETL_ATTR_CATV_RESIDUAL_CARRIER_STATE,
    "CATV Residual Carrier State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:ADEM:RPC:PDEF:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_RESIDUAL_CARRIER_VALUE =
  {
    RSETL_ATTR_CATV_RESIDUAL_CARRIER_VALUE,
    "CATV Residual Carrier Value",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvResCarr, NULL,
    "SENS:ADEM:RPC:MAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    11.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_SOUND_DEMOD_MODE =
  {
    RSETL_ATTR_CATV_SOUND_DEMOD_MODE,
    "CATV Sound Demodulator Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvSoundMode, NULL, NULL,
    "SENS:ADEM:SOUN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_SOUND_ICAR,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_VIDEO_CLAMPING_MODE =
  {
    RSETL_ATTR_CATV_VIDEO_CLAMPING_MODE,
    "CATV Video Clamping Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvVideoClamp, NULL, NULL,
    "SENS:ADEM:VID:CLAM",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_VIDEO_HARD,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_VIDEO_GEN_STATE =
  {
    RSETL_ATTR_CATV_VIDEO_GEN_STATE,
    "CATV Video Generator State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:ADEM:VGEN:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    "K203",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_VIDEO_GEN_IF_OUT =
  {
    RSETL_ATTR_CATV_VIDEO_GEN_IF_OUT,
    "CATV Video Generator IF Out",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvVideoGenIFOut, NULL, NULL,
    "SENS:ADEM:VGEN:IFO",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_VIDEO_IF_OUT_IFS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    "B201|K203",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_VIDEO_GEN_TEST_PATTERN =
  {
    RSETL_ATTR_CATV_VIDEO_GEN_TEST_PATTERN,
    "CATV Video Generator Test Pattern",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvVideoTestPattern, NULL, NULL,
    "SENS:ADEM:VGEN:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_VIDEO_PATT_CBAR75,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    "K203",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_VIDEO_GEN_USER_DEFINED_IMAGE =
  {
    RSETL_ATTR_CATV_VIDEO_GEN_USER_DEFINED_IMAGE,
    "CATV Video Generator User Defined Image",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "SENS:ADEM:VGEN:CONF:USER{User}:FILE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_TRUE,
    // Models, Options
    NULL,
    "K203",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_WAV_PARAM =
  {
    RSETL_ATTR_CATV_ATV_WAV_PARAM,
    "CATV Analog TV Waveform Parameter",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVWavParam, NULL, NULL,
    "CONF:ATV:MEAS:WAV:PAR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_ATV_VME_LBAR,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_WAV_LOC =
  {
    RSETL_ATTR_CATV_ATV_WAV_LOC,
    "CATV Analog TV Waveform Location",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCATVWavLoc, NULL,
    "CONF:ATV:MEAS:WAV:LOC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_ATV_WAV_POINTS =
  {
    RSETL_ATTR_CATV_GET_ATV_WAV_POINTS,
    "CATV Get Analog TV Waveform Points",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CONF:ATV:MEAS:WAV:LOC:POIN?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_ATV_WAV_CENTER =
  {
    RSETL_ATTR_CATV_GET_ATV_WAV_CENTER,
    "CATV Get Analog TV Waveform Center",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CONF:ATV:MEAS:WAV:LOC{CATVlocation}:CENT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_ATV_WAV_WIDTH =
  {
    RSETL_ATTR_CATV_GET_ATV_WAV_WIDTH,
    "CATV Get Analog TV Waveform Width",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CONF:ATV:MEAS:WAV:LOC{CATVlocation}:WIDT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET =
  {
    RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET,
    "CATV Analog TV Frequency Offset Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvFreqOffset, NULL,
    "CALC:ATV:LIM:CARR:{AtvSoundCarrier}IF:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER =
  {
    RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER,
    "CATV Analog TV Relative Power Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvRelPower, NULL,
    "CALC:ATV:LIM:CARR:{AtvSoundCarrier}PR:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -20.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_LIM_VCF =
  {
    RSETL_ATTR_CATV_ATV_CARR_LIM_VCF,
    "CATV Analog TV Frequency Offset Limit, Vision Carrier",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvFreqOffset, NULL,
    "CALC:ATV:LIM:CARR:VCF:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_LIM_VCP =
  {
    RSETL_ATTR_CATV_ATV_CARR_LIM_VCP,
    "CATV Analog TV Absolute Limit, Vision Carrier",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvAbsPower, NULL,
    "CALC:ATV:LIM:CARR:VCP:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -60.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_CN =
  {
    RSETL_ATTR_CATV_ATV_LIM_CN,
    "CATV Analog TV Carrier to Noise Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvRelPower, NULL,
    "CALC:ATV:LIM:CN:CN:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    40.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_CSO =
  {
    RSETL_ATTR_CATV_ATV_LIM_CSO,
    "CATV Analog TV Carrier to Second Order Beat Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvRelPower, NULL,
    "CALC:ATV:LIM:CSO:CSO:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_CTB =
  {
    RSETL_ATTR_CATV_ATV_LIM_CTB,
    "CATV Analog TV Carrier to Composite Triple Beat Ratio Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvRelPower, NULL,
    "CALC:ATV:LIM:CTB:CTB",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_HUM_LOW =
  {
    RSETL_ATTR_CATV_ATV_LIM_HUM_LOW,
    "CATV Analog TV Hum Limit Lower",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvHumLimitLower, NULL,
    "CALC:ATV:LIM:HUM:HUM:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    40.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_HUM_UPP =
  {
    RSETL_ATTR_CATV_ATV_LIM_HUM_UPP,
    "CATV Analog TV Hum Limit Upper",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvHumLimitUpper, NULL,
    "CALC:ATV:LIM:HUM:HUM:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    40.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP =
  {
    RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP,
    "CATV Analog TV Modulation Depth Limit, Vision Modulation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPct, NULL,
    "CALC:ATV:LIM:VMOD:MDEP:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_VMOD_RPC =
  {
    RSETL_ATTR_CATV_ATV_LIM_VMOD_RPC,
    "CATV Analog TV Residual Pictures Limit, Vision Modulation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPct, NULL,
    "CALC:ATV:LIM:VMOD:RPC:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_VMOD_VCP =
  {
    RSETL_ATTR_CATV_ATV_LIM_VMOD_VCP,
    "CATV Analog TV Vision Carrier Power Limit, Vision Modulation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvAbsPower, NULL,
    "CALC:ATV:LIM:VMOD:VCP:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -60.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_VMOD_LFOF =
  {
    RSETL_ATTR_CATV_ATV_LIM_VMOD_LFOF,
    "CATV Analog TV Line Frequency Offset Limit, Vision Modulation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvVModLFOF, NULL,
    "CALC:ATV:LIM:VMOD:LFOF:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -0.5,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS =
  {
    RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS,
    "CATV Analog TV Analysis Measurement Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvVMELimit, NULL,
    "CALC:ATV:LIM:VME:{ModifLowUpp} {AtvAnalysisMeasValue},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_ATV_LIM_ANALYSIS_MEAS =
  {
    RSETL_ATTR_CATV_GET_ATV_LIM_ANALYSIS_MEAS,
    "CATV Get Analog TV Analysis Measurement Limit",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:LIM:VME:{ModifLowUpp}? {AtvAnalysisMeasValue}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_MIN_MAX =
  {
    RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_MIN_MAX,
    "CATV Analog TV Analysis Measurement Limit Min Max",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:ATV:LIM:VME:{ModifLowUpp} {AtvAnalysisMeasValue},{ModifMinMax}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_ATV_LIM_ANALYSIS_MEAS_MIN_MAX =
  {
    RSETL_ATTR_CATV_GET_ATV_LIM_ANALYSIS_MEAS_MIN_MAX,
    "CATV Get Analog TV Analysis Measurement Limit Min Max",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:LIM:VME:{ModifLowUpp}? {AtvAnalysisMeasValue},{ModifMinMax}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET_RESULT =
  {
    RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET_RESULT,
    "CATV Analog TV Frequency Offset Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:CARR:{AtvSoundCarrier}IF:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER_RESULT =
  {
    RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER_RESULT,
    "CATV Analog TV Relative Power Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:CARR:{AtvSoundCarrier}PR:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_LIM_VCF_RESULT =
  {
    RSETL_ATTR_CATV_ATV_CARR_LIM_VCF_RESULT,
    "CATV Analog TV Frequency Offset Limit, Vision Carrier Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:CARR:VCF:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_LIM_VCP_RESULT =
  {
    RSETL_ATTR_CATV_ATV_CARR_LIM_VCP_RESULT,
    "CATV Analog TV Absolute Limit, Vision Carrier Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:CARR:VCP:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_CN_RESULT =
  {
    RSETL_ATTR_CATV_ATV_LIM_CN_RESULT,
    "CATV Analog TV Carrier to Noise Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:CN:CN:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_CSO_RESULT =
  {
    RSETL_ATTR_CATV_ATV_LIM_CSO_RESULT,
    "CATV Analog TV Carrier to Second Order Beat Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:CSO:CSO:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_CTB_RESULT =
  {
    RSETL_ATTR_CATV_ATV_LIM_CTB_RESULT,
    "CATV Analog TV Carrier to Composite Triple Beat Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:CTB:CTB:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_HUM_RESULT =
  {
    RSETL_ATTR_CATV_ATV_LIM_HUM_RESULT,
    "CATV Analog TV Hum Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:HUM:HUM:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP_RESULT =
  {
    RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP_RESULT,
    "CATV Analog TV Vision Modulation Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:VMOD:{AtvVisionModulResult}:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_RESULT =
  {
    RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_RESULT,
    "CATV Analog TV Analysis Measurement Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:ATV:LIM:RES:VME:{ModifLowUpp}? {AtvAnalysisMeasValue}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_SIGNAL_LOCKED =
  {
    RSETL_ATTR_CATV_ATV_SIGNAL_LOCKED,
    "CATV Get Analog TV Signal Locked",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:ATV:RES:DEMOD:SYNC?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_VCPA =
  {
    RSETL_ATTR_CATV_ATV_CARR_VCPA,
    "CATV Get Analog TV Vision Carrier Power Abs",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:CARR? VCP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_VCF_VALUE =
  {
    RSETL_ATTR_CATV_ATV_CARR_VCF_VALUE,
    "CATV Get Analog TV Vision Carrier Frequency Offset Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:CARR? VCF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_REL_POWER_VALUE =
  {
    RSETL_ATTR_CATV_ATV_CARR_REL_POWER_VALUE,
    "CATV Get Analog TV Sound Carrier Power Rel Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:CARR? {AtvSoundCarrier}PR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CARR_FREQ_OFFSET_VALUE =
  {
    RSETL_ATTR_CATV_ATV_CARR_FREQ_OFFSET_VALUE,
    "CATV Get Analog TV Sound Carrier Intercarrier Frequency Offset Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:CARR? {AtvSoundCarrier}IF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_VALUE =
  {
    RSETL_ATTR_CATV_ATV_VALUE,
    "CATV Get Analog TV Carrier Result Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:{AtvCarrier}? {AtvCarrierResult}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CN_CN_VALUE =
  {
    RSETL_ATTR_CATV_ATV_CN_CN_VALUE,
    "CATV Get Analog TV CN Carrier to Noise Ratio Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:CN? CN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CSO_CSO_VALUE =
  {
    RSETL_ATTR_CATV_ATV_CSO_CSO_VALUE,
    "CATV Get Analog TV CSO Carrier to Second Order Beat Ratio Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:CSO? CSO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_CTB_CTB_VALUE =
  {
    RSETL_ATTR_CATV_ATV_CTB_CTB_VALUE,
    "CATV Get Analog TV CTB Carrier to Composite Triple Beat Ratio Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:CTB? CTB",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_HUM_VALUE =
  {
    RSETL_ATTR_CATV_ATV_HUM_VALUE,
    "CATV Get Analog TV Hum Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:HUM?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE =
  {
    RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE,
    "CATV Get Analog TV Vision Modulation Result Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:VMOD? {AtvVisionModulResult}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_ATV_ANALYSIS_MEAS_VALUE =
  {
    RSETL_ATTR_CATV_GET_ATV_ANALYSIS_MEAS_VALUE,
    "CATV Get Analog TV Analysis Measurement Value",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:ATV:RES:VME? {AtvAnalysisMeasValue}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K202",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS =
  {
    RSETL_ATTR_CATV_DTV_MEAS,
    "CATV Digital TV Measurement",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvMeas, NULL, NULL,
    "CONF:DTV:MEAS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_MEAS_DSP,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SATT =
  {
    RSETL_ATTR_CATV_DTV_SATT,
    "CATV Digital TV Shoulder Measurement",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:DTV:MEAS:SATT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_STATE =
  {
    RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_STATE,
    "CATV Digital TV Out Of Band Emissions State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:DTV:MEAS:OOB",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SATT_GUIDELINE =
  {
    RSETL_ATTR_CATV_DTV_SATT_GUIDELINE,
    "CATV Digital TV Shoulder Measurement Guideline",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVShoulderGuideline, NULL, NULL,
    "CONF:DTV:MEAS:SATT:GUID",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_SHOULDER_GUIDELINE_ETSI,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER_RANGE =
  {
    RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER_RANGE,
    "CATV Digital TV Out Of Band Emissions Transmitter Power Range",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCATVOOBETranPowerRange, NULL,
    "SENS:DTV:SPEC:OOB:MCON:TPR",
    // Defaults I32, I64, Float, Bool, String
    3,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER =
  {
    RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER,
    "CATV Digital TV Out Of Band Emissions Transmitter Power",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:DTV:SPEC:OOB:MCON:TPOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.25,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_MASK_TYPE =
  {
    RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_MASK_TYPE,
    "CATV Digital TV Out Of Band Emissions Mask Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVOOBEMaskType, NULL, NULL,
    "SENS:DTV:SPEC:OOB:MCON:MTYP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_MASK_TYPE_CRIT,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_SHOW_PEAKS =
  {
    RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_SHOW_PEAKS,
    "CATV Digital TV Out Of Band Emissions Show Peaks",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DTV:SPEC:OOB:MSET:SPE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_NOISE_FLOOR_CORRECTION =
  {
    RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_NOISE_FLOOR_CORRECTION,
    "CATV Digital TV Out Of Band Emissions Noise Floor Correction",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DTV:SPEC:OOB:MSET:NFC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_EXTERNAL_NOTCH_FILTER =
  {
    RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_EXTERNAL_NOTCH_FILTER,
    "CATV Digital TV Out Of Band Emissions External Notch Filter",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DTV:SPEC:OOB:MSET:ENF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_COUNTRY =
  {
    RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_COUNTRY,
    "CATV Digital TV Out Of Band Emissions Country",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVOOBECountry, NULL, NULL,
    "SENS:DTV:SPEC:OOB:MCON:COUN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_COUNTRY_JAPAN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FREQ_OFFSET =
  {
    RSETL_ATTR_CATV_DTV_FREQ_OFFSET,
    "CATV Digital TV Frequency Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:DTV:MEAS:SFNF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K241",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SPECTRUM_MARGIN_LIST =
  {
    RSETL_ATTR_CATV_DTV_SPECTRUM_MARGIN_LIST,
    "CATV Digital TV Spectrum Margin List",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:DTV:MEAS:MLIS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_REFERENCE_FREQUENCY =
  {
    RSETL_ATTR_CATV_DTV_REFERENCE_FREQUENCY,
    "CATV Digital TV Reference Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:FREQ:PIL:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CHAN_BAND =
  {
    RSETL_ATTR_CATV_DTV_CHAN_BAND,
    "CATV Digital TV Channel Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:DTV:BAND:CHAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    8.0e6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CHAN_BAND_DVBT =
  {
    RSETL_ATTR_CATV_DTV_CHAN_BAND_DVBT,
    "CATV Digital TV Channel Bandwidth DVBT",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvChanBwid, NULL, NULL,
    "SENS:DTV:BAND:CHAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_CHAN_BWID_5MHZ,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OVERVIEW_SCREEN_SELECT =
  {
    RSETL_ATTR_CATV_DTV_OVERVIEW_SCREEN_SELECT,
    "CATV Digital TV Overview Screen Select",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:MEAS:OVER:TMCC:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_FREQUENCY_START =
  {
    RSETL_ATTR_CATV_DTV_MER_FREQUENCY_START,
    "CATV Digital TV MER Frequency Start",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERFreqStartStopCenter, NULL,
    "DTV:MPN:FOFF:STAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_FREQUENCY_STOP =
  {
    RSETL_ATTR_CATV_DTV_MER_FREQUENCY_STOP,
    "CATV Digital TV MER Frequency Stop",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERFreqStartStopCenter, NULL,
    "DTV:MPN:FOFF:STOP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    2.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_FREQUENCY_CENTER =
  {
    RSETL_ATTR_CATV_DTV_MER_FREQUENCY_CENTER,
    "CATV Digital TV MER Frequency Center",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERFreqStartStopCenter, NULL,
    "DTV:MPN:FOFF:CENT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_FREQUENCY_SPAN =
  {
    RSETL_ATTR_CATV_DTV_MER_FREQUENCY_SPAN,
    "CATV Digital TV MER Frequency Span",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERFreqSpan, NULL,
    "DTV:MPN:FOFF:SPAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_OPTIMIZATION =
  {
    RSETL_ATTR_CATV_DTV_MER_OPTIMIZATION,
    "CATV Digital TV MER Optimization",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:POW:ACH:PRES:RLEV:MER:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EPAT_UNIT =
  {
    RSETL_ATTR_CATV_DTV_EPAT_UNIT,
    "CATV Digital TV Echo Pattern Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngUnitSecMin, NULL, NULL,
    "CALC:DTV:UNIT:POW:EPAT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_SEC,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EPAT_RVEL =
  {
    RSETL_ATTR_CATV_DTV_EPAT_RVEL,
    "CATV Digital TV Echo Pattern Velocity Factor",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvDtvEPattVelocity, NULL,
    "CORR:RVEL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TIME_RANGE_MODE =
  {
    RSETL_ATTR_CATV_DTV_TIME_RANGE_MODE,
    "CATV Digital TV Echo Pattern Time Range Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvTimeRangeMode, NULL, NULL,
    "DISP:WIND:TRAC:X:SCAL:TRAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_RANGE_TIME_MODE_NORM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_THRESHOLD_LINE =
  {
    RSETL_ATTR_CATV_DTV_ECHO_THRESHOLD_LINE,
    "CATV Digital TV Echo Threshold Line",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:MEAS:EPAT:THR:LINE:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_STATE =
  {
    RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_STATE,
    "CATV Digital TV Echo Frequency Offset State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:DTV:MEAS:EPAT:SFNF:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K241|K221|K251|K261|K321|K341",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_MODE =
  {
    RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_MODE,
    "CATV Digital TV Echo Frequency Offset Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVEchoOffMode, NULL, NULL,
    "CONF:DTV:MEAS:EPAT:SFNF:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_STATE_AUTO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K241|K221|K251|K261|K321|K341",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_TRESHOLD =
  {
    RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_TRESHOLD,
    "CATV Digital TV Echo Frequency Offset Treshold",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVEchoOffTreshold, NULL,
    "CONF:DTV:MEAS:EPAT:SFNF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -40.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K241|K221|K251|K261|K321|K341",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQUALIZER_STATE =
  {
    RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQUALIZER_STATE,
    "CATV Digital TV Echo Shortened Equalizer State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:DTV:MEAS:EPAT:MERS:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_TAPS =
  {
    RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_TAPS,
    "CATV Digital TV Echo Shortened Equalizer FFE Length Taps",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVEchoFFETaps, NULL,
    "CONF:DTV:MEAS:EPAT:FFEL:EQT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    15,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_SECONDS =
  {
    RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_SECONDS,
    "CATV Digital TV Echo Shortened Equalizer FFE Length Seconds",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVEchoFFESec, NULL,
    "CONF:DTV:MEAS:EPAT:FFEL:USEC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -2.0e-6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_TAPS =
  {
    RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_TAPS,
    "CATV Digital TV Echo Shortened Equalizer DFE Length Taps",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVEchoDFETaps, NULL,
    "CONF:DTV:MEAS:EPAT:DFEL:EQT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    108,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_SECONDS =
  {
    RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_SECONDS,
    "CATV Digital TV Echo Shortened Equalizer DFE Length Seconds",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVEchoDFESec, NULL,
    "CONF:DTV:MEAS:EPAT:DFEL:USEC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    15.0e-6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ECHO_FREQ_VELOCITY_FACTOR =
  {
    RSETL_ATTR_CATV_DTV_ECHO_FREQ_VELOCITY_FACTOR,
    "CATV Digital TV Echo Velocity Factor",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVVelFactor, NULL,
    "CONF:DTV:MEAS:EPAT:VFAC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EYE_DIAGRAM_TIME_SPAN =
  {
    RSETL_ATTR_CATV_DTV_EYE_DIAGRAM_TIME_SPAN,
    "CATV Digital TV Eye Diagram Time Span",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVEyeDiagramTimeSpan, NULL, NULL,
    "CALC:AVER:TIME:SPAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_TIME_SPAN_S2,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_CONST_SELECT =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_CONST_SELECT,
    "CATV Digital TV ISDB-T Const Select",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVISDBTConstSelect, NULL, NULL,
    "DISP:WIND:SEL:CONS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_CONS_SEL_SUM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_CONTINUAL_SCATTERED_PILOTS =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_CONTINUAL_SCATTERED_PILOTS,
    "CATV Digital TV ISDB-T Constellation Diagram Data Carriers Continual Scattered Pilots",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:SEL:CONS:CARR:CSP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_TMCC =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_TMCC,
    "CATV Digital TV ISDB-T Constellation Diagram Data Carriers TMCC",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:SEL:CONS:CARR:TMCC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC1 =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC1,
    "CATV Digital TV ISDB-T Constellation Diagram Data Carriers AC1",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:SEL:CONS:CARR:ACA",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC2 =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC2,
    "CATV Digital TV ISDB-T Constellation Diagram Data Carriers AC2",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:SEL:CONS:CARR:ACB",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_XAXIS_UNIT =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_XAXIS_UNIT,
    "CATV Digital TV ISDB-T X-Axis Unit",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVISDBTXAxisUnit, NULL, NULL,
    "DISP:WIND:TRAC:X:SCAL:MER:UNIT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_X_AXIS_UNIT_SEG,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ERROR_UNIT =
  {
    RSETL_ATTR_CATV_DTV_ERROR_UNIT,
    "CATV Digital TV Error Measurements Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngUnitDbPct, NULL, NULL,
    "CALC:DTV:UNIT:POW:{DtvErrorMeas}",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_PCT,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_POW_LEV_UNIT =
  {
    RSETL_ATTR_CATV_DTV_POW_LEV_UNIT,
    "CATV Digital TV Root Mean Square Units",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPowLevUnits, NULL, NULL,
    "CALC:DTV:UNIT:POW:LEV",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_DBM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EQUALIZER_STATE =
  {
    RSETL_ATTR_CATV_DTV_EQUALIZER_STATE,
    "CATV Digital TV Equalizer State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DDEM:EQU",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EQUALIZER_COUNT =
  {
    RSETL_ATTR_CATV_DTV_EQUALIZER_COUNT,
    "CATV Digital TV Equalizer Learning Sweeps",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SENS:DDEM:EQU:COUN",
    // Defaults I32, I64, Float, Bool, String
    100,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EQUALIZER_FREEZE =
  {
    RSETL_ATTR_CATV_DTV_EQUALIZER_FREEZE,
    "CATV Digital TV Equalizer Freeze",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DDEM:EQU:FRE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EQUALIZER_MODE =
  {
    RSETL_ATTR_CATV_DTV_EQUALIZER_MODE,
    "CATV Digital TV Equalizer Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvEquMode, NULL, NULL,
    "SENS:DDEM:EQU:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_EQU_MODE_ON,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EQUALIZER_RESET =
  {
    RSETL_ATTR_CATV_DTV_EQUALIZER_RESET,
    "CATV Digital TV Equalizer Reset",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "DDEM:EQU:RES",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE =
  {
    RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE,
    "CATV Digital TV Equalizer Step Size",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvEqualStepSize, NULL, NULL,
    "SENS:DDEM:EQU:SSIZ",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_EQUAL_SSIZE_FINE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE_SHRINK =
  {
    RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE_SHRINK,
    "CATV Digital TV Equalizer Step Size Shrinkage",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvEqualStepSizeShrink, NULL, NULL,
    "SENS:DDEM:EQU:SSIZ:SHR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_EQUAL_SSIZE_SHRINK_NONE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FILTER_ALPHA =
  {
    RSETL_ATTR_CATV_DTV_FILTER_ALPHA,
    "CATV Digital TV Roll Off",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFilterAlpha, NULL, NULL,
    "DDEM:FILT:ALPH",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CATV_DTV_ALPHA_R015,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SRATE =
  {
    RSETL_ATTR_CATV_DTV_SRATE,
    "CATV Digital TV Symbol Rate",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "DDEM:SRAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6900000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_STANDARD =
  {
    RSETL_ATTR_CATV_DTV_STANDARD,
    "CATV Digital TV Standard",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvStandard, NULL, NULL,
    "SET:TV:STAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_STAN_J83A,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    RS_VAL_WAIT_FOR_OPC,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_T2_PROFILE =
  {
    RSETL_ATTR_CATV_DTV_T2_PROFILE,
    "CATV Digital TV T2 Profile",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVT2Profile, NULL, NULL,
    "DTV:T2PR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_T2_PROFILE_T2BASE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FORMAT =
  {
    RSETL_ATTR_CATV_DTV_FORMAT,
    "CATV Digital TV Constellation Parameter",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFormat, NULL, NULL,
    "SOUR:DM:FORM",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_FORMAT_QAM64,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MIN_BER_SAMPLES =
  {
    RSETL_ATTR_CATV_DTV_MIN_BER_SAMPLES,
    "CATV Digital TV Min BER Integration Samples",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvBERSamples, NULL, NULL,
    "CALC:AVER:BER:COUN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_BER_SAMP_10,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DISP_IQ_SAMPLES =
  {
    RSETL_ATTR_CATV_DTV_DISP_IQ_SAMPLES,
    "CATV Digital TV Display IQ Samples",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvDtvIQSamples, NULL,
    "CALC:AVER:SYMB:COUN",
    // Defaults I32, I64, Float, Bool, String
    30000,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_IQ_SOURCE =
  {
    RSETL_ATTR_CATV_DTV_IQ_SOURCE,
    "CATV Digital TV IQ Source",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvIQSource, NULL, NULL,
    "SOUR:DM:IQ:SEL",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_IQ_SRC_PLO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_IQ_CARRIER_TYPE =
  {
    RSETL_ATTR_CATV_DTV_IQ_CARRIER_TYPE,
    "CATV Digital TV IQ Carrier Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngIQCarrierType, NULL, NULL,
    "SOUR:DM:IQ:SRC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_IQ_CARRIER_TYPE_FHON,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DISPLAY_START_SYMBOL =
  {
    RSETL_ATTR_CATV_DTV_DISPLAY_START_SYMBOL,
    "CATV Digital TV Display Start Symbol",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "DDEM:SYMB:STAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DISPLAY_FRAME_COUNT =
  {
    RSETL_ATTR_CATV_DTV_DISPLAY_FRAME_COUNT,
    "CATV Digital TV Display Frame Count",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngDTVDispFrameCell, NULL,
    "CALC:AVER:FRAM:COUN",
    // Defaults I32, I64, Float, Bool, String
    10,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DISPLAY_CELL_COUNT =
  {
    RSETL_ATTR_CATV_DTV_DISPLAY_CELL_COUNT,
    "CATV Digital TV Display Cell Count",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngDTVDispFrameCell, NULL,
    "CALC:AVER:CELL:COUN",
    // Defaults I32, I64, Float, Bool, String
    200000,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_BER_RESET =
  {
    RSETL_ATTR_CATV_DTV_BER_RESET,
    "CATV Digital TV BER Reset",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:AVER:BER:CLE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MLOG_RESET =
  {
    RSETL_ATTR_CATV_DTV_MLOG_RESET,
    "CATV Digital TV Meas Log Reset",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CALC:AVER:MLOG:CLE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_AUTO_DETECTION =
  {
    RSETL_ATTR_CATV_DTV_AUTO_DETECTION,
    "CATV Digital TV Auto Detection",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DDEM:ADET:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARRIER_START =
  {
    RSETL_ATTR_CATV_DTV_CARRIER_START,
    "CATV Digital TV Carrier Start",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:DDEM:CARR:STAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARRIER_STOP =
  {
    RSETL_ATTR_CATV_DTV_CARRIER_STOP,
    "CATV Digital TV Carrier Stop",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:DDEM:CARR:STOP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARRIER_SPAN =
  {
    RSETL_ATTR_CATV_DTV_CARRIER_SPAN,
    "CATV Digital TV Carrier Span",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:DDEM:CARR:SPAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARRIER_CENTER =
  {
    RSETL_ATTR_CATV_DTV_CARRIER_CENTER,
    "CATV Digital TV Carrier Center",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SENS:DDEM:CARR:CENT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARRIER_DATA_STATE =
  {
    RSETL_ATTR_CATV_DTV_CARRIER_DATA_STATE,
    "CATV Digital TV Carrier Data State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DDEM:CARR:DATA",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARRIER_TR_STATE =
  {
    RSETL_ATTR_CATV_DTV_CARRIER_TR_STATE,
    "CATV Digital TV Carrier TR State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DDEM:CARR:TR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARRIER_LOOPS =
  {
    RSETL_ATTR_CATV_DTV_CARRIER_LOOPS,
    "CATV Digital TV Carrier Loops",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvLoops, NULL, NULL,
    "SENS:DDEM:LOOP:CARR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_LOOPS_MED,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARRIER_MODULATION =
  {
    RSETL_ATTR_CATV_DTV_CARRIER_MODULATION,
    "CATV Digital TV Carrier Modulation",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCarrierModulation, NULL, NULL,
    "SENS:DDEM:MOD:CARR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_CARR_MOD_MULT,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CODE_RATE =
  {
    RSETL_ATTR_CATV_DTV_CODE_RATE,
    "CATV Digital TV Code Rate",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCodeRate, NULL, NULL,
    "SENS:DDEM:CRAT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_CODE_RATE_R04,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CODE_RATE_HIGH_PRIOR =
  {
    RSETL_ATTR_CATV_DTV_CODE_RATE_HIGH_PRIOR,
    "CATV Digital TV Code Rate High Priority",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCodeRatePriority, NULL, NULL,
    "SENS:DDEM:CRAT:PRI:HIGH",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_CODE_RATE_PRIOR_R1_2,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CODE_RATE_LOW_PRIOR =
  {
    RSETL_ATTR_CATV_DTV_CODE_RATE_LOW_PRIOR,
    "CATV Digital TV Code Rate Low Priority",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCodeRatePriority, NULL, NULL,
    "SENS:DDEM:CRAT:PRI:LOW",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_CODE_RATE_PRIOR_R1_2,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FEC_SYNC_REQUIRED =
  {
    RSETL_ATTR_CATV_DTV_FEC_SYNC_REQUIRED,
    "CATV Digital TV FEC Sync Required",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFECSync, NULL, NULL,
    "SENS:DDEM:FECS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_FEC_SYNC_FEC,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FIC_SYNC_REQUIRED =
  {
    RSETL_ATTR_CATV_DTV_FIC_SYNC_REQUIRED,
    "CATV Digital TV FIC Sync Required",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFICSync, NULL, NULL,
    "SENS:DDEM:FICS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_FIC_SYNC_FIC,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MPEG_SYNC_REQUIRED =
  {
    RSETL_ATTR_CATV_DTV_MPEG_SYNC_REQUIRED,
    "CATV Digital TV MPEG Sync Required",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvMPGSync, NULL, NULL,
    "SENS:DDEM:MPGS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_MPEG_SYNC_MPG,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FFT_MODE =
  {
    RSETL_ATTR_CATV_DTV_FFT_MODE,
    "CATV Digital TV FFT Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFFTMode, NULL, NULL,
    "SENS:DDEM:FFTM",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_FFT_MODE_F2K,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_GUARD_INTERVAL =
  {
    RSETL_ATTR_CATV_DTV_GUARD_INTERVAL,
    "CATV Digital TV Guard Interval",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvGInterval, NULL, NULL,
    "SENS:DDEM:GINT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_GINT_G420,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_GUARD_INTERVAL_PN =
  {
    RSETL_ATTR_CATV_DTV_GUARD_INTERVAL_PN,
    "CATV Digital TV Guard Interval PN",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvPNSequence, NULL, NULL,
    "SENS:DDEM:GINT:PN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_PN_SEQ_VAR,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_INTERLEAVER =
  {
    RSETL_ATTR_CATV_DTV_INTERLEAVER,
    "CATV Digital TV Interleaver",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvInterleaver, NULL, NULL,
    "SENS:DDEM:INT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_INTERLEAVER_NAT,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LDPC_MODE =
  {
    RSETL_ATTR_CATV_DTV_LDPC_MODE,
    "CATV Digital TV LDPC Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvLDPCMode, NULL, NULL,
    "SENS:DDEM:LDPC:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_LDPC_MODE_NORM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SYMBOL_LOOPS =
  {
    RSETL_ATTR_CATV_DTV_SYMBOL_LOOPS,
    "CATV Digital TV Symbol Loops",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvLoops, NULL, NULL,
    "SENS:DDEM:LOOP:SYMB",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_LOOPS_MED,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_AGC_LOOPS =
  {
    RSETL_ATTR_CATV_DTV_AGC_LOOPS,
    "CATV Digital TV AGC Loops",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvLoops, NULL, NULL,
    "SENS:DDEM:LOOP:AGC",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_LOOPS_MED,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SYSTEM_OPTIMATION =
  {
    RSETL_ATTR_CATV_DTV_SYSTEM_OPTIMATION,
    "CATV Digital TV System Optimation",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvSystOpt, NULL, NULL,
    "SENS:DDEM:SOPT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_SOPT_MOB,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TIME_DEINTERLEAVER =
  {
    RSETL_ATTR_CATV_DTV_TIME_DEINTERLEAVER,
    "CATV Digital TV Time Deinterleaver",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, &rsetl_rngCatvDtvTimeDeinterleaver,
    "SENS:DDEM:TDE",
    // Defaults I32, I64, Float, Bool, String
    48,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MPEG_TS_OUTPUT =
  {
    RSETL_ATTR_CATV_DTV_MPEG_TS_OUTPUT,
    "CATV Digital TV MPEG TS Output",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvTSOutput, NULL, NULL,
    "SENS:DDEM:TSO",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_TSO_HIGH,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DISPLAY_TMCC_NEXT_VALUES =
  {
    RSETL_ATTR_CATV_DTV_DISPLAY_TMCC_NEXT_VALUES,
    "CATV Digital TV Display TMCC Next Values",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:MEAS:OVER:TMCC:NEXT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DATA_ID_MODE =
  {
    RSETL_ATTR_CATV_DTV_DATA_ID_MODE,
    "CATV Digital TV Data ID Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVDataMode, NULL, NULL,
    "DDEM:{DataID}:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_AUTO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DATA_ID_MAN =
  {
    RSETL_ATTR_CATV_DTV_DATA_ID_MAN,
    "CATV Digital TV Data ID Manual",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngDTVDataPLP, NULL,
    "DDEM:{DataID}:MAN",
    // Defaults I32, I64, Float, Bool, String
    3,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_QUERY_CATV_DTV_DATA_ID =
  {
    RSETL_ATTR_QUERY_CATV_DTV_DATA_ID,
    "Query CATV Digital TV Data ID",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "DDEM:{DataID}:AUTO?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_CODE_RATE =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_CODE_RATE,
    "CATV Digital TV ISDB-T Code Rate",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVISDBTCodeRate, NULL, NULL,
    "SENS:DDEM:CRAT:{HierarchicalLayer}",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_FUNC_CODE_RATE_R1_2,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TIME_DEINTERLEAVER =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TIME_DEINTERLEAVER,
    "CATV Digital TV ISDB-T Time Deinterleaver",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, &rsetl_rngCATVISDBTTimeDeinterleaver,
    "SENS:DDEM:TDE:{HierarchicalLayer}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_SEGMENTS =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_SEGMENTS,
    "CATV Digital TV ISDB-T Segments",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCATVISDBTSegments, NULL,
    "SENS:DDEM:SEGM:{HierarchicalLayer}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_ISDBT_SEGMENT_C =
  {
    RSETL_ATTR_CATV_GET_DTV_ISDBT_SEGMENT_C,
    "CATV Get Digital TV ISDB-T Segment C",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SENS:DDEM:SEGM:C?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_MODULATION =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_MODULATION,
    "CATV Digital TV ISDB-T Modulation",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVISDBTModulation, NULL, NULL,
    "SOUR:DM:FORM:{HierarchicalLayer}",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_MODUL_QPSK,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_PARTIAL_RECEPTION =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_PARTIAL_RECEPTION,
    "CATV Digital TV ISDB-T Partial Reception",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DDEM:PREC:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_POSITION =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_POSITION,
    "CATV Digital TV ISDB-T FFT Window Position",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCATVISDBTFFTWindowPosition, NULL, NULL,
    "SENS:DDEM:FFT:WPOS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_WPOS_AUTO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_OFFSET =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_OFFSET,
    "CATV Digital TV ISDB-T FFT Window Offset",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCATVISDBTFFTWindowOffset, NULL,
    "SENS:DDEM:FFT:WOFF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DTMB_SI_POWER_NORMALIZATION =
  {
    RSETL_ATTR_CATV_DTV_DTMB_SI_POWER_NORMALIZATION,
    "CATV Digital TV DTMB SI Power Normalization",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTMBPowerNormalization, NULL, NULL,
    "CONF:DTV:MEAS:SSET:SIP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTMB_POWER_NORMALIZATION_AUTO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_BOOST =
  {
    RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_BOOST,
    "CATV Digital TV DTMB FH Power Boost",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTMBPowerBoost, NULL, NULL,
    "CONF:DTV:MEAS:SSET:FHP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTMB_POWER_BOOST_AUTO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_REFERENCE =
  {
    RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_REFERENCE,
    "CATV Digital TV DTMB FH Power Reference",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTMBPowerReference, NULL, NULL,
    "CONF:DTV:MEAS:SSET:FHPR",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTMB_POWER_REFERENCE_STDC,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DTMB_ESR_TIMEBASE =
  {
    RSETL_ATTR_CATV_DTV_DTMB_ESR_TIMEBASE,
    "CATV Digital TV DTMB ESR Timebase",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, &rsetl_rngDTMBESRTimebase,
    "CONF:DTV:MEAS:SSET:ESRT",
    // Defaults I32, I64, Float, Bool, String
    300,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DTMB_BER_INDICATION =
  {
    RSETL_ATTR_CATV_DTV_DTMB_BER_INDICATION,
    "CATV Digital TV DTMB BER Indication",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTMBBERIndication, NULL, NULL,
    "DISPlay:STAT:BER",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTMB_BER_INDICATION_BERL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DVB_ISSY_PROCESSING =
  {
    RSETL_ATTR_CATV_DTV_DVB_ISSY_PROCESSING,
    "CATV Digital TV DVB ISSY Processing",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVISSYProcessing, NULL, NULL,
    "DDEM:ISSY",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_ISSY_COMPLIANT,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_TRANSMISSION_SYSTEM =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_TRANSMISSION_SYSTEM,
    "CATV Digital TV DVB Transmission System",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVDVBSystem, NULL, NULL,
    "DDEM:TSYS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_TS_SISO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PILOT_PATTERN =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PILOT_PATTERN,
    "CATV Digital TV DVB Pilot Pattern",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVDVBPilPat, NULL, NULL,
    "DDEM:PPAT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_PILOT_PP1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PAPR =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PAPR,
    "CATV Digital TV DVB PAPR",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DDEM:PAPR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_DATA_SYMBOLS =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_DATA_SYMBOLS,
    "CATV Digital TV DVB Data Symbols",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngDTVDVBDataSymbol, NULL,
    "DDEM:LDAT",
    // Defaults I32, I64, Float, Bool, String
    59,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_PAYLOAD_TYPE =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_PAYLOAD_TYPE,
    "CATV Digital TV DVB PLP Payload Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVPLPPayload, NULL, NULL,
    "DDEM:PLP:PTYP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_PLP_TS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_CODE_RATE =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_CODE_RATE,
    "CATV Digital TV DVB PLP Code Rate",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVPLPCodeRate, NULL, NULL,
    "DDEM:PLP:CRAT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_CODE_RATE_12,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MODULATION =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MODULATION,
    "CATV Digital TV DVB PLP Modulation",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVPLPModulation, NULL, NULL,
    "DDEM:PLP:CONS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_PLP_MOD_QAM256,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_ROTATION =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_ROTATION,
    "CATV Digital TV DVB PLP Rotation",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DDEM:PLP:ROT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_FEC_TYPE =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_FEC_TYPE,
    "CATV Digital TV DVB PLP FEC Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngDTVPLPFECType, NULL, NULL,
    "DDEM:PLP:FECT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_PLP_FEC_NORMAL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MAX_BLOCKS =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MAX_BLOCKS,
    "CATV Digital TV DVB PLP Max Blocks",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngDTVPLPBlocks, NULL,
    "DDEM:PLP:TIFB",
    // Defaults I32, I64, Float, Bool, String
    202,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_TI_BLOCKS =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_TI_BLOCKS,
    "CATV Digital TV DVB PLP TI Blocks",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngDTVPLPTIBlocks, NULL,
    "DDEM:PLP:TIL",
    // Defaults I32, I64, Float, Bool, String
    3,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_ATSC_SCAN_SLT =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_ATSC_SCAN_SLT,
    "CATV Digital TV ATSC Scan SLT",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "DDEM:DPAR:SCAN:SLT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_SORT_LIST =
  {
    RSETL_ATTR_CATV_DTV_ATSC_SORT_LIST,
    "CATV Digital TV ATSC Sort List",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISPlay:SORT:SLT:SERV:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_SELECT_PARADE_BY_SERVICE =
  {
    RSETL_ATTR_CATV_DTV_ATSC_SELECT_PARADE_BY_SERVICE,
    "CATV Digital TV ATSC Select Parade By Service",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCATVDigitalTVATSCSelectParadeByService, NULL,
    "DDEM:DPAR:BYS",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_NOISE_GEN_CN_STATE =
  {
    RSETL_ATTR_CATV_DTV_NOISE_GEN_CN_STATE,
    "CATV Digital TV Noise Generator CN State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SOUR:NOIS:CN:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_NOISE_GEN_CN =
  {
    RSETL_ATTR_CATV_DTV_NOISE_GEN_CN,
    "CATV Digital TV Noise Generator CN",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvDtvNoiseGenCN, NULL,
    "SOUR:NOIS:CN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_STATE =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_STATE,
    "CATV Digital TV Meas Log State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:MLOG:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_DISP_PARAM =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_DISP_PARAM,
    "CATV Digital TV Meas Log Display Parameter",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvMLogMode, NULL, NULL,
    "CONF:MLOG:TRAC{MLogTrace}:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_MLOG_MODE_LEV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_MAN =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_MAN,
    "CATV Digital TV Meas Log Span Manual",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvMLogSpan, NULL, NULL,
    "CONF:MLOG:TIME:SPAN:MAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_MLOG_SPAN_T1MIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_AUTO =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_AUTO,
    "CATV Digital TV Meas Log Span Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:MLOG:TIME:SPAN:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_PORT =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_PORT,
    "CATV Digital TV Meas Log GPS Port",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngDTVLogGPSPort, NULL,
    "SYST:COMM:SER:PORT",
    // Defaults I32, I64, Float, Bool, String
    3,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_STATE =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_STATE,
    "CATV Digital TV Meas Log GPS State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SYST:POS:GPS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_CONNECTION_STATE =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_CONNECTION_STATE,
    "CATV Digital TV Meas Log GPS Connection State",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SYST:POS:GPS:CONN?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_HDOP =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_HDOP,
    "CATV Digital TV Meas Log GPS HDOP",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SYST:POS:GPS:QUAL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_SATELLITES =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_SATELLITES,
    "CATV Digital TV Meas Log GPS Satellites",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SYST:POS:GPS:SAT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_VALID_INFO =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_VALID_INFO,
    "CATV Digital TV Meas Log GPS Valid Info",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SYST:POS:VAL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LONGITUDE =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LONGITUDE,
    "CATV Digital TV Meas Log GPS Longitude",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SYST:POS:LONG?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LATITUDE =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LATITUDE,
    "CATV Digital TV Meas Log GPS Latitude",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SYST:POS:LAT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_ALTITUDE =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_ALTITUDE,
    "CATV Digital TV Meas Log GPS Altitude",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "SYST:POS:ALT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_STATUS =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_STATUS,
    "CATV Digital TV Meas Log GPS Status",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngGPSStatus, NULL, NULL,
    "SYST:POS:GPS:VAL?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_GPS_STATUS_OFF,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_DEVICE =
  {
    RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_DEVICE,
    "CATV Digital TV Meas Log GPS Device",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngGPSDevice, NULL, NULL,
    "SYST:POS:GPS:DEV",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_GPS_DEVICE_NONE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_ENABLED =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_ENABLED,
    "CATV Digital TV Meas Log GPS TSMX Enabled",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SYST:POS:GPS:TSMX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_DEAD_RECKONING =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_DEAD_RECKONING,
    "CATV Digital TV Meas Log GPS TSMX Dead Reckoning",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SYST:POS:GPS:TSMX:DREC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_PIN_DIRECTION =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_PIN_DIRECTION,
    "CATV Digital TV Meas Log GPS TSMX Pin Direction",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngGPSPinDirection, NULL, NULL,
    "SYST:POS:GPS:TSMX:DIRP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_GPS_PIN_DIRECTION_FORW,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_STATUS =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_STATUS,
    "CATV Digital TV Meas Log GPS TSMX Gyroscope Status",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngGPSTSMXStatus, NULL, NULL,
    "SYST:POS:GPS:TSMX:STAT:GYR?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_GPS_TSMX_STATUS_INV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_STATUS =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_STATUS,
    "CATV Digital TV Meas Log GPS TSMX Speed Pulse Status",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngGPSTSMXStatus, NULL, NULL,
    "SYST:POS:GPS:TSMX:STAT:SPE?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_GPS_TSMX_STATUS_INV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_CALIBRATION_STATUS =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_CALIBRATION_STATUS,
    "CATV Digital TV Meas Log GPS TSMX Gyroscope Calibration Status",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngGPSTSMXCalibrationStatus, NULL, NULL,
    "SYST:POS:GPS:TSMX:CAL:GYR?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_INV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_CALIBRATION_STATUS =
  {
    RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_CALIBRATION_STATUS,
    "CATV Digital TV Meas Log GPS TSMX Speed Pulse Calibration Status",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngGPSTSMXCalibrationStatus, NULL, NULL,
    "SYST:POS:GPS:TSMX:CAL:SPE?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_GPS_TSMX_CALIBRATION_STATUS_INV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FREQ_RANGE =
  {
    RSETL_ATTR_CATV_DTV_FREQ_RANGE,
    "CATV Digital TV Frequency Range",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "DISP:WIND:TRAC:X:SCAL:FRAN:EXT:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_NOTCH_FILTER =
  {
    RSETL_ATTR_CATV_DTV_NOTCH_FILTER,
    "CATV Digital TV Notch Filter",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DDEM:NRF:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_NOTCH_FILTER_BWIDTH =
  {
    RSETL_ATTR_CATV_DTV_NOTCH_FILTER_BWIDTH,
    "CATV Digital TV Notch Filter Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvNotchBW, NULL, NULL,
    "SENS:DDEM:NRF:NOTC:WIDT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_NOTCH_BW_100,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_NOTCH_FILTER_FREQ =
  {
    RSETL_ATTR_CATV_DTV_NOTCH_FILTER_FREQ,
    "CATV Digital TV Notch Filter Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvDtvNFilterFreq, NULL,
    "SENS:DDEM:NRF:VCAR:FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.75e6,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FIC_RETRIEVE_DATA_SET =
  {
    RSETL_ATTR_CATV_DTV_FIC_RETRIEVE_DATA_SET,
    "CATV Digital TV FIC Retrieve Data Set",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "SENS:DDEM:FIC:ADJ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CN_MEAS_STATE =
  {
    RSETL_ATTR_CATV_DTV_CN_MEAS_STATE,
    "CATV Digital TV CN Measurement State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:DTV:MEAS:CN:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CN_MEAS_FREQUENCY =
  {
    RSETL_ATTR_CATV_DTV_CN_MEAS_FREQUENCY,
    "CATV Digital TV CN Measurement Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVCNFreq, NULL,
    "CONF:DTV:MEAS:CN:FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CN_MEAS_NOISE_BANDWIDTH =
  {
    RSETL_ATTR_CATV_DTV_CN_MEAS_NOISE_BANDWIDTH,
    "CATV Digital TV CN Measurement Noise Bandwith",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVCNBandwidth, NULL,
    "CONF:DTV:MEAS:BAND:NOIS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FIC_SUBCH_SELECT =
  {
    RSETL_ATTR_CATV_DTV_FIC_SUBCH_SELECT,
    "CATV Digital TV FIC Subchannel Select",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SENS:DDEM:FIC:SUBC:SEL",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_FIC_SUBCH_NUMBER =
  {
    RSETL_ATTR_CATV_GET_DTV_FIC_SUBCH_NUMBER,
    "CATV Get Digital TV FIC Subchannel Number",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SENS:DDEM:FIC:SUBC:NUMB?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_NUMBER =
  {
    RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_NUMBER,
    "CATV Get Digital TV FIC Service Number",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SENS:DDEM:FIC:SERV:NUMB?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_COMP_NUMBER =
  {
    RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_COMP_NUMBER,
    "CATV Get Digital TV FIC Service Component Number",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SENS:DDEM:FIC:SCOM{Subchannel}:NUMB?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TRANS_MODE =
  {
    RSETL_ATTR_CATV_DTV_TRANS_MODE,
    "CATV Digital TV Transmission Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvDtvTransMode, NULL,
    "SENS:DDEM:TRAN:MODE",
    // Defaults I32, I64, Float, Bool, String
    1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_AUTO_SUBCH_ORG =
  {
    RSETL_ATTR_CATV_DTV_AUTO_SUBCH_ORG,
    "CATV Digital TV Automatic Subchannel Organization",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DDEM:ADET:SUBC:ORG:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SUBCH_FIRST_CUNIT =
  {
    RSETL_ATTR_CATV_DTV_SUBCH_FIRST_CUNIT,
    "CATV Digital TV Subchannel First Capacity Unit",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvDtvFirstCapacityUnit, NULL,
    "SENS:DDEM:SUBC:STAR:CUN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SUBCH_DATA_RATE =
  {
    RSETL_ATTR_CATV_DTV_SUBCH_DATA_RATE,
    "CATV Digital TV Subchannel Data Rate",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "SENS:DDEM:SUBC:DRAT",
    // Defaults I32, I64, Float, Bool, String
    5,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SUBCH_USE_MPEG =
  {
    RSETL_ATTR_CATV_DTV_SUBCH_USE_MPEG,
    "CATV Digital TV Subchannel Use MPEG Transport Stream",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "SENS:DDEM:SUBC:MPEG:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SUBCH_PROTECTION_LEVEL =
  {
    RSETL_ATTR_CATV_DTV_SUBCH_PROTECTION_LEVEL,
    "CATV Digital TV Subchannel Protection Level",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvProtLevel, NULL, NULL,
    "SENS:DDEM:SUBC:PLEV",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_DTV_PROT_LEV_PL1,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET =
  {
    RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET,
    "CATV Digital TV Carrier Frequency Offset Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvFreqOffset, NULL,
    "CALC:DTV:LIM:CFOF:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_SUPP =
  {
    RSETL_ATTR_CATV_DTV_LIM_SUPP,
    "CATV Digital TV Carrier Suppression Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvCarrSuppression, NULL,
    "CALC:DTV:LIM:CSUP:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    35,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ERR_LOW =
  {
    RSETL_ATTR_CATV_DTV_LIM_ERR_LOW,
    "CATV Digital TV Error Limit Lower",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvErrLimitLower, NULL,
    "CALC:DTV:LIM:{DtvErrorMeas}:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    20.7,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ERR_UPP =
  {
    RSETL_ATTR_CATV_DTV_LIM_ERR_UPP,
    "CATV Digital TV Error Limit Upper",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvErrLimitUpper, NULL,
    "CALC:DTV:LIM:{DtvErrorMeas}:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    22.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_IMB =
  {
    RSETL_ATTR_CATV_DTV_LIM_IMB,
    "CATV Digital TV IQ Imbalance Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvImbLimit, NULL,
    "CALC:DTV:LIM:IMB:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -2.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PJIT =
  {
    RSETL_ATTR_CATV_DTV_LIM_PJIT,
    "CATV Digital TV Phase Jitter Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvPhaseJitterLimit, NULL,
    "CALC:DTV:LIM:PJIT:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    2.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_QERR =
  {
    RSETL_ATTR_CATV_DTV_LIM_QERR,
    "CATV Digital TV Quadrature Error Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvQuadratureErrLimit, NULL,
    "CALC:DTV:LIM:QERR:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -2.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET =
  {
    RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET,
    "CATV Digital TV Symbol Rate Offset Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvSymbRateLimit, NULL,
    "CALC:DTV:LIM:SROF:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -10000,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_SNR =
  {
    RSETL_ATTR_CATV_DTV_LIM_SNR,
    "CATV Digital TV Signal To Noise Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvDtvSNRLimit, NULL,
    "CALC:DTV:LIM:SNR:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BBV =
  {
    RSETL_ATTR_CATV_DTV_LIM_BBV,
    "CATV Digital TV BER Before Viterbi Decoder Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:BBV:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BVF =
  {
    RSETL_ATTR_CATV_DTV_LIM_BVF,
    "CATV Digital TV BER Before Viterbi FIC Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvBVFLimit, NULL,
    "CALC:DTV:LIM:BVF:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BVM =
  {
    RSETL_ATTR_CATV_DTV_LIM_BVM,
    "CATV Digital TV BER Before VIterbi MSC Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvBVFLimit, NULL,
    "CALC:DTV:LIM:BVM:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.01,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BBRS =
  {
    RSETL_ATTR_CATV_DTV_LIM_BBRS,
    "CATV Digital TV BER Before Reed-Solomon Decoder Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:BBRS:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BIT_RATE_OFFSET =
  {
    RSETL_ATTR_CATV_DTV_LIM_BIT_RATE_OFFSET,
    "CATV Digital TV Bit Rate Offset Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvBROFLimit, NULL,
    "CALC:DTV:LIM:BROF:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_LEVEL =
  {
    RSETL_ATTR_CATV_DTV_LIM_LEVEL,
    "CATV Digital TV Level Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvLevelLimit, NULL,
    "CALC:DTV:LIM:LEV:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PER =
  {
    RSETL_ATTR_CATV_DTV_LIM_PER,
    "CATV Digital TV Packet Error Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:PER:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0e-8,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PERR =
  {
    RSETL_ATTR_CATV_DTV_LIM_PERR,
    "CATV Digital TV Packet Error Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvPERRLimit, NULL,
    "CALC:DTV:LIM:PERR:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BER_LDPC =
  {
    RSETL_ATTR_CATV_DTV_LIM_BER_LDPC,
    "CATV Digital TV BER LDPC Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:BERL:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0e-2,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BER_BBCH =
  {
    RSETL_ATTR_CATV_DTV_LIM_BER_BBCH,
    "CATV Digital TV BER BBCH Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:BBCH",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MRLO_LOW =
  {
    RSETL_ATTR_CATV_DTV_LIM_MRLO_LOW,
    "CATV Digital TV MER L1 RMS Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvMERL1Lower, NULL,
    "CALC:DTV:LIM:MRLO:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    24.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MRLO_UPP =
  {
    RSETL_ATTR_CATV_DTV_LIM_MRLO_UPP,
    "CATV Digital TV MER L1 RMS Upper Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvMERL1Upper, NULL,
    "CALC:DTV:LIM:MRLO:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6.3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MPLO_LOW =
  {
    RSETL_ATTR_CATV_DTV_LIM_MPLO_LOW,
    "CATV Digital TV MER L1 Peak Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvMERL1Lower, NULL,
    "CALC:DTV:LIM:MPLO:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MPLO_UPP =
  {
    RSETL_ATTR_CATV_DTV_LIM_MPLO_UPP,
    "CATV Digital TV MER L1 Peak Upper Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvMERL1Upper, NULL,
    "CALC:DTV:LIM:MPLO:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6.3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MRPL =
  {
    RSETL_ATTR_CATV_DTV_LIM_MRPL,
    "CATV Digital TV MER PLP RMS Error Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:MRPL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    24.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MPPL =
  {
    RSETL_ATTR_CATV_DTV_LIM_MPPL,
    "CATV Digital TV MER PLP Peak Error Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:MPPL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT,
    "CATV Digital TV MER Peak Ratio RMS Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERRMSLow, NULL,
    "CALC:DTV:LIM:MPFH:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT,
    "CATV Digital TV MER Peak Ratio RMS Upper Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERRMSUpp, NULL,
    "CALC:DTV:LIM:MPFH:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3.2,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT,
    "CATV Digital TV MER Peak Ratio System Info RMS Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERRMSLow, NULL,
    "CALC:DTV:LIM:MPS:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT,
    "CATV Digital TV MER Peak Ratio System Info RMS Upper Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERRMSUpp, NULL,
    "CALC:DTV:LIM:MPS:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3.2,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT,
    "CATV Digital TV MER Frame Header RMS Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERRMSLow, NULL,
    "CALC:DTV:LIM:MRFH:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    24.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT,
    "CATV Digital TV MER Frame Header RMS Upper Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERRMSUpp, NULL,
    "CALC:DTV:LIM:MRFH:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6.3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT,
    "CATV Digital TV MER System Info RMS Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERRMSLow, NULL,
    "CALC:DTV:LIM:MRS:LOW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    24.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT,
    "CATV Digital TV MER System Info RMS Upper Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngMERRMSUpp, NULL,
    "CALC:DTV:LIM:MRS:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6.3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT,
    "CATV Digital TV MER Amplitude Noise Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVAmplitudeNoiseLowerLimit, NULL,
    "CALC:DTV:LIM:AMPN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    24.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT,
    "CATV Digital TV MER Image Rejection Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngDTVImageRejectionLowerLimit, NULL,
    "CALC:DTV:LIM:IRR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    35.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT =
  {
    RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT,
    "CATV Digital TV MER Phase Noise Lower Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPhaseNoiseLowerLimit, NULL,
    "CALC:DTV:LIM:PHIN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    24.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ERPL =
  {
    RSETL_ATTR_CATV_DTV_LIM_ERPL,
    "CATV Digital TV EVM PLP RMS Error Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:ERPL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    4.4,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_EPPL =
  {
    RSETL_ATTR_CATV_DTV_LIM_EPPL,
    "CATV Digital TV EVM PLP Peak Error Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:EPPL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    22.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW =
  {
    RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW,
    "CATV Digital TV ATSC Overview Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:LIM:ATSM:{ATSCChannel} {ATSCMeasurement},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_CNR =
  {
    RSETL_ATTR_CATV_DTV_LIM_CNR,
    "CATV Digital TV Carrier To Noise Ratio Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvCNRLimit, NULL,
    "CALC:DTV:LIM:CNR:LOW",
    // Defaults I32, I64, Float, Bool, String
    15,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE =
  {
    RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE,
    "CATV Digital TV Pilot Value Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvPilotLimit, NULL,
    "CALC:DTV:LIM:PILV:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    11.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA =
  {
    RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA,
    "CATV Digital TV Signal Pilot Data Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvSignalPilotLimit, NULL,
    "CALC:DTV:LIM:SPV:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR =
  {
    RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR,
    "CATV Digital TV Pilot Amplitude Error Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCatvPilotAmplErrLimit, NULL,
    "CALC:DTV:LIM:PAER:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.2,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATE =
  {
    RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATE,
    "CATV Digital TV ISDB-T Modulation Error Rate Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCATVISDBTMerr, NULL,
    "CALC:DTV:LIM:{ISDBTmerr}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS =
  {
    RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS,
    "CATV Digital TV ISDB-T BER After RS Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngCATVISDBTBARS, NULL,
    "CALC:DTV:LIM:BARS:{ModifLowUpp}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    2.0e-4,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET_RESULT =
  {
    RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET_RESULT,
    "CATV Digital TV Carrier Frequency Offset Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:CFOF:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CARR_LIM_CARR_SUPP_RESULT =
  {
    RSETL_ATTR_CATV_DTV_CARR_LIM_CARR_SUPP_RESULT,
    "CATV Digital TV Carrier Suppression Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:CSUP:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ERROR_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_ERROR_RESULT,
    "CATV Digital TV Error Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:{DtvErrorMeas}:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_FAIL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_IMB_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_IMB_RESULT,
    "CATV Digital TV IQ Imbalance Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:IMB:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PJIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_PJIT_RESULT,
    "CATV Digital TV Phase Jitter Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:PJIT:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_QERR_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_QERR_RESULT,
    "CATV Digital TV Quadrature Error Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:QERR:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET_RESULT,
    "CATV Digital TV Symbol Rate Offset Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:SROF:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_SNR_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_SNR_RESULT,
    "CATV Digital TV Signal To Noise Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:SNR:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BBV_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_BBV_RESULT,
    "CATV Digital TV BER Before Viterbi Decoder Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:BBV:UPP?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BVF_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_BVF_RESULT,
    "CATV Digital TV BER Before Viterbi FIC Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:BVF:UPP?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BVM_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_BVM_RESULT,
    "CATV Digital TV BER Before Viterbi MSC Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:BVM:UPP?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BBRS_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_BBRS_RESULT,
    "CATV Digital TV BER Before Reed-Solomon Decoder Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:BBRS:UPP?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BROF_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_BROF_RESULT,
    "CATV Digital TV Bit Rate Offset Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:BROF:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_FAIL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_LEVEL_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_LEVEL_RESULT,
    "CATV Digital TV Level Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:LEV:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_FAIL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PER_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_PER_RESULT,
    "CATV Digital TV Packet Error Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:PER:UPP?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PERR_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_PERR_RESULT,
    "CATV Digital TV Packet Error Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:PERR:UPP?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BER_LDPC_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_BER_LDPC_RESULT,
    "CATV Digital TV BER LDPC Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:BERL:UPP?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_BER_BBCH_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_BER_BBCH_RESULT,
    "CATV Digital TV BER BBCH Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:BBCH?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MRLO_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_MRLO_RESULT,
    "CATV Digital TV MER L1 RMS Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MRLO:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MPLO_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_MPLO_RESULT,
    "CATV Digital TV MER L1 Peak Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MPLO:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MRPL_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_MRPL_RESULT,
    "CATV Digital TV MER PLP RMS Error Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MRPL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_MPPL_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_MPPL_RESULT,
    "CATV Digital TV MER PLP Peak Error Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MPPL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT_RESULT,
    "CATV Digital TV MER Peak Ratio RMS Lower Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MPFH:LOW?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT_RESULT,
    "CATV Digital TV MER Peak Ratio RMS Upper Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MPFH:UPP?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT,
    "CATV Digital TV MER Peak Ratio System Info RMS Lower Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MPS:LOW?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT,
    "CATV Digital TV MER Peak Ratio System Info RMS Upper Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MPS:UPP?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT_RESULT,
    "CATV Digital TV MER Frame Header RMS Lower Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MRFH:LOW?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT_RESULT,
    "CATV Digital TV MER Frame Header RMS Upper Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MRFH:UPP?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT,
    "CATV Digital TV MER System Info RMS Lower Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MRS:LOW?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT,
    "CATV Digital TV MER System Info RMS Upper Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:MRS:UPP?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT_RESULT,
    "CATV Digital TV MER Amplitude Noise Lower Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:AMPN?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT_RESULT,
    "CATV Digital TV MER Image Rejection Lower Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:IRR?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT_RESULT,
    "CATV Digital TV MER Phase Noise Lower Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:PHIN?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ERPL_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_ERPL_RESULT,
    "CATV Digital TV EVM PLP RMS Error Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:ERPL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_EPPL_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_EPPL_RESULT,
    "CATV Digital TV EVM PLP Peak Error Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:EPPL?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW_RESULT =
  {
    RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW_RESULT,
    "CATV Digital TV ATSC Overview Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:ATSM:{ATSCChannel}? {ATSCMeasurement}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_CNR_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_CNR_RESULT,
    "CATV Digital TV Carrier To Noise Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:CNR:LOW?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE_RESULT,
    "CATV Digital TV Pilot Value Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:PILV:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_FAIL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA_RESULT,
    "CATV Digital TV Signal Pilot Data Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:SPV:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_FAIL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR_RESULT,
    "CATV Digital TV Pilot Amplitude Error Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:PAER:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_FAIL,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_RESULT,
    "CATV Digital TV ISDB-T Modulation Error Ratio Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:{ISDBTmerr}:{HierarchicalLayer}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_CARRIERS_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_CARRIERS_RESULT,
    "CATV Digital TV ISDB-T Modulation Error Ratio Carriers Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:{ISDBTmerr}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS_RESULT =
  {
    RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS_RESULT,
    "CATV Digital TV ISDB-T BER After RS Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:DTV:LIM:RES:BARS:{ModifLowUpp}?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SIGNAL_LOCKED =
  {
    RSETL_ATTR_CATV_DTV_SIGNAL_LOCKED,
    "CATV Get Digital TV Signal Locked",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:DEMOD:SYNC?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MPEG_SIGNAL_LOCKED =
  {
    RSETL_ATTR_CATV_DTV_MPEG_SIGNAL_LOCKED,
    "CATV Get Digital TV MPEG Signal Locked",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:MPEG:SYNC?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_FIC_SYNC_STATUS =
  {
    RSETL_ATTR_CATV_DTV_FIC_SYNC_STATUS,
    "CATV Get Digital TV FIC Sync Status",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:FIC:SYNC?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TPS_MEAS_CONST_SETTING =
  {
    RSETL_ATTR_CATV_DTV_TPS_MEAS_CONST_SETTING,
    "CATV Get Digital TV TPS Measurement Constellation Setting",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFormat, NULL, NULL,
    "CALC:DTV:RES:TPS? CONS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TPS_MEAS_FFT_MODE_SETTING =
  {
    RSETL_ATTR_CATV_DTV_TPS_MEAS_FFT_MODE_SETTING,
    "CATV Get Digital TV TPS Measurement FFT Mode Setting",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFFTMode, NULL, NULL,
    "CALC:DTV:RES:TPS? FFTM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TPS_MEAS_GUARD_INTERVAL_SETTING =
  {
    RSETL_ATTR_CATV_DTV_TPS_MEAS_GUARD_INTERVAL_SETTING,
    "CATV Get Digital TV TPS Measurement Guard Interval Setting",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvGInterval, NULL, NULL,
    "CALC:DTV:RES:TPS? GINT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_SETTING =
  {
    RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_SETTING,
    "CATV Get Digital TV TPS Measurement Code Rate Setting",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCodeRate, NULL, NULL,
    "CALC:DTV:RES:TPS? CRAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_HIGH_PRIOR_SETTING =
  {
    RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_HIGH_PRIOR_SETTING,
    "CATV Get Digital TV TPS Measurement Code Rate High Priority Setting",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCodeRatePriority, NULL, NULL,
    "CALC:DTV:RES:TPS? CRHP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_LOW_PRIOR_SETTING =
  {
    RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_LOW_PRIOR_SETTING,
    "CATV Get Digital TV TPS Measurement Code Rate Low Priority Setting",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCodeRatePriority, NULL, NULL,
    "CALC:DTV:RES:TPS? CRLP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TPS_MEAS_INTERLEAVER_SETTING =
  {
    RSETL_ATTR_CATV_DTV_TPS_MEAS_INTERLEAVER_SETTING,
    "CATV Get Digital TV TPS Measurement Interleaver Setting",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvInterleaver, NULL, NULL,
    "CALC:DTV:RES:TPS? INT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_TPS_MEAS_DEINTERLEAVER_SETTING =
  {
    RSETL_ATTR_CATV_DTV_TPS_MEAS_DEINTERLEAVER_SETTING,
    "CATV Get Digital TV TPS Measurement Time Deinterleaver Setting",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, &rsetl_rngCatvDtvTimeDeinterleaver,
    "CALC:DTV:RES:TPS? DEIN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_APGD_MEAS_RESULT =
  {
    RSETL_ATTR_CATV_DTV_APGD_MEAS_RESULT,
    "CATV Get Digital TV APGD Measurement Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:APGD? {DtvAPGDResult}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_SPEC =
  {
    RSETL_ATTR_CATV_DTV_SPEC,
    "CATV Get Digital TV Spectrum Shoulder Attenuation",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? {DtvShoulderAtt}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ERROR =
  {
    RSETL_ATTR_CATV_DTV_ERROR,
    "CATV Get Digital TV Error",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? {DtvErrorMeas}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OVER_CARR_FREQ_OFFSET =
  {
    RSETL_ATTR_CATV_DTV_OVER_CARR_FREQ_OFFSET,
    "CATV Get Digital TV Overview Carrier Frequency Offset",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? CFOF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OVER_SRATE_OFFSET =
  {
    RSETL_ATTR_CATV_DTV_OVER_SRATE_OFFSET,
    "CATV Get Digital TV Overview Symbol Rate Offset",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? SROF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_OVERVIEW =
  {
    RSETL_ATTR_CATV_DTV_OVERVIEW,
    "CATV Get Digital TV Overview",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? {DtvOverview}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_FFT_MODE =
  {
    RSETL_ATTR_CATV_GET_DTV_FFT_MODE,
    "CATV Get Digital TV FFT Mode",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFFTMode, NULL, NULL,
    "CALC:DTV:RES? FFTM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_GUARD_INTERVAL =
  {
    RSETL_ATTR_CATV_GET_DTV_GUARD_INTERVAL,
    "CATV Get Digital TV Guard Interval",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvGInterval, NULL, NULL,
    "CALC:DTV:RES? GINT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_CODE_RATE =
  {
    RSETL_ATTR_CATV_GET_DTV_CODE_RATE,
    "CATV Get Digital TV Code Rate",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCATVGetDigitalTVCodeRate, NULL, NULL,
    "CALC:DTV:RES? CRAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_CODE_RATE_HIGH_PRIORITY =
  {
    RSETL_ATTR_CATV_GET_DTV_CODE_RATE_HIGH_PRIORITY,
    "CATV Get Digital TV Code Rate High Priority",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCodeRatePriority, NULL, NULL,
    "CALC:DTV:RES? CRHP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_CODE_RATE_LOW_PRIORITY =
  {
    RSETL_ATTR_CATV_GET_DTV_CODE_RATE_LOW_PRIORITY,
    "CATV Get Digital TV Code Rate Low Priority",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvCodeRatePriority, NULL, NULL,
    "CALC:DTV:RES? CRLP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_INTERLEAVER =
  {
    RSETL_ATTR_CATV_GET_DTV_INTERLEAVER,
    "CATV Get Digital TV Interleaver",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvInterleaver, NULL, NULL,
    "CALC:DTV:RES? INT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_TRANSMISSION_MODE =
  {
    RSETL_ATTR_CATV_GET_DTV_TRANSMISSION_MODE,
    "CATV Get Digital TV Transmission Mode",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, &rsetl_rngCatvDtvTransMode, NULL,
    "CALC:DTV:RES? TMOD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_SIDEBAND_POSITION =
  {
    RSETL_ATTR_CATV_GET_DTV_SIDEBAND_POSITION,
    "CATV Get Digital TV Sideband Position",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvSBand, NULL, NULL,
    "CALC:DTV:RES? SBP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_TIME_DEINTERLEAVER =
  {
    RSETL_ATTR_CATV_GET_DTV_TIME_DEINTERLEAVER,
    "CATV Get Digital TV Time Deinterleaver",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, &rsetl_rngCatvDtvTimeDeinterleaver,
    "CALC:DTV:RES? DEIN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_CONTROL_FRAME =
  {
    RSETL_ATTR_CATV_GET_DTV_CONTROL_FRAME,
    "CATV Get Digital TV Control Frame",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCATVGetDigitalTVCFrame, NULL, NULL,
    "CALC:DTV:RES? CFR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_CELL_ID =
  {
    RSETL_ATTR_CATV_GET_DTV_CELL_ID,
    "CATV Get Digital TV Cell ID",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES? CID",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_hex_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_TPS_RESERVED =
  {
    RSETL_ATTR_CATV_GET_DTV_TPS_RESERVED,
    "CATV Get Digital TV TPS Reserved",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES? TPSR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_hex_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DTV_LENGTH_INDICATOR =
  {
    RSETL_ATTR_CATV_GET_DTV_LENGTH_INDICATOR,
    "CATV Get Digital TV Length Indicator",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES? LIND",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_hex_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CONST_VAL =
  {
    RSETL_ATTR_CATV_DTV_CONST_VAL,
    "CATV Get Digital TV Constellation Value",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvFormat, NULL, NULL,
    "CALC:DTV:RESult? CONS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MERR_IMB =
  {
    RSETL_ATTR_CATV_DTV_MERR_IMB,
    "CATV Get Digital TV Amplitude Imbalance",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? IMB",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MERR_QERR =
  {
    RSETL_ATTR_CATV_DTV_MERR_QERR,
    "CATV Get Digital TV Quadrature Error",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? QERR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MERR_CSUP =
  {
    RSETL_ATTR_CATV_DTV_MERR_CSUP,
    "CATV Get Digital TV Carrier Suppression",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? CSUP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MERR_PJIT =
  {
    RSETL_ATTR_CATV_DTV_MERR_PJIT,
    "CATV Get Digital TV Phase Jitter",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? PJIT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MOD_ERRORS =
  {
    RSETL_ATTR_CATV_DTV_MOD_ERRORS,
    "CATV Get Digital TV Mod Errors",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? {DtvModErrors}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_CONST =
  {
    RSETL_ATTR_CATV_DTV_CONST,
    "CATV Get Digital TV Constellation",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? {DtvConstellation}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_VS_CAR =
  {
    RSETL_ATTR_CATV_DTV_MER_VS_CAR,
    "CATV Get Digital TV Mod Error vs Carrier",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? MERF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_RESULT,
    "CATV Get Digital TV MER Phase Noise Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:MPN? {DTVMPnoise}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_IQ_IMBALANCE =
  {
    RSETL_ATTR_CATV_DTV_IQ_IMBALANCE,
    "CATV Get Digital TV IQ Imbalance",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? IMBD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_GET_DIGITAL_TV_ECHO_PATTERN_RESULT =
  {
    RSETL_ATTR_CATV_GET_DIGITAL_TV_ECHO_PATTERN_RESULT,
    "CATV Get Digital TV Echo Pattern Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:EPAT? {DTVEchoPatt}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_INGRESS_DIAGRAM_EQUIVALENT_NOISE_BANDWIDTH =
  {
    RSETL_ATTR_CATV_DTV_INGRESS_DIAGRAM_EQUIVALENT_NOISE_BANDWIDTH,
    "CATV Get Digital TV Ingress Diagram Equivalent Noise Bandwidth",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:INGR? NBW",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_LAYER_SPECIFIC =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_LAYER_SPECIFIC,
    "CATV Get Digital TV ISDB-T Layer Specific",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:{HierarchicalLayer}? {ISDBTmerr}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_SYSTEM_IDENTIFICATION =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_SYSTEM_IDENTIFICATION,
    "CATV Get Digital TV ISDB-T TMCC Overview System Identification",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:DTV:RES:TMCC? SID",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PARAMETER_SWITCHING_INDICATOR =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PARAMETER_SWITCHING_INDICATOR,
    "CATV Get Digital TV ISDB-T TMCC Overview Parameter Switching Indicator",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:DTV:RES:TMCC? PSIN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_EMERGENCY_ALARM_BROADCASTING =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_EMERGENCY_ALARM_BROADCASTING,
    "CATV Get Digital TV ISDB-T TMCC Overview Emergency Alarm Broadcasting",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DTV:RES:TMCC? EMER",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashBoolean_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CURRENT_PARTIAL_RECEPTION =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CURRENT_PARTIAL_RECEPTION,
    "CATV Get Digital TV ISDB-T TMCC Overview Current Partial Reception",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DTV:RES:TMCC? PREC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashBoolean_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NEXT_PARTIAL_RECEPTION =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NEXT_PARTIAL_RECEPTION,
    "CATV Get Digital TV ISDB-T TMCC Overview Next Partial Reception",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DTV:RES:TMCC? NPR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashBoolean_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PHASE_SHIFT_CORRECTION =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PHASE_SHIFT_CORRECTION,
    "CATV Get Digital TV ISDB-T TMCC Overview Phase Shift Correction",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:TMCC? PSH",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_hex_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_RESERVED_BITS =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_RESERVED_BITS,
    "CATV Get Digital TV ISDB-T TMCC Overview Reserved Bits",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:TMCC? RES",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_hex_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_MODULATION =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_MODULATION,
    "CATV Get Digital TV ISDB-T TMCC Overview Modulation",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCATVISDBTModulation, NULL, NULL,
    "CALC:DTV:RES:TMCC:{TMCCNextCurr}:{HierarchicalLayer}? CONS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CODE_RATE =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CODE_RATE,
    "CATV Get Digital TV ISDB-T TMCC Overview Code Rate",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCATVISDBTCodeRate, NULL, NULL,
    "CALC:DTV:RES:TMCC:{TMCCNextCurr}:{HierarchicalLayer}? CRAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_TIME_DEINTERLEAVER =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_TIME_DEINTERLEAVER,
    "CATV Get Digital TV ISDB-T TMCC Overview Time Deinterleaver",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:TMCC:{TMCCNextCurr}:{HierarchicalLayer}? TDE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NUMBER_OF_SEGMENTS =
  {
    RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NUMBER_OF_SEGMENTS,
    "CATV Get Digital TV ISDB-T TMCC Overview Number Of Segments",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, &rsetl_rngCATVISDBTSegments, NULL,
    "CALC:DTV:RES:TMCC:{TMCCNextCurr}:{HierarchicalLayer}? SEGM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DVB_PLP_SYNC_STATE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_DVB_PLP_SYNC_STATE_RESULT,
    "CATV DTV DVB PLP Synchronization State Result",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DTV:RES:PLP:SYNC?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_DVB_T2_RESULT =
  {
    RSETL_ATTR_CATV_DTV_DVB_T2_RESULT,
    "CATV DTV DVB T2 Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES? {DtvDVBT2Result}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_BANDWIDTH_EXTENSION_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_BANDWIDTH_EXTENSION_RESULT,
    "CATV DTV L1 Bandwidth Extension Result",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? BWEX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_GUARD_INTERVAL_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_GUARD_INTERVAL_RESULT,
    "CATV DTV L1 Guard Interval Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvDtvGInterval, NULL, NULL,
    "CALC:DTV:RES:L1PR? GINT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_PILOT_PATTERN_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_PILOT_PATTERN_RESULT,
    "CATV DTV L1 Pilot Pattern Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDTVDVBPilPat, NULL, NULL,
    "CALC:DTV:RES:L1PR? PPAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_TRANSMISSION_SYSTEM_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_TRANSMISSION_SYSTEM_RESULT,
    "CATV DTV L1 Transmission System Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDTVTransSyst, NULL, NULL,
    "CALC:DTV:RES:L1PR? TSYS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_T2_VERSION_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_T2_VERSION_RESULT,
    "CATV DTV L1 T2 Version Result",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? T2V",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_T2_FRAME_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_T2_FRAME_RESULT,
    "CATV DTV L1 T2 Frame Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? {T2Frame}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_POST_CONSTELATION_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_POST_CONSTELATION_RESULT,
    "CATV DTV L1 Post Constelation Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDTVConstelation, NULL, NULL,
    "CALC:DTV:RES:L1PR? CONS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_POST_SIZE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_POST_SIZE_RESULT,
    "CATV DTV L1 Post Size Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? {PostSize}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_POST_EXTENSION_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_POST_EXTENSION_RESULT,
    "CATV DTV L1 Post Extension Result",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? LPEX",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashBoolean_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_POST_REPETITION_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_POST_REPETITION_RESULT,
    "CATV DTV L1 Post Repetition Result",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? LREP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashBoolean_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_POST_CODE_RATE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_POST_CODE_RATE_RESULT,
    "CATV DTV L1 Post Code Rate Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDTVCodeRate, NULL, NULL,
    "CALC:DTV:RES:L1PR? LPCR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_POST_FEC_TYPE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_POST_FEC_TYPE_RESULT,
    "CATV DTV L1 Post FEC Type Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDTVFECType, NULL, NULL,
    "CALC:DTV:RES:L1PR? LPF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_PAPR_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_PAPR_RESULT,
    "CATV DTV L1 PAPR Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngDTVPAPR, NULL, NULL,
    "CALC:DTV:RES:L1PR? PAPR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_STREAM_TYPE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_STREAM_TYPE_RESULT,
    "CATV DTV L1 Stream Type Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCATVDTVL1StreamTypeResult, NULL, NULL,
    "CALC:DTV:RES:L1PR? STYP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_S_BIT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_S_BIT_RESULT,
    "CATV DTV L1 S Bit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? {SBit}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_bin_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_ID_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_ID_RESULT,
    "CATV DTV L1 ID Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? {L1ID}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_hex_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_REGENERATION_FLAG_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_REGENERATION_FLAG_RESULT,
    "CATV DTV L1 Regeneration Flag Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? RFL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_FREQUENCIES_COUNT_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_FREQUENCIES_COUNT_RESULT,
    "CATV DTV L1 Frequencies Count Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_RF_INDEX_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_RF_INDEX_RESULT,
    "CATV DTV L1 RF Index Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? RFIN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_CRC_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_CRC_RESULT,
    "CATV DTV L1 CRC Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? CRC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_hex_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_RESERVED_BITS_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_RESERVED_BITS_RESULT,
    "CATV DTV L1 Reserved Bits Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1PR? RES",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_hex_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_L1_POST_SIGNALING_RESULT =
  {
    RSETL_ATTR_CATV_DTV_L1_POST_SIGNALING_RESULT,
    "CATV DTV L1 Post Signaling Result",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:DTV:RES:L1P? {PostSignaling}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_SYNC_STATE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_ATSC_SYNC_STATE_RESULT,
    "CATV DTV ATSC Synchronization State Result",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:DTV:RES:ATSM:{ATSCChannel}:SYNC?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashBoolean_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_RESULT =
  {
    RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_RESULT,
    "CATV DTV ATSC Overview Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:ATSM:{ATSCChannel}? {ATSCMeasurement}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_PROGRESS =
  {
    RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_PROGRESS,
    "CATV DTV ATSC Overview Progress",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:ATSM:{ATSCChannel}? P{ATSCMeasurement}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_TARGET =
  {
    RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_TARGET,
    "CATV DTV ATSC Overview Target",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:ATSM:{ATSCChannel}? T{ATSCMeasurement}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_ENS_SIG_BIT_RATE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_ATSC_ENS_SIG_BIT_RATE_RESULT,
    "CATV DTV ATSC Ensemble Signaling Bit Rate Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:ATSM:{ATSCChannel}? {BitRate}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_PAY_PAR_BIT_RATE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_ATSC_PAY_PAR_BIT_RATE_RESULT,
    "CATV DTV ATSC Payload Parade Bit Rate Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:DTV:RES:ATSM? {BitRate}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_FIC_DECODED_PARADE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_ATSC_FIC_DECODED_PARADE_RESULT,
    "CATV DTV ATSC FIC Decoded Parade Result",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:DTV:RES:ATSM:FIC:ANAL? DPAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_DTV_ATSC_FIC_ALL_PARADE_RESULT =
  {
    RSETL_ATTR_CATV_DTV_ATSC_FIC_ALL_PARADE_RESULT,
    "CATV DTV ATSC FIC All Parade Result",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:DTV:RES:ATSM:FIC:ANAL? APAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_TV_MEAS =
  {
    RSETL_ATTR_CATV_TV_MEAS,
    "CATV TV Analyzer Measurement",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCatvTvMeas, NULL, NULL,
    "CONF:TV:MEAS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TV_MEAS_TILT,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_TV_CHANNEL =
  {
    RSETL_ATTR_CATV_TV_CHANNEL,
    "CATV TV Analyzer Channel",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CONF:TV:CTAB:SEL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_ACTIVATE =
  {
    RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_ACTIVATE,
    "CATV TV Analyzer Activate Modulation Standard for Tilt",
    RS_VAL_WRITE_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "TV:TILT:MST:CEN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_DEACTIVATE =
  {
    RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_DEACTIVATE,
    "CATV TV Analyzer Deactivate Modulation Standard for Tilt",
    RS_VAL_WRITE_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "TV:TILT:MST:CDIS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    rsetl_quotedString_WriteCallback,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MEASUREMENT =
  {
    RSETL_ATTR_RADIO_MEASUREMENT,
    "Radio Measurement",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioMeas, NULL, NULL,
    "CONF:RAD:MEAS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_MEAS_SPECTRUM,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SPECTRUM_SELECT_MASK =
  {
    RSETL_ATTR_RADIO_SPECTRUM_SELECT_MASK,
    "Radio Spectrum Select Mask",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioSpectrumMask, NULL, NULL,
    "RAD:SPEC:PRAT:MASK",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_SPECTRUM_MASK_PSHQ,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_STANDARD =
  {
    RSETL_ATTR_RADIO_STANDARD,
    "Radio Standard",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioStandard, NULL, NULL,
    "SET:TV:STAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_CHANNEL_BANDWIDTH =
  {
    RSETL_ATTR_RADIO_CHANNEL_BANDWIDTH,
    "Radio Channel Bandwidth",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioBandwidth, NULL, NULL,
    "RAD:BAND:CHAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_BW_150K,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DATA_SYSTEM =
  {
    RSETL_ATTR_RADIO_DATA_SYSTEM,
    "Radio Data System",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioData, NULL, NULL,
    "RAD:DTSY",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_DATA_NONE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SCA_MODE =
  {
    RSETL_ATTR_RADIO_SCA_MODE,
    "Radio SCA Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioSCA, NULL, NULL,
    "RAD:SCA:MODE",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SCA_FREQUENCY =
  {
    RSETL_ATTR_RADIO_SCA_FREQUENCY,
    "Radio SCA Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "RAD:SCA:FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    67.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_PILOT_DEVIATION_TRESHOLD =
  {
    RSETL_ATTR_RADIO_PILOT_DEVIATION_TRESHOLD,
    "Radio Pilot Deviation Treshold",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioPilDeviation, NULL,
    "RAD:FMST:THR:PDEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    500,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_PILOT_NOISE =
  {
    RSETL_ATTR_RADIO_PILOT_NOISE,
    "Radio Pilot Noise",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "RAD:FMST:THR:PNO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OUTPUT_SIGNAL =
  {
    RSETL_ATTR_RADIO_OUTPUT_SIGNAL,
    "Radio Output Signal",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioOutSignal, NULL, NULL,
    "OUTP:RAD:AUD",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_OUTPUT_AUTO,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OUTPUT_DEEMPHASIS =
  {
    RSETL_ATTR_RADIO_OUTPUT_DEEMPHASIS,
    "Radio Output Deemphasis",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioPhasis, NULL, NULL,
    "OUTP:RAD:FILT:DEMP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OUTPUT_DEVIATION =
  {
    RSETL_ATTR_RADIO_OUTPUT_DEVIATION,
    "Radio Output Deviation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioOutDeviation, NULL,
    "OUTP:RAD:ADEM:DEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    40.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OUTPUT_CCVS =
  {
    RSETL_ATTR_RADIO_OUTPUT_CCVS,
    "Radio Output CCVS",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioOutCCVS, NULL, NULL,
    "OUTP:RAD:CCVS",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_OUTPUT_CCVS_OFF,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DUT_INPUT_LEVEL =
  {
    RSETL_ATTR_RADIO_DUT_INPUT_LEVEL,
    "Radio DUT Input Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioDUTLevel, NULL,
    "RAD:AGEN:DUT:INP:LEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DUT_AES_EBU =
  {
    RSETL_ATTR_RADIO_DUT_AES_EBU,
    "Radio DUT AES/EBU",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "RAD:AGEN:DUT:DIG:INP:LEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DUT_DEVIATION =
  {
    RSETL_ATTR_RADIO_DUT_DEVIATION,
    "Radio DUT Deviation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioDUTDeviation, NULL,
    "RAD:AGEN:DUT:DEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    75.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_VERTICAL_SCALING =
  {
    RSETL_ATTR_RADIO_VERTICAL_SCALING,
    "Radio Vertical Scaling",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioYScaling, NULL, NULL,
    "DISPlay:TRAC:Y:RAD:SPAC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SWEEP_POINTS =
  {
    RSETL_ATTR_RADIO_SWEEP_POINTS,
    "Radio Sweep Points",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngRadioSweepPoints, NULL,
    "RAD:SWE:POIN",
    // Defaults I32, I64, Float, Bool, String
    100,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_START_FREQUENCY =
  {
    RSETL_ATTR_RADIO_START_FREQUENCY,
    "Radio Start Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioStart, NULL,
    "RAD:FREQ:STAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_STOP_FREQUENCY =
  {
    RSETL_ATTR_RADIO_STOP_FREQUENCY,
    "Radio Stop Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioStopCenter, NULL,
    "RAD:FREQ:STOP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_CENTER_FREQUENCY =
  {
    RSETL_ATTR_RADIO_CENTER_FREQUENCY,
    "Radio Center Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioStopCenter, NULL,
    "RAD:FREQ:CENT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_FREQUENCY_SPAN =
  {
    RSETL_ATTR_RADIO_FREQUENCY_SPAN,
    "Radio Frequency Span",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioSpan, NULL,
    "RAD:FREQ:SPAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_ZOOM =
  {
    RSETL_ATTR_RADIO_ZOOM,
    "Radio Zoom",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioZoom, NULL, NULL,
    "DISP:RAD:ZOOM",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_ZOOM_NONE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_FREQ_RESPONSE_TYPE =
  {
    RSETL_ATTR_RADIO_FREQ_RESPONSE_TYPE,
    "Radio Freq Response Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioType, NULL, NULL,
    "RAD:FRES:RTYP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_FREQ_RESPONSE_ARMS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_FREQ_RESPONSE_REFERENCE =
  {
    RSETL_ATTR_RADIO_FREQ_RESPONSE_REFERENCE,
    "Radio Freq Response Reference",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioRefFreq, NULL,
    "FREQ:FRES:REF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    500.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_FREQ_RESPONSE_PHASE_RANGE =
  {
    RSETL_ATTR_RADIO_FREQ_RESPONSE_PHASE_RANGE,
    "Radio Freq Response Phase Range",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioPhaseRange, NULL,
    "DISPlay:TRAC:Y:RAD:PHR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    180.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_FREQUENCY_RANGE =
  {
    RSETL_ATTR_RADIO_FREQUENCY_RANGE,
    "Radio Frequency Range",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioFreqRange, NULL,
    "DISPlay:TRAC:Y:RAD:RANG",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_REFERENCE_POSITION =
  {
    RSETL_ATTR_RADIO_REFERENCE_POSITION,
    "Radio Reference Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioRefPos, NULL,
    "DISPlay:TRAC:Y:RAD:RPOS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    200.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_CROSSTALK_TYPE =
  {
    RSETL_ATTR_RADIO_CROSSTALK_TYPE,
    "Radio Crosstalk Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCrosstalkType, NULL, NULL,
    "RAD:CROS:TYPE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CROSSTALK_LINEAR,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_CROSSTALK_REFERENCE =
  {
    RSETL_ATTR_RADIO_CROSSTALK_REFERENCE,
    "Radio Crosstalk Reference",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngCrosstalkReference, NULL, NULL,
    "RAD:CROS:RSIG",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_CROSSTALK_REF_RDEV,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SN_REFERENCE_DEVIATION =
  {
    RSETL_ATTR_RADIO_SN_REFERENCE_DEVIATION,
    "Radio S/N Reference Deviation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioDeviation, NULL,
    "RAD:SN:RDEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    40.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SN_WEIGHTING_FILTER =
  {
    RSETL_ATTR_RADIO_SN_WEIGHTING_FILTER,
    "Radio S/N Weighting Filter",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "RAD:FILT:ITUR:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_REFERENCE_DEVIATION =
  {
    RSETL_ATTR_RADIO_REFERENCE_DEVIATION,
    "Radio Reference Deviation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioDeviation, NULL,
    "RAD:RDEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    75.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT =
  {
    RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT,
    "Radio Power Peak Measurement",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioPowPeakMeas, NULL, NULL,
    "CONF:RAD:MPOW:MLOG:TRAC:MODE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_MPX_POWER_PEAK,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN =
  {
    RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN,
    "Radio MPX Power Time Span",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioMPXTimeSpan, NULL, NULL,
    "CONF:RAD:MPOW:MLOG:TIME:SPAN:MAN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_MPX_TIME_SPAN_T1MIN,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN_AUTO =
  {
    RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN_AUTO,
    "Radio MPX Power Time Span Auto",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CONF:RAD:MPOW:MLOG:TIME:SPAN:AUTO",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_TRUE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K208",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_POWER_REF_POSITION =
  {
    RSETL_ATTR_RADIO_MPX_POWER_REF_POSITION,
    "Radio MPX Power Ref Position",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioMPXRefPos, NULL,
    "DISPlay:TRAC{Trace}:Y:RAD:MPOW:PRP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_POWER_RANGE =
  {
    RSETL_ATTR_RADIO_MPX_POWER_RANGE,
    "Radio MPX Power Range",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioPowerRange, NULL,
    "DISP:TRAC{Trace}:Y:RAD:MPOW:PRAN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_PEAK_DEV_REFERENCE =
  {
    RSETL_ATTR_RADIO_MPX_PEAK_DEV_REFERENCE,
    "Radio MPX Peak Dev Reference",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioPeakDev, NULL,
    "DISPlay:TRAC{Trace}:Y:RAD:MPOW:PDRF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_PEAK_DEV_RANGE =
  {
    RSETL_ATTR_RADIO_MPX_PEAK_DEV_RANGE,
    "Radio MPX Peak Dev Range",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioPeakDev, NULL,
    "DISPlay:TRAC{Trace}:Y:RAD:MPOW:PDRG",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    100.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_SAMPLES =
  {
    RSETL_ATTR_RADIO_MPX_SAMPLES,
    "Radio MPX Samples",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioMPXSamples, NULL, NULL,
    "CONF:RAD:DDIS:MLOG:TRAC:SAMP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_MPX_SAMPLES_PKHOLD,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SAMPLE_COUNT =
  {
    RSETL_ATTR_RADIO_SAMPLE_COUNT,
    "Radio Sample Count",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, &rsetl_rngRadioSampleCount, NULL,
    "CALC:AVER:SAMP:COUN",
    // Defaults I32, I64, Float, Bool, String
    200,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_THD_TOP_LIMIT =
  {
    RSETL_ATTR_RADIO_THD_TOP_LIMIT,
    "Radio THD Top Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "DISPlay:TRAC{Trace}:Y:RAD:THD:TVAL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_THD_BOTTOM_LIMIT =
  {
    RSETL_ATTR_RADIO_THD_BOTTOM_LIMIT,
    "Radio THD Bottom Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "DISPlay:TRAC{Trace}:Y:RAD:THD:BVAL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    -100,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DFD_TOP_LIMIT =
  {
    RSETL_ATTR_RADIO_DFD_TOP_LIMIT,
    "Radio DFD Top Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "DISPlay:TRAC{Trace}:Y:RAD:DFD:TVAL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.1,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DFD_BOTTOM_LIMIT =
  {
    RSETL_ATTR_RADIO_DFD_BOTTOM_LIMIT,
    "Radio DFD Bottom Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "DISPlay:TRAC{Trace}:Y:RAD:DFD:BVAL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SIGNAL_PATH =
  {
    RSETL_ATTR_RADIO_SIGNAL_PATH,
    "Radio Signal Path",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioSignalPath, NULL, NULL,
    "INP:RAD:SPAT",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_PATH_MPX,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DEEMPHASIS =
  {
    RSETL_ATTR_RADIO_DEEMPHASIS,
    "Radio Deemphasis",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioDeemphasis, NULL, NULL,
    "RAD:FILT:DEMP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RADIO_DEEMPHASIS_OFF,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OBW_ADJUST_SETTINGS =
  {
    RSETL_ATTR_RADIO_OBW_ADJUST_SETTINGS,
    "Radio OBW Adjust Settings",
    RS_VAL_WRITE_ONLY,
    RS_VAL_EVENT,
    NULL, NULL, NULL,
    "CONF:RAD:OBW:ADJS",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_TYPE =
  {
    RSETL_ATTR_RADIO_AGEN_TYPE,
    "Radio Audio Generator Type",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioAGenType, NULL, NULL,
    "RAD:AGEN:TYPE",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_AUDIO_GEN_ANALOG,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_SIGNAL =
  {
    RSETL_ATTR_RADIO_AGEN_SIGNAL,
    "Radio Audio Generator Signal",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioAGenSignal, NULL, NULL,
    "RAD:AGEN:SIGN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_AUDIO_SIG_L,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_CONNECTOR_CONFIG =
  {
    RSETL_ATTR_RADIO_AGEN_CONNECTOR_CONFIG,
    "Radio Audio Generator Connector Config",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioAGenConfig, NULL, NULL,
    "RAD:AGEN:CONN:CONF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_AMPLITUDE_DEFINITION =
  {
    RSETL_ATTR_RADIO_AGEN_AMPLITUDE_DEFINITION,
    "Radio Audio Generator Amplitude Definition",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioAGenAmplitude, NULL, NULL,
    "RAD:AGEN:ADEF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_WAVEFORM =
  {
    RSETL_ATTR_RADIO_AGEN_WAVEFORM,
    "Radio Audio Generator Waveform",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioAGenWaveform, NULL, NULL,
    "RAD:AGEN:WAV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_LEVEL =
  {
    RSETL_ATTR_RADIO_AGEN_LEVEL,
    "Radio Audio Generator Level",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioAGenLevel, NULL,
    "RAD:AGEN:LEV{AudioLevel}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_FREQUENCY =
  {
    RSETL_ATTR_RADIO_AGEN_FREQUENCY,
    "Radio Audio Generator Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioAGenFrequency, NULL,
    "RAD:AGEN:FREQ{AudioFrequency}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_FREQUENCY_SPACING =
  {
    RSETL_ATTR_RADIO_AGEN_FREQUENCY_SPACING,
    "Radio Audio Generator Frequency Spacing",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioAGenFreqSpac, NULL,
    "RAD:AGEN:FREQ:SPAC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_FREQUENCY_UPPER =
  {
    RSETL_ATTR_RADIO_AGEN_FREQUENCY_UPPER,
    "Radio Audio Generator Frequency Upper",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioAGenFreqUpp, NULL,
    "RAD:AGEN:FREQ:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    6000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_SUBCARRIER_STATE =
  {
    RSETL_ATTR_RADIO_AGEN_SUBCARRIER_STATE,
    "Radio Audio Generator Subcarrier State",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "RAD:AGEN:DEV:SCAR:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_SUBCARRIER_DEVIATION =
  {
    RSETL_ATTR_RADIO_AGEN_SUBCARRIER_DEVIATION,
    "Radio Audio Generator Subcarrier Deviation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioAGenDeviation, NULL,
    "RAD:AGEN:DEV:SCAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    2.0e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_ALTERNATE_CHANNEL =
  {
    RSETL_ATTR_RADIO_AGEN_ALTERNATE_CHANNEL,
    "Radio Audio Generator Alternate Channel",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "RAD:AGEN:ALT:LR:STAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_DUT_PREEMPHASIS =
  {
    RSETL_ATTR_RADIO_AGEN_DUT_PREEMPHASIS,
    "Radio Audio Generator DUT Preemphasis",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngRadioPhasis, NULL, NULL,
    "RAD:AGEN:DUT:PREM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AGEN_DUT_DEVIATION =
  {
    RSETL_ATTR_RADIO_AGEN_DUT_DEVIATION,
    "Radio Audio Generator DUT Deviation",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioAGenDUTDeviation, NULL,
    "RAD:AGEN:DUT:DES:DEV{DUTDeviation}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    7.5e3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT,
    "Radio Overview Level Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:OVER:{LimitType} LEV,",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT,
    "Radio Overview CF Offset Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:OVER:{LimitType} CFOF,",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT,
    "Radio Overview AM ModulationLimit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:OVER:{LimitType} AMMD,",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT,
    "Radio Overview MPX Deviaton Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:OVER:{LimitType} {MPXDev},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT,
    "Radio Overview Pilot Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:OVER:{LimitType} {Pilot},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT,
    "Radio Overview RDS Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:OVER:{LimitType} RDS{RDS},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT,
    "Radio Overview DARC Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:OVER:{LimitType} DARC,",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT,
    "Radio Overview SCA Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:OVER:{LimitType} {SCA},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AUDIO_SN_LIMIT =
  {
    RSETL_ATTR_RADIO_AUDIO_SN_LIMIT,
    "Radio Audio SN Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioSNTHDLimit, NULL,
    "CALC:RAD:LIM:SN{LimitChannel}:LOW {SN},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    66.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AUDIO_THD_LIMIT =
  {
    RSETL_ATTR_RADIO_AUDIO_THD_LIMIT,
    "Radio Audio THD Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioSNTHDLimit, NULL,
    "CALC:RAD:LIM:THD{LimitChannel}:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    50.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT =
  {
    RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT,
    "Radio Audio DFD Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioDFDLimit, NULL,
    "CALC:RAD:LIM:DFD{LimitChannel}:UPP {DFD},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    2.9,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_POW_LIMIT =
  {
    RSETL_ATTR_RADIO_MPX_POW_LIMIT,
    "Radio MPX Power Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioMPXLimit, NULL,
    "CALC:RAD:LIM:MPOW:UPP MPOW,",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_PEAK_LIMIT =
  {
    RSETL_ATTR_RADIO_MPX_PEAK_LIMIT,
    "Radio MPX Peak Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioMPXPeakLimit, NULL,
    "CALC:RAD:LIM:MPOW:UPP PDEV,",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    3,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT =
  {
    RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT,
    "Radio MPX Deviation Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioMPXDeviationLimit, NULL,
    "CALC:RAD:LIM:DVI:LIM",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    75000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT_RATIO =
  {
    RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT_RATIO,
    "Radio MPX Deviation Limit Ratio",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngPct, NULL,
    "CALC:RAD:LIM:DVI:RAT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0001,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OBW_UPPER_LIMIT =
  {
    RSETL_ATTR_RADIO_OBW_UPPER_LIMIT,
    "Radio OBW Upper Limit",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngRadioMPXOBWUpperLimit, NULL,
    "CALC:RAD:LIM:OBW:UPP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    180000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MP_DETECTION_LIMIT =
  {
    RSETL_ATTR_RADIO_MP_DETECTION_LIMIT,
    "Radio MP Detection Limit",
    RS_VAL_WRITE_ONLY,
    RS_VAL_REAL64,
    NULL, &rsetl_rngrsetl_rngRadioMPDetectLimit, NULL,
    "CALC:RAD:LIM:MDET:UPP {MPD},",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DFD_UNIT =
  {
    RSETL_ATTR_RADIO_DFD_UNIT,
    "Radio DFD Unit",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPmetUnitRel, NULL, NULL,
    "CALC:RAD:UNIT:DFD",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_DB,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_THD_UNIT =
  {
    RSETL_ATTR_RADIO_THD_UNIT,
    "RadioTHD Unit",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngPmetUnitRel, NULL, NULL,
    "CALC:RAD:UNIT:THD",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_UNIT_DB,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110|K111",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_LEVEL_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_LEVEL_RESULT,
    "Radio Overview Level Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OVER? LEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_RESULT,
    "Radio Overview CF Offset Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OVER? CFOF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_RESULT,
    "Radio Overview AM Modulation Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OVER? AMMD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_RESULT,
    "Radio Overview MPX Deviaton Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OVER? {MPXDev}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_PILOT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_PILOT_RESULT,
    "Radio Overview Pilot Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OVER? {Pilot}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_RDS_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_RDS_RESULT,
    "Radio Overview RDS Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OVER? RDS{RDS}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_DARC_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_DARC_RESULT,
    "Radio Overview DARC Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OVER? DARC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_SCA_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_SCA_RESULT,
    "Radio Overview SCA Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OVER? {SCA}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AUDIO_SCOPE_RESULT =
  {
    RSETL_ATTR_RADIO_AUDIO_SCOPE_RESULT,
    "Radio Audio Scope Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:ASC? {AudioScope}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SPECTRUM_RESULT_SINAD =
  {
    RSETL_ATTR_RADIO_SPECTRUM_RESULT_SINAD,
    "Radio Spectrum Result SINAD",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:ASP? SIN{AudioChannel}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SPECTRUM_RESULT_THD =
  {
    RSETL_ATTR_RADIO_SPECTRUM_RESULT_THD,
    "Radio Spectrum Result THD",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:ASP? THD{AudioChannel}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SPECTRUM_RESULT_MOD_FREQ =
  {
    RSETL_ATTR_RADIO_SPECTRUM_RESULT_MOD_FREQ,
    "Radio Spectrum Result Modulation Frequency",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:ASP? MFR{AudioChannel}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SPECTRUM_RESULT_SC_FREQ_OFFSET =
  {
    RSETL_ATTR_RADIO_SPECTRUM_RESULT_SC_FREQ_OFFSET,
    "Radio Spectrum Result SC Frequency Offset",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:ASP? SCF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_POWER_PEAK_CURRENT_RESULT =
  {
    RSETL_ATTR_RADIO_POWER_PEAK_CURRENT_RESULT,
    "Radio Power Peak Current Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:MPOW? {PowerPeak}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_POWER_PEAK_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_POWER_PEAK_LIMIT_RESULT,
    "Radio Power Peak Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:MPOW:TLIM? {PowerPeak}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_RATIO_RESULT =
  {
    RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_RATIO_RESULT,
    "Radio MPX Deviation Violation Ratio Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:DVI:RAT?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_VIOLATING_RESULT =
  {
    RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_VIOLATING_RESULT,
    "Radio MPX Deviation Violation Samples Violating Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:RES:DVI:VSAM?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_TOTAL_RESULT =
  {
    RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_TOTAL_RESULT,
    "Radio MPX Deviation Violation Samples Total Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:RES:DVI:TSAM?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_DEVIATION_RAW_VIOLATION_SAMPLES_RESULT =
  {
    RSETL_ATTR_RADIO_MPX_DEVIATION_RAW_VIOLATION_SAMPLES_RESULT,
    "Radio MPX Deviation Raw Samples Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:RES:DDIS:RSAM?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MULTIPATH_DETECTION_RESULT =
  {
    RSETL_ATTR_RADIO_MULTIPATH_DETECTION_RESULT,
    "Radio Multipath Detection Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:MDET? {MPD}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_SYNC =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_SYNC,
    "Radio RDS Result Sync",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? SYNC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_PID =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_PID,
    "Radio RDS Result PID",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? PID",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_NAME =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_NAME,
    "Radio RDS Result Name",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? PSN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_ECC =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_ECC,
    "Radio RDS Result ECC",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? ECC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_COUNTRY =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_COUNTRY,
    "Radio RDS Result Country",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? COUN",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_FLAG =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_FLAG,
    "Radio RDS Result Flag",
    RS_VAL_READ_ONLY,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? {RDSFlag}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashBoolean_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_PTYPE =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_PTYPE,
    "Radio RDS Result Program Type",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? PTYP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "type",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_DID =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_DID,
    "Radio RDS Result DID",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? DID",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashInt_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_RDS_RESULT_DATE_TIME =
  {
    RSETL_ATTR_RADIO_RDS_RESULT_DATE_TIME,
    "Radio RDS Result Date Time",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "CALC:RAD:RES:RDS? {RDSDateTime}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OBW_RESULT =
  {
    RSETL_ATTR_RADIO_OBW_RESULT,
    "Radio OBW Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:OBW?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_AMPLIITUDE =
  {
    RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_AMPLIITUDE,
    "Radio Freq Response Result Amplitude",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:FRES{AudioChannel}? {AudioPosNeg}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_PHASE =
  {
    RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_PHASE,
    "Radio Freq Response Result Phase",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:FRES{AudioChannel}? P{AudioPosNeg}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_FREQUENCY =
  {
    RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_FREQUENCY,
    "Radio Freq Response Result Frequency",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:FRES{AudioChannel}? F{AudioPosNeg}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_CROSSTALK_RESULT =
  {
    RSETL_ATTR_RADIO_CROSSTALK_RESULT,
    "Radio Crosstalk Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:CROS{AudioChannel}? {AudioCrosstalk}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_SN_RESULT =
  {
    RSETL_ATTR_RADIO_SN_RESULT,
    "Radio SN Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:SN{AudioChannel}? {SN}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_THD_RESULT =
  {
    RSETL_ATTR_RADIO_THD_RESULT,
    "Radio THD Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:THD{AudioChannel}? {THD}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_DFD_RESULT =
  {
    RSETL_ATTR_RADIO_DFD_RESULT,
    "Radio DFD Result",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "CALC:RAD:RES:DFD{AudioChannel}? {DFD}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K111",
    // Callbacks Read, Write, p2Value
    rsetl_dashReal_ReadCallback,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT_RESULT,
    "Radio Overview Level Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OVER:{LimitType}? LEV",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT_RESULT,
    "Radio Overview CF Offset Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OVER:{LimitType}? CFOF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT_RESULT,
    "Radio Overview AM ModulationLimit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OVER:{LimitType}? AMMD",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT_RESULT,
    "Radio Overview MPX Deviaton Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OVER:{LimitType}? {MPXDev}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT_RESULT,
    "Radio Overview Pilot Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OVER:{LimitType}? {Pilot}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT_RESULT,
    "Radio Overview RDS Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OVER:{LimitType}? RDS{RDS}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT_RESULT,
    "Radio Overview DARC Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OVER:{LimitType}? DARC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT_RESULT,
    "Radio Overview SCA Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OVER:{LimitType}? {SCA}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MPX_POW_PEAK_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_MPX_POW_PEAK_LIMIT_RESULT,
    "Radio MPX Power Peak Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:RES:MPOW:UPP? {PowerPeak}",
    // Defaults I32, I64, Float, Bool, String
    3,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_OBW_UPPER_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_OBW_UPPER_LIMIT_RESULT,
    "Radio OBW Upper Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    &rsetl_rngCatvResults, NULL, NULL,
    "CALC:RAD:LIM:RES:OBW:UPP?",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_RES_PASS,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_MP_DETECTION_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_MP_DETECTION_LIMIT_RESULT,
    "Radio MP Detection Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:RES:MDET:UPP? {MPD}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AUDIO_SN_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_AUDIO_SN_LIMIT_RESULT,
    "Radio Audio SN Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:RES:SN{LimitChannel}:LOW? {SN}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AUDIO_THD_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_AUDIO_THD_LIMIT_RESULT,
    "Radio Audio THD Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:RES:THD{LimitChannel}:UPP?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT_RESULT =
  {
    RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT_RESULT,
    "Radio Audio DFD Limit Result",
    RS_VAL_READ_ONLY,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "CALC:RAD:LIM:RES:DFD{LimitChannel}:UPP? {DFD}",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_TRUE,
    // Models, Options
    NULL,
    "K110",
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_RECORDER_MODE =
  {
    RSETL_ATTR_TS_GENERATOR_RECORDER_MODE,
    "TS Generator Recorder Mode",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTSGeneratorRecorderMode, NULL, NULL,
    "TSG:CONF:PREP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TSGEN_REC_MODE_GENERATOR,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_RECORDER_STATUS =
  {
    RSETL_ATTR_TS_GENERATOR_RECORDER_STATUS,
    "TS Generator Recorder Status",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTSGeneratorRecorderStatus, NULL, NULL,
    "TSG:CONF:COMM",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TSGEN_REC_STATUS_STOP,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_SELECT_FILE =
  {
    RSETL_ATTR_TS_GENERATOR_SELECT_FILE,
    "TS Generator Select File",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "TSG:CONF:PLAY",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "myfile",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_DATA_RATE =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_DATA_RATE,
    "TS Generator Timing Data Rate",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "TSG:CONF:TSR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    10000000.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_NULLPACKET_STUFFING =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_NULLPACKET_STUFFING,
    "TS Generator Timing Nullpacket Stuffing",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TSG:CONF:STUF",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_START =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_START,
    "TS Generator Timing Play Window Start",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "TSG:CONF:SEEK:STAR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_STOP =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_STOP,
    "TS Generator Timing Play Window Stop",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "TSG:CONF:SEEK:STOP",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_POSITION =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_POSITION,
    "TS Generator Timing Play Window Position",
    RS_VAL_READ_ONLY,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "TSG:CONF:SEEK:POS?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER,
    "TS Generator Timing PCR Jitter",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TSG:CONF:JITT:PCR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_WAVEFORM =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_WAVEFORM,
    "TS Generator Timing PCR Jitter Waveform",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTSGeneratorWaveform, NULL, NULL,
    "TSG:CONF:JITT:PCR:WAV",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TSGEN_WAVEFORM_SINE,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_AMPLITUDE =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_AMPLITUDE,
    "TS Generator Timing PCR Jitter Amplitude",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, NULL, NULL,
    "TSG:CONF:JITT:PCR:AMPL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0005,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_FREQUENCY =
  {
    RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_FREQUENCY,
    "TS Generator Timing PCR Jitter Frequency",
    RS_VAL_READ_WRITE,
    RS_VAL_REAL64,
    NULL, &rsetl_rngTSGeneratorPCRJitterFrequency, NULL,
    "TSG:CONF:JITT:PCR:FREQ",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    1.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_CONTINUITY_COUNTER =
  {
    RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_CONTINUITY_COUNTER,
    "TS Generator Seamless Loop Continuity Counter",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TSG:CONF:SEAM:CC",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_PCR =
  {
    RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_PCR,
    "TS Generator Seamless Loop PCR",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TSG:CONF:SEAM:PCR",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_TDT_TOT =
  {
    RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_TDT_TOT,
    "TS Generator Seamless Loop TDT/TOT",
    RS_VAL_READ_WRITE,
    RS_VAL_BOOLEAN,
    NULL, NULL, NULL,
    "TSG:CONF:SEAM:TT",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_INTERFACE_PACKET_LENGTH =
  {
    RSETL_ATTR_TS_GENERATOR_INTERFACE_PACKET_LENGTH,
    "TS Generator Interface Packet Length",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTSGeneratorPacketLength, NULL, NULL,
    "TSG:CONF:PLEN",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TSGEN_PACKET_LENGTH_P188,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_GENERATOR_INTERFACE_SERIAL_OUTPUT =
  {
    RSETL_ATTR_TS_GENERATOR_INTERFACE_SERIAL_OUTPUT,
    "TS Generator Interface Serial Output",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTSGeneratorSerialOutput, NULL, NULL,
    "TSG:CONF:ASIF",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TSGEN_SERIAL_OUTPUT_ASIC,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_RECORDER_INPUT =
  {
    RSETL_ATTR_TS_RECORDER_INPUT,
    "TS Recorder Input",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    &rsetl_rngTSRecorderInput, NULL, NULL,
    "TSG:CONF:REC:INP",
    // Defaults I32, I64, Float, Bool, String
    RSETL_VAL_TSREC_INPUT_ASII,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_RECORDER_FILE_SIZE =
  {
    RSETL_ATTR_TS_RECORDER_FILE_SIZE,
    "TS Recorder File Size",
    RS_VAL_READ_WRITE,
    RS_VAL_INT32,
    NULL, NULL, NULL,
    "TSG:CONF:REC:SIZE",
    // Defaults I32, I64, Float, Bool, String
    20,
    0,
    0.0,
    VI_FALSE,
    NULL,
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_TS_RECORDER_FILE_NAME =
  {
    RSETL_ATTR_TS_RECORDER_FILE_NAME,
    "TS Recorder File Name",
    RS_VAL_READ_WRITE,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "TSG:CONF:REC:FIL",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "myfile",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };

RsCoreAttribute  g_RSETL_ATTR_ID_QUERY_RESPONSE =
  {
    RSETL_ATTR_ID_QUERY_RESPONSE,
    "ID Query Response",
    RS_VAL_READ_ONLY,
    RS_VAL_STRING,
    NULL, NULL, NULL,
    "*IDN?",
    // Defaults I32, I64, Float, Bool, String
    0,
    0,
    0.0,
    VI_FALSE,
    "ETL",
    // Flags, HasRepCaps
    0,
    VI_FALSE,
    // Models, Options
    NULL,
    NULL,
    // Callbacks Read, Write, p2Value
    NULL,
    NULL,
    NULL,
  };


/*****************************************************************************
 *- Attributes List ---------------------------------------------------------*
 *****************************************************************************/

ViInt32 rsetl_RsCoreAttributeListLength = 1057;

RsCoreAttributePtr rsetl_RsCoreAttributeList[1057] =
  {
    &g_RSETL_RS_ATTR_RANGE_CHECK,
    &g_RSETL_RS_ATTR_QUERY_INSTRUMENT_STATUS,
    &g_RSETL_RS_ATTR_SIMULATE,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_DESCRIPTION,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_PREFIX,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_LOCATOR,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_VENDOR,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_REVISION,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MAJOR_VERSION,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MINOR_VERSION,
    &g_RSETL_RS_ATTR_SUPPORTED_INSTRUMENT_MODELS,
    &g_RSETL_RS_ATTR_GROUP_CAPABILITIES,
    &g_RSETL_RS_ATTR_FUNCTION_CAPABILITIES,
    &g_RSETL_RS_ATTR_CHANNEL_COUNT,
    &g_RSETL_RS_ATTR_DRIVER_SETUP,
    &g_RSETL_RS_ATTR_INSTRUMENT_MANUFACTURER,
    &g_RSETL_RS_ATTR_INSTRUMENT_MODEL,
    &g_RSETL_RS_ATTR_INSTRUMENT_FIRMWARE_REVISION,
    &g_RSETL_RS_ATTR_OPTIONS_LIST,
    &g_RSETL_RS_ATTR_IO_RESOURCE_DESCRIPTOR,
    &g_RSETL_RS_ATTR_LOGICAL_NAME,
    &g_RSETL_RS_ATTR_PRIMARY_ERROR,
    &g_RSETL_RS_ATTR_SECONDARY_ERROR,
    &g_RSETL_RS_ATTR_ERROR_ELABORATION,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_MAJOR_VERSION,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_MINOR_VERSION,
    &g_RSETL_RS_ATTR_SPECIFIC_DRIVER_MINOR_MINOR_VERSION,
    &g_RSETL_RS_ATTR_CLASS_DRIVER_MAJOR_VERSION,
    &g_RSETL_RS_ATTR_CLASS_DRIVER_MINOR_VERSION,
    &g_RSETL_RS_ATTR_ENGINE_MAJOR_VERSION,
    &g_RSETL_RS_ATTR_ENGINE_MINOR_VERSION,
    &g_RSETL_RS_ATTR_ENGINE_REVISION,
    &g_RSETL_RS_ATTR_OPC_TIMEOUT,
    &g_RSETL_ATTR_AMPLITUDE_UNITS,
    &g_RSETL_ATTR_INSTR_MODE,
    &g_RSETL_ATTR_ATTENUATION,
    &g_RSETL_ATTR_ATTENUATION_AUTO,
    &g_RSETL_ATTR_FREQUENCY_START,
    &g_RSETL_ATTR_FREQUENCY_STOP,
    &g_RSETL_ATTR_FREQUENCY_OFFSET,
    &g_RSETL_ATTR_FREQUENCY_CENTER,
    &g_RSETL_ATTR_FREQUENCY_CENTER_STEP,
    &g_RSETL_ATTR_FREQUENCY_STEP_AUTO,
    &g_RSETL_ATTR_FREQUENCY_CENTER_LINK,
    &g_RSETL_ATTR_FREQUENCY_CENTER_LINK_FACTOR,
    &g_RSETL_ATTR_FREQUENCY_SPAN,
    &g_RSETL_ATTR_FREQUENCY_SPAN_FULL,
    &g_RSETL_ATTR_FREQUENCY_MODE,
    &g_RSETL_ATTR_INPUT_IMPEDANCE,
    &g_RSETL_ATTR_INPUT_IQ_STATE,
    &g_RSETL_ATTR_NUMBER_OF_SWEEPS,
    &g_RSETL_ATTR_REFERENCE_LEVEL,
    &g_RSETL_ATTR_REFERENCE_LEVEL_OFFSET,
    &g_RSETL_ATTR_RESOLUTION_BANDWIDTH,
    &g_RSETL_ATTR_RESOLUTION_BANDWIDTH_AUTO,
    &g_RSETL_ATTR_RESOLUTION_BANDWIDTH_RATIO,
    &g_RSETL_ATTR_SWEEP_MODE_CONTINUOUS,
    &g_RSETL_ATTR_SWEEP_TIME,
    &g_RSETL_ATTR_SWEEP_TIME_AUTO,
    &g_RSETL_ATTR_SWEEP_POINTS,
    &g_RSETL_ATTR_SWEEP_COUNT_CURRENT,
    &g_RSETL_ATTR_VERTICAL_SCALE,
    &g_RSETL_ATTR_VIDEO_BANDWIDTH,
    &g_RSETL_ATTR_VIDEO_BANDWIDTH_AUTO,
    &g_RSETL_ATTR_VIDEO_BANDWIDTH_RATIO,
    &g_RSETL_ATTR_MEAS_ABORT,
    &g_RSETL_ATTR_INIT,
    &g_RSETL_ATTR_INIT_CONT,
    &g_RSETL_ATTR_INIT_SW_TRIGGER,
    &g_RSETL_ATTR_INIT_CONMEAS,
    &g_RSETL_ATTR_AVG_STATE,
    &g_RSETL_ATTR_AVG_TYPE,
    &g_RSETL_ATTR_AVG_COUNT,
    &g_RSETL_ATTR_AVG_COUNT_AUTO,
    &g_RSETL_ATTR_RESOLUTION_BANDWIDTH_FILTER_TYPE,
    &g_RSETL_ATTR_VIDEO_BANDWIDTH_TYPE,
    &g_RSETL_ATTR_TRACE_STATE,
    &g_RSETL_ATTR_TRACE_RESET_BEHAVIOR,
    &g_RSETL_ATTR_TRACE_TYPE,
    &g_RSETL_ATTR_TRACE_MATH_STATE,
    &g_RSETL_ATTR_TRACE_MATH_POSITION,
    &g_RSETL_ATTR_DETECTOR_TYPE,
    &g_RSETL_ATTR_DETECTOR_TYPE_AUTO,
    &g_RSETL_ATTR_CALIBRATION_CHECK,
    &g_RSETL_ATTR_CALIBRATION,
    &g_RSETL_ATTR_CALIBRATION_ABORT,
    &g_RSETL_ATTR_CALIBRATION_RESULT_QUERY,
    &g_RSETL_ATTR_CALIBRATION_STATE,
    &g_RSETL_ATTR_INP_UPORT_STATE,
    &g_RSETL_ATTR_INP_UPORT_VALUE,
    &g_RSETL_ATTR_OUT_UPORT_VALUE,
    &g_RSETL_ATTR_DISP_REF_VALUE,
    &g_RSETL_ATTR_DISP_COUP_REF_LEV,
    &g_RSETL_ATTR_DISP_REF_POSITION,
    &g_RSETL_ATTR_DISP_FREQ_STATE,
    &g_RSETL_ATTR_DISP_TIME_STATE,
    &g_RSETL_ATTR_DISP_LOGO,
    &g_RSETL_ATTR_DISP_COMMENT_STATE,
    &g_RSETL_ATTR_DISP_COMMENT,
    &g_RSETL_ATTR_DISP_PWR_SAVE_STATE,
    &g_RSETL_ATTR_DISP_PWR_SAVE_HOLDOFF,
    &g_RSETL_ATTR_DISP_WINDOW_SIZE,
    &g_RSETL_ATTR_DISP_COL_PRESET,
    &g_RSETL_ATTR_DISP_COL_PREDEFINED,
    &g_RSETL_ATTR_DISP_LOG_RANGE,
    &g_RSETL_ATTR_DISP_AMPLITUDE_GRID_MODE,
    &g_RSETL_ATTR_DISP_SINGLE_SWEEP,
    &g_RSETL_ATTR_DISP_UPDATE,
    &g_RSETL_ATTR_DISP_FP_KEYS,
    &g_RSETL_ATTR_UNIT_POWER,
    &g_RSETL_ATTR_DISP_CHANNEL_IMPULSE_RESPONSE,
    &g_RSETL_ATTR_DISP_MER_VS_FREQ,
    &g_RSETL_ATTR_DISPL_SET_TO_FOREGROUND,
    &g_RSETL_ATTR_DISP_MER_PHASE_REFERENCE_POSITION,
    &g_RSETL_ATTR_DISP_MER_PHASE_REFERENCE_DEVIATION,
    &g_RSETL_ATTR_DISP_MER_PHASE_DEVIATION_SCALING,
    &g_RSETL_ATTR_DISP_MER_PHASE_DEVIATION_RANGE,
    &g_RSETL_ATTR_DISP_GPS_POSITION,
    &g_RSETL_ATTR_DISP_PEAK_LIST,
    &g_RSETL_ATTR_DISP_DIAGRAM_FULL_SIZE,
    &g_RSETL_ATTR_DISP_MISO,
    &g_RSETL_ATTR_TFAC_SEL_NAME,
    &g_RSETL_ATTR_TFAC_UNIT,
    &g_RSETL_ATTR_TFAC_SCALING,
    &g_RSETL_ATTR_TFAC_COMMENT,
    &g_RSETL_ATTR_TFAC_STATE,
    &g_RSETL_ATTR_TFAC_DELETE,
    &g_RSETL_ATTR_TFAC_DISPLAY,
    &g_RSETL_ATTR_TFAC_ADJ_STATE,
    &g_RSETL_ATTR_MARKER_AMPLITUDE,
    &g_RSETL_ATTR_MARKER_ENABLED,
    &g_RSETL_ATTR_MARKER_POSITION,
    &g_RSETL_ATTR_MARKER_TRACE,
    &g_RSETL_ATTR_MARKER_AOFF,
    &g_RSETL_ATTR_MARKER_LOEX,
    &g_RSETL_ATTR_SIGNAL_TRACK_ENABLED,
    &g_RSETL_ATTR_SIGNAL_TRACK_BWID,
    &g_RSETL_ATTR_SIGNAL_TRACK_THRESHOLD,
    &g_RSETL_ATTR_SIGNAL_TRACK_TRACE,
    &g_RSETL_ATTR_MARKER_STEP_SIZE,
    &g_RSETL_ATTR_MARKER_PROBABILITY,
    &g_RSETL_ATTR_MARKER_RADIO_PROBABILITY,
    &g_RSETL_ATTR_MARKER_RADIO_PROBABILITY_VALUE,
    &g_RSETL_ATTR_MARKER_RADIO_DEVIATION,
    &g_RSETL_ATTR_MARKER_SEARCH_MIN_RIGHT,
    &g_RSETL_ATTR_MARKER_SEARCH_MIN_LEFT,
    &g_RSETL_ATTR_MARKER_SEARCH_PEAK,
    &g_RSETL_ATTR_MARKER_SEARCH_PEAK_NEXT,
    &g_RSETL_ATTR_MARKER_SEARCH_PEAK_RIGHT,
    &g_RSETL_ATTR_MARKER_SEARCH_PEAK_LEFT,
    &g_RSETL_ATTR_MARKER_SEARCH_MIN,
    &g_RSETL_ATTR_MARKER_SEARCH_MIN_NEXT,
    &g_RSETL_ATTR_MARKER_SEARCH_PEAK_AUTO,
    &g_RSETL_ATTR_MARKER_SEARCH_MIN_AUTO,
    &g_RSETL_ATTR_MARKER_THRESHOLD_STATE,
    &g_RSETL_ATTR_MARKER_THRESHOLD,
    &g_RSETL_ATTR_PEAK_EXCURSION,
    &g_RSETL_ATTR_MARKER_SEARCH_LIMITS_STATE,
    &g_RSETL_ATTR_MARKER_SEARCH_LIMITS_LEFT,
    &g_RSETL_ATTR_MARKER_SEARCH_LIMITS_RIGHT,
    &g_RSETL_ATTR_MARKER_PEAK_LIST_COUNT,
    &g_RSETL_ATTR_MARKER_PEAK_LIST_FOUND,
    &g_RSETL_ATTR_MARKER_PEAK_LIST_SORT,
    &g_RSETL_ATTR_MARKER_ZOOM,
    &g_RSETL_ATTR_MARKER_DEMOD_STATE,
    &g_RSETL_ATTR_MARKER_DEMOD_TYPE,
    &g_RSETL_ATTR_MARKER_DEMOD_HOLDOFF,
    &g_RSETL_ATTR_MARKER_DEMOD_CONT,
    &g_RSETL_ATTR_MARKER_TO_CENTER,
    &g_RSETL_ATTR_MARKER_TO_STEP,
    &g_RSETL_ATTR_MARKER_TO_REFERENCE,
    &g_RSETL_ATTR_MARKER_REF_STATE,
    &g_RSETL_ATTR_MARKER_REF_LEVEL,
    &g_RSETL_ATTR_MARKER_REF_LEVEL_OFFSET,
    &g_RSETL_ATTR_MARKER_REF_FREQ,
    &g_RSETL_ATTR_MARKER_REF_PEAK,
    &g_RSETL_ATTR_REFERENCE_MARKER_STATE,
    &g_RSETL_ATTR_REFERENCE_MARKER_MODE,
    &g_RSETL_ATTR_REFERENCE_MARKER_POSITION,
    &g_RSETL_ATTR_REFERENCE_MARKER_REL_POSITION,
    &g_RSETL_ATTR_REFERENCE_MARKER_AMPLITUDE,
    &g_RSETL_ATTR_REFERENCE_MARKER_TRACE,
    &g_RSETL_ATTR_REFERENCE_MARKER_AOFF,
    &g_RSETL_ATTR_REFERENCE_MARKER_PEAK,
    &g_RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT,
    &g_RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_RIGHT,
    &g_RSETL_ATTR_REFERENCE_MARKER_PEAK_NEXT_LEFT,
    &g_RSETL_ATTR_REFERENCE_MARKER_MIN,
    &g_RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT,
    &g_RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_RIGHT,
    &g_RSETL_ATTR_REFERENCE_MARKER_MIN_NEXT_LEFT,
    &g_RSETL_LIMIT_STATE,
    &g_RSETL_LIMIT_CLEAR,
    &g_RSETL_LIMIT_ASSIGN_TRACE,
    &g_RSETL_LIMIT_UNITS,
    &g_RSETL_LIMIT_COMMENT,
    &g_RSETL_LIMIT_COPY,
    &g_RSETL_LIMIT_NAME,
    &g_RSETL_LIMIT_DELETE,
    &g_RSETL_LIMIT_CONTROL_DOMAIN,
    &g_RSETL_LIMIT_CONTROL_SPACING,
    &g_RSETL_LIMIT_CONTROL_SCALING,
    &g_RSETL_LIMIT_CONTROL_OFFSET,
    &g_RSETL_LIMIT_CONTROL_SHIFT,
    &g_RSETL_LIMIT_LOWER_STATE,
    &g_RSETL_LIMIT_LOWER_SCALING,
    &g_RSETL_LIMIT_LOWER_SPACING,
    &g_RSETL_LIMIT_LOWER_MARGIN,
    &g_RSETL_LIMIT_LOWER_THRESHOLD,
    &g_RSETL_LIMIT_LOWER_OFFSET,
    &g_RSETL_LIMIT_LOWER_SHIFT,
    &g_RSETL_LIMIT_UPPER_STATE,
    &g_RSETL_LIMIT_UPPER_SCALING,
    &g_RSETL_LIMIT_UPPER_SPACING,
    &g_RSETL_LIMIT_UPPER_MARGIN,
    &g_RSETL_LIMIT_UPPER_THRESHOLD,
    &g_RSETL_LIMIT_UPPER_OFFSET,
    &g_RSETL_LIMIT_UPPER_SHIFT,
    &g_RSETL_ATTR_THRLINE_STATE,
    &g_RSETL_ATTR_THRLINE_POSITION,
    &g_RSETL_ATTR_DLINE_STATE,
    &g_RSETL_ATTR_DLINE_POSITION,
    &g_RSETL_ATTR_FLINE_STATE,
    &g_RSETL_ATTR_FLINE_POSITION,
    &g_RSETL_ATTR_TLINE_STATE,
    &g_RSETL_ATTR_TLINE_POSITION,
    &g_RSETL_ATTR_TRIGGER_SOURCE,
    &g_RSETL_ATTR_TRIGGER_DELAY,
    &g_RSETL_ATTR_TRIGGER_SLOPE,
    &g_RSETL_ATTR_EXTERNAL_GATE,
    &g_RSETL_ATTR_EXTERNAL_GATE_HOLD,
    &g_RSETL_ATTR_EXTERNAL_GATE_TRIGGER_TYPE,
    &g_RSETL_ATTR_EXTERNAL_GATE_POLARITY,
    &g_RSETL_ATTR_EXTERNAL_GATE_LENGTH,
    &g_RSETL_ATTR_EXTERNAL_GATE_SIGNAL_SOURCE,
    &g_RSETL_ATTR_VIDEO_TRIGGER_LEVEL,
    &g_RSETL_ATTR_TRIGGER_IFP_LEVEL,
    &g_RSETL_ATTR_TRIGGER_IFP_OFFSET,
    &g_RSETL_ATTR_TRIGGER_IFP_HYSTERESIS,
    &g_RSETL_ATTR_TRIGGER_TV_FREE_RUN_TRIG_MODE,
    &g_RSETL_ATTR_TRIGGER_TV_VERTICAL_SYNC,
    &g_RSETL_ATTR_TRIGGER_TV_LINE_SYSTEM,
    &g_RSETL_ATTR_TRIGGER_TV_HORIZONTAL_SYNC_LINE_NUMBER,
    &g_RSETL_ATTR_TRIGGER_TV_VIDEO_SYNC_SIGNAL_POLARITY,
    &g_RSETL_ATTR_AMPL_PREAMPLIFIER,
    &g_RSETL_ATTR_EXTERN_PREAMP_GAIN,
    &g_RSETL_LIMIT_CHECK_RESULT,
    &g_RSETL_ATTR_TRACK_GEN_STATE,
    &g_RSETL_ATTR_TRACK_GEN_CORR_STATE,
    &g_RSETL_ATTR_TRACK_GEN_RECALL_SETTINGS,
    &g_RSETL_ATTR_TRACK_GEN_MEAS_TYPE,
    &g_RSETL_ATTR_TRACK_GEN_CAL_RESULT_TYPE,
    &g_RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL,
    &g_RSETL_ATTR_TRACK_GEN_OUTPUT_LEVEL_OFFSET,
    &g_RSETL_ATTR_MARKER_NOISE_STATE,
    &g_RSETL_ATTR_MARKER_NOISE_RESULT,
    &g_RSETL_ATTR_REFERENCE_MARKER_PNO_STATE,
    &g_RSETL_ATTR_REFERENCE_MARKER_PNO_RESULT,
    &g_RSETL_ATTR_MARKER_FREQUENCY_COUNTER_ENABLED,
    &g_RSETL_ATTR_MARKER_FREQUENCY_COUNTER_RESOLUTION,
    &g_RSETL_ATTR_MARKER_COUNT,
    &g_RSETL_ATTR_MARKER_NDB_STATE,
    &g_RSETL_ATTR_MARKER_NDB_VAL,
    &g_RSETL_ATTR_MARKER_NDB_RESULT,
    &g_RSETL_ATTR_LIST_POW_STATE_OFF,
    &g_RSETL_ATTR_MEAS_TDOM_STATE,
    &g_RSETL_ATTR_MEAS_TDOM_PEAK,
    &g_RSETL_ATTR_MEAS_TDOM_RMS,
    &g_RSETL_ATTR_MEAS_TDOM_MEAN,
    &g_RSETL_ATTR_MEAS_TDOM_SDEV,
    &g_RSETL_ATTR_MEAS_TDOM_AVG,
    &g_RSETL_ATTR_MEAS_TDOM_MAX_HOLD,
    &g_RSETL_ATTR_MEAS_TDOM_MODE,
    &g_RSETL_ATTR_MEAS_TDOM_AOFF,
    &g_RSETL_ATTR_MEAS_TDOM_SET_REFERENCE,
    &g_RSETL_ATTR_MEAS_TDOM_PEAK_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_RMS_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_MEAN_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_SDEV_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_AVG_PEAK_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_AVG_RMS_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_AVG_MEAN_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_AVG_SDEV_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_RMS_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_MEAN_RESULT,
    &g_RSETL_ATTR_MEAS_TDOM_PEAK_HOLD_SDEV_RESULT,
    &g_RSETL_ATTR_MEAS_POW_SELECT,
    &g_RSETL_ATTR_MEAS_POW_OFF,
    &g_RSETL_ATTR_MEAS_POW_ADJ_NUM,
    &g_RSETL_ATTR_MEAS_POW_ADJ_MODE,
    &g_RSETL_ATTR_MEAS_POW_MODE,
    &g_RSETL_ATTR_MEAS_POW_RESULT_MODE,
    &g_RSETL_ATTR_MEAS_POW_CHANNEL_SPACING,
    &g_RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_SPACING,
    &g_RSETL_ATTR_MEAS_POW_ALT_CHANNEL_SPACING,
    &g_RSETL_ATTR_MEAS_POW_CHANNEL_BANDWIDTH,
    &g_RSETL_ATTR_MEAS_POW_ADJ_CHANNEL_BANDWIDTH,
    &g_RSETL_ATTR_MEAS_POW_ALT_CHANNEL_BANDWIDTH,
    &g_RSETL_ATTR_MEAS_POW_TRACE,
    &g_RSETL_ATTR_MEAS_POW_STANDARD,
    &g_RSETL_ATTR_MEAS_POW_REF_VALUE,
    &g_RSETL_ATTR_MEAS_POW_ADJ_PRESET,
    &g_RSETL_ATTR_MEAS_ACP_HSP,
    &g_RSETL_ATTR_MEAS_ACP_PRESET_REF_LEVEL,
    &g_RSETL_ATTR_MEAS_ACP_LIMIT_STATE,
    &g_RSETL_ATTR_MEAS_ACP_LIMIT_REL_STATE,
    &g_RSETL_ATTR_MEAS_ACP_LIMIT_ABS_STATE,
    &g_RSETL_ATTR_MEAS_ACP_ALT_LIMIT_REL_STATE,
    &g_RSETL_ATTR_MEAS_ACP_ALT_LIMIT_ABS_STATE,
    &g_RSETL_ATTR_MEAS_POW_CARR_SIG_NUM,
    &g_RSETL_ATTR_MEAS_POW_REF_CHAN_SEL_AUTO,
    &g_RSETL_ATTR_MEAS_POW_ADJ_REF_TXCHANNEL,
    &g_RSETL_ATTR_MEAS_POW_BANDWIDTH,
    &g_RSETL_ATTR_MEAS_STAT_APD_STATE,
    &g_RSETL_ATTR_MEAS_STAT_CCDF_STATE,
    &g_RSETL_ATTR_MEAS_STAT_SAMPLES,
    &g_RSETL_ATTR_MEAS_STAT_X_REF,
    &g_RSETL_ATTR_MEAS_STAT_X_RANGE,
    &g_RSETL_ATTR_MEAS_STAT_Y_MIN,
    &g_RSETL_ATTR_MEAS_STAT_Y_MAX,
    &g_RSETL_ATTR_MEAS_STAT_ADJ,
    &g_RSETL_ATTR_MEAS_STAT_PRESET,
    &g_RSETL_ATTR_STAT_RESULT,
    &g_RSETL_ATTR_MEAS_MDEPTH_STATE,
    &g_RSETL_ATTR_MEAS_MDEPTH_RESULT,
    &g_RSETL_ATTR_MEAS_MDEPTH_SEARCH,
    &g_RSETL_ATTR_MEAS_TOI_STATE,
    &g_RSETL_ATTR_MEAS_TOI_RESULT,
    &g_RSETL_ATTR_MEAS_TOI_SEARCH,
    &g_RSETL_ATTR_MEAS_HDIST_STATE,
    &g_RSETL_ATTR_MEAS_HDIST_NOOFHARM,
    &g_RSETL_ATTR_MEAS_HDIST_RBWAUTO,
    &g_RSETL_ATTR_MEAS_HDIST_PRESET,
    &g_RSETL_ATTR_MPOW_MIN,
    &g_RSETL_ATTR_MPOW_FTYPE,
    &g_RSETL_ATTR_IQ_SAMPLE_RATE,
    &g_RSETL_ATTR_IQ_DATA_STATE,
    &g_RSETL_ATTR_IQ_DATA_AVER_STATE,
    &g_RSETL_ATTR_IQ_DATA_AVER_COUNT,
    &g_RSETL_ATTR_IQ_DATA_SYNC,
    &g_RSETL_ATTR_SERVICE_INPUT_SOURCE,
    &g_RSETL_ATTR_SERVICE_INPUT_COMB_FREQUENCY,
    &g_RSETL_ATTR_SERVICE_NOISE_SOURCE,
    &g_RSETL_ATTR_SERVICE_STEST_RESULTS,
    &g_RSETL_ATTR_SERVICE_STEST,
    &g_RSETL_ATTR_FILE_RECALL,
    &g_RSETL_ATTR_FILE_STARTUP_RECALL,
    &g_RSETL_ATTR_FILE_SAVE,
    &g_RSETL_ATTR_FILE_DATA_CLEAR,
    &g_RSETL_ATTR_FILE_DATA_CLEAR_ALL,
    &g_RSETL_ATTR_FILE_DEC_SEPARATOR,
    &g_RSETL_ATTR_FILE_MANAGER_EDIT_PATH,
    &g_RSETL_ATTR_FILE_MANAGER_DELETE,
    &g_RSETL_ATTR_FILE_MANAGER_MAKE_DIR,
    &g_RSETL_ATTR_FILE_MANAGER_EDIT_PATH_DEVICE,
    &g_RSETL_ATTR_FILE_MANAGER_DELETE_DIR,
    &g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_SOURCE_CAL_DATA,
    &g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAN,
    &g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_HWSETTINGS,
    &g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_TRAC,
    &g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_SEL_LINE,
    &g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_ALL,
    &g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_NONE,
    &g_RSETL_ATTR_FILE_ITEMS_SAVE_RECAL_DEFAULT,
    &g_RSETL_ATTR_HCOPY_ABORT,
    &g_RSETL_ATTR_HCOPY_COLOR_DEF,
    &g_RSETL_ATTR_HCOPY_COLOR,
    &g_RSETL_ATTR_HCOPY_PRINT,
    &g_RSETL_ATTR_HCOPY_PRINT_NEXT,
    &g_RSETL_ATTR_HCOPY_DEVICE_DESTINATION,
    &g_RSETL_ATTR_HCOPY_COLOR_PREDEFINED,
    &g_RSETL_ATTR_HCOPY_DEVICE_LANG_OUT_FORM,
    &g_RSETL_ATTR_HCOPY_PRINT_SCREEN,
    &g_RSETL_ATTR_HCOPY_COMM_SCR,
    &g_RSETL_ATTR_HCOPY_PRINT_TRACE,
    &g_RSETL_ATTR_HCOPY_DEVICE_ORIENTATION,
    &g_RSETL_ATTR_HCOPY_FILE_NAME,
    &g_RSETL_ATTR_HCOPY_PRINTER,
    &g_RSETL_ATTR_HCOPY_PRINTER_NEXT,
    &g_RSETL_ATTR_HCOPY_PRINTER_FIRST,
    &g_RSETL_ATTR_ROSC_SOURCE,
    &g_RSETL_ATTR_SYST_ERR,
    &g_RSETL_ATTR_SYST_ERR_LIST,
    &g_RSETL_ATTR_SYST_ERR_CLEAR,
    &g_RSETL_ATTR_SYST_PRESET,
    &g_RSETL_ATTR_SYST_VERSION,
    &g_RSETL_ATTR_SYST_SPEAKER,
    &g_RSETL_ATTR_OUTPUT_MEAS_MODE,
    &g_RSETL_ATTR_SYSTEM_POWER_SUPPLY,
    &g_RSETL_ATTR_FMDEM_TRIGGER_SOURCE,
    &g_RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_ABS,
    &g_RSETL_ATTR_ADEM_TRIGGER_AM_LEVEL_REL,
    &g_RSETL_ATTR_ADEM_TRIGGER_FM_LEVEL,
    &g_RSETL_ATTR_ADEM_TRIGGER_PM_LEVEL,
    &g_RSETL_ATTR_FMDEM_DISPLAY_PDIV,
    &g_RSETL_ATTR_FMDEM_STATE,
    &g_RSETL_ATTR_FMDEM_AF_COUP,
    &g_RSETL_ATTR_FMDEM_MTIM,
    &g_RSETL_ATTR_FMDEM_BAND_DEM,
    &g_RSETL_ATTR_FMDEM_RLEN,
    &g_RSETL_ATTR_FMDEM_SRATE,
    &g_RSETL_ATTR_FMDEM_ZOOM,
    &g_RSETL_ATTR_FMDEM_ZOOM_START,
    &g_RSETL_ATTR_ADEM_PHASE_WRAP,
    &g_RSETL_ATTR_ADEM_UNIT_ANGLE,
    &g_RSETL_ATTR_ADEM_PM_RPO_X,
    &g_RSETL_ATTR_FMDEM_AF_CENTER,
    &g_RSETL_ATTR_FMDEM_AF_SPAN,
    &g_RSETL_ATTR_FMDEM_AF_START,
    &g_RSETL_ATTR_FMDEM_AF_STOP,
    &g_RSETL_ATTR_FMDEM_AF_FULL_SPAN,
    &g_RSETL_ATTR_FMDEM_BAND_RES,
    &g_RSETL_ATTR_FMDEM_SPEC_SPAN,
    &g_RSETL_ATTR_FMDEM_SPEC_ZOOM,
    &g_RSETL_ATTR_FMDEM_FILT_HPAS_STAT,
    &g_RSETL_ATTR_FMDEM_FILT_HPAS_FREQ,
    &g_RSETL_ATTR_FMDEM_FILT_LPAS_STAT,
    &g_RSETL_ATTR_FMDEM_FILT_DEMP_STAT,
    &g_RSETL_ATTR_FMDEM_FILT_LPAS_FREQ,
    &g_RSETL_ATTR_FMDEM_FILT_DEMP_TCON,
    &g_RSETL_ATTR_ADEM_FILT_LPAS_FREQ_REL,
    &g_RSETL_ATTR_FMDEM_AFR_RES,
    &g_RSETL_ATTR_FMDEM_FERR_RES,
    &g_RSETL_ATTR_FMDEM_SIN_RES,
    &g_RSETL_ATTR_FMDEM_THD_RES,
    &g_RSETL_ATTR_FMDEM_CARR_RES,
    &g_RSETL_ATTR_ADEM_SUMM_RES,
    &g_RSETL_ATTR_ADEM_FM_OFFSET,
    &g_RSETL_ATTR_PMET_REL,
    &g_RSETL_ATTR_PMET_REL_AUTO,
    &g_RSETL_ATTR_PMET_FREQ,
    &g_RSETL_ATTR_PMET_MEAS_TIME,
    &g_RSETL_ATTR_PMET_COUPLING,
    &g_RSETL_ATTR_PMET_ZERO,
    &g_RSETL_ATTR_PMET_UNIT_ABS,
    &g_RSETL_ATTR_PMET_UNIT_REL,
    &g_RSETL_ATTR_PMET_STATE,
    &g_RSETL_ATTR_PMET_AVERAGE_AUTO,
    &g_RSETL_ATTR_PMET_AVERAGE_COUNT,
    &g_RSETL_ATTR_PMET_REF_LEVEL_OFFSET_STATE,
    &g_RSETL_ATTR_PMET_BARGRAPH_STATE,
    &g_RSETL_ATTR_PMET_RELATIVE,
    &g_RSETL_ATTR_PMET_READ,
    &g_RSETL_ATTR_PMET_FETCH,
    &g_RSETL_ATTR_CATV_MODE,
    &g_RSETL_ATTR_CATV_MEAS_MODE,
    &g_RSETL_ATTR_CATV_Y_SCALE_AUTO,
    &g_RSETL_ATTR_CATV_EPAT_ZOOM_STATE,
    &g_RSETL_ATTR_CATV_EPAT_ZOOM_FACTOR,
    &g_RSETL_ATTR_CATV_EPAT_MEAS_SORT,
    &g_RSETL_ATTR_CATV_MERR_ZOOM,
    &g_RSETL_ATTR_CATV_OVER_ZOOM,
    &g_RSETL_ATTR_CATV_QUAD_ZOOM,
    &g_RSETL_ATTR_CATV_TRACE_MODE_FREEZE,
    &g_RSETL_ATTR_CATV_X_AXIS_AUTO_SCALING,
    &g_RSETL_ATTR_CATV_DISPLAY_CENTER_POSITION,
    &g_RSETL_ATTR_CATV_DISPAY_DIVISION,
    &g_RSETL_ATTR_CATV_CHANNEL,
    &g_RSETL_ATTR_CATV_RF_FREQUENCY,
    &g_RSETL_ATTR_CATV_RF_FREQUENCY_STEP_SIZE,
    &g_RSETL_ATTR_CATV_SWEEP_SPACING,
    &g_RSETL_ATTR_CATV_SIDE_BAND,
    &g_RSETL_ATTR_CATV_MODUL_STANDARD,
    &g_RSETL_ATTR_CATV_MODUL_STANDARD_GDELAY,
    &g_RSETL_ATTR_CATV_MODUL_STANDARD_SIG_TYPE,
    &g_RSETL_ATTR_CATV_PRES_STATE,
    &g_RSETL_ATTR_CATV_ATT_MODE,
    &g_RSETL_ATTR_CATV_SOUND_CHAN,
    &g_RSETL_ATTR_CATV_GET_TRIGGER_SOURCE,
    &g_RSETL_ATTR_CATV_AUDIO_STATE,
    &g_RSETL_ATTR_CATV_AUDIO_VOLUME,
    &g_RSETL_ATTR_CATV_REFERENCE_LEVEL_AUTO,
    &g_RSETL_ATTR_CATV_LEVEL_DISPLAY,
    &g_RSETL_ATTR_CATV_INPUT_SELECT,
    &g_RSETL_ATTR_CATV_INPUT_SELECT_MPX,
    &g_RSETL_ATTR_CATV_VISION_MODULATION,
    &g_RSETL_ATTR_CATV_ATTENUATOR_STATE,
    &g_RSETL_ATTR_CATV_ATTENUATION_DRIVE_MODE,
    &g_RSETL_ATTR_CATV_ATTENUATION_DRIVE_RESERVE,
    &g_RSETL_ATTR_CATV_ATTENUATION_DRIVE_HYSTERESIS,
    &g_RSETL_ATTR_QUERY_CATV_AMPL_PREAMPLIFIER_STATE,
    &g_RSETL_ATTR_CATV_ATV_MEAS,
    &g_RSETL_ATTR_CATV_ATV_CARR_MEAS,
    &g_RSETL_ATTR_CATV_ATV_MEAS_MODE,
    &g_RSETL_ATTR_CATV_ATV_BWID,
    &g_RSETL_ATTR_CATV_ATV_FREQ_NEXT,
    &g_RSETL_ATTR_CATV_ATV_NOISE_FLOOR_CORRECTION,
    &g_RSETL_ATTR_CATV_ATV_REF_CHANNEL_MANUAL,
    &g_RSETL_ATTR_CATV_ATV_REF_POWER_MANUAL,
    &g_RSETL_ATTR_CATV_ATV_REF_POWER_MODE,
    &g_RSETL_ATTR_CATV_ATV_HUM_UNIT,
    &g_RSETL_ATTR_CATV_ATV_VCP_UNIT,
    &g_RSETL_ATTR_CATV_ATV_VMOD_UNIT,
    &g_RSETL_ATTR_CATV_ATV_STANDARD,
    &g_RSETL_ATTR_CATV_ATV_SOUND_SYSTEM,
    &g_RSETL_ATTR_CATV_ATV_COLOR,
    &g_RSETL_ATTR_CATV_ATV_TRIGGER_BAR_FIELD,
    &g_RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE,
    &g_RSETL_ATTR_CATV_ATV_TRIGGER_BAR_LINE_TYPE,
    &g_RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_FIELD,
    &g_RSETL_ATTR_CATV_ATV_TRIGGER_VIDEO_SCOPE_LINE,
    &g_RSETL_ATTR_CATV_ATV_TRIGGER_QLINE_FIELD,
    &g_RSETL_ATTR_CATV_ATV_TRIGGER_QUIET_LINE,
    &g_RSETL_ATTR_CATV_ATV_MEAS_TEST_SIGNAL,
    &g_RSETL_ATTR_CATV_GET_ATV_MEAS_TEST_SIGNAL,
    &g_RSETL_ATTR_CATV_ATV_AVER_DEPTH,
    &g_RSETL_ATTR_CATV_ATV_AVER_RESET,
    &g_RSETL_ATTR_CATV_GET_ATV_ACHIEVED_AVER_DEPTH,
    &g_RSETL_ATTR_CATV_RESIDUAL_CARRIER_STATE,
    &g_RSETL_ATTR_CATV_RESIDUAL_CARRIER_VALUE,
    &g_RSETL_ATTR_CATV_SOUND_DEMOD_MODE,
    &g_RSETL_ATTR_CATV_VIDEO_CLAMPING_MODE,
    &g_RSETL_ATTR_CATV_VIDEO_GEN_STATE,
    &g_RSETL_ATTR_CATV_VIDEO_GEN_IF_OUT,
    &g_RSETL_ATTR_CATV_VIDEO_GEN_TEST_PATTERN,
    &g_RSETL_ATTR_CATV_VIDEO_GEN_USER_DEFINED_IMAGE,
    &g_RSETL_ATTR_CATV_ATV_WAV_PARAM,
    &g_RSETL_ATTR_CATV_ATV_WAV_LOC,
    &g_RSETL_ATTR_CATV_GET_ATV_WAV_POINTS,
    &g_RSETL_ATTR_CATV_GET_ATV_WAV_CENTER,
    &g_RSETL_ATTR_CATV_GET_ATV_WAV_WIDTH,
    &g_RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET,
    &g_RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER,
    &g_RSETL_ATTR_CATV_ATV_CARR_LIM_VCF,
    &g_RSETL_ATTR_CATV_ATV_CARR_LIM_VCP,
    &g_RSETL_ATTR_CATV_ATV_LIM_CN,
    &g_RSETL_ATTR_CATV_ATV_LIM_CSO,
    &g_RSETL_ATTR_CATV_ATV_LIM_CTB,
    &g_RSETL_ATTR_CATV_ATV_LIM_HUM_LOW,
    &g_RSETL_ATTR_CATV_ATV_LIM_HUM_UPP,
    &g_RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP,
    &g_RSETL_ATTR_CATV_ATV_LIM_VMOD_RPC,
    &g_RSETL_ATTR_CATV_ATV_LIM_VMOD_VCP,
    &g_RSETL_ATTR_CATV_ATV_LIM_VMOD_LFOF,
    &g_RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS,
    &g_RSETL_ATTR_CATV_GET_ATV_LIM_ANALYSIS_MEAS,
    &g_RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_MIN_MAX,
    &g_RSETL_ATTR_CATV_GET_ATV_LIM_ANALYSIS_MEAS_MIN_MAX,
    &g_RSETL_ATTR_CATV_ATV_CARR_LIM_FREQ_OFFSET_RESULT,
    &g_RSETL_ATTR_CATV_ATV_CARR_LIM_REL_POWER_RESULT,
    &g_RSETL_ATTR_CATV_ATV_CARR_LIM_VCF_RESULT,
    &g_RSETL_ATTR_CATV_ATV_CARR_LIM_VCP_RESULT,
    &g_RSETL_ATTR_CATV_ATV_LIM_CN_RESULT,
    &g_RSETL_ATTR_CATV_ATV_LIM_CSO_RESULT,
    &g_RSETL_ATTR_CATV_ATV_LIM_CTB_RESULT,
    &g_RSETL_ATTR_CATV_ATV_LIM_HUM_RESULT,
    &g_RSETL_ATTR_CATV_ATV_LIM_VMOD_MDEP_RESULT,
    &g_RSETL_ATTR_CATV_ATV_LIM_ANALYSIS_MEAS_RESULT,
    &g_RSETL_ATTR_CATV_ATV_SIGNAL_LOCKED,
    &g_RSETL_ATTR_CATV_ATV_CARR_VCPA,
    &g_RSETL_ATTR_CATV_ATV_CARR_VCF_VALUE,
    &g_RSETL_ATTR_CATV_ATV_CARR_REL_POWER_VALUE,
    &g_RSETL_ATTR_CATV_ATV_CARR_FREQ_OFFSET_VALUE,
    &g_RSETL_ATTR_CATV_ATV_VALUE,
    &g_RSETL_ATTR_CATV_ATV_CN_CN_VALUE,
    &g_RSETL_ATTR_CATV_ATV_CSO_CSO_VALUE,
    &g_RSETL_ATTR_CATV_ATV_CTB_CTB_VALUE,
    &g_RSETL_ATTR_CATV_ATV_HUM_VALUE,
    &g_RSETL_ATTR_CATV_ATV_VMOD_RESULT_VALUE,
    &g_RSETL_ATTR_CATV_GET_ATV_ANALYSIS_MEAS_VALUE,
    &g_RSETL_ATTR_CATV_DTV_MEAS,
    &g_RSETL_ATTR_CATV_DTV_SATT,
    &g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_STATE,
    &g_RSETL_ATTR_CATV_DTV_SATT_GUIDELINE,
    &g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER_RANGE,
    &g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_TRANSMITTER_POWER,
    &g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_MASK_TYPE,
    &g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_SHOW_PEAKS,
    &g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_NOISE_FLOOR_CORRECTION,
    &g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_EXTERNAL_NOTCH_FILTER,
    &g_RSETL_ATTR_CATV_DTV_OUT_OF_BAND_EMISSIONS_COUNTRY,
    &g_RSETL_ATTR_CATV_DTV_FREQ_OFFSET,
    &g_RSETL_ATTR_CATV_DTV_SPECTRUM_MARGIN_LIST,
    &g_RSETL_ATTR_CATV_DTV_REFERENCE_FREQUENCY,
    &g_RSETL_ATTR_CATV_DTV_CHAN_BAND,
    &g_RSETL_ATTR_CATV_DTV_CHAN_BAND_DVBT,
    &g_RSETL_ATTR_CATV_DTV_OVERVIEW_SCREEN_SELECT,
    &g_RSETL_ATTR_CATV_DTV_MER_FREQUENCY_START,
    &g_RSETL_ATTR_CATV_DTV_MER_FREQUENCY_STOP,
    &g_RSETL_ATTR_CATV_DTV_MER_FREQUENCY_CENTER,
    &g_RSETL_ATTR_CATV_DTV_MER_FREQUENCY_SPAN,
    &g_RSETL_ATTR_CATV_DTV_MER_OPTIMIZATION,
    &g_RSETL_ATTR_CATV_DTV_EPAT_UNIT,
    &g_RSETL_ATTR_CATV_DTV_EPAT_RVEL,
    &g_RSETL_ATTR_CATV_DTV_TIME_RANGE_MODE,
    &g_RSETL_ATTR_CATV_DTV_ECHO_THRESHOLD_LINE,
    &g_RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_STATE,
    &g_RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_MODE,
    &g_RSETL_ATTR_CATV_DTV_ECHO_FREQ_OFFSET_TRESHOLD,
    &g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQUALIZER_STATE,
    &g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_TAPS,
    &g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_FFE_LENGTH_SECONDS,
    &g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_TAPS,
    &g_RSETL_ATTR_CATV_DTV_ECHO_SHORT_EQ_DFE_LENGTH_SECONDS,
    &g_RSETL_ATTR_CATV_DTV_ECHO_FREQ_VELOCITY_FACTOR,
    &g_RSETL_ATTR_CATV_DTV_EYE_DIAGRAM_TIME_SPAN,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_CONST_SELECT,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_CONTINUAL_SCATTERED_PILOTS,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_TMCC,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC1,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_CONSTELL_DIAGRAM_DATA_CARRIERS_AC2,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_XAXIS_UNIT,
    &g_RSETL_ATTR_CATV_DTV_ERROR_UNIT,
    &g_RSETL_ATTR_CATV_DTV_POW_LEV_UNIT,
    &g_RSETL_ATTR_CATV_DTV_EQUALIZER_STATE,
    &g_RSETL_ATTR_CATV_DTV_EQUALIZER_COUNT,
    &g_RSETL_ATTR_CATV_DTV_EQUALIZER_FREEZE,
    &g_RSETL_ATTR_CATV_DTV_EQUALIZER_MODE,
    &g_RSETL_ATTR_CATV_DTV_EQUALIZER_RESET,
    &g_RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE,
    &g_RSETL_ATTR_CATV_DTV_EQUALIZER_STEP_SIZE_SHRINK,
    &g_RSETL_ATTR_CATV_DTV_FILTER_ALPHA,
    &g_RSETL_ATTR_CATV_DTV_SRATE,
    &g_RSETL_ATTR_CATV_DTV_STANDARD,
    &g_RSETL_ATTR_CATV_DTV_T2_PROFILE,
    &g_RSETL_ATTR_CATV_DTV_FORMAT,
    &g_RSETL_ATTR_CATV_DTV_MIN_BER_SAMPLES,
    &g_RSETL_ATTR_CATV_DTV_DISP_IQ_SAMPLES,
    &g_RSETL_ATTR_CATV_DTV_IQ_SOURCE,
    &g_RSETL_ATTR_CATV_DTV_IQ_CARRIER_TYPE,
    &g_RSETL_ATTR_CATV_DTV_DISPLAY_START_SYMBOL,
    &g_RSETL_ATTR_CATV_DTV_DISPLAY_FRAME_COUNT,
    &g_RSETL_ATTR_CATV_DTV_DISPLAY_CELL_COUNT,
    &g_RSETL_ATTR_CATV_DTV_BER_RESET,
    &g_RSETL_ATTR_CATV_DTV_MLOG_RESET,
    &g_RSETL_ATTR_CATV_DTV_AUTO_DETECTION,
    &g_RSETL_ATTR_CATV_DTV_CARRIER_START,
    &g_RSETL_ATTR_CATV_DTV_CARRIER_STOP,
    &g_RSETL_ATTR_CATV_DTV_CARRIER_SPAN,
    &g_RSETL_ATTR_CATV_DTV_CARRIER_CENTER,
    &g_RSETL_ATTR_CATV_DTV_CARRIER_DATA_STATE,
    &g_RSETL_ATTR_CATV_DTV_CARRIER_TR_STATE,
    &g_RSETL_ATTR_CATV_DTV_CARRIER_LOOPS,
    &g_RSETL_ATTR_CATV_DTV_CARRIER_MODULATION,
    &g_RSETL_ATTR_CATV_DTV_CODE_RATE,
    &g_RSETL_ATTR_CATV_DTV_CODE_RATE_HIGH_PRIOR,
    &g_RSETL_ATTR_CATV_DTV_CODE_RATE_LOW_PRIOR,
    &g_RSETL_ATTR_CATV_DTV_FEC_SYNC_REQUIRED,
    &g_RSETL_ATTR_CATV_DTV_FIC_SYNC_REQUIRED,
    &g_RSETL_ATTR_CATV_DTV_MPEG_SYNC_REQUIRED,
    &g_RSETL_ATTR_CATV_DTV_FFT_MODE,
    &g_RSETL_ATTR_CATV_DTV_GUARD_INTERVAL,
    &g_RSETL_ATTR_CATV_DTV_GUARD_INTERVAL_PN,
    &g_RSETL_ATTR_CATV_DTV_INTERLEAVER,
    &g_RSETL_ATTR_CATV_DTV_LDPC_MODE,
    &g_RSETL_ATTR_CATV_DTV_SYMBOL_LOOPS,
    &g_RSETL_ATTR_CATV_DTV_AGC_LOOPS,
    &g_RSETL_ATTR_CATV_DTV_SYSTEM_OPTIMATION,
    &g_RSETL_ATTR_CATV_DTV_TIME_DEINTERLEAVER,
    &g_RSETL_ATTR_CATV_DTV_MPEG_TS_OUTPUT,
    &g_RSETL_ATTR_CATV_DTV_DISPLAY_TMCC_NEXT_VALUES,
    &g_RSETL_ATTR_CATV_DTV_DATA_ID_MODE,
    &g_RSETL_ATTR_CATV_DTV_DATA_ID_MAN,
    &g_RSETL_ATTR_QUERY_CATV_DTV_DATA_ID,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_CODE_RATE,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TIME_DEINTERLEAVER,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_SEGMENTS,
    &g_RSETL_ATTR_CATV_GET_DTV_ISDBT_SEGMENT_C,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_MODULATION,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_PARTIAL_RECEPTION,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_POSITION,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_FFT_WINDOW_OFFSET,
    &g_RSETL_ATTR_CATV_DTV_DTMB_SI_POWER_NORMALIZATION,
    &g_RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_BOOST,
    &g_RSETL_ATTR_CATV_DTV_DTMB_FH_POWER_REFERENCE,
    &g_RSETL_ATTR_CATV_DTV_DTMB_ESR_TIMEBASE,
    &g_RSETL_ATTR_CATV_DTV_DTMB_BER_INDICATION,
    &g_RSETL_ATTR_CATV_DTV_DVB_ISSY_PROCESSING,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_TRANSMISSION_SYSTEM,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PILOT_PATTERN,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PAPR,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_DATA_SYMBOLS,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_PAYLOAD_TYPE,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_CODE_RATE,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MODULATION,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_ROTATION,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_FEC_TYPE,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_MAX_BLOCKS,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_DVB_PLP_TI_BLOCKS,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_ATSC_SCAN_SLT,
    &g_RSETL_ATTR_CATV_DTV_ATSC_SORT_LIST,
    &g_RSETL_ATTR_CATV_DTV_ATSC_SELECT_PARADE_BY_SERVICE,
    &g_RSETL_ATTR_CATV_DTV_NOISE_GEN_CN_STATE,
    &g_RSETL_ATTR_CATV_DTV_NOISE_GEN_CN,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_STATE,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_DISP_PARAM,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_MAN,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_SPAN_AUTO,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_PORT,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_STATE,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_CONNECTION_STATE,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_HDOP,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_SATELLITES,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_VALID_INFO,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LONGITUDE,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_LATITUDE,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_ALTITUDE,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_STATUS,
    &g_RSETL_ATTR_CATV_DTV_MEAS_LOG_GPS_DEVICE,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_ENABLED,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_DEAD_RECKONING,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_PIN_DIRECTION,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_STATUS,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_STATUS,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_GYROSCOPE_CALIBRATION_STATUS,
    &g_RSETL_ATTR_CATV_DIGITAL_TV_MEAS_LOG_GPS_TSMX_SPEED_PULSE_CALIBRATION_STATUS,
    &g_RSETL_ATTR_CATV_DTV_FREQ_RANGE,
    &g_RSETL_ATTR_CATV_DTV_NOTCH_FILTER,
    &g_RSETL_ATTR_CATV_DTV_NOTCH_FILTER_BWIDTH,
    &g_RSETL_ATTR_CATV_DTV_NOTCH_FILTER_FREQ,
    &g_RSETL_ATTR_CATV_DTV_FIC_RETRIEVE_DATA_SET,
    &g_RSETL_ATTR_CATV_DTV_CN_MEAS_STATE,
    &g_RSETL_ATTR_CATV_DTV_CN_MEAS_FREQUENCY,
    &g_RSETL_ATTR_CATV_DTV_CN_MEAS_NOISE_BANDWIDTH,
    &g_RSETL_ATTR_CATV_DTV_FIC_SUBCH_SELECT,
    &g_RSETL_ATTR_CATV_GET_DTV_FIC_SUBCH_NUMBER,
    &g_RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_NUMBER,
    &g_RSETL_ATTR_CATV_GET_DTV_FIC_SERVICE_COMP_NUMBER,
    &g_RSETL_ATTR_CATV_DTV_TRANS_MODE,
    &g_RSETL_ATTR_CATV_DTV_AUTO_SUBCH_ORG,
    &g_RSETL_ATTR_CATV_DTV_SUBCH_FIRST_CUNIT,
    &g_RSETL_ATTR_CATV_DTV_SUBCH_DATA_RATE,
    &g_RSETL_ATTR_CATV_DTV_SUBCH_USE_MPEG,
    &g_RSETL_ATTR_CATV_DTV_SUBCH_PROTECTION_LEVEL,
    &g_RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET,
    &g_RSETL_ATTR_CATV_DTV_LIM_SUPP,
    &g_RSETL_ATTR_CATV_DTV_LIM_ERR_LOW,
    &g_RSETL_ATTR_CATV_DTV_LIM_ERR_UPP,
    &g_RSETL_ATTR_CATV_DTV_LIM_IMB,
    &g_RSETL_ATTR_CATV_DTV_LIM_PJIT,
    &g_RSETL_ATTR_CATV_DTV_LIM_QERR,
    &g_RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET,
    &g_RSETL_ATTR_CATV_DTV_LIM_SNR,
    &g_RSETL_ATTR_CATV_DTV_LIM_BBV,
    &g_RSETL_ATTR_CATV_DTV_LIM_BVF,
    &g_RSETL_ATTR_CATV_DTV_LIM_BVM,
    &g_RSETL_ATTR_CATV_DTV_LIM_BBRS,
    &g_RSETL_ATTR_CATV_DTV_LIM_BIT_RATE_OFFSET,
    &g_RSETL_ATTR_CATV_DTV_LIM_LEVEL,
    &g_RSETL_ATTR_CATV_DTV_LIM_PER,
    &g_RSETL_ATTR_CATV_DTV_LIM_PERR,
    &g_RSETL_ATTR_CATV_DTV_LIM_BER_LDPC,
    &g_RSETL_ATTR_CATV_DTV_LIM_BER_BBCH,
    &g_RSETL_ATTR_CATV_DTV_LIM_MRLO_LOW,
    &g_RSETL_ATTR_CATV_DTV_LIM_MRLO_UPP,
    &g_RSETL_ATTR_CATV_DTV_LIM_MPLO_LOW,
    &g_RSETL_ATTR_CATV_DTV_LIM_MPLO_UPP,
    &g_RSETL_ATTR_CATV_DTV_LIM_MRPL,
    &g_RSETL_ATTR_CATV_DTV_LIM_MPPL,
    &g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT,
    &g_RSETL_ATTR_CATV_DTV_LIM_ERPL,
    &g_RSETL_ATTR_CATV_DTV_LIM_EPPL,
    &g_RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW,
    &g_RSETL_ATTR_CATV_DTV_LIM_CNR,
    &g_RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE,
    &g_RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA,
    &g_RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR,
    &g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATE,
    &g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS,
    &g_RSETL_ATTR_CATV_DTV_CARR_LIM_FREQ_OFFSET_RESULT,
    &g_RSETL_ATTR_CATV_DTV_CARR_LIM_CARR_SUPP_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_ERROR_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_IMB_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_PJIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_QERR_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_SYMB_RATE_OFFSET_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_SNR_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_BBV_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_BVF_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_BVM_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_BBRS_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_BROF_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_LEVEL_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_PER_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_PERR_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_BER_LDPC_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_BER_BBCH_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_MRLO_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_MPLO_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_MRPL_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_MPPL_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_LOWER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_RMS_UPPER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_PEAK_RATIO_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_LOWER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_FRAME_HEADER_RMS_UPPER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_LOWER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_SYSTEM_INFO_RMS_UPPER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_AMPLITUDE_NOISE_LOWER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_IMAGE_REJECTION_LOWER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_LOWER_LIMIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_ERPL_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_EPPL_RESULT,
    &g_RSETL_ATTR_CATV_ATSC_LIM_OVERVIEW_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_CNR_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_PILOT_VALUE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_SIGNAL_PILOT_DATA_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_PILOT_AMPL_ERROR_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_MODULATION_ERROR_RATIO_CARRIERS_RESULT,
    &g_RSETL_ATTR_CATV_DTV_LIM_ISDBT_BER_AFTER_RS_RESULT,
    &g_RSETL_ATTR_CATV_DTV_SIGNAL_LOCKED,
    &g_RSETL_ATTR_CATV_DTV_MPEG_SIGNAL_LOCKED,
    &g_RSETL_ATTR_CATV_DTV_FIC_SYNC_STATUS,
    &g_RSETL_ATTR_CATV_DTV_TPS_MEAS_CONST_SETTING,
    &g_RSETL_ATTR_CATV_DTV_TPS_MEAS_FFT_MODE_SETTING,
    &g_RSETL_ATTR_CATV_DTV_TPS_MEAS_GUARD_INTERVAL_SETTING,
    &g_RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_SETTING,
    &g_RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_HIGH_PRIOR_SETTING,
    &g_RSETL_ATTR_CATV_DTV_TPS_MEAS_CODE_RATE_LOW_PRIOR_SETTING,
    &g_RSETL_ATTR_CATV_DTV_TPS_MEAS_INTERLEAVER_SETTING,
    &g_RSETL_ATTR_CATV_DTV_TPS_MEAS_DEINTERLEAVER_SETTING,
    &g_RSETL_ATTR_CATV_DTV_APGD_MEAS_RESULT,
    &g_RSETL_ATTR_CATV_DTV_SPEC,
    &g_RSETL_ATTR_CATV_DTV_ERROR,
    &g_RSETL_ATTR_CATV_DTV_OVER_CARR_FREQ_OFFSET,
    &g_RSETL_ATTR_CATV_DTV_OVER_SRATE_OFFSET,
    &g_RSETL_ATTR_CATV_DTV_OVERVIEW,
    &g_RSETL_ATTR_CATV_GET_DTV_FFT_MODE,
    &g_RSETL_ATTR_CATV_GET_DTV_GUARD_INTERVAL,
    &g_RSETL_ATTR_CATV_GET_DTV_CODE_RATE,
    &g_RSETL_ATTR_CATV_GET_DTV_CODE_RATE_HIGH_PRIORITY,
    &g_RSETL_ATTR_CATV_GET_DTV_CODE_RATE_LOW_PRIORITY,
    &g_RSETL_ATTR_CATV_GET_DTV_INTERLEAVER,
    &g_RSETL_ATTR_CATV_GET_DTV_TRANSMISSION_MODE,
    &g_RSETL_ATTR_CATV_GET_DTV_SIDEBAND_POSITION,
    &g_RSETL_ATTR_CATV_GET_DTV_TIME_DEINTERLEAVER,
    &g_RSETL_ATTR_CATV_GET_DTV_CONTROL_FRAME,
    &g_RSETL_ATTR_CATV_GET_DTV_CELL_ID,
    &g_RSETL_ATTR_CATV_GET_DTV_TPS_RESERVED,
    &g_RSETL_ATTR_CATV_GET_DTV_LENGTH_INDICATOR,
    &g_RSETL_ATTR_CATV_DTV_CONST_VAL,
    &g_RSETL_ATTR_CATV_DTV_MERR_IMB,
    &g_RSETL_ATTR_CATV_DTV_MERR_QERR,
    &g_RSETL_ATTR_CATV_DTV_MERR_CSUP,
    &g_RSETL_ATTR_CATV_DTV_MERR_PJIT,
    &g_RSETL_ATTR_CATV_DTV_MOD_ERRORS,
    &g_RSETL_ATTR_CATV_DTV_CONST,
    &g_RSETL_ATTR_CATV_DTV_MER_VS_CAR,
    &g_RSETL_ATTR_CATV_DTV_MER_PHASE_NOISE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_IQ_IMBALANCE,
    &g_RSETL_ATTR_CATV_GET_DIGITAL_TV_ECHO_PATTERN_RESULT,
    &g_RSETL_ATTR_CATV_DTV_INGRESS_DIAGRAM_EQUIVALENT_NOISE_BANDWIDTH,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_LAYER_SPECIFIC,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_SYSTEM_IDENTIFICATION,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PARAMETER_SWITCHING_INDICATOR,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_EMERGENCY_ALARM_BROADCASTING,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CURRENT_PARTIAL_RECEPTION,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NEXT_PARTIAL_RECEPTION,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_PHASE_SHIFT_CORRECTION,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_RESERVED_BITS,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_MODULATION,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_CODE_RATE,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_TIME_DEINTERLEAVER,
    &g_RSETL_ATTR_CATV_DTV_ISDBT_TMCC_OVERVIEW_NUMBER_OF_SEGMENTS,
    &g_RSETL_ATTR_CATV_DTV_DVB_PLP_SYNC_STATE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_DVB_T2_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_BANDWIDTH_EXTENSION_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_GUARD_INTERVAL_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_PILOT_PATTERN_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_TRANSMISSION_SYSTEM_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_T2_VERSION_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_T2_FRAME_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_POST_CONSTELATION_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_POST_SIZE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_POST_EXTENSION_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_POST_REPETITION_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_POST_CODE_RATE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_POST_FEC_TYPE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_PAPR_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_STREAM_TYPE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_S_BIT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_ID_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_REGENERATION_FLAG_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_FREQUENCIES_COUNT_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_RF_INDEX_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_CRC_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_RESERVED_BITS_RESULT,
    &g_RSETL_ATTR_CATV_DTV_L1_POST_SIGNALING_RESULT,
    &g_RSETL_ATTR_CATV_DTV_ATSC_SYNC_STATE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_RESULT,
    &g_RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_PROGRESS,
    &g_RSETL_ATTR_CATV_DTV_ATSC_OVERVIEW_TARGET,
    &g_RSETL_ATTR_CATV_DTV_ATSC_ENS_SIG_BIT_RATE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_ATSC_PAY_PAR_BIT_RATE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_ATSC_FIC_DECODED_PARADE_RESULT,
    &g_RSETL_ATTR_CATV_DTV_ATSC_FIC_ALL_PARADE_RESULT,
    &g_RSETL_ATTR_CATV_TV_MEAS,
    &g_RSETL_ATTR_CATV_TV_CHANNEL,
    &g_RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_ACTIVATE,
    &g_RSETL_ATTR_CATV_TV_MOD_STANDARD_TILT_DEACTIVATE,
    &g_RSETL_ATTR_RADIO_MEASUREMENT,
    &g_RSETL_ATTR_RADIO_SPECTRUM_SELECT_MASK,
    &g_RSETL_ATTR_RADIO_STANDARD,
    &g_RSETL_ATTR_RADIO_CHANNEL_BANDWIDTH,
    &g_RSETL_ATTR_RADIO_DATA_SYSTEM,
    &g_RSETL_ATTR_RADIO_SCA_MODE,
    &g_RSETL_ATTR_RADIO_SCA_FREQUENCY,
    &g_RSETL_ATTR_RADIO_PILOT_DEVIATION_TRESHOLD,
    &g_RSETL_ATTR_RADIO_PILOT_NOISE,
    &g_RSETL_ATTR_RADIO_OUTPUT_SIGNAL,
    &g_RSETL_ATTR_RADIO_OUTPUT_DEEMPHASIS,
    &g_RSETL_ATTR_RADIO_OUTPUT_DEVIATION,
    &g_RSETL_ATTR_RADIO_OUTPUT_CCVS,
    &g_RSETL_ATTR_RADIO_DUT_INPUT_LEVEL,
    &g_RSETL_ATTR_RADIO_DUT_AES_EBU,
    &g_RSETL_ATTR_RADIO_DUT_DEVIATION,
    &g_RSETL_ATTR_RADIO_VERTICAL_SCALING,
    &g_RSETL_ATTR_RADIO_SWEEP_POINTS,
    &g_RSETL_ATTR_RADIO_START_FREQUENCY,
    &g_RSETL_ATTR_RADIO_STOP_FREQUENCY,
    &g_RSETL_ATTR_RADIO_CENTER_FREQUENCY,
    &g_RSETL_ATTR_RADIO_FREQUENCY_SPAN,
    &g_RSETL_ATTR_RADIO_ZOOM,
    &g_RSETL_ATTR_RADIO_FREQ_RESPONSE_TYPE,
    &g_RSETL_ATTR_RADIO_FREQ_RESPONSE_REFERENCE,
    &g_RSETL_ATTR_RADIO_FREQ_RESPONSE_PHASE_RANGE,
    &g_RSETL_ATTR_RADIO_FREQUENCY_RANGE,
    &g_RSETL_ATTR_RADIO_REFERENCE_POSITION,
    &g_RSETL_ATTR_RADIO_CROSSTALK_TYPE,
    &g_RSETL_ATTR_RADIO_CROSSTALK_REFERENCE,
    &g_RSETL_ATTR_RADIO_SN_REFERENCE_DEVIATION,
    &g_RSETL_ATTR_RADIO_SN_WEIGHTING_FILTER,
    &g_RSETL_ATTR_RADIO_REFERENCE_DEVIATION,
    &g_RSETL_ATTR_RADIO_POWER_PEAK_MEASUREMENT,
    &g_RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN,
    &g_RSETL_ATTR_RADIO_MPX_POWER_TIME_SPAN_AUTO,
    &g_RSETL_ATTR_RADIO_MPX_POWER_REF_POSITION,
    &g_RSETL_ATTR_RADIO_MPX_POWER_RANGE,
    &g_RSETL_ATTR_RADIO_MPX_PEAK_DEV_REFERENCE,
    &g_RSETL_ATTR_RADIO_MPX_PEAK_DEV_RANGE,
    &g_RSETL_ATTR_RADIO_MPX_SAMPLES,
    &g_RSETL_ATTR_RADIO_SAMPLE_COUNT,
    &g_RSETL_ATTR_RADIO_THD_TOP_LIMIT,
    &g_RSETL_ATTR_RADIO_THD_BOTTOM_LIMIT,
    &g_RSETL_ATTR_RADIO_DFD_TOP_LIMIT,
    &g_RSETL_ATTR_RADIO_DFD_BOTTOM_LIMIT,
    &g_RSETL_ATTR_RADIO_SIGNAL_PATH,
    &g_RSETL_ATTR_RADIO_DEEMPHASIS,
    &g_RSETL_ATTR_RADIO_OBW_ADJUST_SETTINGS,
    &g_RSETL_ATTR_RADIO_AGEN_TYPE,
    &g_RSETL_ATTR_RADIO_AGEN_SIGNAL,
    &g_RSETL_ATTR_RADIO_AGEN_CONNECTOR_CONFIG,
    &g_RSETL_ATTR_RADIO_AGEN_AMPLITUDE_DEFINITION,
    &g_RSETL_ATTR_RADIO_AGEN_WAVEFORM,
    &g_RSETL_ATTR_RADIO_AGEN_LEVEL,
    &g_RSETL_ATTR_RADIO_AGEN_FREQUENCY,
    &g_RSETL_ATTR_RADIO_AGEN_FREQUENCY_SPACING,
    &g_RSETL_ATTR_RADIO_AGEN_FREQUENCY_UPPER,
    &g_RSETL_ATTR_RADIO_AGEN_SUBCARRIER_STATE,
    &g_RSETL_ATTR_RADIO_AGEN_SUBCARRIER_DEVIATION,
    &g_RSETL_ATTR_RADIO_AGEN_ALTERNATE_CHANNEL,
    &g_RSETL_ATTR_RADIO_AGEN_DUT_PREEMPHASIS,
    &g_RSETL_ATTR_RADIO_AGEN_DUT_DEVIATION,
    &g_RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT,
    &g_RSETL_ATTR_RADIO_AUDIO_SN_LIMIT,
    &g_RSETL_ATTR_RADIO_AUDIO_THD_LIMIT,
    &g_RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT,
    &g_RSETL_ATTR_RADIO_MPX_POW_LIMIT,
    &g_RSETL_ATTR_RADIO_MPX_PEAK_LIMIT,
    &g_RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT,
    &g_RSETL_ATTR_RADIO_MPX_DEVIATION_LIMIT_RATIO,
    &g_RSETL_ATTR_RADIO_OBW_UPPER_LIMIT,
    &g_RSETL_ATTR_RADIO_MP_DETECTION_LIMIT,
    &g_RSETL_ATTR_RADIO_DFD_UNIT,
    &g_RSETL_ATTR_RADIO_THD_UNIT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_LEVEL_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_PILOT_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_RDS_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_DARC_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_SCA_RESULT,
    &g_RSETL_ATTR_RADIO_AUDIO_SCOPE_RESULT,
    &g_RSETL_ATTR_RADIO_SPECTRUM_RESULT_SINAD,
    &g_RSETL_ATTR_RADIO_SPECTRUM_RESULT_THD,
    &g_RSETL_ATTR_RADIO_SPECTRUM_RESULT_MOD_FREQ,
    &g_RSETL_ATTR_RADIO_SPECTRUM_RESULT_SC_FREQ_OFFSET,
    &g_RSETL_ATTR_RADIO_POWER_PEAK_CURRENT_RESULT,
    &g_RSETL_ATTR_RADIO_POWER_PEAK_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_RATIO_RESULT,
    &g_RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_VIOLATING_RESULT,
    &g_RSETL_ATTR_RADIO_MPX_DEVIATION_VIOLATION_SAMPLES_TOTAL_RESULT,
    &g_RSETL_ATTR_RADIO_MPX_DEVIATION_RAW_VIOLATION_SAMPLES_RESULT,
    &g_RSETL_ATTR_RADIO_MULTIPATH_DETECTION_RESULT,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_SYNC,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_PID,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_NAME,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_ECC,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_COUNTRY,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_FLAG,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_PTYPE,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_DID,
    &g_RSETL_ATTR_RADIO_RDS_RESULT_DATE_TIME,
    &g_RSETL_ATTR_RADIO_OBW_RESULT,
    &g_RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_AMPLIITUDE,
    &g_RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_PHASE,
    &g_RSETL_ATTR_RADIO_FREQ_RESPONSE_RESULT_FREQUENCY,
    &g_RSETL_ATTR_RADIO_CROSSTALK_RESULT,
    &g_RSETL_ATTR_RADIO_SN_RESULT,
    &g_RSETL_ATTR_RADIO_THD_RESULT,
    &g_RSETL_ATTR_RADIO_DFD_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_LEVEL_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_CF_OFFSET_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_AM_MODULATION_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_MPX_DEVIATION_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_PILOT_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_RDS_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_DARC_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_OVERVIEW_SCA_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_MPX_POW_PEAK_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_OBW_UPPER_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_MP_DETECTION_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_AUDIO_SN_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_AUDIO_THD_LIMIT_RESULT,
    &g_RSETL_ATTR_RADIO_AUDIO_DFD_LIMIT_RESULT,
    &g_RSETL_ATTR_TS_GENERATOR_RECORDER_MODE,
    &g_RSETL_ATTR_TS_GENERATOR_RECORDER_STATUS,
    &g_RSETL_ATTR_TS_GENERATOR_SELECT_FILE,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_DATA_RATE,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_NULLPACKET_STUFFING,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_START,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_STOP,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_PLAY_WINDOW_POSITION,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_WAVEFORM,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_AMPLITUDE,
    &g_RSETL_ATTR_TS_GENERATOR_TIMING_PCR_JITTER_FREQUENCY,
    &g_RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_CONTINUITY_COUNTER,
    &g_RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_PCR,
    &g_RSETL_ATTR_TS_GENERATOR_SEAMLESS_LOOP_TDT_TOT,
    &g_RSETL_ATTR_TS_GENERATOR_INTERFACE_PACKET_LENGTH,
    &g_RSETL_ATTR_TS_GENERATOR_INTERFACE_SERIAL_OUTPUT,
    &g_RSETL_ATTR_TS_RECORDER_INPUT,
    &g_RSETL_ATTR_TS_RECORDER_FILE_SIZE,
    &g_RSETL_ATTR_TS_RECORDER_FILE_NAME,
    &g_RSETL_ATTR_ID_QUERY_RESPONSE
  };
