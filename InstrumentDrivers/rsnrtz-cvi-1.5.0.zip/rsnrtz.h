/*= Rohde&Schwarz Directional Power Sensor NRT-Z ===========================*/

/*===========================================================================*/
/*  Please do not use global variables or arrays in the include file of      */
/*  instrument drivers that will be submitted for inclusion into the         */
/*  LabWindows Instrument Driver Library.                                    */
/*===========================================================================*/

#ifndef __rsnrtz_HEADER
#define __rsnrtz_HEADER

#include <vpptype.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#if defined(__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif

/*****************************************************************************/
/*= Multiplatform support defines ===========================================*/
/*                                                                           */
/*  Note that improper platform preprocessor directive may cause unexpected  */
/*  behaviour of the driver functions.                                       */
/*                                                                           */
/*****************************************************************************/

#if defined(_NI_unix_) || defined(_NI_sparc_)
#define CLOCKS_PER_SEC 1000000
#elif defined(_NI_mswin16_) || defined(_NI_mswin32_) || defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
#define CLOCKS_PER_SEC 1000
#elif defined(_NI_mac_)
#define CLOCKS_PER_SEC 1
#else
#error Undefined Platform. You need to add one of the
#error following to your compiler defines:
#error     Platform                      Preprocessor directive
#error Microsoft Windows 3.1           #define _NI_mswin16_
#error Windows 95/NT                   #define _NI_mswin32_
#error Solaris 1                       #define _NI_sparc_       1
#error Solaris 2                       #define _NI_sparc_       2
#error Mackintosh                      #define _NI_mac_
#endif

/*****************************************************************************/
/*= Define Instrument Specific Error/Warning Codes Here =====================*/
/*****************************************************************************/
#define VI_ERROR_INSTR_INTERPRETING_RESPONSE    (_VI_ERROR+0x3FFC0803L)
#define VI_INSTR_WARNING_OFFSET                           (0x3FFC0900L)
#define VI_INSTR_ERROR_OFFSET                   (_VI_ERROR+0x3FFC0900L)

#define RSNRT_ERROR_INVALID_CONFIGURATION      (VI_INSTR_ERROR_OFFSET + 0xF0L)

#define RSNRTZ_PARITY                           0

#define RSNRTZ_ERROR_INSTR_RESET                (VI_INSTR_ERROR_OFFSET+0x10L)
#define RSNRTZ_ERROR_INSTR_ZERO                 (VI_INSTR_ERROR_OFFSET+0x20L)
#define RSNRTZ_ERROR_INSTR_MEAS_STAT            (VI_INSTR_ERROR_OFFSET+0x30L)
#define RSNRTZ_ERROR_NSUP_INTERFACE             (VI_INSTR_ERROR_OFFSET+0x40L)
#define RSNRTZ_ERROR_INSTR_SENSOR_BUSY          (VI_INSTR_ERROR_OFFSET+0x50L)
#define RSNRTZ_ERROR_INSTR_ERROR_RANGE			(VI_INSTR_ERROR_OFFSET+0x60L)

/*****************************************************************************/
/*= GLOBAL USER-CALLABLE FUNCTION DECLARATIONS (Exportable Functions) =======*/
/*****************************************************************************/
ViStatus _VI_FUNC rsnrtz_init (ViRsrc resourceName, ViBoolean IDQuery,
					ViBoolean resetDevice, ViPSession instrumentHandle);
ViStatus _VI_FUNC rsnrtz_applMeasPower (ViSession instrumentHandle,
					ViPReal64 forwardAveragePowerW, ViPReal64 reflectedPowerW);
ViStatus _VI_FUNC rsnrtz_configBurst (ViSession instrumentHandle,
					ViReal64 burstPeriods, ViReal64 burstWidths,
					ViPReal64 oldBurstPeriods, ViPReal64 oldBurstWidths);
ViStatus _VI_FUNC rsnrtz_configCCDF (ViSession instrumentHandle,
					ViReal64 CCDFThresholdW, ViPReal64 oldCCDFThresholdW);
ViStatus _VI_FUNC rsnrtz_configDir (ViSession instrumentHandle, 
					ViInt16 direction, ViPInt16 oldDirection);
ViStatus _VI_FUNC rsnrtz_configCarrFreq (ViSession instrumentHandle,
					ViReal64 carrierFrequencyHz,ViPReal64 oldCarrierFrequencyHz);
ViStatus _VI_FUNC rsnrtz_configAver (ViSession instrumentHandle,
					ViBoolean averagingMode, ViInt16 averagingFilterCount,
					ViBoolean averagingResolution, 
					ViPInt16 averagingFilterCountOld,
					ViPInt16 averagingResolutionOld);
ViStatus _VI_FUNC rsnrtz_configIntTime (ViSession instrumentHandle,
					ViReal64 integrationTimes, ViPReal64 oldIntegrationTimes);
ViStatus _VI_FUNC rsnrtz_configVideoBW (ViSession instrumentHandle,
					ViInt16 videoBandwidth, ViBoolean spreadSpectrumSignal,
					ViPReal64 oldVideoBandwidth, 
					ViPInt16 oldSpreadSpectrumSignal);
ViStatus _VI_FUNC rsnrtz_configHoldTime (ViSession instrumentHandle,
					ViReal64 holdTimes, ViPReal64 oldHoldTimes);
ViStatus _VI_FUNC rsnrtz_configRefPlane (ViSession instrumentHandle,
					ViBoolean referencePlane, ViPInt16 oldReferencePlane);
ViStatus _VI_FUNC rsnrtz_configMeas (ViSession instrumentHandle,
					ViBoolean statusCheck, ViInt16 readResults,
					ViPInt16 oldStatusCheck, ViPInt16 oldReadResults);
ViStatus _VI_FUNC rsnrtz_configMod (ViSession instrumentHandle,
									ViReal64 chipRate1s,
									ViInt16 communicationStandard,
									ViReal64 *oldChipRate,
									ViInt16 *oldCommunicationStandard);
ViStatus _VI_FUNC rsnrtz_configAttn (ViSession instrumentHandle,
									 ViReal64 attenuationdB,
									 ViReal64 *oldAttenuation);
ViStatus _VI_FUNC rsnrtz_configBoot (ViSession instrumentHandle);
ViStatus _VI_FUNC rsnrtz_configPurge (ViSession instrumentHandle);
ViStatus _VI_FUNC rsnrtz_configQueryOpMode (ViSession instrumentHandle,
					ViPInt16 operatingMode);
ViStatus _VI_FUNC rsnrtz_configHWTestPts (ViSession instrumentHandle,
					ViReal64 _VI_FAR limitsLow[], 
					ViReal64 _VI_FAR measuredValues[],
					ViReal64 _VI_FAR limitsHigh[]);
ViStatus _VI_FUNC rsnrtz_actstatFwdMeasMode (ViSession instrumentHandle,
					ViInt16 forwardMeasMode, ViPInt16 oldForwardMeasMode);
ViStatus _VI_FUNC rsnrtz_actstatRevMeasMode (ViSession instrumentHandle,
					ViInt16 reverseMeasMode, ViPInt16 oldReverseMeasMode);
ViStatus _VI_FUNC rsnrtz_actstatZero (ViSession instrumentHandle, ViBoolean zeriong,
					ViPReal64 forwardOffsetV, ViPReal64 reverseOffsetV,
					ViPReal64 PEPZero4kHzV, ViPReal64 PEPZero200kHzV,
					ViPReal64 PEPZero4MHzV);
ViStatus _VI_FUNC rsnrtz_actstatMeas (ViSession instrumentHandle, ViBoolean trigger,
					ViPReal64 forwardValue, ViPReal64 reversValue);
ViStatus _VI_FUNC rsnrtz_actstatMeasWithStat (ViSession instrumentHandle,
					ViBoolean trigger, ViPReal64 forwardValue, 
					ViPReal64 reversValue, ViPInt16 error, ViPInt16 limit,
					ViPInt16 forwardFunction, ViPInt16 reverseFunction,
					ViPInt16 forwardPowerDirection, ViPInt16 averagePowFwdFilter,
					ViPInt16 averagePowRevFilter, ViPInt16 PEPFilter,
					ViPInt16 distributionFunctionFilter);
ViStatus _VI_FUNC rsnrtz_actstatMeasNoise (ViSession instrumentHandle,
					ViPReal64 vpp1V, ViPReal64 vpp2V,
					ViPReal64 noise1, ViPReal64 noise2);
ViStatus _VI_FUNC rsnrtz_actstatMeasOffs (ViSession instrumentHandle,
					ViPReal64 filter1OffsetV, ViPReal64 filter2OffsetV);
ViStatus _VI_FUNC rsnrtz_dataStatusTxt (ViSession instrumentHandle,
					ViInt16 statusParameter, ViChar _VI_FAR statusText[],
					ViPInt32 numberOfBytesRead);
ViStatus _VI_FUNC rsnrtz_writeInstrData (ViSession instrumentHandle,
					ViString writeBuffer);
ViStatus _VI_FUNC rsnrtz_readInstrData (ViSession instrumentHandle,
					ViInt32 numberBytesToRead, ViChar _VI_FAR readBuffer[],
					ViPInt32 numBytesRead);
ViStatus _VI_FUNC rsnrtz_reset (ViSession instrumentHandle);
ViStatus _VI_FUNC rsnrtz_self_test (ViSession instrumentHandle,
					ViPInt16 selfTestResult, ViChar _VI_FAR selfTestMessage[]);
ViStatus _VI_FUNC rsnrtz_error_query (ViSession instrumentHandle, ViPInt32 errorCode,
					ViChar _VI_FAR errorMessage[]);
ViStatus _VI_FUNC rsnrtz_error_message (ViSession instrumentHandle,
					ViStatus statusCode, ViChar _VI_FAR message[]);
ViStatus _VI_FUNC rsnrtz_revision_query (ViSession instrumentHandle,
					ViChar _VI_FAR instrumentDriverRevision[],
					ViChar _VI_FAR firmwareRevision[]);
ViStatus _VI_FUNC rsnrtz_close (ViSession instrumentHandle);


#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif

/*****************************************************************************/
/*=== END INCLUDE FILE ======================================================*/
/*****************************************************************************/

#endif
