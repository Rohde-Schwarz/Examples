/*===========================================================================*/
/* Rohde & Schwarz - Directional Power Sensor NRT-Z =========================*/
/* LabWindows/CVI 5.0 Instrument Driver                                      */
/* Original Release: December 1998                                           */
/* By: Michal Harhaj                                                         */
/*     PH. +420 696996146   Fax +420 696996147                               */
/*     e-mail: michal.harhaj@vsb.cz                                          */
/*                                                                           */
/* Modification History:                                                     */
/*  see file rsnrtz_vxi.chm                                                  */
/*===========================================================================*/

//#include <ansi_c.h>
#include <visa.h>
#include "rsnrtz.h"
  
#define RSNRTZ_REVISION     "Rev 1.5.0, 06/2021" /*  Instrument driver revision */
#define BUFFER_SIZE         128         /* I/O buffer size */

/*= Macros ==================================================================*/
#define CHECKERR(fCal) if (rsnrtz_status = (fCal), rsnrtz_status < VI_SUCCESS) \
                            return rsnrtz_status; else

/*****************************************************************************/
/*= INSTRUMENT-DEPENDENT COMMAND ARRAYS =====================================*/
/*****************************************************************************/
static ViString directionArr[] = {"AUTO","1>2","2>1"};
static ViString directionArrQuery[] = {"A","1","2"};
static ViString averResArr[] = {"LOW","HIGH"};
static ViString fwdMeasModeArr[] = {"AVER","CBAV","CCDF","CF","MBAV","PEP"};
static ViString revMeasModeArr[] = {"POW","RCO","RL","SWR"};
static ViString refPlaneArr[] = {"LOAD","SOUR"};
static ViString stateArr[] = {"OFF","ON"};
static ViString errorStatusArr[] = {"_","e"};
static ViString limitStatusArr[] = {"_","i","o"};
static ViString fwdFuncStatusArr[] = {"av","cd","cf","cb","mb","pp"};
static ViString revFuncStatusArr[] = {"pw","rc","rl","sw"};
static ViString powDirStatusArr[] = {"1","2"};
static ViString operModeArr[] = {"boot","busy","oper"};
static ViString statParamArr[] = {"SPEC","STAT:MEAS","STAT:ERR:TEXT"};
static ViString bandwidthArr[] = {"4E3","200E3","4E6"};
static ViString bandwidthArr14[] = {"4E3","200E3","6E6"};
static ViString modArr[] = {"OFF", "IS95", "EDGE", "WCDMA", "DVBT", "DAB"};

/*****************************************************************************/
/*= INSTRUMENT-DEPENDENT STATUS/RANGE STRUCTURE  ============================*/
/*****************************************************************************/
/* buffer is used to write and read data from the instrument                 */
/* rsnrtz_stringValPair is used in the rsnrtz_errorMessage function          */
/* rsnrtz_statusDataRanges is used to track session dependent status & ranges*/
/*      measStatCheck - indicates whether DISP:STAT is ON (1) or OFF (0)     */
/*      measReadRes - indicates which data will be read out:                 */
/*          0 - FORW + REFL                                                  */
/*          1 - FORW                                                         */
/*          2 - REFL                                                         */
/*      sensorType - indicates sensor type                                   */
/*          0 - NRT-Z43                                                      */
/*          1 - NRT-Z44                                                      */
/*===========================================================================*/
static ViChar buffer[BUFFER_SIZE];

typedef struct  rsnrtz_stringValPair
{
   ViInt32 stringVal;
   ViChar *stringName;
}  rsnrtz_tStringValPair;
 
struct rsnrtz_statusDataRanges 
{
    ViInt16 measStatCheck;
    ViInt16 measReadRes;
    ViInt16 sensorType;
    ViChar instrDriverRevision[256];
};

typedef struct rsnrtz_statusDataRanges *rsnrtz_instrRange;

/*****************************************************************************/
/*= UTILITY ROUTINE DECLARATIONS (Non-Exportable Functions) =================*/
/*****************************************************************************/
ViBoolean rsnrtz_invalidViBooleanRange (ViBoolean val);
ViBoolean rsnrtz_invalidViInt16Range (ViInt16 val, ViInt16 min, ViInt16 max);
ViBoolean rsnrtz_invalidViInt32Range (ViInt32 val, ViInt32 min, ViInt32 max);
ViBoolean rsnrtz_invalidViReal64Range (ViReal64 val, ViReal64 min, ViReal64 max);
ViStatus rsnrtz_initCleanUp (ViSession openRMSession, ViPSession openinstrumentHandle, ViStatus currentStatus);
ViStatus rsnrtz_readASCII (ViSession instrumentHandle, ViPByte buf, ViUInt32 cnt, ViPUInt32 retCnt);
ViStatus rsnrtz_writeASCII (ViSession instrumentHandle, ViPByte buf, ViUInt32 cnt, ViPUInt32 retCnt);
ViStatus rsnrtz_initCleanUp (ViSession openRMSession, ViPSession openinstrumentHandle, ViStatus currentStatus);
ViStatus rsnrtz_defaultInstrSetup (ViSession openinstrumentHandle);
ViStatus rsnrtz_reconfigInterface (ViSession instrumentHandle, ViInt32 baudRate, ViInt32 timeoutms);
void rsnrtz_delay (ViReal64 numberOfSeconds);

/*****************************************************************************/
/*------ INSTRUMENT-DEPENDENT UTILITY ROUTINE DECLARATIONS ------------------*/
/*****************************************************************************/
ViStatus rsnrtz_parseInstrResp (ViPByte rdBuffer, ViPString paramArr[], 
    ViInt32 arrSize, ViInt32 bytesToCompare, ViPInt16 paramPos);
ViStatus rsnrtz_writeReadInstrResp (ViSession instrumentHandle, ViPByte wrtBuffer, 
    ViPByte rdBuffer, ViInt32 bytesToWrite);

/*****************************************************************************/
/*====== USER-CALLABLE FUNCTIONS (Exportable Functions) =====================*/
/*****************************************************************************/

/*=========================================================================*/
/* Function: Initialize                                                    */
/* Purpose:  This function opens a com port for the instrument, queries    */
/*           the instrument for its ID, and initializes the instrument to  */
/*           a known state.                                                */
/*=========================================================================*/
ViStatus _VI_FUNC rsnrtz_init (ViRsrc resourceName, ViBoolean IDQuery, 
            ViBoolean resetDevice, ViPSession instrumentHandle)
{
    ViUInt16 interfaceType;
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViSession rmSession = 0;
    ViUInt32 retCnt = 0;
    ViChar rdBuffer[BUFFER_SIZE];

    /*- Check input parameter ranges ----------------------------------------*/
    if (rsnrtz_invalidViBooleanRange (IDQuery))
        return VI_ERROR_PARAMETER2;
    if (rsnrtz_invalidViBooleanRange (resetDevice))
        return VI_ERROR_PARAMETER3;
        
    /*- Open instrument session ---------------------------------------------*/
    if ((rsnrtz_status = viOpenDefaultRM (&rmSession)) < 0)
        return rsnrtz_status;

    if ((rsnrtz_status = viOpen (rmSession, resourceName, VI_LOAD_CONFIG, VI_NULL, instrumentHandle)) < 0) {
        viClose (rmSession);
        return rsnrtz_status;
    }
    
    if ((rsnrtz_status = viSetAttribute (*instrumentHandle, VI_ATTR_TMO_VALUE, 10000)) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);

    if ((rsnrtz_status = viGetAttribute (*instrumentHandle, VI_ATTR_INTF_TYPE, &interfaceType)) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);

    if (interfaceType != 4) {
        rsnrtz_status = RSNRTZ_ERROR_NSUP_INTERFACE;
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
    }    
    
    /*- Configure VISA Formatted I/O ----------------------------------------*/
    if ((rsnrtz_status = viSetBuf (*instrumentHandle, VI_ASRL_IN_BUF|VI_ASRL_OUT_BUF, 512)) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
   
    if ((rsnrtz_status = viSetBuf (*instrumentHandle, VI_READ_BUF|VI_WRITE_BUF, 4000)) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
   
    if ((rsnrtz_status = viSetAttribute (*instrumentHandle, VI_ATTR_WR_BUF_OPER_MODE,
                            VI_FLUSH_ON_ACCESS)) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
    
    if ((rsnrtz_status = viSetAttribute (*instrumentHandle, VI_ATTR_RD_BUF_OPER_MODE,
                            VI_FLUSH_ON_ACCESS)) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
 
    if ((rsnrtz_status = viSetAttribute (*instrumentHandle, VI_ATTR_TERMCHAR, '\n')) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
 
    if ((rsnrtz_status = viSetAttribute (*instrumentHandle, VI_ATTR_ASRL_END_IN,
                                         VI_ASRL_END_TERMCHAR)) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
   
    if ((rsnrtz_status = viSetAttribute (*instrumentHandle, VI_ATTR_ASRL_END_OUT,
                                         VI_ASRL_END_NONE)) < 0)
        return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);

    if (IDQuery) 
    {
        if ((rsnrtz_status = rsnrtz_writeASCII (*instrumentHandle, (ViPByte)"ID\r\n", 4, &retCnt)) < 0)
            return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
        if ((rsnrtz_status = rsnrtz_readASCII (*instrumentHandle, (ViPByte)rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
            return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
        if (strstr (rdBuffer, "NRT-Z44") == VI_NULL)
            if (strstr (rdBuffer, "NRT-Z43") == VI_NULL)
                if (strstr (rdBuffer, "NRT-Z14") == VI_NULL)
                    return rsnrtz_initCleanUp (rmSession, instrumentHandle, VI_ERROR_FAIL_ID_QUERY);
    }
        
    /*- Reset instrument ----------------------------------------------------*/
    if (resetDevice) 
    {
        if ((rsnrtz_status = rsnrtz_reset (*instrumentHandle)) < 0)
            return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
    }       
    else  /*- Send Default Instrument Setup ---------------------------------*/
        if ((rsnrtz_status = rsnrtz_defaultInstrSetup (*instrumentHandle)) < 0)
            return rsnrtz_initCleanUp (rmSession, instrumentHandle, rsnrtz_status);
          
    return rsnrtz_status;
}

/*****************************************************************************/
/*--------------- USER-CALLABLE INSTRUMENT-DEPENDENT ROUTINES ---------------*/
/*****************************************************************************/

/*===========================================================================*/
/* Function: Measure Forwarded And Reflected Power                           */
/* Purpose:  This function represents a high-level approach to the instrument*/
/*           driver. It demonstrates how to create an application function   */
/*           which contains a set of low-level functions.                    */
/*                                                                           */
/* This function performs the following operations:                          */
/*                                                                           */
/*           1. Resets the instrument to the default state.                  */
/*           2. Configures measurement - measure both forward and reflected  */
/*              power.                                                       */
/*           3. Configures forward measurement mode                          */
/*           4. Configures reverse measurement mode                          */
/*           5. Triggers measurement and reads results.                      */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_applMeasPower (ViSession instrumentHandle, ViPReal64 fwdPower, 
    ViPReal64 reflPower)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViInt16 oldStat, oldRes, oldFwdMeas, oldRevMeas;

    /* Reset instrument to default state */
    CHECKERR(rsnrtz_reset (instrumentHandle));

    /* Config measurement - measure both forward and reflected power */
    CHECKERR(rsnrtz_configMeas (instrumentHandle, VI_OFF, 0, &oldStat, &oldRes));
        
    /* Config forward measurement mode */
    CHECKERR(rsnrtz_actstatFwdMeasMode (instrumentHandle, 0, &oldFwdMeas));
        
    /* Config reverse measurement mode */
    CHECKERR(rsnrtz_actstatRevMeasMode (instrumentHandle, 0, &oldRevMeas));
    
    /* Trigger measurement and read results */
    CHECKERR(rsnrtz_actstatMeas (instrumentHandle, VI_ON, fwdPower, reflPower));
    
    return rsnrtz_status;
}
    
/*===========================================================================*/
/* Function: Config Burst                                                    */
/* Purpose:  This function configures the burst width and burst period.      */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configBurst (ViSession instrumentHandle, ViReal64 burstPeriodNew,
    ViReal64 burstWidthNew, ViPReal64 burstPeriodOld, ViPReal64 burstWidthOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViChar rdBuffer[BUFFER_SIZE];
    
    if (rsnrtz_invalidViReal64Range (burstPeriodNew, burstWidthNew, 1.0))
        return VI_ERROR_PARAMETER2;
    if (rsnrtz_invalidViReal64Range (burstWidthNew, 10.0E-9, burstPeriodNew))
        return VI_ERROR_PARAMETER3;
        
    sprintf(buffer, "BURS:PER %Le\r\n", burstPeriodNew);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, (ViPByte)rdBuffer, 
        strlen(buffer)));

    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (sscanf (index+5, "%Le", burstPeriodOld) != 1) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    sprintf (buffer, "BURS:WIDT %Le\r\n", burstWidthNew);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen(buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (sscanf (index+5, "%Le", burstWidthOld) != 1) 
        rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    return rsnrtz_status;
}
           
/*===========================================================================*/
/* Function: Config CCDF                                                     */
/* Purpose:  This function configures the CCDF.                              */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configCCDF (ViSession instrumentHandle, ViReal64 threshNew, 
    ViPReal64 threshOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViChar rdBuffer[BUFFER_SIZE];
    rsnrtz_instrRange instrPtr;
    
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
    
    if (rsnrtz_invalidViReal64Range (threshNew, (instrPtr -> sensorType == 1) ? 1.0 : 0.25,
                                                (instrPtr -> sensorType == 1) ? 300.0 : 75.0))
            return VI_ERROR_PARAMETER2;

    sprintf(buffer, "CCDF %Le\r\n", threshNew);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte) buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == 0) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (sscanf (index+5, "%Le", threshOld) != 1) 
        rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Forward Power Direction                                  */
/* Purpose:  This function specifies the direction of the forward power      */
/*           relative to the sensor ports 1 and 2.                           */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configDir (ViSession instrumentHandle, ViInt16 directionNew,
    ViPInt16 directionOld)
{
    ViChar* index = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar rdBuffer[BUFFER_SIZE];
    ViInt32 i = 0;    

    if (rsnrtz_invalidViInt16Range (directionNew, 0, 2))
        return VI_ERROR_PARAMETER2;
        
    sprintf(buffer, "DIR %s\r\n", directionArr[directionNew]);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen(buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    do {
        if (strncmp (index+5, directionArrQuery[i], 1) == 0)
        {
            *directionOld = i;
            i = -1;
        }           
        else 
        {
            if (i >= 2) 
            {
                *directionOld = -1;
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            }               
            i++;
        }           
    } while (i > 0);
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Carrier Frequency                                        */
/* Purpose:  This function sets the carrier frequency of the test signal.    */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configCarrFreq (ViSession instrumentHandle, ViReal64 carrFreqNew,
    ViPReal64 carrFreqOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index = 0;
    ViChar rdBuffer[BUFFER_SIZE];
    rsnrtz_instrRange instrPtr;
    
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
    
    switch (instrPtr -> sensorType)
    {
        case 0:
            if (rsnrtz_invalidViReal64Range (carrFreqNew, 400.0E6, 4.0E9))
                return VI_ERROR_PARAMETER2;
            break;
        case 1:
            if (rsnrtz_invalidViReal64Range (carrFreqNew, 200.0E6, 4.0E9))
                return VI_ERROR_PARAMETER2;
            break;
        case 2:
            if (rsnrtz_invalidViReal64Range (carrFreqNew, 25.0E6, 1.0E9))
                return VI_ERROR_PARAMETER2;
            break;
    }
        
    sprintf (buffer, "FREQ %Le\r\n", carrFreqNew);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer,
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (sscanf (index+5, "%Le", carrFreqOld) != 1) 
        rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Averaging                                                */
/* Purpose:  This function configures averaging filters.                     */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configAver (ViSession instrumentHandle, ViBoolean averModeNew,
    ViInt16 averFiltCountNew, ViBoolean averResNew, ViPInt16 averFiltCountOld, 
    ViPInt16 averResOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViChar rdBuffer[BUFFER_SIZE];
    rsnrtz_instrRange instrPtr;
    
    if (rsnrtz_invalidViBooleanRange (averModeNew))
        return VI_ERROR_PARAMETER2;
    if (rsnrtz_invalidViBooleanRange (averResNew))
        return VI_ERROR_PARAMETER4;
        
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
    
    if (instrPtr -> sensorType == 1) 
    {
        if (rsnrtz_invalidViInt16Range (averFiltCountNew, 0, 7))
            return VI_ERROR_PARAMETER3;
    }           
    else
        if (rsnrtz_invalidViInt16Range (averFiltCountNew, 0, 8))
            return VI_ERROR_PARAMETER3;
    
    if (averModeNew == VI_OFF)
        sprintf (buffer, "FILT:RES %s\r\n", averResArr[averResNew]);
    else    
        sprintf (buffer, "FILT:AVER:COUN %d\r\n", (int)pow (2, averFiltCountNew));
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr (rdBuffer,"old:");
    
    if (index == VI_NULL) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (averModeNew == VI_OFF)
    {
        CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index+5), averResArr, 2, 3, averResOld));
        *averFiltCountOld = -1;
    }
    else 
    {
        if (sscanf (index+4, "%hd", averFiltCountOld) != 1) 
            return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
        *averResOld = -1;
    }       
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Integration Time                                         */
/* Purpose:  This function configures the integration time of the A/D        */
/*           converters in the two measurement channels.                     */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configIntTime (ViSession instrumentHandle, ViReal64 intTimeNew,
    ViPReal64 intTimeOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViChar rdBuffer[BUFFER_SIZE];

    if (rsnrtz_invalidViReal64Range (intTimeNew, 5.0E-3, 0.111))
        return VI_ERROR_PARAMETER2;
        
    sprintf (buffer, "FILT:INT:TIME %Le\r\n", intTimeNew);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (sscanf (index + 5, "%Le", intTimeOld) != 1) 
        rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Video Bandwidth                                          */
/* Purpose:  This function is used for setting the video bandwidth for CCDF  */
/*           CF, PEP and MBAV.                                               */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configVideoBW (ViSession instrumentHandle, ViInt16 bandwidthNew, 
    ViBoolean SPSPNew, ViPReal64 bandwidthOld, ViPInt16 SPSPOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar rdBuffer[BUFFER_SIZE];
    ViChar* index = 0;
    rsnrtz_instrRange instrPtr;
    
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
    
    if (rsnrtz_invalidViInt16Range (bandwidthNew, 0, 2))
        return VI_ERROR_PARAMETER2;
    if (rsnrtz_invalidViBooleanRange (SPSPNew))
        return VI_ERROR_PARAMETER3;
        
    if (SPSPNew == VI_ON)
         sprintf(buffer, "FILT:SPSP ON\r\n");
    else
        sprintf(buffer, "FILT:SPSP OFF\r\n");
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");

    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index + 5), stateArr, 2, 2, SPSPOld));

    *bandwidthOld = -1;
    
    if (SPSPNew == VI_OFF) 
    {
        if (instrPtr -> sensorType == 2)
            sprintf(buffer, "FILT:VID %s\r\n", bandwidthArr14[bandwidthNew]);
        else
            sprintf(buffer, "FILT:VID %s\r\n", bandwidthArr[bandwidthNew]);
    
        CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
            (ViPByte)rdBuffer, strlen (buffer)));
    
        index = strstr (rdBuffer, "old:");
    
        if (index == VI_NULL)
            return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
        
        if (sscanf (index+4, "%Le", bandwidthOld) != 1)
            rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;
    }   

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Hold Time                                                */
/* Purpose:  This function sets the hold time of the peak hold circuit.      */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configHoldTime (ViSession instrumentHandle, ViReal64 holdTimeNew,
    ViPReal64 holdTimeOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar rdBuffer[BUFFER_SIZE];
    ViChar* index;

    if (rsnrtz_invalidViReal64Range (holdTimeNew, 1.0E-3, 0.1))
        return VI_ERROR_PARAMETER2;
        
    sprintf(buffer, "PEP:TIME %Le\r\n", holdTimeNew);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (sscanf (index + 5, "%Le", holdTimeOld) != 1)
        rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Reference Plane                                          */
/* Purpose:  This function defines the reference plane for the measurement.  */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configRefPlane (ViSession instrumentHandle, ViBoolean refPlaneNew, 
    ViPInt16 refPlaneOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar rdBuffer[BUFFER_SIZE];
    ViChar* index;

    if (rsnrtz_invalidViBooleanRange (refPlaneNew))
        return VI_ERROR_PARAMETER2;
        
    if (refPlaneNew == VI_OFF)
        sprintf (buffer, "PORT LOAD\r\n");
    else        
        sprintf (buffer, "PORT SOUR\r\n");
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, (ViPByte)rdBuffer, 
        strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index + 5), refPlaneArr, 2, 4, refPlaneOld));
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Measurement                                              */
/* Purpose:  This function configures read-out of measurement results.       */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configMeas (ViSession instrumentHandle, ViBoolean statCheckNew,
    ViInt16 readResNew, ViPInt16 statCheckOld, ViPInt16 readResOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViUInt32 retCnt;
    ViInt16 oldFwd = 0;
    ViInt16 oldRev = 0;
    ViChar rdBuffer[BUFFER_SIZE];
    rsnrtz_instrRange instrPtr;    

    if (rsnrtz_invalidViBooleanRange (statCheckNew))
        return VI_ERROR_PARAMETER2;
    if (rsnrtz_invalidViInt16Range (readResNew, 0, 2))
        return VI_ERROR_PARAMETER3;

    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
        
    if (statCheckNew == VI_OFF)
    {
        sprintf (buffer, "DISP:STAT OFF\r\n");
        instrPtr -> measStatCheck = 0;
    }
    else
    {
        sprintf (buffer, "DISP:STAT ON\r\n");
        instrPtr -> measStatCheck = 1;
    }       
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, (ViPByte)rdBuffer, 
        strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index + 5), stateArr, 2, 2, statCheckOld));
    
    switch (readResNew) 
    {
        case 0:
                sprintf (buffer, "DISP:FORW ON, DISP:REFL ON\r\n");
                instrPtr -> measReadRes = 0;
            break;
        case 1:
                sprintf (buffer, "DISP:FORW ON, DISP:REFL OFF\r\n");
                instrPtr -> measReadRes = 1;
            break;
        case 2:
                sprintf (buffer, "DISP:FORW OFF, DISP:REFL ON\r\n");
                instrPtr -> measReadRes = 2;
            break;
    }

    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_USER_DATA, (ViUInt32)instrPtr));
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
            
    index = strstr (rdBuffer, "old:");

    if (index == VI_NULL) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index + 5), stateArr, 2, 2, &oldFwd));
    
    CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
            
    index = strstr (buffer, "old:");

    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

       
    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index+5), stateArr, 2, 2, &oldRev));
            
    if ((oldFwd == 0) && (oldRev == 0))
    {
        *readResOld = 0;
    }       
    else 
        if ((oldFwd == 0) && (oldRev == 1)) 
        {
            *readResOld = 2;
        }       
        else 
            if ((oldFwd == 1) && (oldRev == 1)) 
            {
                *readResOld = 0;
            }       
            else 
                if ((oldFwd == 1) && (oldRev == 0)) 
                {
                    *readResOld = 1;
                }       
        
    return rsnrtz_status;
}
    

/*===========================================================================*/
/* Function: Config Modulation                                               */
/* Purpose:  This function configures the modulation parameters in the power */
/*           sensor.                                                         */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configMod (ViSession instrumentHandle,
                                    ViReal64 chipRate1s,
                                    ViInt16 communicationStandard,
                                    ViReal64 *oldChipRate,
                                    ViInt16 *oldCommunicationStandard)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViChar rdBuffer[BUFFER_SIZE];
    rsnrtz_instrRange instrPtr;
    
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
    
    if (instrPtr -> sensorType == 2)
        return RSNRT_ERROR_INVALID_CONFIGURATION;

    if (rsnrtz_invalidViReal64Range (chipRate1s, 0, 8.2E+6))
        return VI_ERROR_PARAMETER2;
    if (rsnrtz_invalidViInt16Range (communicationStandard, 0, 5))
        return VI_ERROR_PARAMETER3;

    sprintf (buffer, "MOD:RATE %Le\r\n", chipRate1s);
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (sscanf (index + 5, "%Le", oldChipRate) != 1) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
    
    sprintf (buffer, "MOD:TYPE %s\r\n", modArr[communicationStandard]);

    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, (ViPByte)rdBuffer,
        strlen (buffer)));
            
    index = strstr (rdBuffer, "old:");

    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index + 5), modArr, 6, 3, oldCommunicationStandard));
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Config Attenuation                                              */
/* Purpose:  This function configures the RF cable attenuation               */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configAttn (ViSession instrumentHandle,
                                     ViReal64 attenuationdB,
                                     ViReal64 *oldAttenuation)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index ;
    ViChar rdBuffer[BUFFER_SIZE];

    if (rsnrtz_invalidViReal64Range (attenuationdB, 0.0, 100.0))
        return VI_ERROR_PARAMETER2;

    sprintf (buffer, "OFFS %Le\r\n", attenuationdB);
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr(rdBuffer, "old:");
    
    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    if (sscanf (index + 5, "%Le", oldAttenuation) != 1)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Boot                                                            */
/* Purpose:  This function activates the boot mode of the sensor from any    */
/*           other operating mode.                                           */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configBoot (ViSession instrumentHandle)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
        
    CHECKERR(viPrintf (instrumentHandle, "BOOT\r\n"));

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Purge                                                           */
/* Purpose:  This function deletes the input buffer of the sensor and thus   */
/*           prevents execution of waiting commands.                         */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configPurge (ViSession instrumentHandle)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    
    CHECKERR(viPrintf (instrumentHandle, "PURGE\r\n"));

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Query Operating Mode                                            */
/* Purpose:  This function switches the sensor to the measurement mode and   */
/*           indicates the current operating status of the sensor before the */
/*           command was sent.                                               */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configQueryOpMode (ViSession instrumentHandle, ViPInt16 operMode)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar rdBuffer[BUFFER_SIZE];
    
    sprintf (buffer, "APPL\r\n");
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));

    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(rdBuffer + 4), operModeArr, 3, 4, operMode));
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Query Hardware Test Points                                      */
/* Purpose:  This function reads measured values for selected hardware test  */
/*           points along with their limit values.                           */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_configHWTestPts (ViSession instrumentHandle, _VI_FAR ViReal64 limLow[], 
    _VI_FAR ViReal64 vals[], _VI_FAR ViReal64 limHigh[])
{
    ViUInt32 retCnt = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViInt32 pack = 0;
    ViInt32 i = 0;
    ViChar rdBuffer[BUFFER_SIZE];
    
    sprintf (buffer, "STAT:ERR:VALS\r\n");
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));

    index = strstr (rdBuffer, "pack");
    
    if (sscanf (index + 5, "%ld", &pack) != 1) 
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    for (i=0; i<pack; i++) 
    {
        index = VI_NULL;
        
        CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
        
        if (sscanf (buffer, "%*[^:]:%Le %Le %Le", &limLow[i], &vals[i], &limHigh[i]) != 3)
            return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
    }
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Select Forward Measurement Mode                                 */
/* Purpose:  This function selects the forward measurement function.         */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_actstatFwdMeasMode (ViSession instrumentHandle,
    ViInt16 fwdMeasModeNew, ViPInt16 fwdMeasModeOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViChar rdBuffer[BUFFER_SIZE];

    if (rsnrtz_invalidViInt16Range (fwdMeasModeNew, 0, 5))
        return VI_ERROR_PARAMETER2;
        
    sprintf (buffer, "FOR:%s\r\n", fwdMeasModeArr[fwdMeasModeNew]);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));
    
    index = strstr (rdBuffer, "old:");
    
    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index + 4), fwdMeasModeArr, 6, 2, fwdMeasModeOld));

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Select Reverse Measurement Mode                                 */
/* Purpose:  This function sets the reverse measurement mode.                */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_actstatRevMeasMode (ViSession instrumentHandle, ViInt16 revMeasModeNew, 
    ViPInt16 revMeasModeOld)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViChar rdBuffer[BUFFER_SIZE];

    if (rsnrtz_invalidViInt16Range (revMeasModeNew, 0, 3))
        return VI_ERROR_PARAMETER2;
        
    sprintf (buffer, "REV:%s\r\n", revMeasModeArr[revMeasModeNew]);
    
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen(buffer)));
    
    index = strstr(rdBuffer, "old:");
    
    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)(index + 4), revMeasModeArr, 4, 2, revMeasModeOld));

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Zeroing                                                         */
/* Purpose:  This function turns off zeroing or performs single zeroing and  */
/*           turns zeroing on.                                               */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_actstatZero (ViSession instrumentHandle, ViBoolean zero,
    ViPReal64 fwdOffs, ViPReal64 revOffs, ViPReal64 zero4kHz, ViPReal64 zero200kHz,
    ViPReal64 zero4MHz)
{
    ViUInt32 retCnt = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar rdBuffer[BUFFER_SIZE];
    ViChar* index;

    if (rsnrtz_invalidViBooleanRange (zero))
        return VI_ERROR_PARAMETER2;
        
    if (zero == VI_OFF) 
    {
        sprintf (buffer, "ZERO 0\r\n");
        *fwdOffs = 0.0;
        *revOffs = 0.0;
        *zero4kHz = 0.0;
        *zero200kHz = 0.0;
        *zero4MHz = 0.0;
    }       
    else        
        sprintf (buffer, "ZERO\r\n");
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen(buffer)));

    index = strstr (rdBuffer, "Error ZERO");
    
    if (index != VI_NULL)
    {
        *fwdOffs = 0.0;
        *revOffs = 0.0;
        *zero4kHz = 0.0;
        *zero200kHz = 0.0;
        *zero4MHz = 0.0;
        return RSNRTZ_ERROR_INSTR_ZERO;
    }        
    else
        if (zero == VI_ON)
        {
            CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
            if (sscanf(buffer, "%*[^=]=%Le%*[^=]=%Le", fwdOffs, revOffs) != 2)
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            
            CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
            if (sscanf (buffer, "%*[^:]:%Le", zero4kHz) != 1)
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
        
            CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
            if (sscanf (buffer, "%*[^:]:%Le", zero200kHz) != 1)
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            
            CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
            if (sscanf (buffer, "%*[^:]:%Le", zero4MHz) != 1)
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
        }   
    

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Measure                                                         */
/* Purpose:  This function triggers measurement and reads measurement results*/
/*           from the instrument.                                            */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_actstatMeas (ViSession instrumentHandle, ViBoolean trigType,
    ViPReal64 fwdVal, ViPReal64 revVal)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar rdBuffer[BUFFER_SIZE];
    rsnrtz_instrRange instrPtr;    
    
    if (rsnrtz_invalidViBooleanRange (trigType))
        return VI_ERROR_PARAMETER2;
        
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
        
    if (instrPtr -> measStatCheck != 0)
        return RSNRTZ_ERROR_INSTR_MEAS_STAT;
  
    if (trigType == VI_OFF)
        sprintf (buffer, "FTRG\r\n");
    else        
        sprintf (buffer, "RTRG\r\n");
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen (buffer)));

    switch (instrPtr -> measReadRes) 
    {
        case 0:
            if (sscanf (rdBuffer+4, "%Le %Le", fwdVal, revVal) != 2)
                rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            break;
        case 1:
            if (sscanf (rdBuffer+4, "%Le", fwdVal) != 1)
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            *revVal = 0.0;
            break;
        case 2:
            if (sscanf (rdBuffer+4, "%Le", revVal) != 1)
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            *fwdVal = 0.0;
            break;
    }
    
    return rsnrtz_status;
} 
    
/*===========================================================================*/
/* Function: Measure With Status                                             */
/* Purpose:  This function triggers measurement and reads measurement results*/
/*           with status information from the instrument.                    */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_actstatMeasWithStat (ViSession instrumentHandle, ViBoolean trigType,
    ViPReal64 fwdVal, ViPReal64 revVal, ViPInt16 error, ViPInt16 limit, ViPInt16 fwdFunc,
    ViPInt16 revFunc, ViPInt16 powDir, ViPInt16 avgPowFwdFilt, ViPInt16 avgPowRevFilt, 
    ViPInt16 PEPFilt, ViPInt16 distrFuncFilt)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar statusString[BUFFER_SIZE];
    ViChar rdBuffer[BUFFER_SIZE];
    ViChar tempString[5];
    rsnrtz_instrRange instrPtr;

    if (rsnrtz_invalidViBooleanRange (trigType))
        return VI_ERROR_PARAMETER2;
        
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
        
    if (instrPtr -> measStatCheck != 1)
        return RSNRTZ_ERROR_INSTR_MEAS_STAT;
        
    if (trigType == VI_OFF)
        sprintf (buffer, "FTRG\r\n");
    else        
        sprintf (buffer, "RTRG\r\n");
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, (ViPByte)rdBuffer, 
        strlen (buffer)));
    
    switch (instrPtr -> measReadRes) 
    {
        case 0:
            if (sscanf (rdBuffer+4, "%Le %Le %s", fwdVal, revVal, statusString) != 3)
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            break;
        case 1:
            if (sscanf (rdBuffer+4, "%Le %s", fwdVal, statusString) != 2) 
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            *revVal = 0.0;
            break;
        case 2:
            if (sscanf (rdBuffer+4, "%Le %s", revVal, statusString) != 2)
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            *fwdVal = 0.0;
            break;
    }

    tempString[0] = statusString[0];
    tempString[1] = '\0';
    
    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)tempString, errorStatusArr, 2, 1, error));
    
    tempString[0] = statusString[1];
    
    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)tempString, limitStatusArr, 3, 1, limit));

    memcpy(tempString, statusString+2, 2);
    tempString[2] = 0;
    
    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)tempString, fwdFuncStatusArr, 6, 2, fwdFunc));
    
    memcpy (tempString, statusString+4, 2);
    tempString[2] = '\0';
    
    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)tempString, revFuncStatusArr, 4, 2, revFunc));
    
    tempString[0]=statusString[6];
    tempString[1] = '\0';
    
    CHECKERR(rsnrtz_parseInstrResp ((ViPByte)tempString, powDirStatusArr, 2, 1, powDir));
    
    if (sscanf (statusString + 7, "%1hd%1hd%1hd%1hd", avgPowFwdFilt, avgPowRevFilt,
        PEPFilt, distrFuncFilt) != 4)
        rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Measure Noise                                                   */
/* Purpose:  This function measures noise obtained with the average power    */
/*           measurement (forward and reverse).                              */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_actstatMeasNoise (ViSession instrumentHandle, ViPReal64 Vpp1,
    ViPReal64 Vpp2, ViPReal64 noise1, ViPReal64 noise2)
{
    ViUInt32 retCnt = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViInt32 timeoutOrig;
  
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_TMO_VALUE, &timeoutOrig));
    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_TMO_VALUE, 180000));
                                                        
    CHECKERR(viPrintf (instrumentHandle, "SERV:NOISE:AVER\r\n"));

    CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
    CHECKERR(viScanf (instrumentHandle,"%*[^=]=%Le%*[^=]=%Le",Vpp1, Vpp2));
    CHECKERR(viScanf (instrumentHandle, "%*[^=]=%Le%*[^=]=%Le", noise1, noise2))

    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_TMO_VALUE, timeoutOrig));
    
    return rsnrtz_status;
}
    
/*===========================================================================*/
/* Function: Measure Peak Hold Offset                                        */
/* Purpose:  This function measures offset voltages of peak hold circuit as  */
/*           function of video filter setting.                               */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_actstatMeasOffs (ViSession instrumentHandle, ViPReal64 offs1,
    ViPReal64 offs2)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar rdBuffer[BUFFER_SIZE];
  
    sprintf (buffer, "SERV:NOISE:PEP\r\n");
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, (ViPByte)rdBuffer, 
        strlen(buffer)));

    CHECKERR(viScanf (instrumentHandle, "%*[^:]:%Le", offs1));
    CHECKERR(viScanf (instrumentHandle, "%*[^:]:%Le", offs2));

    return rsnrtz_status;
}
    
/*===========================================================================*/
/* Function: Status Text                                                     */
/* Purpose:  This function reads text status information from the sensor.    */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_dataStatusTxt (ViSession instrumentHandle, ViInt16 statParam,
    _VI_FAR ViChar text[], ViPInt32 numbOfBytes)
{
    ViUInt32 retCnt = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViChar* index;
    ViInt32 pack = 0;
    ViInt32 i = 0;
    ViInt32 count = 0;
    ViChar rdBuffer[BUFFER_SIZE];

    if (rsnrtz_invalidViInt16Range (statParam, 0, 2))
        return VI_ERROR_PARAMETER2;
    
    sprintf (buffer, "%s\r\n", statParamArr[statParam]);
        
    CHECKERR(rsnrtz_writeReadInstrResp (instrumentHandle, (ViPByte)buffer, 
        (ViPByte)rdBuffer, strlen(buffer)));

    index = strstr (rdBuffer, "pack");
    
    if (index == VI_NULL)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
    
    if (sscanf (index+5, "%ld", &pack) != 1)
        return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    count = 0;
    for (i=0; i<pack; i++)
    {
        CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
        
        memcpy(text+count, buffer, retCnt);
        count += retCnt;
    }

    text[count]='\0';
    *numbOfBytes = count - 1;
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Write To Instrument                                             */
/* Purpose:  This function writes a command string to the instrument.        */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_writeInstrData (ViSession instrumentHandle, ViString writeBuffer)
{
    return viPrintf (instrumentHandle, "%s\r\n", writeBuffer);
}

/*===========================================================================*/
/* Function: Read Instrument Buffer                                          */
/* Purpose:  This function reads the output buffer of the instrument.        */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_readInstrData (ViSession instrumentHandle, ViInt32 numberBytesToRead,
                    ViChar _VI_FAR readBuffer[], ViPInt32 numBytesRead)
{
    *numBytesRead = 0L;
        
    return viRead (instrumentHandle, (ViPByte)readBuffer, numberBytesToRead, (ViPUInt32)numBytesRead);
}

/*===========================================================================*/
/* Function: Reset                                                           */
/* Purpose:  This function resets the instrument.                            */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_reset (ViSession instrumentHandle)
{
    ViUInt32 retCnt = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;

    /*  Initialize the instrument to a known state.  */
    CHECKERR(viPrintf (instrumentHandle, "RESET\r\n"));
    CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
    
    if (strstr(buffer,"OK") == VI_NULL)
        return RSNRTZ_ERROR_INSTR_RESET;
    
    CHECKERR(rsnrtz_defaultInstrSetup (instrumentHandle));
        
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Self-Test                                                       */
/* Purpose:  This function executes the instrument self-test and returns     */
/*           the result.                                                     */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_self_test (ViSession instrumentHandle, ViPInt16 testResult,
                    ViChar _VI_FAR testMessage[])
{
    ViUInt32 retCnt = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;

    CHECKERR(viPrintf (instrumentHandle, "SERV:TEST\r\n"));
    CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
    
    if (strstr(buffer,"OK") != VI_NULL)
    {
        sprintf (testMessage, "Self-test passed.");
        *testResult = 0;
        return rsnrtz_status;
    }        
    
    if (strstr(buffer,"ERROR") != VI_NULL)
    {
        sprintf (testMessage, "Self-test failed.");
        *testResult = 1;
        return rsnrtz_status;
    }        
    
    return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
}

/*===========================================================================*/
/* Function: Error Query                                                     */
/* Purpose:  This function queries the instrument error queue, and returns   */
/*           the result.                                                     */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_error_query (ViSession instrumentHandle, ViPInt32 errorCode,
                    ViChar _VI_FAR errorMessage[])
{
    ViUInt32 retCnt = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;

    CHECKERR(viPrintf (instrumentHandle, "STAT:ERR:CODE\r\n"));
    CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
    
    if (strstr(buffer+4,"1") != VI_NULL)
    {
        sprintf (errorMessage, "Instrument specific error.");
        *errorCode = 300;
        return rsnrtz_status;
    }       
    
    if (strstr(buffer+4,"0") == VI_NULL)
        rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;
        
    sprintf (errorMessage, "No error.");
    *errorCode = 0;

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Error Message                                                   */
/* Purpose:  This function translates the error return value from the        */
/*           instrument driver into a user-readable string.                  */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_error_message (ViSession instrumentHandle, ViStatus statusCode,
                    ViChar _VI_FAR message[])
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViInt16 i;
    static rsnrtz_tStringValPair statusDescArray[] = {
        {VI_WARN_NSUP_ID_QUERY,     "WARNING: ID Query not supported"},
        {VI_WARN_NSUP_RESET,        "WARNING: Reset not supported"},
        {VI_WARN_NSUP_SELF_TEST,    "WARNING: Self-test not supported"},
        {VI_WARN_NSUP_ERROR_QUERY,  "WARNING: Error Query not supported"},     
        {VI_WARN_NSUP_REV_QUERY,    "WARNING: Revision Query not supported"},
        {VI_ERROR_PARAMETER1,   "ERROR: Parameter 1 out of range"},
        {VI_ERROR_PARAMETER2,   "ERROR: Parameter 2 out of range"},
        {VI_ERROR_PARAMETER3,   "ERROR: Parameter 3 out of range"},
        {VI_ERROR_PARAMETER4,   "ERROR: Parameter 4 out of range"},
        {VI_ERROR_PARAMETER5,   "ERROR: Parameter 5 out of range"},
        {VI_ERROR_FAIL_ID_QUERY,"ERROR: Identification query failed"},
        {VI_ERROR_INV_RESPONSE, "ERROR: Interpreting instrument response"},
        {VI_ERROR_INSTR_INTERPRETING_RESPONSE, "ERROR: Interpreting the instrument's response"},
        {RSNRTZ_ERROR_INSTR_RESET,    "ERROR: Instrument reset error."},
        {RSNRTZ_ERROR_INSTR_ZERO,     "ERROR: Error zeroing (possibly RF on)."},
        {RSNRTZ_ERROR_INSTR_MEAS_STAT,"ERROR: Measurement configuration error."},
        {RSNRTZ_ERROR_NSUP_INTERFACE, "ERROR: Specified Interface not supported"},
        {RSNRTZ_ERROR_INSTR_SENSOR_BUSY, "ERROR: Sensor busy."},
        {RSNRTZ_ERROR_INSTR_ERROR_RANGE, "ERROR: Data out of range."},
        {VI_NULL, VI_NULL}
    };

    rsnrtz_status = viStatusDesc (instrumentHandle, statusCode, message);
    if (rsnrtz_status == VI_WARN_UNKNOWN_STATUS) {
        for (i=0; statusDescArray[i].stringName; i++) {
            if (statusDescArray[i].stringVal == statusCode) {
                sprintf (message, "%s", statusDescArray[i].stringName);
                return (VI_SUCCESS);
            }
        }
        sprintf (message, "Unknown Error 0x%x[uw8p0]", statusCode);
        return (VI_WARN_UNKNOWN_STATUS);
    }
    
    rsnrtz_status = VI_SUCCESS;
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Revision Query                                                  */
/* Purpose:  This function returns the driver and instrument revisions.      */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_revision_query (ViSession instrumentHandle,
                    ViChar _VI_FAR driverRev[], ViChar _VI_FAR instrRev[])
{
    ViUInt32 retCnt = 0;
    ViStatus rsnrtz_status = VI_SUCCESS;

    CHECKERR(viPrintf (instrumentHandle, "ID\r\n"));
    CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
    
    if ((strstr (buffer, "NRT")) == VI_NULL)
        rsnrtz_status = VI_ERROR_INSTR_INTERPRETING_RESPONSE;
    
    sscanf (buffer, "%*[^ ] %*[^ ] %[^\r\n]",instrRev);

    sprintf (driverRev, "%s", RSNRTZ_REVISION);
    
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Reconfigure Interface                                           */
/* Purpose:  This function allows the user to change the Baud Rate, Parity,  */
/*           and Time Out of the serial interface.                           */
/*===========================================================================*/
ViStatus rsnrtz_reconfigInterface (ViSession instrumentHandle, ViInt32 baudRate,
                                   ViInt32 timeoutmSec)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    
    switch (baudRate) 
    {
        case   4800: 
        case   9600: 
        case  19200:
        case  38400:
            break;
        default:
            rsnrtz_status = VI_ERROR_PARAMETER2;
            return rsnrtz_status;
    }
    if (timeoutmSec != -1 && timeoutmSec != 0)
        if (rsnrtz_invalidViInt32Range (timeoutmSec, 1, 0x7fffffff))
            return VI_ERROR_PARAMETER3;
    
    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_ASRL_BAUD, 
                                        (ViUInt32)baudRate));
    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_TMO_VALUE,
                                        (ViUInt32)timeoutmSec));
    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Close                                                           */
/* Purpose:  This function closes the instrument.                            */
/*===========================================================================*/
ViStatus _VI_FUNC rsnrtz_close (ViSession instrumentHandle)
{
    rsnrtz_instrRange instrPtr;
    ViSession rmSession;
    ViStatus rsnrtz_status = VI_SUCCESS;

    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_RM_SESSION, &rmSession));
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
    
    if (instrPtr != NULL) 
        free (instrPtr);
    
    rsnrtz_status = viClose (instrumentHandle);
    viClose (rmSession);

    return rsnrtz_status;
}

/*****************************************************************************/
/*= UTILITY ROUTINES (Non-Exportable Functions) =============================*/
/*****************************************************************************/

/*===========================================================================*/
/* Function: Boolean Value Out Of Range - ViBoolean                          */
/* Purpose:  This function checks a Boolean to see if it is equal to VI_TRUE */
/*           or VI_FALSE. If the value is out of range, the return value is  */
/*           VI_TRUE, otherwise the return value is VI_FALSE.                */
/*===========================================================================*/
ViBoolean rsnrtz_invalidViBooleanRange (ViBoolean val)
{
    return ((val != VI_FALSE && val != VI_TRUE) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Short Signed Integer Value Out Of Range - ViInt16               */
/* Purpose:  This function checks a short signed integer value to see if it  */  
/*           lies between a minimum and maximum value.  If the value is out  */
/*           of range, the return value is VI_TRUE, otherwise the return     */
/*           value is VI_FALSE.                                              */
/*===========================================================================*/
ViBoolean rsnrtz_invalidViInt16Range (ViInt16 val, ViInt16 min, ViInt16 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Long Signed Integer Value Out Of Range - ViInt32                */
/* Purpose:  This function checks a long signed integer value to see if it   */  
/*           lies between a minimum and maximum value.  If the value is out  */
/*           of range, the return value is VI_TRUE, otherwise the return     */
/*           value is VI_FALSE.                                              */
/*===========================================================================*/
ViBoolean rsnrtz_invalidViInt32Range (ViInt32 val, ViInt32 min, ViInt32 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Real (Double) Value Out Of Range - ViReal64                     */
/* Purpose:  This function checks a real (double) value to see if it lies    */  
/*           between a minimum and maximum value.  If the value is out of    */
/*           range, the return value is VI_TRUE, otherwise the return value  */
/*           is VI_FALSE.                                                    */
/*===========================================================================*/
ViBoolean rsnrtz_invalidViReal64Range (ViReal64 val, ViReal64 min, ViReal64 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Initialize Clean Up                                             */
/* Purpose:  This function is used only by the rsnrtz_init function.  When   */
/*           an error is detected this function is called to close the       */
/*           open resource manager and instrument object sessions and to     */
/*           set the instrumentHandle that is returned from rsnrtz_init to       */
/*           VI_NULL.                                                        */
/*===========================================================================*/
ViStatus rsnrtz_initCleanUp (ViSession openRMSession,
                    ViPSession openinstrumentHandle, ViStatus currentStatus)
{
    viClose (*openinstrumentHandle);
    viClose (openRMSession);
    *openinstrumentHandle = VI_NULL;
    
    return currentStatus;
}

/*=========================================================================*/
/* Function: Read ASCII Data                                               */
/* Purpose:  This function reads data in ASCII format from the instrument. */
/*           the read is terminated upon reaching MaxCount or upon receipt */
/*           of the termination character. The return value is equal to the*/
/*           global error variable. The only valid VI_ATTR_ASRL_END_IN     */
/*           attribute for this function is VI_ASRL_END_TERMCHAR. The      */
/*           Termination  character is set in the rsnrtz_init function.    */
/*=========================================================================*/
ViStatus rsnrtz_readASCII (ViSession instrumentHandle, ViPByte rdBuffer, ViUInt32 cnt,
            ViPUInt32 retCnt)
{
    ViStatus  rsnrtz_status = VI_SUCCESS;
    ViUInt16 rdEnd = VI_ASRL_END_TERMCHAR;

    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_ASRL_END_IN, &rdEnd));
    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_ASRL_END_IN,VI_ASRL_END_TERMCHAR));

    if ((rsnrtz_status = viRead (instrumentHandle, rdBuffer, cnt, retCnt)) < 0) 
    {
        CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_ASRL_END_IN, rdEnd));
        return rsnrtz_status;
    }
    
    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_ASRL_END_IN, rdEnd));

    return rsnrtz_status;
}

/*=========================================================================*/
/* Function: Write ASCII Data                                              */
/* Purpose:  This function Writes data in ASCII format to the instrument.  */
/*           the write is terminated upon reaching MaxCount. The return    */
/*           value is equal to the global error variable. The only valid   */
/*           VI_ATTR_ASRL_END_OUT attribute for this function is           */
/*           VI_ASRL_END_NONE.                                             */
/*=========================================================================*/
ViStatus rsnrtz_writeASCII (ViSession instrumentHandle, ViPByte wrtBuffer, ViUInt32 cnt,
            ViPUInt32 retCnt)
{
    ViStatus  rsnrtz_status = VI_SUCCESS;
    ViUInt16 wrtEnd = VI_ASRL_END_NONE;

    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_ASRL_END_OUT, &wrtEnd));
    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_ASRL_END_OUT, VI_ASRL_END_NONE));

    if ((rsnrtz_status = viWrite (instrumentHandle, (ViPByte)wrtBuffer, cnt, retCnt)) != VI_SUCCESS)
    {
        CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_ASRL_END_OUT, wrtEnd));
        return rsnrtz_status;
    }

    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_ASRL_END_OUT, wrtEnd));
             
    return rsnrtz_status;
}

/*****************************************************************************/
/*----------- INSTRUMENT-DEPENDENT UTILITY ROUTINES -------------------------*/
/*****************************************************************************/

/*===========================================================================*/
/* Function: Default Instrument Setup                                        */
/* Purpose:  This function sends a default setup to the instrument.  This    */
/*           function is called by the rsnrtz_reset operation and by the     */
/*           rsnrtz_init function if the reset option has not been           */
/*           selected.  This function is useful for configuring any          */
/*           instrument settings that are required by the rest of the        */
/*           instrument driver functions such as turning headers ON or OFF   */
/*           or using the long or short form for commands, queries, and data.*/                                    
/*===========================================================================*/
ViStatus rsnrtz_defaultInstrSetup (ViSession instrumentHandle)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViUInt32 retCnt = 0;
    rsnrtz_instrRange instrPtr;
    ViChar* index;
    
    /* Determine if the structure has been initialized for the current VISA  */
    /* Session and malloc if it has not.                                     */
    CHECKERR(viGetAttribute (instrumentHandle, VI_ATTR_USER_DATA, &instrPtr));
    
    if (instrPtr == NULL) 
        instrPtr = malloc (sizeof (struct rsnrtz_statusDataRanges));

    sprintf (instrPtr -> instrDriverRevision, "%s", RSNRTZ_REVISION);
    
    /* DISP:STAT ON */
    instrPtr -> measStatCheck = 1;
    
    /* DISP:FORW ON, DISP:REFL ON */
    instrPtr -> measReadRes = 0;
    
    /* The DMA ON command allows all response lines to be filled up to a uniform*/
    /* length of 50 characters incl. "\r\n". Device responses shorter than      */ 
    /* 50 chars  are filled with "_" (ASCII 95dec, 5Fhex). The filling-in       */
    /* is switched off by the following command:                                */
    
    CHECKERR(viWrite (instrumentHandle, (ViPByte)"DMA OFF\r\n", 9, &retCnt));
    CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));
    
    /* Check sensor type */
    CHECKERR(viWrite (instrumentHandle, (ViBuf)"ID\r\n", 4, &retCnt));
    CHECKERR(viRead (instrumentHandle, (ViPByte)buffer, BUFFER_SIZE, &retCnt));

    index = strstr (buffer, "NRT-Z44");
    
    if (index == VI_NULL)
    {
        if (strstr (buffer, "NRT-Z14") == VI_NULL)
            instrPtr -> sensorType = 0;
        else
            instrPtr -> sensorType = 2;
    }
    else
            instrPtr -> sensorType = 1;
    
    CHECKERR(viSetAttribute (instrumentHandle, VI_ATTR_USER_DATA, (ViUInt32)instrPtr));

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Write and Read Instrument Response                              */
/* Purpose:  This function writes a command to the sensor and reads its      */
/*           response.  If the sensor returns "busy" this function keeps     */
/*           writing until the sensor accepts the command.                   */
/*===========================================================================*/
ViStatus rsnrtz_writeReadInstrResp (ViSession instrumentHandle, ViPByte wrtBuffer, 
    ViPByte rdBuffer, ViInt32 bytesToWrite)
{
    ViUInt32 retCnt = 0;
    ViReal64 startTime = 0.0;
    ViReal64 currTime = 0.0;
    ViStatus rsnrtz_status = VI_SUCCESS;

    startTime = clock()/CLOCKS_PER_SEC;
    
    do {
        CHECKERR(viWrite (instrumentHandle, wrtBuffer, bytesToWrite, &retCnt));
        CHECKERR(viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt));
    
        currTime = clock()/CLOCKS_PER_SEC;
        
        if ((currTime - startTime) >= 10.0) {
            rsnrtz_status = RSNRTZ_ERROR_INSTR_SENSOR_BUSY;
            return rsnrtz_status;
        }           
        rsnrtz_delay (0.010);
    } while (strstr ((ViChar*)rdBuffer, "busy") != VI_NULL);

    if (strstr ((ViChar*)rdBuffer, "Error RANGE") != VI_NULL)
        rsnrtz_status = RSNRTZ_ERROR_INSTR_ERROR_RANGE;

    return rsnrtz_status;
}


/*===========================================================================*/
/* Function: Parse Instrument Response                                       */
/* Purpose:  This function compares first "bytesToCompare" bytes from the    */
/*           "rdBuffer" (instrument's response) with elements of "paramArr"  */
/*           from index 0 to "arrSize" and returns index of the correspondent*/
/*           element to "paramPos". "paramPos" = -1 if none matches.         */
/*===========================================================================*/
ViStatus rsnrtz_parseInstrResp (ViPByte rdBuffer, ViPString paramArr[], 
    ViInt32 arrSize, ViInt32 bytesToCompare, ViPInt16 paramPos)
{
    ViStatus rsnrtz_status = VI_SUCCESS;
    ViInt32 i = 0;
    
    do 
    {
        if (!strncmp((ViChar*)rdBuffer,paramArr[i],bytesToCompare))
        {
            *paramPos = i;
            i = -1;
        }
        else
        {
            if (i >= (arrSize - 1))
            {
                *paramPos = -1;
                return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
            }
            i++;
        }
    
    } while (i > 0);

    return rsnrtz_status;
}

/*===========================================================================*/
/* Function: Delay                                                           */
/* Purpose : With a call to rsnrt_delay, the current program is suspended    */
/*           from execution for the number of seconds specified by the       */
/*           argument seconds. rsnrt_delay is accurate to a millisecond.     */
/*           This function is platform independent.                          */
/*===========================================================================*/
void rsnrtz_delay (ViReal64 numberOfSeconds)
{
  clock_t StartTime = clock();

  while (((double)(clock() - StartTime)/CLOCKS_PER_SEC) < (numberOfSeconds));

  return;
}
/*****************************************************************************/
/*=== END INSTRUMENT DRIVER SOURCE CODE =====================================*/
/*****************************************************************************/
